# READ THIS FIRST — Exact existing Wix project handoff (Oct 25, 2026)

**This is a real, current-source engineering handoff for the SAME Wix site, not a proposal or a new deployment.**

**Existing public site:** https://headless-spqwsttbeuf-classroomsolar-140e.wix-site-host.com/
**Site ID:** `ec984f80-a998-4e29-a38c-ca6b85dac4f4`
**Observed site inventory:** 217 Wix assets, 34 rollback manifests, 218 objects inside the provider-export ZIP (extra Wix config).
**Observed files revision:** `dcc810083b1dc82d2cb5554812e4750a070da2c4`

## Restore priorities

1. `02_LATEST_WIX_COMPLETE_217_ASSETS.zip` is **the authoritative recovered source snapshot at transfer time**. It contains all 218 ZIP entries. It is a reconstructed ZIP, individually compared file-by-file against the latest authenticated Wix ZIP inventory. 218/218 length and FNV-1a byte checks passed. Archive SHA-256 of this *repackaging*: `6547d6f9de2021bd1f891f9397161ee4061259fdb506d02ef0f5604b01543322`. Provider original archive had a different ZIP-envelope hash: `ededc98fca2a3cc72e572ed595f98f3c91e39c18931753bbe7d23ce7277743bb`, bytes 12,866,088. Do not assert these two ZIP envelopes are byte-for-byte equal.
2. `INITIAL_2026-10-24_FULL_PROJECT_TRANSFER.zip` (in the FULL handoff only) has the original owner-provided 85 MB background, private thermal app source, 93-sheet workbook and initial long master project prompt. That archive is **not** the current live source. If using the compact handoff, attach this original 85 MB file separately.
3. `01_NEW_CHAT_PROMPT.md` contains complete copy-and-paste new-chat instructions. The `03_ENGINEERING_CATALOG_AUDIT` data is grounded in all 26,000 records and upstream official SAM Git blob; **OEM qualification remains independent and incomplete**.
4. `04_PREVIOUS_RELEASES_AND_REPORTS` has previous smaller release source/test ZIPs and QA notes; source patches in those archives are old relative to `02_LATEST...zip` and must NOT overwrite the newer live release.
5. `05_EXTERNAL_PVLIB_REFERENCE` contains pinned external pvlib Python text for research, not vendor-certified parameters.

## Read-only verification carried out in this handoff

- Official `NatLabRockies/SAM/deploy/libraries/CEC Modules.csv` has Git blob SHA `5f931df381c77633463c68eb7647a5e9bae30588`; reconstructed source was verified by `git hash-object`.
- All 26,000 module source rows reconciled against 21,677 upstream records by normalized maker+model and five STC quantities. Exact within 0.01: 8,202; difference <=2%: 236; >2% discrepancy: 58; ambiguous: 12; no exact source match: 17,492. Source overlay is not full OEM approval.
- Latest reconstructed ZIP passed `ZipFile.testzip` and all **218** live file length + FNV-byte checks against a separately fetched authenticated Wix manifest.
- Node 22 checked **124/124** JavaScript `.js`/`.mjs` syntax, all passed. This is syntax only, not live site browser acceptance.
- This work did not change the Wix website or canonical 26,000-record equipment database.

## Privacy and release constraints

The complete original Cable Thermal Studio v3.6.2 source is private, housed in the initial October 24 archive. Do not publish the old archive, customer documents, private source or Excel worksheets to a public website. Do not treat user-controlled assumptions or reference-library matches as approved engineering ratings.

## Contents of this package

- `01_NEW_CHAT_PROMPT.md`
- `02_LATEST_WIX_COMPLETE_217_ASSETS.zip`
- `LATEST_VERIFIED_DEPLOYMENT.json`
- `03_ENGINEERING_CATALOG_AUDIT/` (full per-row and discrepancy CSV + pinned SAM library)
- `04_PREVIOUS_RELEASES_AND_REPORTS/` (smaller prior snapshots and QA evidence)
- `05_EXTERNAL_PVLIB_REFERENCE/` (upstream pvlib reference source text)
- `06_TRANSFER_VERIFICATION/` (all 218 source asset hashes, syntax checker results, comparison/recovery scripts)
- `INITIAL_2026-10-24_FULL_PROJECT_TRANSFER.zip` (FULL package only)
