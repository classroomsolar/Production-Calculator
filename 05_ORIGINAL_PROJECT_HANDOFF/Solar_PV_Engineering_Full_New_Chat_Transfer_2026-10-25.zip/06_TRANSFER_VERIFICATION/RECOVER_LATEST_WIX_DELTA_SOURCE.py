from pathlib import Path
import base64,gzip,io,hashlib,zipfile,json,os
root=Path('/mnt/data')
p1=(root/'PRIVATE exact Wix latest 217-asset update delta 2026-10-25 part 1 of 2.txt').read_text('utf-8-sig').strip()
p2=(root/'PRIVATE exact Wix latest 217-asset update delta 2026-10-25 part 2 of 2.txt').read_text('utf-8-sig').strip()
print('segment lengths',len(p1),len(p2))
assert len(p1)==300000 and len(p2)==221644
zipgz=base64.b64decode(p1+p2,validate=True)
assert len(zipgz)==391233
assert hashlib.sha256(zipgz).hexdigest()=='a137133dd8c2f877cc78a0b29d4c060def4eeb9f0f56fe44c8c761aabbed12f0'
stream=io.BytesIO(gzip.decompress(zipgz))

def line():
   b=stream.readline()
   assert b.endswith(b'\n'),b[:60]
   return b[:-1].decode('utf-8')
assert line()=='PVDELTA1'
num=int(line())
assert num==17
changes={}
for i in range(num):
    name=line(); n=int(line());data=stream.read(n);assert len(data)==n
    assert stream.read(1)==b'\n'
    changes[name]=data
assert stream.read()==b''
print('delta bytes',sum(map(len,changes.values())))
old=root/'Solar_PV_Wix_Independent_Private_Recovery_2026-10-25.zip'
new=root/'Solar_PV_Engineering_Current_217_Assets_Full_Source_2026-10-25.zip'
with zipfile.ZipFile(old) as zin,zipfile.ZipFile(new,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as zout:
    for item in zin.infolist():
        data=changes.pop(item.filename,zin.read(item.filename))
        zout.writestr(item.filename,data)
    for path,data in changes.items():
        zout.writestr(path,data)
manifest_path=root/'TEMP Current Wix 217 assets byte hashes — new chat transfer 2026-10-25.txt'
manifest=json.loads(manifest_path.read_text('utf-8-sig'))
expected={x['path']:(x['size'],x['fnv']) for x in manifest['manifest']}
with zipfile.ZipFile(new) as z:
    assert z.testzip() is None
    assert len(z.namelist())==218
    assert set(z.namelist())==set(expected)
    for name in z.namelist():
        s=z.read(name)
        h=2166136261
        for x in s:h=((h^x)*16777619)&0xffffffff
        assert expected[name]==(len(s),h),(name,expected[name],len(s),h)
print('VERIFIED:',len(expected),'of',len(expected),'exact live file sizes and FNV byte hashes')
print('new zip bytes',new.stat().st_size,'new zip sha256',hashlib.sha256(new.read_bytes()).hexdigest())
print('wix provider archive original sha256: ededc98fca2a3cc72e572ed595f98f3c91e39c18931753bbe7d23ce7277743bb; reconstructed ZIP container has same 218 file bytes but is not byte-for-byte same ZIP envelope')
