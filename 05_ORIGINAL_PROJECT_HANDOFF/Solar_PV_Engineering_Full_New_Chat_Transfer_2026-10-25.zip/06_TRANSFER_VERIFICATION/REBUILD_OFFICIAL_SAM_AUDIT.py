from pathlib import Path
import csv,io,re,json,zipfile,hashlib,collections
from datetime import datetime,timezone
ROOT=Path('/mnt/data')
WORK=ROOT/'Solar_PV_2026-10-25_New_Chat_Handoff'
WORK.mkdir(exist_ok=True)

# Recover exact SAM library from segmented copies. Google Docs normalizes paragraph boundaries:
# part 1 has lost its final space, last part loses the terminal newline. Check exact expected length.
raw=[]
for i in range(1,10):
    s=(ROOT/f'TEMP official SAM CEC Modules exact blob part {i}.txt').read_text('utf-8')
    assert s.startswith('\ufeff')
    s=s.removeprefix('\ufeff')
    if i==1: s+=' '
    if i==9: s+='\n'
    raw.append(s)
sam=''.join(raw)
assert len(sam)==6274198,len(sam)
assert sam.startswith('Name,Manufacturer,Technology') and sam.endswith(',\n')
SAM_PATH=WORK/'REFERENCE_SAM_CEC_Modules_pinned_blob.csv'
SAM_PATH.write_text(sam,encoding='utf-8',newline='')

ZIP=ROOT/'Solar_PV_Wix_Independent_Private_Recovery_2026-10-25.zip'
zip_bytes=ZIP.read_bytes()
sha=hashlib.sha256(zip_bytes).hexdigest()
assert len(zip_bytes)==10169110 and sha=='d815185d764fe71597ede57801083a44ca77e79cb97c47a95c5568b77d6956d9'
with zipfile.ZipFile(ZIP) as z:
    assert z.testzip() is None
    db=json.loads(z.read('master_pv_modules.json'))
    print('db:',db.keys(), 'models',len(db['models']))
    assert len(db['models'])==26000

# Build row-level provenance matrix. Only exact maker+model identity; avoid false claims of OEM approval.
def norm(s): return re.sub('[^A-Z0-9]','',str(s or '').upper())
reader=csv.DictReader(io.StringIO(sam))
refs=[]
for i,row in enumerate(reader):
    if i<2:continue # SAM Units, internal name headers
    name=(row.get('Name') or '').strip()
    maker=(row.get('Manufacturer') or '').strip()
    if not maker or not name:continue
    model=name[len(maker):].strip() if name.startswith(maker+' ') else name
    record={'refName':name,'refMaker':maker,'refModel':model}
    mapping={'w':'STC','voc':'V_oc_ref','isc':'I_sc_ref','vmp':'V_mp_ref','imp':'I_mp_ref'}
    for k,v in mapping.items():
      try: record[k]=float(row[v])
      except (ValueError,TypeError): record[k]=None
    for k in ['a_ref','I_L_ref','I_o_ref','R_s','R_sh_ref','alpha_sc','beta_oc','T_NOCT']:
      try:record[k]=float(row[k])
      except (ValueError,TypeError):record[k]=None
    refs.append(record)
print('sam refs',len(refs))
index=collections.defaultdict(list)
for r in refs:index[norm(r['refMaker'])+'|'+norm(r['refModel'])].append(r)
sam_distinct_keys=len(index)

rows=[];stat=collections.Counter();diffs=[];uncertain=[]
for n,m in enumerate(db['models'],1):
    ref_list=index[norm(m.get('maker'))+'|'+norm(m.get('model'))]
    rr={'row':n,'id':m.get('id'),'maker':m.get('maker'),'model':m.get('model'),
        'original_source':m.get('source'),'status':'','sam_reference':'','fields_checked':'',
        'max_relative_difference_pct':'','difference_fields':'','notes':''}
    if len(ref_list)==0:
        rr['status']='NO_EXACT_REFERENCE_IDENTITY';stat[rr['status']]+=1
    elif len(ref_list)>1:
        rr['status']='AMBIGUOUS_REFERENCE_IDENTITY';rr['sam_reference']=' | '.join(x['refName'] for x in ref_list[:3]);stat[rr['status']]+=1;uncertain.append(rr)
    else:
        a=ref_list[0];rr['sam_reference']=a['refName'];checks=[];fields=[];large=[]
        for k in ['w','voc','isc','vmp','imp']:
            v=m.get(k)
            try:v=float(v)
            except (TypeError,ValueError):continue
            actual=a[k]
            if not (v>0 and actual is not None and actual>0):continue
            checks.append(k)
            if abs(v-actual)>0.01+1e-10:
                fields.append(k)
                if abs(v-actual)>max(0.01,0.02*actual):large.append(k)
        rr['fields_checked']=';'.join(checks);rr['difference_fields']=';'.join(fields)
        if not checks:
            rr['status']='MATCH_IDENTITY_NO_COMPARABLE_NUMERIC_FIELDS'
        elif large:
            rr['status']='LARGE_STC_DISCREPANCY_GT_2_PERCENT';rr['notes']='Significant STC discrepancy: '+';'.join(large)
        elif fields:
            rr['status']='STC_DIFFERENCE_LE_2_PERCENT';rr['notes']='Tolerance review; not strict five-field equality'
        elif len(checks)==5:
            rr['status']='EXACT_FIVE_FIELD_STC_MATCH_0.01'
        else:
            rr['status']='MATCH_PARTIAL_AVAILABLE_STC'
        stat[rr['status']]+=1
        if rr['status'] in ['LARGE_STC_DISCREPANCY_GT_2_PERCENT','STC_DIFFERENCE_LE_2_PERCENT']:
            rr['source_numeric']={k:a[k] for k in ['w','voc','isc','vmp','imp']}
            rr['catalog_numeric']={k:m.get(k) for k in ['w','voc','isc','vmp','imp']}
            diffs.append(rr)
    rows.append(rr)

summary={'reference':'Pinned NatLabRockies/SAM deploy/libraries/CEC Modules.csv Git blob 5f931df381c77633463c68eb7647a5e9bae30588','reference_sha256_of_reassembled_utf8':hashlib.sha256(sam.encode('utf-8')).hexdigest(),'reference_rows':len(refs),'reference_identity_keys':sam_distinct_keys,'catalog_origin':db.get('origin'),'catalog_records':len(db['models']),'source_wix_snapshot_sha256':sha,'categories':dict(stat),'csv_schema':'Strict normalized maker+model identity. Compare Pmax, Voc, Isc, Vmp, Imp within absolute 0.01 for exact five-field classification; large flag if difference > max(0.01, 2% reference); no equipment is approved or certified.', 'catalog_unchanged':True,'no_OEM_approval_from_reference_matches':True}
assert sum(stat.values())==26000, stat
print('audit summary',summary)
( WORK/'CATALOG_AUDIT_README.md').write_text('# Full 26,000-Record PV Catalogue Read-Only Audit\n\nReference SAM official pinned Git blob `5f931df381c77633463c68eb7647a5e9bae30588` at `NatLabRockies/SAM/deploy/libraries/CEC Modules.csv`. This is a historical SAM/CEC library and not an OEM source-approval list.\n\nWix snapshot hash: `'+sha+'`. Source data never modified.\n\nResults:\n'+''.join(f'- **{k}**: {v:,}\n' for k,v in sorted(stat.items()))+'\n**Limitations:** strict maker+model string matching excludes naming variants. Distinct revisions may have different STC. Mathematical STC agreement does not authenticate manufacturer coefficients, system voltage/current limits, UL/IEC certifications, or site-specific designs. No row approved automatically.\n', encoding='utf-8')
(WORK/'CATALOG_AUDIT_SUMMARY.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False),encoding='utf-8')
keys=['row','id','maker','model','original_source','status','sam_reference','fields_checked','difference_fields','notes']
for name,subset in [('CATALOG_AUDIT_ALL_26000_ROWS.csv',rows),('CATALOG_AUDIT_DISCREPANCIES.csv',diffs),('CATALOG_AUDIT_AMBIGUOUS.csv',uncertain)]:
    with (WORK/name).open('w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=keys,extrasaction='ignore');w.writeheader();w.writerows(subset)
print('created',list(x.name for x in WORK.iterdir()))
