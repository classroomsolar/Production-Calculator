# CONTINUE EXISTING SOLAR PV ENGINEERING PLATFORM — DO NOT RESTART

I am transferring my existing, ongoing **Solar Resource, PV Production & Electrical Engineering Platform** project to this chat. **Your task is to CONTINUE the existing software and engineering validation work, not design a new site, create another app or restart the project.** I expect you to do the work, run appropriate tests, fix defects, preserve all my work and supply actual working deliverables. Do not substitute a plan for engineering and implementation, and do not repeatedly ask me questions already answered in the attached source and project charter. Use conservative, explicitly labelled engineering assumptions when data is unavailable, but NEVER invent OEM approval, electrical ratings, code compliance, certification or 100% numerical accuracy.

## Files to open FIRST

I have attached the ZIP called `Solar_PV_Engineering_Full_New_Chat_Transfer_2026-10-25.zip` (or `Solar_PV_Engineering_Latest_Only_Transfer_2026-10-25.zip`, together with the October 24 original transfer ZIP if sending the compact version).

1. Read `00_READ_ME_FIRST.md` and `01_NEW_CHAT_PROMPT.md` in the handoff.
2. Read `INITIAL_2026-10-24_FULL_PROJECT_TRANSFER.zip` > `00_START_HERE/MASTER_PROMPT_NEW_CHAT.md`, `HANDOFF_STATUS_AND_NEXT_ACTIONS.md`, `README_FIRST.md`, and `SOURCE_AND_LICENSE_WARNINGS.md`. That 85 MB initial handoff is **historical context**, NOT the latest website version.
3. Read `LATEST_VERIFIED_DEPLOYMENT.json`, `02_LATEST_WIX_COMPLETE_217_ASSETS.zip`, and `LATEST_SOURCE_JAVASCRIPT_PARSE_CHECK.csv` before modifying anything.
4. Read `03_ENGINEERING_CATALOG_AUDIT/` row-by-row status CSV, discrepancy CSV, the exact pinned SAM CEC reference file and limitations.
5. Review `04_PREVIOUS_RELEASES_AND_REPORTS/` and `05_EXTERNAL_PVLIB_REFERENCE/` before trying to reproduce or replace work already done.

## THE LIVE SITE TO CONTINUE — MUST PRESERVE

- **Existing website:** https://headless-spqwsttbeuf-classroomsolar-140e.wix-site-host.com/
- **Wix site ID:** `ec984f80-a998-4e29-a38c-ca6b85dac4f4`
- Latest authenticated observation: **217 deployed assets, 34 rollback manifests**, 218 items in Wix's full deployment ZIP including generated Wix configuration; revision `dcc810083b1dc82d2cb5554812e4750a070da2c4` at that observation.
- Wix's current ZIP at handoff: 12,866,088 bytes; SHA-256 `ededc98fca2a3cc72e572ed595f98f3c91e39c18931753bbe7d23ce7277743bb`. A separately reconstructed local ZIP contains the **same 218 individual source assets**, byte-size and byte-FNV fingerprints all verified against the newer live manifest; its ZIP *container* SHA-256 differs because it was repackaged. Reconstructed ZIP SHA-256: `6547d6f9de2021bd1f891f9397161ee4061259fdb506d02ef0f5604b01543322`. **Do not conflate the two archive SHA values.**
- The canonical `master_pv_modules.json` contains 26,000 PV module records; never overwrite them blindly. The 93-sheet `Engineering_Master_Database_Audited.xlsx` is in the original transfer archive. The Cable Thermal Studio original is privately held in that older archive; do not publish/rehost the complete private source or confuse it with a simplified rebuild.
- **ALWAYS inspect the Wix site live first:** it may have advanced after this snapshot. Compare current file paths and checksums before patches. Use Wix `wix.headless.files.patch` (preserves other assets) with guards and rollback. DO NOT use a destructive incomplete file-set replacement or start a new Wix website. Recheck published active files and UI after each change.

## Work already implemented, do NOT redo blindly

- Synthetic solar-resource, irradiance and PV engineering models; a research v1.7 De Soto single-diode/PVWatts annual engine and equipment feasibility screens, AC cable/transformer/POI export calculations, strict hourly DC voltage and current checks and annual UTC calendar checks.
- Updated De Soto reference physics and >100% PVWatts efficiency rejection; a recent Sandia/CEC inverter physical AC/DC guard; historical CEC/SAM reference inverter catalogue; basic optical tracker/backtracking, bifacial and substring shading models, full 26,000-module catalogue UI and partial qualification overlays.
- DC conductor ampacity and voltage drop screening with metres, decimal feet or feet+inches; integrated Cable Thermal Studio v3.6.2 research UI/engine; BESS deterministic AC-bus energy dispatch and monthly accounting; simplified pre-tax NPV/LCOE/IRR; Gaussian P50/P90 uncertainty with correlation controls and explicit screening restrictions; unified UI modules.
- Previous test evidence: De Soto numeric independent SciPy comparisons, PVWatts reference-vector tests, local JavaScript regressions, 537 thermal internal checks plus 19 integration checks, 10 full-year BESS Python-oracle scenarios, and research external pvlib inverter/shadow/bifacial comparisons. Check the detailed evidence and do **not** upgrade a described test to a stronger test type. The latest complete 217-asset archive had **124/124 JavaScript syntactic parse checks** pass. Source syntax is NOT end-to-end acceptance.
- An older (205-asset) snapshot was privately saved to Google Drive in three Base64/gzip segments and successfully recovered locally. The **217-asset refreshed handoff ZIP supersedes it as latest source**. Neither Git version control nor full deployment runtime calibration can be inferred merely from having an archive.

## Full manufacturer catalogue independent audit performed in this handoff

The source file `REFERENCE_SAM_CEC_Modules_pinned_blob.csv` was reconstructed and verified with `git hash-object = 5f931df381c77633463c68eb7647a5e9bae30588`, matching pinned `NatLabRockies/SAM` `deploy/libraries/CEC Modules.csv` (21,677 records, 21,533 normalized reference identities). All 26,000 live Wix catalogue records were compared by normalized manufacturer+model, plus five electrical STC quantities (Pmax, Voc, Isc, Vmp, Imp). This strict reference crosscheck yielded **8,202 exact five-field STC matches within 0.01**, **236 small STC mismatches within 2% threshold**, **58 large discrepancy flags**, **12 ambiguous reference identity matches**, **17,492 no strict identity match**. The read-only, per-row audit CSV has all results. This is historical SAM/CEC **reference matching, NOT current OEM qualification, approval, or CEC certification**. Do not automatically change records or present matches as cleared for construction. Investigate the flagged rows against original manufacturer data and current certified equipment records before approving for use.

## Remaining implementation and engineering acceptance work — ACTUALLY DO IT

1. **Real reference execution:** Execute the latest compatible `pvlib-python` and NLR/NREL SSC/PySAM modules with pinned versions, matched weather/equipment parameters, reproducible test vectors, and error budgets. Do not confuse independent reimplementation with running the actual package. Compare annual POI energy, each loss stage and hourly ranges; fix source issues with tests.
2. **Tracker/shade/bifacial:** Independently benchmark front/rear POA and row-shading against executable pvlib/validated ray traces; characterize terrain, albedo, GCR, tracker backtracking, diffuse/beam IAM, partial bypass substrings and mismatch, and error envelopes. Treat screens as preliminary until calibration evidence exists.
3. **Manufacturer equipment verification:** Work through the full 26,000-module index with unique IDs, normalized aliases, duplicates, source references, STC parameters, certified ratings and revisioned OEM datasheets. Preserve an explicit verified vs missing vs flagged provenance overlay and never invent calibration coefficients.
4. **Thermal, DC, MV, NEC:** Independently verify cable thermal physics (IEC 60287/60853 or supported equivalent), wire layouts, installation environments, ampacity/derating, protection, short-circuit duty, grounding, voltage drop, nameplate upstream current beyond POI cap and governing edition/AHJ. Do not declare a project construction-ready without actual project design conditions and qualified approvals.
5. **BESS, grid, PPC:** Extend deterministic screens with vendor-limited BMS/PCS, efficiency maps, SOC/availability/dispatch, charge/export controls and faults and AC power balance; do not treat an export cap as upstream ampacity protection. Implement project POI imports/exports correctly.
6. **Pxx/finance and product UI:** Long-term resource and covariance uncertainty, bias adjustment, empirical/model validation, energy forecasts, detailed cash flows, usable reports/exports, responsive UI and accessibility. P50/P90 and financial screens must clearly state uncertainty limits.
7. **Live quality/recovery:** Real browser E2E on the existing public site, not just offline DOM; inspect network/CORS and all controls; include independent restore rehearsal and safe source-control/private backup. TinyFish and Firecrawl wallet credits were exhausted in previous sessions, so attempt other available real-browser testing paths where authorized; never fake browser results.

## Working rules and deliverables

- **Take action in this conversation**, not merely a new future-work outline. Choose a technically sound path when a tool is unavailable. Use existing connected plugins only when they help; don't redirect to an entirely new website.
- Safely snapshot current Wix source first, compute and compare hashes, write small guarded changes, run focused and regression QA, publish to the same site and re-read published files.
- Give direct evidence: exact file changes, deployment URL, reference model revisions, error tolerances, test outputs, independent source citations and labelled assumptions. No fabricated validation, no false 100% promises.
- Preserve the official record of defects/unknowns; distinguish mathematical parity from measured performance, OEM qualification, NEC compliance, code sign-off or bankable yields.
- Package updated source, audit reports, test files, installation/run instructions and rollback into a newly dated ZIP. Don't tell me an engineering task is done when crucial project inputs are missing; implement all defensible portions first and explicitly mark the precise blocked acceptance evidence.

Begin by inspecting the current Wix source and the handoff files. Continue directly with the highest-impact remaining engineering work, tests and code changes without asking me to repeat previous instructions.
