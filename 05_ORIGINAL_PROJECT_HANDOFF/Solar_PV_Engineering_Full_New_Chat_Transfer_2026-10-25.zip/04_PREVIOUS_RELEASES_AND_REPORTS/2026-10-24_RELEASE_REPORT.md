# Solar PV Engineering Platform — Continuation Engineering Release

**Site:** https://headless-spqwsttbeuf-classroomsolar-140e.wix-site-host.com/
**Wix site ID:** `ec984f80-a998-4e29-a38c-ca6b85dac4f4`
**Release designation:** continuation 2026-10-24, three independently published incremental patches.
**Status:** Published + current Wix file-source readback verified. Production models, code and public browser not fully accepted.

## New modifications actually published in this continuation turn

1. `pv-reference-kernel.js`: De Soto corrected temperature-dependent bandgap/dark-current calculation; PVWatts physical guard against fitted efficiency exceeding 100%; reference De Soto accepts physically valid zero series resistance. This adjusts calculated I–V and reference output outside 25 °C; it intentionally stops nonphysical inverter points instead of giving erroneous results. Verified source FNV-1a UTF-16 `2365299264` vs previous `2039913041`.
2. `electrical-ui.js`: UI options metres, decimal feet, and feet + inches for total conductor loop length; all screening kernels still receive metres, using exact conventional factors 0.3048 m/ft and 0.0254 m/in. Includes reject logic for negative values and inch values >=12. The numeric design engine `electrical-screen.js` remained unchanged. Verified source FNV `1633870699` vs previous `340003599`.
3. `pv-catalog-qualification.js` and `pv-catalog-qualification-ui.js`: added three independent source-checked REC Alpha Pure-RX (REC450AA, REC460AA, REC470AA PURE-RX-DC) six-field STC transcription records from REC June 2026 V7 manufacturer PDF. Existing eight LONGi V05 table matches preserved. Equipment remains unqualified for project-production modelling; no canonical source record was edited. Source FNV `430086322` vs `2785020899`; UI FNV `189215621` vs `912246503`.

## Numerical and integration evidence

- Independent Python `scipy.optimize.brentq` and `minimize_scalar` single-diode I-V cross-reference: 38 synthetic model points over seven cell temperatures, five irradiance intensities and three zero-resistance ideal cases. Across 38 cases, all independent `Isc`, `Voc`, `Vmp`, `Imp`, `Pmp` comparisons passed the numerical tolerances in the test suite. All source model parameters are synthetic, NOT OEM measurements or bankable PV coefficients.
- 165 independently evaluated, reference-algebra PVWatts input points passed while inside its physically feasible efficiency envelope.
- 29 targeted/core/UI/OEM test groups passed in the new combined suite, including a 8,784-hour leap-year detailed-model test and a synthetic 48-hour no-change scenario.
- 19 Batch 3 tracker test groups, 16 Batch 4 conductor/BESS test groups, and 11 Batch 5 finance test groups passed locally. **Total 75/75 local test groups** across these sets.
- The new source-workbook projected index was audited read-only: 26,000 rows; 24,705 blank sources; 69 basic invalid STC cases; 39 basic power inconsistencies above 7%; 11 six-field OEM table transcriptions; zero production-qualified device model records.
- Four UI in-process event/controller tests passed, including length-preserving metres ↔ ft/in conversion, equivalent conductor voltage drop/I²R, and rejection of 12-inch over-range input.

**Tool limits:** Direct pvlib/PySAM runtime is not installed in the container; the independent SciPy oracle implements the documented published equations rather than executing the pvlib package. The container's Chromium page navigation to both `http://127.0.0.1` and local `file://` was blocked by administrator policy (`ERR_BLOCKED_BY_ADMINISTRATOR`), and the normal public Wix site request is blocked by web access policy. Consequently these tests are source/numeric/in-process controller tests, not full public-browser acceptance or manufacturer/IEC/NEC certification.

## Independent manufacturer primary source (read and visually verified)

REC Alpha Pure-RX UL EN 6.2026 V7, `PM-DS-12-06/08.04.08.01`: https://www.recgroup.com/sites/default/files/2026-03/DS_Alpha_Pure-RX_UL%20DC.pdf, page 2 STC Electrical Data. Exact STC [Pmax W, Voc V, Vmp V, Isc A, Imp A, Efficiency %]:

- REC450AA PURE-RX-DC: 450, 65.6, 54.3, 8.81, 8.29, 21.6
- REC460AA PURE-RX-DC: 460, 65.7, 54.9, 8.88, 8.38, 22.1
- REC470AA PURE-RX-DC: 470, 65.7, 55.4, 8.95, 8.49, 22.6

This establishes 18/18 exact STC transcription matches for these three manufacturer part numbers, but not verified current listing status, SDM calibration, temperature coefficients in the canonical input schema, or site-specific eligibility. Do not treat an explicit source-link match as automatic independent engineering approval.

## Primary numerical-method sources

- pvlib `calcparams_desoto` documented/source equations for temperature-dependent Eg and I0: https://pvlib-python.readthedocs.io/en/latest/_modules/pvlib/pvsystem.html
- NREL PVWatts Version 5 Manual, inverter model equations: https://pvwatts.nrel.gov/downloads/pvwattsv5.pdf
- Sandia PV Performance Modeling Collaborative, performance ratio and model context: https://pvpmc.sandia.gov/modeling-guide/5-ac-system-output/pv-performance-metrics/performance-ratio/

## Verified current Wix deployment, after all patches

Current same site ID; `200` Wix deployed project files, `29` on-site rollback manifests. The site's generated downloadable ZIP has an additional Wix configuration entry not counted in the file listing. Current revision (`files` REST response): `dfe8e241f3f0a2120ac35f6349dcd5bc0b83b729`.

| Active file | Current UTF-16 FNV hash | Status |
|---|---:|---|
| `pv-reference-kernel.js` | `2365299264` | Modified, verified |
| `electrical-ui.js` | `1633870699` | Modified, verified |
| `pv-catalog-qualification.js` | `430086322` | Modified, verified |
| `pv-catalog-qualification-ui.js` | `189215621` | Modified, verified |
| `pv-detailed-v17.js` | `2410520032` | Preserved prior voltage safety patch |
| `index.html` | `463400936` | Unchanged |
| `main.js` | `959920766` | Unchanged |
| `master_pv_modules.json` | 6,809,617 bytes | Unmodified by all three patches |

Wix returned successful `published:true` for three separate guarded patches. Site remained at the same URL. **Zero** file deletion reported.

### On-site rollback locations

- `release-backups/pre-desoto-bandgap-pvwatts-physics-20261024/`
- `release-backups/pre-dc-units-ft-in-20261024/`
- `release-backups/pre-rec-pure-rx-v7-stc-20261024/`

Each directory contains exact previous source(s) and a manifest. These public hosting assets do **not** count as private off-site source control. This ZIP has the original and updated four source files, a separate secondary copy for the particular release; it is **not** a byte-complete export of all 200 live assets.

## Remaining critical blockers and next engineering tasks

1. Verify all production-critical module/inverter data against OEM revisions, manufacturer's installation manuals and published independent reference fits, beyond 11 STC table matches. Missing source references in 24,705 records remain. Retain a non-destructive verification overlay and original canonical database.
2. Independent deployed-model parity tests against executable pvlib and SSC/PySAM under matched inputs and versions, then independently measured performance and site-specific data. Synthetic parity is not field validation.
3. Detailed 3D shadow, substring-level electrical shade, terrain-correct bifacial/tracker loss modelling, IAM/spectral and measured albedo calibration.
4. Code-jurisdiction-specific NEC 690/691/705/706, conductors and OCPD, IEC/Neher–McGrath thermal, MV collection/protection studies, PCC export controls. Screen results must not be falsely labeled compliant.
5. Site-specific BESS PCS/BMS controls, flexible load and tariff, resource uncertainty covariance/tails, P50/P90 long-term bias, taxes/financing and customer finance models.
6. Responsive unified UI, keyboard/accessibility, complete cross-module integration, real public-browser regression, data security and private backup, traceable PDF/Excel reports and qualified professional engineering acceptance.

**This is a verified incremental continuation, NOT a claim that the total requested platform is completed or that any device is certified.**
