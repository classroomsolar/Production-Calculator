# Solar PV Engineering Platform — Live Source Correction and QA

**Release date:** 2026-10-24 (handoff naming; testing completed in this continuation session)  
**Existing Wix site ID:** `ec984f80-a998-4e29-a38c-ca6b85dac4f4`  
**Unchanged website:** https://headless-spqwsttbeuf-classroomsolar-140e.wix-site-host.com/  
**Engineering status:** SOFTWARE PATCH RELEASED; MANUFACTURER, CODE, PRODUCTION-YIELD AND LIVE BROWSER ACCEPTANCE NOT COMPLETE.

## 1. Transfer and existing live-source verification

The user-provided transfer ZIP `Solar_PV_Engineering_Complete_New_Chat_Transfer_2026-10-24.zip` was recovered from ChatGPT Library, materialized, and extracted (63 entries). The six controlling handoff files and master scope were reviewed. The live Wix Headless deployment was retrieved read-only first; it matched the current handoff source fingerprints.

**Before:** Wix file listing 191 assets; ZIP 192 entries including generated Wix configuration; 25 rollback manifests.

| Active source | Baseline FNV-1a (UTF-16 code units) | After release FNV-1a | Result |
|---|---:|---:|---|
| `index.html` | 463400936 | 463400936 | Unchanged |
| `main.js` | 959920766 | 959920766 | Unchanged |
| `bifacial-tracker.js` | 606702301 | 606702301 | Unchanged |
| `pv-detailed-v17.js` | 2218218517 | 2410520032 | Intentional safety correction |
| `master_pv_modules.json` | 6,809,617 bytes | 6,809,617 bytes | Unchanged bytes count; read-only catalog cross-check |

FNV-1a is an unkeyed noncryptographic integrity clue, not a secure attestation.

## 2. Defect and correction

### Defect

The previous detailed PV hourly engine screened the array open-circuit voltage against a user-specified design minimum cell temperature at 1,000 W/m². Some high-irradiance, low-temperature hourly cases produced a modeled string open-circuit voltage above the user-entered inverter absolute DC voltage rating even though the initial screen passed. The old engine did not reject that new out-of-envelope condition.

### Implementation

After `singleDiodeAtReference(deSotoAuxiliary(...))` is solved for each irradiated hour, the new source rejects

`model.voc * modulesPerString > inverter.maxDCV * (1 + 1e-9)`

with a timestamp and both voltages in the exception text. At zero effective irradiance there is no manufactured light-generated open-circuit potential from this model, and the check is inactive. The `1e-9` factor is a numerical roundoff allowance only, NOT an engineering voltage-rating margin or relaxation of manufacturer's listing.

This is **conservative screening of user-specified nameplate input envelopes**, NOT an IEC/UL/NEC approval or an inverter current/voltage limiting control model. Annual production estimates cannot be accepted without independent manufacturer equipment parameters and the applicable standards.

## 3. Deployment and recovery

Wix `headless.files.patch` was used with a strict baseline source fingerprint and exact textual anchors; no site creation or wholesale replacement was performed. Wix accepted and published the change.

- Wix publication upload ID: `9e71c043-3065-4878-b65d-198c35d41699`.
- Replaced: **only** `pv-detailed-v17.js`.
- Added rollback source: `release-backups/pre-hourly-string-voc-envelope-20261024/pv-detailed-v17.js`.
- Added manifest: `release-backups/pre-hourly-string-voc-envelope-20261024/MANIFEST.json`.
- Deleted: **zero** paths. Other files were not authored or replaced.
- After publication: **193** listing assets, **194** ZIP entries including generated config, **26** rollback manifests.
- Independent live-source re-read confirmed patched FNV **2410520032** / **18,161** characters and backup FNV **2218218517** / **17,527** characters; previous MPPT current and transformer guards remained present.
- This on-site publicly served rollback is **not** an independently stored, private off-site backup.

To undo only this change, replace the current `pv-detailed-v17.js` with the backup path's bytes through the same guarded selective Wix patch procedure; rerun all source/tests/readback before accepting the reverted version. Do not overwrite other assets from an older ZIP.

## 4. Tests rerun here

| Test set | Result | Scope |
|---|---|---|
| Detailed PV hourly safety and legacy calculations | **15 / 15 pass** | Actual patched local source; old-source reference; boundary/cold-Voc, transformer, MPPT, leap-year |
| Batch 3 tracker numerical tests | **19 / 19 pass** | Locally sourced archived/updated optical math source |
| Batch 4 DC conductor + BESS tests | **16 / 16 pass** | Locally sourced archived/current matching analysis modules |
| Batch 5 finance suite | **10 / 10 pass** | Locally sourced finance engine |
| Batch 6 workbench navigation logic | **1 / 1 pass** | Local shell source, NOT interactive browser |
| Independent finance scenario cross-check | **89 comparisons passed across 30 scenarios** | Separate synthetic mathematical checks, not finance underwriting |

**Aggregate explicit Node test count:** 61/61 pass. This is a set of local numeric/module regressions, **not** full website or external PV simulation parity.

A previous handoff includes historical tests, but those historical counts are not claimed as rerun in this release. The attempted new local Chromium ESM smoke test was not completed (browser process timed out); an HTTP fetch of the public URL was blocked by the tool network environment. Therefore the current live public UI has **not** been independently clicked through after this update.

No installed executable PySAM/SSC or pvlib was available for this release. No manufacturer measurements, physical laboratory calibration, or independent NEC/IEC acceptance was performed.

## 5. Actual 26,000-row live-equipment-index reconciliation

Using the original transfer archive's `Engineering_Master_Database_Audited.xlsx` / `PV_MODULES` worksheet and the deployed `master_pv_modules.json`, the entire **26,000-row** model index was compared **read-only** by matching row order, IDs and fields. A projection of the source Excel workbook was sent to the connected Wix tool as an analysis-only attachment; the deployed JSON was read, not rewritten.

- 26,000 row IDs match; no duplicate IDs detected.
- Field-level differences were restricted to **41 manufacturer labels** and **12 model labels** across **52 distinct rows**. Every observed difference is solely **leading/trailing whitespace** in the workbook label that the deployed JSON had trimmed. See `PV_catalog_label_whitespace_differences.csv` for precise Excel row numbers and both label forms.
- No differences observed for ID, STC wattage, Voc, Isc, Vmp, Imp, module efficiency, provenance/source text, or Excel row index within the comparative numerical tolerance of `1e-4 * max(1, |source value|)`.
- 24,705 of 26,000 models have a blank source field.
- 69 rows fail one or more of the existing positivity/ordering STC plausibility checks.
- 39 rows have `abs(Vmp × Imp / Pmp - 1) > 7%` (audit anomaly threshold; not a formal product qualification threshold).
- 19 repeated maker/model-name occurrences when normalized by case and surrounding whitespace.
- Present records cover 578 case/whitespace-normalized manufacturer labels.

**Important:** The catalog is an equipment index, not an OEM-certified production model library. A data-preserving reconciliation does not validate accuracy of manufacturer specifications, SDM coefficients, product listings, inverter fit, or current OEM revisions. No catalog edits were made.

The current uploaded workbook SHA-256 is `d38a19c7e28a4fe79d399d2ff498653b5febc5878d8ddafc155f888cc9855ba5`. The JSON's preexisting `sha256` metadata is `0b57378da5d0f597553140e40a0cecf578d594540c4f1c8ffd05006cd6f427ef`; those digest fields have not been proven to refer to identically serialized files and must not be treated as a failed checksum for this release.

## 6. Still-open acceptance work (Batches 2–6)

- Batch 2: manufacturer cross-checks by model/revision; authoritative CEC and inverter OEM specs, pvlib/SSC numerical and measured curve benchmarks; no manufacturing certification.
- Batch 3: shadow-object geometry, partial electrical shading/substring mismatch, slopes and tracker mechanical envelopes, bifacial view-factor/site measurement comparisons, actual module layout integration.
- Batch 4: installation-specific NEC/AHJ/OCPD/EGC, IEC/Neher-McGrath/thermal ampacity qualification, MV protection studies, dedicated BESS controls and PCS/OEM equipment limits; existing Cable Thermal original v3.6.2 research engine is not generally IEC-certified.
- Batch 5: project finance inputs, resource uncertainty covariance/tails and empirically supported P50/P75/P90 distributions, taxes/debt/PPA/tariff and full financial acceptance.
- Batch 6: full cohesive UI, live-browser and accessibility testing, secure private offsite repo, public-source confidentiality audit, comprehensive PDF/XLSX reporting, final engineering acceptance register.

Never call this entire platform 100% complete, bankable, NEC approved, or PVsyst/HelioScope/ETAP-equivalent based on these tests.
