# Solar PV Engineering Platform — Continuation Evidence

**Existing website:** https://headless-spqwsttbeuf-classroomsolar-140e.wix-site-host.com/
**Wix Site ID:** ec984f80-a998-4e29-a38c-ca6b85dac4f4
**Date:** 2026-10-25 (release date in engineering evidence; ongoing project)

## New release — CEC/Sandia inverter mathematical guard

The `cec-sandia-engine.js` source was patched in-place on the *existing* Wix site to reject candidate model outputs with fitted AC power exceeding simultaneous DC input power. Exact pre-change source preserved at:

`release-backups/pre-sandia-energy-guard-20261025/cec-sandia-engine.js`

**Published site result:** 205 project assets, 31 rollback manifests, zero deletions. Wix read-back found new FNV-1a UTF-16 source hash **3839693657** and old rollback hash **1782293093**. Other tested core source files retained the prior fingerprints.

**Evidence:** 9 pvlib/CEC parity and guard tests plus 1 historical CEC oracle harness all passed. Historical independent Python oracle includes 162 numerical comparisons and 197 source checks. Further read-only sweep: 2,343 historical CEC inverter models, 11,715 valid sampled operating points, zero instances where the proposed new guard tripped. The sweep does *not* cover all voltage/current or temperature/derating conditions.

External upstream pinned test vector source: `pvlib/pvlib-python`, `tests/test_inverter.py`, Git blob `5794669ec996a3aaf6ce798fccbfe8d16ee8e6eb`.

## Battery and thermal validation performed

Ten independent Python-generated full-year deterministic BESS reference cases were compared with the existing JavaScript dispatch engine, covering 8,760- and 8,784-hour datasets; all ten passed at declared numerical tolerances. These are energy-balance and dispatch-algorithm tests, not an OEM PCS/BMS qualification.

Existing original thermal-engine retained QA rerun: 537/537 internal checks and 19 original integration smoke assertions passed. This is *not* a demonstration that IEC 60287, IEC 60853, NEC ampacity, soil thermal transients, or site-specific design are independently certified.

## External catalogue cross-reference

Pinned public reference: `NatLabRockies/SAM`, `deploy/libraries/CEC Modules.csv`, Git blob `5f931df381c77633463c68eb7647a5e9bae30588` (21,677 parsed reference records). Entire deployed 26,000-record PV index was compared read-only in nine batches. Comparison used a dual 32-bit hash of normalized maker+model, and separate dual hash of that key with five STC quantities rounded to 0.01. Results:

- 8,496 unique exact normalized manufacturer/model matches.
- 8,179 of those matched all five screened STC electrical numbers after 0.01 rounding.
- 317 of those exhibited at least one mismatch at that strict quantization level.
- 12 source-key matches were ambiguous (more than one matching SAM reference).
- 17,492 had no exact normalized maker+model match.

These figures reconcile to 26,000 entries. Unlike full per-record equality checks, the fingerprint procedure could theoretically collide and does not distinguish manufacturer normalization ambiguities. A differing reference may reflect vintage, datasheet revisions, units or data issues; none was silently overwritten. **Zero equipment items were newly certified or approved for project production.** This is a read-only reference comparison; no production-index data was modified.

## Off-site private full-site archive

Authenticated Wix site deployment ZIP fetched and gzip-compressed without modifying the website. Verified length of original ZIP 10,169,110 bytes, SHA-256:

`d815185d764fe71597ede57801083a44ca77e79cb97c47a95c5568b77d6956d9`

Compressed gzip 1,487,664 bytes, SHA-256:

`a6b1194a8615e0d2ef523585cbafe9974020f719eefa789f613a311dd517d41b`

Compressed file Base64 encoded (1,983,552 characters) and split into three equal-length segments (661,184 characters each) stored in private Google Drive Docs, with each document read back and checked against the exact intended segment:

1. https://docs.google.com/document/d/16XpNSgEXdx4yrZW1v6RkSR1iJdvmnGhbPSS2z48iY-k/edit
2. https://docs.google.com/document/d/1m_ELq5UiAOrA3PaBtk3Zv-ViGPTfuNL1L5dGPOk0rMI/edit
3. https://docs.google.com/document/d/1eSCsjBmO_0-MGplkUF5HJmLHDQ6y1pZxzI5TMZ3a4EM/edit

**Recovery:** Read text content from each document, excluding trailing Google Docs paragraph newline. Concatenate in order 1, 2, 3 without separators; Base64 decode; verify compressed SHA-256; gzip decompress; verify recovered ZIP SHA-256; then inspect the ZIP manifest before restoring on Wix. An end-to-end recovered binary has not yet been reconstructed independently; such a rehearsal remains required before declaring a fully proven disaster recovery process. These private Google Docs segments are not Git version control.

## Open engineering validation gates

1. Complete full-site public browser E2E and network/CORS audit (TinyFish wallet and Firecrawl credits exhausted; container external DNS/network blocked; local DOM tests do not substitute).
2. Executable pvlib-python and current SSC/PySAM model suite in a reference environment, using project-matched input/weather and accepted parity thresholds.
3. Bifacial tracking/shading calibration to an independently validated ray trace / field data with rear mismatch and inverter coupling.
4. NEC code edition, AHJ, MV and cable thermal models, real nameplate and certified installation equipment ratings, tested against appropriate IEC/IEEE/NFPA methods.
5. Complete plant controls/POI import-export, BMS/PCS interoperability, islanding/protection and interconnection checks.
6. Full OEM sourcing and audit of all 26,000 manufacturer rows (reference-library match alone is not approval).
7. Long-term site weather calibration, traceable loss/uncertainty budgets, bankable Pxx assumptions and lender/independent engineer review.
8. Repository-grade private version control with automated CI and security review, and restoring the saved Wix site ZIP from independently stored bytes as a test.

**Status:** Real incremental releases and evidence exist, but the full platform is **not yet 100% validated, bankable, certified or construction-ready.** No such claim should be made without independent accepted validation and project-specific data.
