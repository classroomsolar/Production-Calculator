/** Independent NLR SAM/CEC reference overlay: read-only, no OEM equipment qualification.
 * Pinned SAM source: NatLabRockies/SAM CEC Modules.csv Git blob
 * 5f931df381c77633463c68eb7647a5e9bae30588.
 * Does NOT modify master_pv_modules.json or prove product certification.
 */
const classes={x:'SAM_STC_5_FIELD_EXACT_0p01',w:'SAM_STC_REVIEW_WITHIN_2PCT',d:'SAM_STC_DISCREPANCY_OVER_2PCT',a:'SAM_AMBIGUOUS'};
const validId=id=>typeof id==='string'&&id.length>=5&&id.length<=128&&/^[A-Za-z0-9._:-]+$/.test(id);
export async function sha256Hex(text){
 if(typeof text!=='string'||typeof crypto==='undefined'||!crypto.subtle)throw Error('SHA-256 verifier unavailable');
 const hash=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(text));
 return [...new Uint8Array(hash)].map(x=>x.toString(16).padStart(2,'0')).join('');
}
export function validateSamOverlay(catalog,overlay,actualCanonicalSHA256){
 if(!catalog||!Array.isArray(catalog.models)||catalog.models.length!==26000)throw Error('Incorrect canonical catalogue size for pinned SAM crosscheck');
 if(!overlay||overlay.version!=='sam-cec-model-identity-stc-audit-2026-10-25'||
    overlay.classification!=='READ_ONLY_REFERENCE_DATA_QA_NOT_OEM_QUALIFICATION')throw Error('Unexpected SAM crosscheck version/classification');
 if(!/^[a-f0-9]{64}$/.test(actualCanonicalSHA256||'')||actualCanonicalSHA256!==overlay.canonicalJsonSHA256)throw Error('Canonical catalog SHA-256 differs from reference crosscheck; recompute offline; no stale labels shown');
 if(overlay.sourceGitBlobSHA1!=='5f931df381c77633463c68eb7647a5e9bae30588'||overlay.scope!==26000||overlay.sourceEntries!==21677)throw Error('External source identity or scope changed');
 const canonicalIdSet=new Set(catalog.models.map(x=>x.id));
 if(canonicalIdSet.size!==26000)throw Error('Duplicate catalogue IDs; overlay cannot be joined safely');
 const lookup=new Map(),ct={};
 for(const [code,label] of Object.entries(classes)){
  const ids=overlay.statusIDs?.[code];if(!Array.isArray(ids))throw Error('SAM audit category missing: '+code);
  for(const id of ids){if(!validId(id)||!canonicalIdSet.has(id)||lookup.has(id))throw Error('Unknown or repeated SAM result record '+id);lookup.set(id,label)}
  ct[label]=ids.length;
 }
 ct.UNMATCHED=26000-lookup.size;
 if(Object.keys(overlay.summary).length!==5||Object.entries(ct).some(([k,v])=>overlay.summary[k]!==v))throw Error('SAM category totals do not reconcile');
 return {summary:Object.freeze({...ct}),sourceGitBlobSHA1:overlay.sourceGitBlobSHA1,canonicalSHA256:actualCanonicalSHA256,
  statusForId:(id)=>lookup.get(id)||'UNMATCHED',recordCount:catalog.models.length,qualifiedForProduction:0,
  scope:'Reference library crosscheck only; not OEM or code qualification.'};
}
