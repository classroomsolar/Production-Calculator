/** Batch 4 — deterministic hourly AC-bus PV+BESS self-consumption dispatch screen.
 * Inputs from v1.7 inverter AC power at AC bus, BEFORE cable and transformer.
 * This is NOT a detailed BMS/PCS, grid protection, project POI or interconnection design.
 */
import {validateAnnualUtcCalendar} from './annual-utc-calendar.js';
const finite=Number.isFinite;
const needed=(v,lo,hi,label)=>{if(!finite(v)||v<lo||v>hi)throw Error(label+' must be '+lo+' to '+hi)};
export function validateDispatchConfig(c){
 if(!c||typeof c!=='object')throw Error('Dispatch configuration required');
 for(const [k,lo,hi] of [['capacityKWh',1,1e10],['loadKW',0,1e7],['maxChargeKW',0,1e7],['maxDischargeKW',0,1e7],['chargeEfficiency',.01,1],['dischargeEfficiency',.01,1],['minSocPct',0,100],['maxSocPct',0,100],['initialSocPct',0,100],['exportCapKW',0,1e9]])needed(c[k],lo,hi,k);
 if(!(c.minSocPct<c.maxSocPct))throw Error('SOC minimum must be below maximum');
 if(c.initialSocPct<c.minSocPct||c.initialSocPct>c.maxSocPct)throw Error('Initial SOC outside permitted range');
 // Optional repeatable UTC-hour demand profile; NOT measured load or an 8760-hour load forecast.
 // Omission preserves original constant-load dispatch exactly.
 if(c.loadProfile24KW!==undefined&&c.loadProfile24KW!==null){
  if(!Array.isArray(c.loadProfile24KW)||c.loadProfile24KW.length!==24)throw Error('loadProfile24KW must contain exactly 24 UTC hourly kW values');
  for(let hour=0;hour<24;hour++)needed(c.loadProfile24KW[hour],0,1e7,`loadProfile24KW[${hour}]`);
 }
 if(c.gridImportCapKW!==undefined&&c.gridImportCapKW!==null)needed(c.gridImportCapKW,0,1e9,'gridImportCapKW');
 return c;
}
export function simulateDispatch(hourly,c){
 const cfg=validateDispatchConfig(c);
 validateAnnualUtcCalendar(hourly,{label:'BESS annual dispatch'});
 const minE=cfg.capacityKWh*cfg.minSocPct/100,maxE=cfg.capacityKWh*cfg.maxSocPct/100;
 let e=cfg.capacityKWh*cfg.initialSocPct/100,last=null;
 const summary={pvBusEnergyKWh:0,onSiteLoadKWh:0,pvDirectToLoadKWh:0,batteryChargeFromPVKWh:0,batteryDischargeToLoadKWh:0,
  gridImportKWh:0,gridExportKWh:0,peakGridImportKW:0,peakLoadKW:0,exportCurtailmentKWh:0,chargeConversionLossKWh:0,dischargeConversionLossKWh:0,initialStoredKWh:e,endStoredKWh:null,dispatchHours:hourly.length,cycleEquivalent:0};
 const monthly=Array.from({length:12},(_,i)=>({month:i+1,pvBusKWh:0,chargeInputKWh:0,dischargeOutputKWh:0,gridExportKWh:0,gridImportKWh:0,curtailedKWh:0}));
 const rows=[];
 for(const h of hourly){
  const ts=Date.parse(h.timestamp_utc);
  if(!finite(ts))throw Error('Invalid UTC timestamp');if(last!==null&&ts-last!==3600000)throw Error('Missing or repeated UTC timestamp');last=ts;
  const pv=h.ac_inverter_kw;if(!finite(pv)||pv<0)throw Error('PV input must be nonnegative AC inverter bus kW');
  // UTC repeated day-profile makes the hour mapping independent of local DST.
  const utcHour=new Date(ts).getUTCHours();
  const load=cfg.loadProfile24KW?.[utcHour]??cfg.loadKW;
  const pvToLoad=Math.min(pv,load),deficit=load-pvToLoad,surplus=pv-pvToLoad;
  const charge=Math.min(surplus,cfg.maxChargeKW,Math.max(0,(maxE-e)/cfg.chargeEfficiency));
  const chargeStored=charge*cfg.chargeEfficiency;e+=chargeStored;
  const discharge=Math.min(deficit,cfg.maxDischargeKW,Math.max(0,(e-minE)*cfg.dischargeEfficiency));
  const taken=discharge/cfg.dischargeEfficiency;e-=taken;
  if(e<minE-1e-7||e>maxE+1e-7)throw Error('SOC physical constraint violated');
  const remainingSurplus=Math.max(0,surplus-charge),gridExport=Math.min(cfg.exportCapKW,remainingSurplus),curtailed=remainingSurplus-gridExport;
  const gridImport=Math.max(0,deficit-discharge);
  // Unlike an export cap, imports cannot be 'curtailed' without unserved
  // demand. Reject an infeasible cap; never silently manufacture power.
  if(cfg.gridImportCapKW!==undefined&&cfg.gridImportCapKW!==null&&gridImport>cfg.gridImportCapKW+1e-9*Math.max(1,cfg.gridImportCapKW))
   throw Error(`Grid import exceeds specified AC-bus import cap at ${h.timestamp_utc}: ${gridImport.toFixed(3)} kW > ${cfg.gridImportCapKW} kW. Battery/PV power cannot serve this demand without unmet load`);
  const residual=pv+discharge+gridImport-load-charge-gridExport-curtailed;
  if(Math.abs(residual)>1e-8*Math.max(1,pv+load))throw Error('AC bus energy conservation failure');
  summary.pvBusEnergyKWh+=pv;summary.onSiteLoadKWh+=load;summary.pvDirectToLoadKWh+=pvToLoad;
  summary.batteryChargeFromPVKWh+=charge;summary.batteryDischargeToLoadKWh+=discharge;
  summary.gridImportKWh+=gridImport;summary.gridExportKWh+=gridExport;summary.peakGridImportKW=Math.max(summary.peakGridImportKW,gridImport);summary.peakLoadKW=Math.max(summary.peakLoadKW,load);summary.exportCurtailmentKWh+=curtailed;
  summary.chargeConversionLossKWh+=charge-chargeStored;summary.dischargeConversionLossKWh+=taken-discharge;
  const month=monthly[new Date(ts).getUTCMonth()];month.pvBusKWh+=pv;month.chargeInputKWh+=charge;month.dischargeOutputKWh+=discharge;month.gridExportKWh+=gridExport;month.gridImportKWh+=gridImport;month.curtailedKWh+=curtailed;
  rows.push({timestamp_utc:h.timestamp_utc,pv_inverter_ac_bus_kw:pv,load_kw:load,pv_direct_to_load_kw:pvToLoad,battery_charge_ac_kw:charge,battery_discharge_ac_kw:discharge,
   soc_percent:100*e/cfg.capacityKWh,stored_kwh:e,grid_export_ac_bus_kw:gridExport,grid_import_ac_bus_kw:gridImport,curtailed_ac_bus_kw:curtailed});
 }
 summary.endStoredKWh=e;summary.cycleEquivalent=summary.batteryDischargeToLoadKWh/(cfg.capacityKWh*cfg.dischargeEfficiency);
 const balance=summary.pvBusEnergyKWh+summary.batteryDischargeToLoadKWh+summary.gridImportKWh-
 (summary.onSiteLoadKWh+summary.batteryChargeFromPVKWh+summary.gridExportKWh+summary.exportCurtailmentKWh);
 if(Math.abs(balance)>1e-6*Math.max(1,summary.pvBusEnergyKWh))throw Error('Yearly AC bus energy balance failure');
 const batteryBalance=summary.initialStoredKWh+summary.batteryChargeFromPVKWh-summary.chargeConversionLossKWh-
 summary.batteryDischargeToLoadKWh-summary.dischargeConversionLossKWh-summary.endStoredKWh;
 if(Math.abs(batteryBalance)>1e-6*Math.max(1,summary.batteryChargeFromPVKWh))throw Error('Battery SOC energy balance failure');
 return {status:'EXPERIMENTAL_AC_BUS_DISPATCH',summary,monthly,hourly:rows,config:{...cfg},warnings:[
 'AC-bus model uses inverter output BEFORE existing AC cables/transformer; exported power is NOT confirmed POI export.',
 'Battery charging uses PV surplus only (no grid charging); onsite load is user-defined constant or a repeated 24-hour UTC profile, not independently measured or seasonal load.',
 'The optional import-cap screen rejects unserved-load conditions; it does NOT synthesize load shedding, import-limit controls or automatic grid protection.',
 'Separate charge/discharge efficiencies approximate PCS+cell losses; no reactive power, thermal derating, degradation, reserve dispatch or battery warranty model.',
 'No demand tariff, pricing optimization, grid breaker/OCPD, islanding, black start, protection settings, battery datasheet approval or NEC 706 certification.']};
}
