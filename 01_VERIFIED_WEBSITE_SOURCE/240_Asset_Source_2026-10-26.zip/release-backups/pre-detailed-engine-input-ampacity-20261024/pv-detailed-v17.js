/** PV Detail v1.7 — EXPERIMENTAL RESEARCH MODEL, not validated project yield.
 * Physics: De Soto/5-parameter SDE (temperature and effective irradiance),
 * inverter PVWatts load-efficiency, DC/AC copper resistance, transformer equivalent losses.
 * Sources: https://pvlib-python.readthedocs.io/en/stable/user_guide/modeling_topics/singlediode.html
 *          https://pvlib-python.readthedocs.io/en/stable/reference/generated/pvlib.inverter.pvwatts.html
 *          https://www.pvsyst.com/help/project-design/array-and-system-losses/ohmic-losses/index.html
 * The source single-diode function and PVWatts inverter are from existing tested experimental v1.6.
 * Does not include detailed diffuse/beam mismatch, spectral IAM, project-design NEC, tracker,
 * shading electrical layout, manufacturer voltage efficiency curves or equipment certification.
 */
import {singleDiodeAtReference,pvwattsInverterKW} from './pv-reference-kernel.js';
const ok=Number.isFinite, clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
const fail=m=>{throw Error(m)};
function pos(x,k,{allowZero=false,max=Infinity}={}) {
 if(!ok(x)||(allowZero?x<0:x<=0)||x>max)fail(`${k} outside allowed range`);
}
function pct(x,k){if(!ok(x)||x<0||x>100)fail(`${k} must be 0–100%`)}
function integer(x,k,lo=1,max=1e6){if(!Number.isInteger(x)||x<lo||x>max)fail(`${k}: integer out of range`)}

/** Complete De Soto effective-irradiance auxiliary equations, with reference
 * bandgap temp slope as used by pvlib.calcparams_desoto. The EgRef/dEgdT
 * pair MUST match the method used to fit any manufacturer's coefficients.
 * Never derive ILref/I0ref/aRef from nameplate Pmp alone.
 */
export function deSotoAuxiliary(ref,irradianceWm2,cellC){
 for(const k of ['ILrefA','I0refA','RshRefOhm','aRefV'])pos(ref[k],`module.${k}`);
 pos(ref.RsRefOhm,'module.RsRefOhm',{allowZero:true});
 if(![ref.alphaIscAperC,ref.EgRefEv,ref.dEgdTPerK,irradianceWm2,cellC].every(ok))fail('De Soto temperature and irradiance inputs must be finite');
 if(ref.EgRefEv<=0||ref.EgRefEv>3||ref.dEgdTPerK<-.01||ref.dEgdTPerK>.01)fail('Invalid reference bandgap or slope');
 if(irradianceWm2<0||irradianceWm2>1800||cellC< -80||cellC>120)fail('De Soto operating range exceeded');
 if(irradianceWm2===0)return null;
 const tRef=298.15,temperatureK=cellC+273.15;
 const Eg=ref.EgRefEv*(1+ref.dEgdTPerK*(temperatureK-tRef));
 if(Eg<=0)fail('Nonphysical bandgap at specified temperature');
 const kBoltzmannEV=8.617333262145e-5;
 const IL=(irradianceWm2/1000)*(ref.ILrefA+ref.alphaIscAperC*(cellC-25));
 if(IL<=0)fail('Nonphysical photocurrent extrapolation');
 return {photocurrentA:IL,
  saturationCurrentA:ref.I0refA*(temperatureK/tRef)**3*Math.exp(ref.EgRefEv/(kBoltzmannEV*tRef)-Eg/(kBoltzmannEV*temperatureK)),
  seriesOhm:ref.RsRefOhm,shuntOhm:ref.RshRefOhm*1000/irradianceWm2,
  nNsVth:ref.aRefV*(temperatureK/tRef)};
}
export function deSotoDetailedPower(ref,g,tc){
 const p=deSotoAuxiliary(ref,g,tc);
 if(!p)return {voc:0,isc:0,vmp:0,imp:0,pmp:0,fillFactor:null};
 const {ivAtVoltage,...other}=singleDiodeAtReference(p);return other;
}

/** Physical round-trip resistance for one identical DC string, or one-way conductor for 3 phase AC. */
export function cableResistance({material='copper',oneWayM,crossSectionMm2,tempC=30},roundTrip=false){
 pos(oneWayM,'conductor length',{allowZero:true,max:2e5});
 pos(crossSectionMm2,'conductor area',{max:10000});
 if(!ok(tempC)||tempC< -50||tempC>160)fail('Cable operating temperature outside -50..160 C');
 const table={copper:{rho:0.017241,alpha:0.00393},aluminum:{rho:0.028264,alpha:0.00403}};
 if(!table[material])fail('Conductor material must be copper or aluminum');
 const t=table[material];const r=t.rho*(1+t.alpha*(tempC-20))*oneWayM/crossSectionMm2*(roundTrip?2:1);
 pos(r,'computed resistance',{allowZero:true});return r;
}
export function validateDetailedConfig(c){
 if(!c||typeof c!=='object')fail('Detailed configuration required');
 const ref=c.module,arr=c.array,inv=c.inverter,loss=c.losses,dc=c.dcCable,ac=c.acCable,tr=c.transformer,thermal=c.thermal;
 if(!ref||!arr||!inv||!loss||!dc||!ac||!tr||!thermal)fail('Required model input group absent');
 for(const k of ['ILrefA','I0refA','RshRefOhm','aRefV'])pos(ref[k],`module.${k}`);
 pos(ref.RsRefOhm,'module.RsRefOhm',{allowZero:true});
 if(!ok(ref.alphaIscAperC))fail('module.alphaIscAperC must be A/°C');
 integer(arr.modulesPerString,'modulesPerString',1,200);
 integer(arr.stringsPerMppt,'stringsPerMppt',1,50);
 integer(arr.mpptsPerInverter,'mpptsPerInverter',1,50);
 integer(arr.inverterCount,'inverterCount',1,5000);
 pos(inv.pacKW,'inverter.pacKW'); pos(inv.etaNom,'inverter.etaNom');
 if(inv.etaNom>1)fail('Inverter efficiency cannot exceed 1');
 pos(inv.mpptMinV,'inverter.mpptMinV');pos(inv.mpptMaxV,'inverter.mpptMaxV');
 pos(inv.maxDCV,'inverter.maxDCV');
 if(inv.mpptMaxV<=inv.mpptMinV||inv.mpptMaxV>inv.maxDCV)fail('Inverter MPPT voltage bounds are contradictory');
 pos(inv.maxOperatingCurrentPerMpptA,'inverter.maxOperatingCurrentPerMpptA');
 pos(inv.maxShortCircuitCurrentPerMpptA,'inverter.maxShortCircuitCurrentPerMpptA');
 pos(thermal.u0,'thermal.u0');pos(thermal.u1,'thermal.u1',{allowZero:true});
 for(const k of ['soilingPct','iamPct','linearShadePct','mismatchPct','availabilityLossPct'])pct(loss[k],k);
 for(const k of ['minCellDesignC','maxCellDesignC'])if(!ok(arr[k]))fail(k+' missing');
 if(arr.minCellDesignC< -80||arr.maxCellDesignC>120||arr.minCellDesignC>=arr.maxCellDesignC)fail('Design cell temperature limits invalid');
 if(loss.exportCapKW!==null&&loss.exportCapKW!==undefined)pos(loss.exportCapKW,'export cap',{allowZero:true});
 cableResistance(dc,true);cableResistance(ac,false);
 pos(ac.voltageLL,'AC line-to-line voltage');pos(ac.powerFactor,'AC power factor');
 if(ac.powerFactor>1)fail('Power factor >1');
 pos(tr.ratedKVA,'Transformer rated kVA');pos(tr.noLoadKW,'Transformer P0',{allowZero:true});
 pos(tr.loadLossRatedKW,'Transformer rated load loss',{allowZero:true});
 if(!['always','sunlit'].includes(tr.energization))fail('transformer.energization must be always or sunlit');
 const stc=deSotoDetailedPower(ref,1000,25),low=deSotoDetailedPower(ref,1000,arr.minCellDesignC),high=deSotoDetailedPower(ref,1000,arr.maxCellDesignC);
 const units=arr.modulesPerString,strings=arr.stringsPerMppt*arr.mpptsPerInverter*arr.inverterCount;
 const seriesCold=units*low.voc,hotMppt=units*high.vmp,coldMppt=units*low.vmp;
 const ch=[{key:'model_cold_open_circuit',passed:seriesCold<=inv.maxDCV,value:seriesCold,limit:inv.maxDCV,unit:'V'},
   {key:'hot_MPPT_operating_range',passed:hotMppt>=inv.mpptMinV,value:hotMppt,limit:inv.mpptMinV,unit:'V'},
   {key:'cold_MPPT_operating_range',passed:coldMppt<=inv.mpptMaxV,value:coldMppt,limit:inv.mpptMaxV,unit:'V'},
   {key:'STC_parallel_operating_current',passed:arr.stringsPerMppt*stc.imp<=inv.maxOperatingCurrentPerMpptA,value:arr.stringsPerMppt*stc.imp,limit:inv.maxOperatingCurrentPerMpptA,unit:'A'},
   {key:'STC_parallel_short_circuit_current',passed:arr.stringsPerMppt*stc.isc<=inv.maxShortCircuitCurrentPerMpptA,value:arr.stringsPerMppt*stc.isc,limit:inv.maxShortCircuitCurrentPerMpptA,unit:'A'}];
 if(ch.some(x=>!x.passed))fail('Device-physics operating screen failed: '+ch.filter(x=>!x.passed).map(x=>x.key).join(', '));
 const moduleCount=strings*units,stcKW=moduleCount*stc.pmp/1000;
 return {stc,moduleCount,strings,stcKW,acKW:inv.pacKW*arr.inverterCount,dcAcRatio:stcKW/(inv.pacKW*arr.inverterCount),checks:ch,
 warnings:['Synthetic coefficients or user-provided parameters are NOT manufacturer-qualified unless independently verified.',
 'Calculated cold Voc is a device-physics screen, NOT a substitute for governing NEC 690.7/690.8 and manufacturer design-temperature methods.',
 'DC resistance is an approximation at array MPP; no iterative re-optimization including cable drop.',
 'AC power factor is assumed constant; detailed inverter voltage-dependent efficiency, reactive-power derating and grid voltage are not modeled.',
 'Transformer no-load loss may require night import from utility, reported separately from energy exported.',
 'No electrical partial-shading bypass diode, bifacial rear-side or tracker model is used in this study.']};
}
/** hour-ending records already normalized upstream to consistent UTC. All power values kW, 1-hour integration. */
export function simulateDetailedHourly(hours,c,{requireYear=true}={}){
 const preliminary=validateDetailedConfig(c);
 if(!Array.isArray(hours)||hours.length===0)fail('Hourly resource array required');
 if(requireYear&&![8760,8784].includes(hours.length))fail('Only 8760/8784-hour full years can be labeled annual');
 const nString=preliminary.strings,nModule=c.array.modulesPerString,pmpRef=preliminary.stc.pmp;
 const Rdc=cableResistance(c.dcCable,true),Rac=cableResistance(c.acCable,false);
 const pFixedR=c.transformer.loadLossRatedKW,cap=c.losses.exportCapKW;
 const monthly=Array.from({length:12},(_,i)=>({month:i+1,hours:0,poaKWhM2:0,theoreticalKWh:0,moduleKWh:0,mismatchLossKWh:0,dcCableLossKWh:0,dcAfterCableKWh:0,inverterConversionLossKWh:0,clippingKWh:0,acCableLossKWh:0,transformerLossKWh:0,availabilityLossKWh:0,curtailmentLossKWh:0,poiExportKWh:0,gridImportKWh:0}));
 let prev=NaN,maxMPPTLimitedHours=0,peakCellC=-Infinity;
 const hourly=[];
 for(let idx=0;idx<hours.length;idx++){
  const h=hours[idx],ts=Date.parse(h.timestamp_utc);
  if(!Number.isFinite(ts))fail(`Invalid UTC timestamp at hour ${idx+1}`);
  if(idx>0&&ts-prev!==3600000)fail(`Duplicate, missing or out-of-order UTC hour at ${idx+1}`);prev=ts;
  const poa=h.poa_wm2,ta=h.temp_air_c,wind=h.wind_speed_mps;
  if(![poa,ta,wind].every(ok)||poa<0||poa>1800||ta< -80||ta>65||wind<0||wind>70)fail(`Invalid weather values at UTC hour ${idx+1}`);
  const cell=ta+poa/(c.thermal.u0+c.thermal.u1*wind);
  if(cell < -80||cell > 120)fail(`Cell thermal model range violated at hour ${idx+1}`);
  peakCellC=Math.max(peakCellC,cell);
  const effective=poa*(1-c.losses.soilingPct/100)*(1-c.losses.iamPct/100)*(1-c.losses.linearShadePct/100);
  const model=effective>0?singleDiodeAtReference(deSotoAuxiliary(c.module,effective,cell)):null;
  let operatingModuleV=model?.vmp||0,operatingModuleI=model?.imp||0,limited=false;
  if(model){
   const seriesV=model.vmp*nModule;
   if(seriesV<c.inverter.mpptMinV||seriesV>c.inverter.mpptMaxV){
    const constrained=clamp(seriesV,c.inverter.mpptMinV,c.inverter.mpptMaxV);
    const mv=constrained/nModule;
    operatingModuleV=mv;
    operatingModuleI=model.ivAtVoltage(mv);
    limited=true;maxMPPTLimitedHours++;
   }
  }
  const modulesTotal=preliminary.moduleCount;
  const theoreticalKW=modulesTotal*pmpRef*poa/1000/1000;
  const moduleDCkW=modulesTotal*operatingModuleV*operatingModuleI/1000;
  // Rdc = round-trip ohm per individual string; I per string is module operating current.
  const dcOhmicKW=Math.min(moduleDCkW,nString*operatingModuleI*operatingModuleI*Rdc/1000);
  const mismatchKW=moduleDCkW*c.losses.mismatchPct/100;
  const dcToInvKW=Math.max(0,moduleDCkW-mismatchKW-dcOhmicKW);
  const inv=pvwattsInverterKW(dcToInvKW,preliminary.acKW,c.inverter.etaNom);
  const acKW=inv.acKW;
  // Assumed balanced 3-phase at fixed line-line volts and power factor; 3 phase conductors.
  const acCurrentA=(1000*acKW)/(Math.sqrt(3)*c.acCable.voltageLL*c.acCable.powerFactor);
  const acCableKW=Math.min(acKW,3*acCurrentA*acCurrentA*Rac/1000);
  const afterAcKW=Math.max(0,acKW-acCableKW);
  const transformerOn=c.transformer.energization==='always'||afterAcKW>0;
  const xfLoadKW=pFixedR*(afterAcKW/(c.transformer.ratedKVA*c.acCable.powerFactor))**2;
  const xfP0KW=transformerOn?c.transformer.noLoadKW:0;
  const beforeAvailKW=afterAcKW-xfLoadKW-xfP0KW;
  const afterAvailKW=beforeAvailKW>0?beforeAvailKW*(1-c.losses.availabilityLossPct/100):beforeAvailKW;
  const exportedKW=Math.max(0,cap===null||cap===undefined?afterAvailKW:Math.min(afterAvailKW,cap));
  const importedKW=Math.max(0,-afterAvailKW);
  const curtailedKW=Math.max(0,afterAvailKW-exportedKW);
  const monthDate=c.weather?.kind==='EPW'?new Date(ts+((c.weather.localStandardTimezoneHours||0)-1)*3600000):new Date(ts);
  const m=monthly[monthDate.getUTCMonth()];m.hours++;m.poaKWhM2+=poa/1000;
  m.theoreticalKWh+=theoreticalKW;m.moduleKWh+=moduleDCkW;m.mismatchLossKWh+=mismatchKW;m.dcCableLossKWh+=dcOhmicKW;
  m.dcAfterCableKWh+=dcToInvKW;m.inverterConversionLossKWh+=Math.max(0,dcToInvKW-inv.acKW-inv.clippingKW);
  m.clippingKWh+=inv.clippingKW;m.acCableLossKWh+=acCableKW;m.transformerLossKWh+=xfLoadKW+xfP0KW;
  m.availabilityLossKWh+=Math.max(0,beforeAvailKW-afterAvailKW);m.curtailmentLossKWh+=curtailedKW;
  m.poiExportKWh+=exportedKW;m.gridImportKWh+=importedKW;
  hourly.push({timestamp_utc:h.timestamp_utc,poa_wm2:poa,effective_irradiance_wm2:effective,cell_temp_c:cell,module_vmp_v:operatingModuleV,module_imp_a:operatingModuleI,module_dc_kw:moduleDCkW,mismatch_loss_kw:mismatchKW,dc_cable_loss_kw:dcOhmicKW,inverter_dc_kw:dcToInvKW,ac_inverter_kw:acKW,ac_cable_loss_kw:acCableKW,transformer_loss_kw:xfLoadKW+xfP0KW,poi_export_kw:exportedKW,grid_import_kw:importedKW,mppt_voltage_constrained:limited?1:0});
 }
 const total=k=>monthly.reduce((s,m)=>s+m[k],0);
 const exported=total('poiExportKWh');
 const lossStages={theoreticalSTCLinearKWh:total('theoreticalKWh'),moduleEnergyKWh:total('moduleKWh'),mismatchLossKWh:total('mismatchLossKWh'),dcCableLossKWh:total('dcCableLossKWh'),inverterDcEnergyKWh:total('dcAfterCableKWh'),inverterConversionLossKWh:total('inverterConversionLossKWh'),inverterClippingKWh:total('clippingKWh'),acCableLossKWh:total('acCableLossKWh'),transformerTotalLossKWh:total('transformerLossKWh'),availabilityLossKWh:total('availabilityLossKWh'),poiCurtailmentKWh:total('curtailmentLossKWh'),poiExportKWh:exported,gridImportKWh:total('gridImportKWh')};
 const checkDcStages=lossStages.moduleEnergyKWh-lossStages.mismatchLossKWh-lossStages.dcCableLossKWh;
 if(Math.abs(checkDcStages-lossStages.inverterDcEnergyKWh)>Math.max(1e-5,lossStages.inverterDcEnergyKWh*1e-9))fail('DC mismatch / I^2R energy reconciliation failure');
 const acEnergyBefore=Math.max(0,total('dcAfterCableKWh')-total('inverterConversionLossKWh')-total('clippingKWh'));
 if(Math.abs(acEnergyBefore-monthly.reduce((s,m)=>s+m.dcAfterCableKWh-m.inverterConversionLossKWh-m.clippingKWh,0))>1e-5)fail('Energy accounting mismatch');
 const energyRec=lossStages.inverterDcEnergyKWh-lossStages.inverterConversionLossKWh-lossStages.inverterClippingKWh-lossStages.acCableLossKWh-lossStages.transformerTotalLossKWh-lossStages.availabilityLossKWh-lossStages.poiCurtailmentKWh;
 if(Math.abs(energyRec-(exported-total('gridImportKWh')))>Math.max(1e-5,Math.abs(energyRec)*1e-9))fail('POI export/import annual conservation mismatch');
 return {method:'EXP v1.7 De Soto 5-parameter + PVWatts inverter + per-string DC I²R + balanced 3φ AC I²R + equivalent transformer P0/Pcu; independent screening only',sourceStatus:c.sourceStatus||'SYNTHETIC / USER INPUT — UNVERIFIED',provenance:c.provenance||'',hourCount:hours.length,stc:preliminary,annual:{poaKWhM2:total('poaKWhM2'),poiExportKWh:exported,gridImportKWh:total('gridImportKWh'),netPoiKWh:exported-total('gridImportKWh'),specificYieldKWhPerKWp:exported/preliminary.stcKW,performanceRatio:total('poaKWhM2')>0?exported/(preliminary.stcKW*total('poaKWhM2')):null,mpptConstrainedHours:maxMPPTLimitedHours,maxCellTemperatureC:peakCellC},lossStages,monthly,hourly,warnings:preliminary.warnings.concat(['Reference STC linear energy is not a strict ceiling: cold operating conditions may produce an apparent gain, and diode response is nonlinear.', 'Detailed curve-based inverter voltage dependence, transformer magnetizing behavior, variable load power factor and grid relay operations are not represented.', 'Hourly energy assumes one-hour mean power and weather provider timestamp alignment; no verified 15-minute or sub-hourly representation.', 'Grid import and export are separately accounted for; net POI energy may differ from exported production.', 'This experimental model is NOT PVsyst/HelioScope-equivalent, bankable, NEC-approved or manufacturer-calibrated.'])};
}
