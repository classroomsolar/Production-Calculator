/** Batch 3 physics: explicit fixed-tilt bifacial row/ground view-factor screen.
 * No automatic modification of the validated main PV production solver.
 */
import {computeEngineering} from './advanced-engine.js';
import {prepareBifacialGeometry,simulateBifacialYear} from './bifacial-vf.js';
const $=id=>document.getElementById(id);
const esc=x=>String(x??'').replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
const fmt=(x,n=2)=>Number.isFinite(x)?x.toLocaleString(undefined,{maximumFractionDigits:n}):'—';
const root=$('pv15Section');
const params=[
 ['tiltDeg','Module front tilt','°',25,0,80,.5],
 ['frontAzimuthDeg','Module front azimuth (N=0, E=90)','°',180,0,360,1],
 ['widthM','Slant module/row width','m',2.1,.2,20,.1],
 ['pitchM','Row center pitch','m',6,.2,100,.1],
 ['heightM','Row midpoint height above level ground','m',1.5,.15,25,.1],
 ['albedo','Ground reflectance / albedo','fraction',.25,0,1,.01],
 ['bifaciality','Rear/front conversion ratio','fraction',.8,0,1,.01],
 ['rearStructuralLoss','Structural rear masking assumption','fraction',.03,0,1,.01]
];
const state={result:null,input:null,source:null};
function getInputs(){const c={};for(const [id] of params){const f=$('bf3_'+id);if(!f||f.value.trim()==='')throw Error(id+' input required');c[id]=Number(f.value)}return c}
function cssNumber(s){return Math.max(0,Math.min(100,s))}
function diagram(c){
 const w=720,h=178,mid=380,scale=39,cy=138;const tilt=c.tiltDeg*Math.PI/180;
 const draw=(k)=>{const x=mid+k*c.pitchM*scale,b=c.widthM*scale/2;return `<line x1="${(x-b*Math.cos(tilt)).toFixed(2)}" y1="${(cy-(c.heightM-c.widthM*Math.sin(tilt)/2)*scale).toFixed(2)}" x2="${(x+b*Math.cos(tilt)).toFixed(2)}" y2="${(cy-(c.heightM+c.widthM*Math.sin(tilt)/2)*scale).toFixed(2)}" stroke="currentColor" stroke-width="5" stroke-linecap="round" />`};
 return `<svg viewBox="0 0 ${w} ${h}" aria-label="Schematic periodic bifacial row geometry; not scaled to installation constraints" role="img"><path d="M 0 ${cy} L ${w} ${cy}" stroke="currentColor" opacity=".35" stroke-width="2"/><g stroke="#6996d2">${[-2,-1,0,1,2].map(draw).join('')}</g><path d="M ${mid} ${cy} v ${-c.heightM*scale}" stroke="currentColor" stroke-dasharray="4 5" opacity=".4"/><text x="16" y="22" fill="currentColor" font-size="12">Cross-section · ideal infinite rows · front azimuth ${esc(c.frontAzimuthDeg)}°</text><text x="16" y="165" fill="currentColor" font-size="12">GCR ${fmt(c.widthM/c.pitchM,3)} · pitch ${fmt(c.pitchM)} m · tilt ${fmt(c.tiltDeg)}° · ground height ${fmt(c.heightM)} m</text></svg>`;
}
function report(res){const a=res.annual,mono=res.geometry;const k=Object.entries(a);const mx=Math.max(1,...res.monthly.map(m=>m.effectiveKWhM2));return `<section class="bf3-summary"><div><small>Front incident energy</small><strong>${fmt(a.frontKWhM2,1)} kWh/m²</strong></div><div><small>Rear incident energy</small><strong>${fmt(a.backKWhM2,1)} kWh/m²</strong></div><div><small>Effective bifacial POA</small><strong>${fmt(a.totalEffectiveKWhM2,1)} kWh/m²</strong></div><div><small>Optical rear addition / front</small><strong>${fmt(a.bifacialOpticalGainPct,2)}%</strong></div></section><h4>Monthly incident POA (kWh/m²)</h4><div class="bf3-chart">${res.monthly.map(m=>`<div><span>${m.month}</span><div class="bf3-track"><i style="width:${cssNumber(100*m.frontKWhM2/mx).toFixed(2)}%"></i><b style="width:${cssNumber(100*m.effectiveKWhM2/mx).toFixed(2)}%"></b></div><small>${fmt(m.effectiveKWhM2,1)}</small></div>`).join('')}</div><h4>2-D row view factors</h4><table class="bf3-table"><thead><tr><th>Surface</th><th>Sky</th><th>Ground</th><th>Adjacent rows</th></tr></thead><tbody>${[['Front',mono.frontView],['Rear',mono.backView]].map(([k,v])=>`<tr><td>${k}</td><td>${fmt(v.sky,3)}</td><td>${fmt(v.ground,3)}</td><td>${fmt(v.row,3)}</td></tr>`).join('')}</tbody></table><p class="bf3-warning">${res.warnings.map(esc).join(' ')}</p>`}
function dl(name,data,mime){const u=URL.createObjectURL(new Blob([data],{type:mime})),a=document.createElement('a');a.href=u;a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(u),8000)}
function csv(rows){const keys=Object.keys(rows[0]||{});const val=x=>{let z=String(x??'');if(/^[=+@]/.test(z))z="'"+z;return /[",\n\r]/.test(z)?`"${z.replaceAll('"','""')}"`:z};return [keys.join(','),...rows.map(r=>keys.map(k=>val(r[k])).join(','))].join('\r\n')}
if(root){
 const tabs=root.querySelector('.pv15-tabs'),base=$('pv15Result');
 if(tabs&&base){
  tabs.insertAdjacentHTML('beforeend','<button type="button" data-bifacial-b3="bifacial">Bifacial / Rear POA R&amp;D · B3</button>');
  const controls=params.map(([id,label,unit,def,lo,hi,step])=>`<label>${esc(label)} <small>${unit}</small><input id="bf3_${id}" type="number" value="${def}" min="${lo}" max="${hi}" step="${step}"></label>`).join('');
  base.insertAdjacentHTML('afterend',`<section id="bifacialB3" class="bf3-workbench" hidden aria-label="Bifacial rear irradiance engineering research"><header><span class="eyebrow">BATCH 3 · OPTICAL RESEARCH MODEL</span><h3>Rear-side irradiation, ground albedo &amp; infinite rows</h3><p>2-D angular view-factor model with row sky masking, ground beam shadows, rear conversion and structural loss. Source-specific testing required before use in project yield.</p></header><div id="bf3Diagram" class="bf3-diagram"></div><div class="bf3-controls">${controls}</div><div class="bf3-actions"><button type="button" id="bf3-run">Calculate hourly bifacial optical screen</button><button type="button" id="bf3-hourly" disabled>Export hourly CSV</button><button type="button" id="bf3-audit" disabled>Audit JSON</button></div><p id="bf3-status" role="status" aria-live="polite">Run the upstream 8,760/8,784-hour weather resource study first.</p><div id="bf3-result"></div><footer><small>References: Sandia PVPMC View Factor Models; pvlib infinite_sheds (comparison of assumptions, not executable/model equivalence). Level ground/fixed tilt only; no tracking coupling, soiling, IAM, spectra, module mismatch or bankable weather validation.</small></footer></section>`);
  const panel=$('bifacialB3'),button=root.querySelector('[data-bifacial-b3]');
  const clear=()=>{state.result=null;state.source=null;state.input=null;$('bf3-result').replaceChildren();$('bf3-hourly').disabled=true;$('bf3-audit').disabled=true;$('bf3-status').textContent='INPUT CHANGED · previous optical result invalidated';};
  const preview=()=>{try{$('bf3Diagram').innerHTML=diagram(getInputs())}catch(e){$('bf3Diagram').textContent='Geometry review required: '+e.message}};
  for(const p of params){$('bf3_'+p[0]).addEventListener('input',()=>{clear();preview()})}
  preview();
  // Unified workbench host handles mutual exclusion. Fallback hides originals if unavailable.
  button.addEventListener('click',()=>{for(const id of ['pv15StringForm','pv15YieldForm','pv15AuditForm','pv17Lab']){const x=$(id);if(x)x.hidden=true}base.hidden=true;tabs.querySelectorAll('button').forEach(x=>x.classList.remove('active'));button.classList.add('active');panel.hidden=false});
  for(const b of tabs.querySelectorAll('button:not([data-bifacial-b3])'))b.addEventListener('click',()=>{panel.hidden=true;button.classList.remove('active')});
  $('bf3-run').addEventListener('click',()=>{
   clear();$('bf3-status').textContent='Checking original resource data and row geometry…';
   try{
    const upstream=window.SolarResourceStudio?.getState?.();if(!upstream?.result?.summary)throw Error('Completed resource study required');
    const c=getInputs(),resource=computeEngineering(upstream.result,upstream.config,'reindl');
    if(![8760,8784].includes(resource.hourly?.length)||resource.warnings?.some(x=>/Partial resource sample/i.test(x)))throw Error('Valid complete-year hourly irradiance missing');
    // All weather and derived sun angles are taken from original resource source pipeline.
    const r=simulateBifacialYear(resource.hourly,c);state.result=r;state.input=c;state.source=upstream.weatherInfo?.label||'resource study';
    $('bf3-result').innerHTML=report(r);$('bf3-status').textContent=`OPTICAL RESEARCH SCREEN · ${r.hours} UTC hours · no AC energy certification`;
    $('bf3-hourly').disabled=false;$('bf3-audit').disabled=false;
   }catch(err){$('bf3-status').textContent='SCREEN REJECTED: '+err.message;}
  });
  $('bf3-hourly').addEventListener('click',()=>{if(state.result)dl('bifacial_optical_hourly.csv',csv(state.result.hourly),'text/csv;charset=utf-8')});
  $('bf3-audit').addEventListener('click',()=>{if(state.result)dl('bifacial_optical_audit.json',JSON.stringify({dateUtc:new Date().toISOString(),configuration:state.input,source:state.source,annual:state.result.annual,monthly:state.result.monthly,geometry:state.result.geometry,warnings:state.result.warnings,researchOnly:true},null,2),'application/json')});
  window.SolarBifacialB3Sheets=()=>state.result?[['B3 Bifacial Optical',Object.entries(state.result.annual).map(([metric,value])=>({metric,value}))],['B3 Bifacial Monthly',state.result.monthly]]:[];
  window.SolarBifacialB3ReportHTML=()=>state.result?`<h2>Batch 3 bifacial optical research — NOT bankable yield</h2><table>${Object.entries(state.result.annual).map(([k,v])=>`<tr><td>${esc(k)}</td><td>${esc(fmt(v,4))}</td></tr>`).join('')}</table><p>${esc(state.result.warnings.join(' '))}</p>`:'';
 }
}
