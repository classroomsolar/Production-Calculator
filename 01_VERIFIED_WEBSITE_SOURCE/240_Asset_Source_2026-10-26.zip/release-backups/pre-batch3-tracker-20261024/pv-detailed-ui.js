/** v1.7 optional detailed research mode — inserted as a tab within the existing
 * v1.5 production panel, not a duplicate standalone dashboard.
 * Real manufacturer/CEC/PVsyst/HelioScope calibration remains unverified.
 */
import {simulateDetailedHourly,validateDetailedConfig} from './pv-detailed-v17.js';
const el=x=>document.getElementById(x);
const esc=v=>String(v??'').replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
const num=(x,d=2)=>Number.isFinite(x)?x.toLocaleString(undefined,{maximumFractionDigits:d}):'—';
const moduleFields=[['ILrefA','Photocurrent IL_ref','A',9.02],['I0refA','Saturation current I0_ref','A',1.4e-10],['RsRefOhm','Series resistance Rs','Ω',.33],['RshRefOhm','Shunt resistance Rsh','Ω',760],['aRefV','Diode nNsVth at reference','V',1.65],['alphaIscAperC','Isc temperature coefficient','A/°C',.0043],['EgRefEv','Reference bandgap EgRef','eV',1.121],['dEgdTPerK','Bandgap relative thermal slope','1/K',-.0002677]];
const arrayFields=[['modulesPerString','Modules per string','count',18],['stringsPerMppt','Parallel strings / MPPT','count',2],['mpptsPerInverter','MPPTs per inverter','count',2],['inverterCount','Identical inverters','count',1],['minCellDesignC','Minimum cell temperature (model screen)','°C',-10],['maxCellDesignC','Maximum cell temperature (model screen)','°C',75]];
const invFields=[['pacKW','Rated AC / inverter','kW',15],['etaNom','Nominal conversion efficiency','fraction',.96],['mpptMinV','MPPT min voltage','V',250],['mpptMaxV','MPPT max voltage','V',850],['maxDCV','Absolute maximum DC input','V',1000],['maxOperatingCurrentPerMpptA','Max operating current / MPPT','A',35],['maxShortCircuitCurrentPerMpptA','Max short-circuit input / MPPT','A',45]];
const lossFields=[['soilingPct','Soiling (effective irradiance)','%',2],['iamPct','IAM simplified (effective irradiance)','%',1],['linearShadePct','Simplified optical shading','%',0],['mismatchPct','Residual module electrical mismatch','%',1],['availabilityLossPct','Expected availability energy loss','%',1],['exportCapKW','POI export cap; 0 = none','kW',0]];
const thermalFields=[['u0','Faiman heat-loss U0','W/m²/K',25],['u1','Faiman U1 at matched wind height','W/m²/K per m/s',6.84]];
const dcFields=[['oneWayM','DC one-way cable length per string','m',30],['crossSectionMm2','DC conductor area','mm²',6],['tempC','DC conductor assumed operating temperature','°C',45]];
const acFields=[['oneWayM','AC one-way cable length','m',40],['crossSectionMm2','AC conductor area','mm²',16],['tempC','AC conductor operating temperature','°C',55],['voltageLL','3-phase nominal line-line voltage','V',400],['powerFactor','AC power factor assumed','ratio',1]];
const txFields=[['ratedKVA','Transformer rated apparent power','kVA',25],['noLoadKW','Transformer energized no-load loss P0','kW',.04],['loadLossRatedKW','Transformer rated copper/load loss','kW',.25]];
const categories=[['Five-parameter module · CEC-like only when coefficients qualified','module',moduleFields],['Array topology & operating-temperature screen','array',arrayFields],['Inverter & MPPT electrical envelopes','inverter',invFields],['Effective irradiance and residual loss assumptions','losses',lossFields],['PV module temperature model','thermal',thermalFields],['DC per-string wiring · I²R','dcCable',dcFields],['AC balanced 3-phase wiring · 3I²R','acCable',acFields],['Transformer equivalent no-load and load loss','transformer',txFields]];
const state={result:null,upstream:null,running:false,source:'',config:null};
function inputs(prefix,fields){return fields.map(([k,label,unit,v])=>`<label>${esc(label)} <small>${esc(unit)}</small><input id="pv17_${prefix}_${k}" type="number" step="any" value="${v}" required></label>`).join('')}
function fieldsets(){return categories.map(([name,prefix,fields],i)=>`<details class="pv17-details" ${i===0||i===1?'open':''}><summary>${esc(name)}</summary><div class="pv17-grid">${inputs(prefix,fields)}${prefix==='dcCable'||prefix==='acCable'?`<label>Conductor metal<select id="pv17_${prefix}_material"><option value="copper" selected>Copper</option><option value="aluminum">Aluminum</option></select></label>`:''}${prefix==='transformer'?`<label>Transformer energized<select id="pv17_transformer_energization"><option value="always">Always energized (night import)</option><option value="sunlit">Only when PV output present</option></select></label>`:''}</div></details>`).join('')}
function markup(){return `<div id="pv17Lab" class="pv17-lab" hidden>
<div class="pv17-intro"><strong>Detailed PV physics R&amp;D · v1.7</strong><p>This research mode is separate from the preliminary production results. The default 283 W module parameters are <strong>SYNTHETIC</strong>, not a 550 W module, and are never fetched from the unqualified 26,000-row catalog. No claim of manufacturer, NEC, PVsyst or bankable equivalence.</p></div>
<label class="pv17-source">Source / coefficients provenance<input id="pv17_provenance" placeholder="Manufacturer + exact model + verified coefficient source and revision (no automatic approval)"></label>
${fieldsets()}
<div class="pv17-actions"><button id="pv17-run" type="button">Compute independently screened hourly physics</button><button id="pv17-csv" type="button" disabled>Detailed hourly CSV</button><button id="pv17-json" type="button" disabled>Audit JSON</button></div>
<p class="pv17-note">Weather input: the existing completed 8,760/8,784-hour solar-resource result. Module heat-loss wind height and De Soto EgRef/dEgdT must match coefficient provenance. DC cable voltage drop does not iteratively shift array MPP; partial-shade bypass diodes, manufacturer inverter curves, detailed IAM/spectra and code compliance remain unimplemented.</p>
<div id="pv17-status" role="status" aria-live="polite">Run the existing resource study above, then calculate this independent experimental production case.</div>
<div id="pv17-results"></div>
</div>`}
const refEl=el('pv15Section');if(!refEl)throw Error('Existing production panel not found; experimental v1.7 integration withheld');
const tabs=refEl.querySelector('.pv15-tabs'),res=el('pv15Result');if(!tabs||!res)throw Error('Old production tabs missing; v1.7 integration withheld');
tabs.insertAdjacentHTML('beforeend','<button type="button" data-pv17="detail">Detailed physics R&amp;D v1.7</button>');
res.insertAdjacentHTML('afterend',markup());
const detail=el('pv17Lab'),newTab=refEl.querySelector('[data-pv17=detail]');
const oldTabs=[...refEl.querySelectorAll('[data-pv15]')];
const oldParts=['pv15StringForm','pv15YieldForm','pv15AuditForm'];
newTab.addEventListener('click',()=>{for(const x of oldParts)el(x).hidden=true;res.hidden=true;for(const b of oldTabs)b.classList.remove('active');newTab.classList.add('active');detail.hidden=false});
for(const b of oldTabs)b.addEventListener('click',()=>{detail.hidden=true;newTab.classList.remove('active');res.hidden=false});
function readGroup(prefix,fields){const o={};for(const [k] of fields){const e=el(`pv17_${prefix}_${k}`);if(!e||e.value.trim()==='')throw Error(`${prefix}.${k} is required`);o[k]=Number(e.value)}return o}
function gather(){const v={};for(const [,prefix,fields] of categories)v[prefix]=readGroup(prefix,fields);
 v.dcCable.material=el('pv17_dcCable_material').value;v.acCable.material=el('pv17_acCable_material').value;
 v.transformer.energization=el('pv17_transformer_energization').value;
 if(v.losses.exportCapKW===0)v.losses.exportCapKW=null;
 v.provenance=el('pv17_provenance').value.trim();v.sourceStatus='USER-ENTERED / SYNTHETIC REFERENCE — UNVERIFIED';return v;}
function download(filename,data,type){const url=URL.createObjectURL(new Blob([data],{type}));const a=document.createElement('a');a.download=filename;a.href=url;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),5000)}
function csv(rows){if(!rows?.length)return'';const keys=Object.keys(rows[0]);const cell=x=>{const y=String(x??'');const safe=/^[=+@]/.test(y)?"'"+y:y;return /[\r\n,\"]/.test(safe)?'"'+safe.replaceAll('"','""')+'"':safe};return [keys.join(','),...rows.map(r=>keys.map(k=>cell(r[k])).join(','))].join('\r\n')}
function render(r){const a=r.annual,s=r.stc,l=r.lossStages;const bars=[['Theoretical linear reference',l.theoreticalSTCLinearKWh],['Actual diode-model module output',l.moduleEnergyKWh],['DC at inverter input',l.inverterDcEnergyKWh],['POI energy exported',l.poiExportKWh]];const max=Math.max(...bars.map(x=>x[1]),1);return `<h3>Experimental one-year production — ${num(r.hourCount,0)} hours</h3>
<div class="pv17-stats"><div><small>Estimated POI export</small><b>${num(a.poiExportKWh/1000,3)} MWh</b></div><div><small>Utility import / transformer standby</small><b>${num(a.gridImportKWh,1)} kWh</b></div><div><small>DC nameplate (synthetic diode fit)</small><b>${num(s.stcKW,2)} kWp</b></div><div><small>AC nameplate</small><b>${num(s.acKW,2)} kW</b></div><div><small>Specific yield (screen)</small><b>${num(a.specificYieldKWhPerKWp,1)} kWh/kWp</b></div><div><small>Modeled MPPT-limit hours</small><b>${num(a.mpptConstrainedHours,0)}</b></div></div>
<h3>Energy stage reconciliation</h3><div class="pv17-bars">${bars.map(([n,v])=>`<div><span>${esc(n)}</span><div class="pv17-track"><i style="width:${Math.min(100,100*v/max).toFixed(1)}%"></i></div><strong>${num(v/1000,2)} MWh</strong></div>`).join('')}</div>
<h3>Separately calculated physical and assumed losses</h3><div class="pv17-table"><table><thead><tr><th>Stage</th><th>Energy (kWh)</th></tr></thead><tbody>${Object.entries(l).map(([k,v])=>`<tr><td>${esc(k)}</td><td>${num(v,2)}</td></tr>`).join('')}</tbody></table></div>
<h3>Monthly production and POI exchange</h3><div class="pv17-table"><table><thead><tr><th>Month</th><th>POA kWh/m²</th><th>DC module kWh</th><th>AC clipped kWh</th><th>POI exported kWh</th><th>Grid import kWh</th></tr></thead><tbody>${r.monthly.map(m=>`<tr><td>${m.month}</td><td>${num(m.poaKWhM2)}</td><td>${num(m.moduleKWh)}</td><td>${num(m.clippingKWh)}</td><td>${num(m.poiExportKWh)}</td><td>${num(m.gridImportKWh)}</td></tr>`).join('')}</tbody></table></div>
${r.warnings.map(w=>`<p class="pv17-warning">${esc(w)}</p>`).join('')}`}
async function calculate(){if(state.running)return;state.running=true;el('pv17-run').disabled=true;el('pv17-status').textContent='Numerical simulation running locally in this browser — synthetic coefficients are not OEM data.';state.result=null;el('pv17-csv').disabled=true;el('pv17-json').disabled=true;
 await new Promise(resolve=>requestAnimationFrame(resolve));
 try{
  const site=window.SolarResourceStudio?.getState?.();const adv=window.SolarV2State?.();
  if(!site?.result?.summary||!adv?.prepared?.hourly?.length)throw Error('Run a complete existing Solar Resource weather analysis before detailed energy simulation.');
  const input=gather();input.weather={kind:site.config?.kind,localStandardTimezoneHours:site.config?.localStandardTimezoneHours};
  const r=simulateDetailedHourly(adv.prepared.hourly,input);
  state.result=r;state.upstream=site.result;state.source=site.weatherInfo?.label||'';state.config=JSON.parse(JSON.stringify(input));
  el('pv17-results').innerHTML=render(r);
  el('pv17-status').textContent='EXPERIMENTAL SIMULATION FINISHED · NOT FOR CONSTRUCTION OR BANKABLE FORECASTS';
  el('pv17-csv').disabled=false;el('pv17-json').disabled=false;
 }catch(e){el('pv17-results').textContent='';el('pv17-status').textContent='SIMULATION NOT ACCEPTED: '+e.message;}
 finally{state.running=false;el('pv17-run').disabled=false;}}
// Prevent cached output being mistaken for a new upstream weather case.
window.addEventListener('solarresource:updated',()=>{if(state.result&&window.SolarResourceStudio?.getState?.().result!==state.upstream){state.result=null;el('pv17-csv').disabled=true;el('pv17-json').disabled=true;el('pv17-results').textContent='';el('pv17-status').textContent='Weather case changed. Detailed production result invalidated; recalculate.';}});
el('pv17-run').addEventListener('click',calculate);
el('pv17-csv').addEventListener('click',()=>{if(state.result)download('pv_detailed_v17_EXPERIMENTAL_hourly.csv',csv(state.result.hourly),'text/csv')});
el('pv17-json').addEventListener('click',()=>{if(state.result)download('pv_detailed_v17_EXPERIMENTAL_audit.json',JSON.stringify({method:state.result.method,sourceStatus:state.result.sourceStatus,provenance:state.result.provenance,upstream:state.source,disclaimer:'SYNTHETIC/USER-ENTERED, NOT manufacturer qualified, construction approved or bankable',stc:state.result.stc,annual:state.result.annual,lossStages:state.result.lossStages,monthly:state.result.monthly,warnings:state.result.warnings},null,2),'application/json')});
window.SolarPV17Sheets=()=>{if(!state.result)return[];const r=state.result;const rows=a=>[Object.keys(a[0]||{}),...a.map(x=>Object.values(x))];return [['PV17_EXPERIMENTAL_Monthly',rows(r.monthly)],['PV17_EXPERIMENTAL_Hourly',rows(r.hourly)],['PV17_EXPERIMENTAL_Stages',[['Stage','Energy_kWh'],...Object.entries(r.lossStages)]]]};
window.SolarPV17ReportHTML=()=>state.result?`<h2>EXPERIMENTAL v1.7 Detailed PV physics — NOT OEM/Bankable</h2><p>Source: ${esc(state.source)} · module parameters: ${esc(state.result.sourceStatus)} · ${esc(state.result.provenance)}. ${num(state.result.stc.stcKW,2)} kWp DC; ${num(state.result.annual.poiExportKWh/1000,3)} MWh exported, ${num(state.result.annual.gridImportKWh,1)} kWh imported. Detailed model is not NEC/PVsyst/HelioScope certified.</p><table><tr><th>Stage</th><th>Energy kWh</th></tr>${Object.entries(state.result.lossStages).map(([k,v])=>`<tr><td>${esc(k)}</td><td>${num(v,2)}</td></tr>`).join('')}</table>`:'';
window.SolarPV17State=()=>({result:state.result,upstream:state.upstream,source:state.source,config:state.config});
