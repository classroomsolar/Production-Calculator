/** Research screen for annual PV energy probability-of-exceedance.
 * Independent Gaussian annual-energy uncertainty budget (not bankable).
 * Based on PVsyst help P50/P90, Sandia PVPMC uncertainty quantification,
 * and IEA PVPS Task 16 solar resource handbook. Assumes independent zero-mean components.
 */
const Z={P50:0,P75:.6744897501960817,P90:1.2815515655446004,P95:1.6448536269514722,P99:2.3263478740408408};
const finite=(x,name,lo,hi)=>{if(!Number.isFinite(x)||x<lo||x>hi)throw Error(`${name} must be finite ${lo}..${hi}`);return x};
export function parseAnnualYieldText(text){
 if(typeof text!=='string')throw Error('Yearly energy series required');
 const tokens=text.split(/[,;\s]+/).filter(Boolean);
 if(tokens.length<5)throw Error('At least five independent annual yield entries required');
 if(tokens.length>100)throw Error('Maximum 100 annual entries');
 return tokens.map((s,i)=>finite(Number(s),`annualYield_${i+1}`,0.01,1e12));
}
export function empiricalQuantile(sorted,p){if(!Array.isArray(sorted)||!sorted.length)throw Error('Samples required');const at=(sorted.length-1)*p,i=Math.floor(at),f=at-i;return sorted[i]*(1-f)+sorted[Math.min(i+1,sorted.length-1)]*f;}
export function energyUncertaintyBudget(input){
 if(!input||typeof input!=='object')throw Error('Energy uncertainty inputs required');
 const x=input.years; if(!Array.isArray(x)||x.length<5||x.length>100)throw Error('Five to one hundred annual energy samples required');
 const e=x.map((v,i)=>finite(v,`year_${i+1}`,0.01,1e12));
 const n=e.length,mean=e.reduce((s,v)=>s+v,0)/n;
 const sampleSd=Math.sqrt(e.reduce((s,v)=>s+(v-mean)**2,0)/(n-1));
 const meanShiftPct=finite(input.meanShiftPct??0,'meanShiftPct',-50,50);
 const uResourcePct=finite(input.uResourcePct??0,'uResourcePct',0,35);
 const uModelPct=finite(input.uModelPct??0,'uModelPct',0,35);
 const uAvailabilityPct=finite(input.uAvailabilityPct??0,'uAvailabilityPct',0,35);
 const p50=mean*(1+meanShiftPct/100);
 if(p50<=0)throw Error('Shifted P50 cannot be negative/zero');
 const others=[uResourcePct,uModelPct,uAvailabilityPct].map(u=>p50*u/100);
 const independentSigma=Math.hypot(sampleSd,...others);
 const positiveSigma=Math.hypot(sampleSd,others.reduce((s,u)=>s+u,0));
 const nonphysical=[];
 const nonnegative=(raw,q,label)=>{if(raw<=0){nonphysical.push(`${label} ${q} mathematically nonpositive under the unbounded Gaussian assumption; no physical energy percentile is reported.`);return null}return raw};
 const quantiles={};for(const [q,z] of Object.entries(Z))quantiles[q]=nonnegative(p50-z*independentSigma,q,'Independent');
 const stress={};for(const [q,z] of Object.entries(Z))stress[q]=nonnegative(p50-z*positiveSigma,q,'Correlation stress');
 const sorted=e.toSorted((a,b)=>a-b);
 const empirical={P50:empiricalQuantile(sorted,.5),P75:empiricalQuantile(sorted,.25),P90:empiricalQuantile(sorted,.1),P95:empiricalQuantile(sorted,.05)};
 const warnings=[
 ...nonphysical,
 'NOT BANKABLE: Gaussian P-values assume annual yields are representative of a stationary long-term resource and uncertainties are normally distributed.',
 'Weather interannual variability is calculated as an uncorrected sample standard deviation; serial correlation, trends and measurement representativeness are not tested.',
 'Resource/model/availability uncertainty terms are user-entered 1-sigma percentages; independence can understate error where correlated or double-counted.',
 'These are ANNUAL energy exceedance levels only, not scaled hourly or monthly P90 weather series.',
 'Check whether year samples already include changes in equipment, curtailment, availability or degradation; mixtures can invalidate the calculation.',
 'Model bias (including systematic source mismatch), resource representativeness, market financing requirements and long-term climatology require project evidence.'
 ];
 if(n<15)warnings.push('SHORT HISTORICAL RECORD: fewer than 15 annual samples; Gaussian and empirical P90 have considerable sampling uncertainty.');
 if(input.uResourcePct===undefined||input.uModelPct===undefined||input.uAvailabilityPct===undefined)warnings.push('Unspecified uncertainty terms default to 0, not verified negligible.');
 if(Math.abs(meanShiftPct)>1e-9)warnings.push('User-specified mean shift is an assumption requiring independent source/bias evidence.');
 return {samples:n,annualMeanKWh:mean,sampleSDkWh:sampleSd,sampleCVPct:100*sampleSd/mean,shiftedP50KWh:p50,otherSigmasKWh:others,sigmaIndependentKWh:independentSigma,sigmaStressKWh:positiveSigma,gaussian:quantiles,highCorrelationStress:stress,empirical,confidence:'SCREENING ONLY',warnings,method:'Annual normal distribution, sample standard deviation n-1, independent sigma RSS; conservative correlated uncertainty stress bound.'};
}
