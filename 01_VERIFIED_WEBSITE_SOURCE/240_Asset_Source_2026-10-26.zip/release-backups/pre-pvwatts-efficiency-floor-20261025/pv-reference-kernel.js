/** Engineering reference kernel: standalone, NOT manufacturer validation or final NEC approval.
 * Five-parameter SDM: De Soto et al. (2006) via Sandia PVPMC; I-V equation, numerical solvers.
 * PVWatts inverter: NREL/TP-6A20-62641, pvlib.inverter.pvwatts implementation.
 * 2023 NEC 690.8 basic max circuit current and ampacity PRE-SCREEN only; exclusions apply.
 * SI: V, A, ohm, W, W/m², °C. No implicit manufacturer parameters.
 */
const kEv=8.617333262145e-5;
const absTol=1e-12;
const finite=(x)=>Number.isFinite(x);
const assert=(q,msg)=>{if(!q)throw new Error(msg)};
const required=(a,ks)=>{for(const k of ks)assert(finite(a[k])&&a[k]>0,`${k} must be finite positive`)};
const safeDiode=(v)=>v>700?Infinity:Math.expm1(v);
export function singleDiodeAtReference({photocurrentA, saturationCurrentA, seriesOhm, shuntOhm, nNsVth}) {
  const p={photocurrentA,saturationCurrentA,seriesOhm,shuntOhm,nNsVth};
  required(p,['photocurrentA','saturationCurrentA','shuntOhm','nNsVth']);
  assert(finite(seriesOhm)&&seriesOhm>=0,'Series resistance must be nonnegative');
  function residual(I,V) {
    const vd=V+I*seriesOhm;
    return photocurrentA-saturationCurrentA*safeDiode(vd/nNsVth)-vd/shuntOhm-I;
  }
  function currentAtVoltage(V) {
    assert(finite(V)&&V>=0,'Voltage must be nonnegative');
    if(residual(0,V)<=0) return 0;
    let lo=0,hi=photocurrentA;
    for(let n=0;n<92;n++){
      const mid=(lo+hi)*0.5;
      if(residual(mid,V)>0)lo=mid;else hi=mid;
    }
    return (lo+hi)*0.5;
  }
  // Voc bounded above by the ideal diode open circuit at infinite Rsh and zero Rs.
  const idealVoc=nNsVth*Math.log1p(photocurrentA/saturationCurrentA);
  let lo=0,hi=idealVoc;
  for(let j=0;j<90;j++){
    const mid=(lo+hi)*0.5;
    if(residual(0,mid)>0)lo=mid;else hi=mid;
  }
  const voc=(lo+hi)*0.5,isc=currentAtVoltage(0);
  let a=0,b=voc;const phi=(Math.sqrt(5)-1)/2;
  let c=b-phi*(b-a),d=a+phi*(b-a),pc=c*currentAtVoltage(c),pd=d*currentAtVoltage(d);
  for(let j=0;j<128;j++){
    if(pc<pd){a=c;c=d;pc=pd;d=a+phi*(b-a);pd=d*currentAtVoltage(d)}
    else {b=d;d=c;pd=pc;c=b-phi*(b-a);pc=c*currentAtVoltage(c)}
  }
  const vmp=(a+b)*0.5,imp=currentAtVoltage(vmp),pmp=vmp*imp;
  return {voc,isc,vmp,imp,pmp,fillFactor:pmp/(voc*isc),ivAtVoltage:currentAtVoltage};
}
export function deSotoParamsAtConditions(ref, irradianceWm2, cellC) {
  required(ref,['ILrefA','I0refA','RshRefOhm','aRefV']);
  assert(finite(ref.RsRefOhm)&&ref.RsRefOhm>=0,'RsRefOhm must be finite nonnegative');
  assert(finite(ref.alphaIscAperC),'alphaIscAperC required, not alpha in %/°C');
  assert(finite(irradianceWm2)&&irradianceWm2>=0&&irradianceWm2<=1800,'Irradiance outside 0..1800 W/m²');
  assert(finite(cellC)&&cellC>=-80&&cellC<=120,'Cell temperature outside -80..120°C');
  if(irradianceWm2===0)return null;
  const Tref=298.15,T=cellC+273.15;
  const EgRef=ref.EgRefEv??1.121,dEgdT=ref.dEgdTPerK??-0.0002677;
  assert(finite(EgRef)&&EgRef>0&&EgRef<3,'Reference bandgap in eV invalid');
  assert(finite(dEgdT)&&dEgdT>=-0.01&&dEgdT<=0.01,'Bandgap temperature slope must be finite, in 1/K');
  // De Soto / pvlib.calcparams_desoto: apply the same EgRef and dEgdT
  // used when fitting reference single-diode parameters. Omitting the
  // temperature slope changes saturation current and Pmp outside STC.
  const Eg=EgRef*(1+dEgdT*(T-Tref));
  assert(Eg>0,'Nonphysical semiconductor bandgap at cell temperature');
  const IL=irradianceWm2/1000*(ref.ILrefA+ref.alphaIscAperC*(cellC-25));
  assert(IL>0,'Nonphysical light-current extrapolation');
  const I0=ref.I0refA*(T/Tref)**3*Math.exp(EgRef/(kEv*Tref)-Eg/(kEv*T));
  return {photocurrentA:IL,saturationCurrentA:I0,seriesOhm:ref.RsRefOhm,shuntOhm:ref.RshRefOhm*1000/irradianceWm2,nNsVth:ref.aRefV*T/Tref};
}
export function deSotoPower(ref, irradianceWm2,cellC){
 const p=deSotoParamsAtConditions(ref,irradianceWm2,cellC);
 if(!p)return {voc:0,isc:0,vmp:0,imp:0,pmp:0,fillFactor:null};
 const {ivAtVoltage,...r}=singleDiodeAtReference(p);
 return r;
}
export function pvwattsInverterKW(dcKW, acRatedKW, etaNom=0.96,etaRef=0.9637){
 assert([dcKW,acRatedKW,etaNom,etaRef].every(finite)&&dcKW>=0&&acRatedKW>0&&etaNom>0&&etaNom<=1&&etaRef>0&&etaRef<=1,'Invalid inverter model inputs');
 if(dcKW===0)return {acKW:0,conversionLossKW:0,clippingKW:0,efficiency:0};
 const pdc0=acRatedKW/etaNom,zeta=dcKW/pdc0;
 const raw=etaNom/etaRef*(-0.0162*zeta-0.0059/zeta+0.9858);
 // The empirical PVWatts fit is not physical when user-defined etaNom
 // makes eta_AC exceed 100%. Reject instead of reporting negative
 // conversion losses or creating AC energy from nowhere.
 if(!finite(raw)||raw>1+1e-10)throw new Error('PVWatts inverter fitted efficiency exceeds 100%: nominal efficiency or operating point outside physical model envelope');
 const eff=Math.min(1,raw); // rounding-only safety, never silently clamp a material violation
 const produced=Math.max(0,dcKW*eff),acKW=Math.min(acRatedKW,produced);
 return {acKW,conversionLossKW:dcKW-produced,clippingKW:produced-acKW,efficiency:eff};
}
export function nec2023SourceCurrentScreen(iscA,parallelStrings=1, correctionFactor=1){
 assert(finite(iscA)&&iscA>0&&Number.isInteger(parallelStrings)&&parallelStrings>0,'Invalid Isc or parallel string count');
 assert(finite(correctionFactor)&&correctionFactor>0&&correctionFactor<=1,'Correction factor should be in (0,1]');
 const sourceIsc=iscA*parallelStrings,maxCircuitA=1.25*sourceIsc;
 const basicAmpacityBeforeAdjustmentsA=1.25*maxCircuitA;
 const adjustedNominalAmpacityA=maxCircuitA/correctionFactor;
 return {sourceIscA:sourceIsc,maxCircuitCurrentA:maxCircuitA,basicAmpacityBeforeAdjustmentsA,minimumUnadjustedAmpacityA:Math.max(basicAmpacityBeforeAdjustmentsA,adjustedNominalAmpacityA),codeEdition:'2023 NFPA 70',articles:'690.8(A)(1)(a)(1),690.8(B)(1)-(2)',status:'PRE-SCREEN ONLY: neither conductor nor OCPD design established; exceptions, bidirectional supply, bifacial listing, terminal temperature and AHJ conditions must be reviewed.'};
}
