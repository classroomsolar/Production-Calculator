/* Solar Resource Studio 1.4: independent geometric near-obstruction + empirical resource risk screen.
   Units m, W/m2, h. No roof structural or electrical mismatch performance claimed. */
const RAD=Math.PI/180, eps=1e-9;
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const finite=Number.isFinite;
export const percentile=(xs,q)=>{if(!xs.length||q<0||q>1)throw Error('Invalid quantile');const a=[...xs].sort((x,y)=>x-y),k=(a.length-1)*q,i=Math.floor(k);return a[i]+(a[Math.min(i+1,a.length-1)]-a[i])*(k-i)};
const dot=(a,b)=>a[0]*b[0]+a[1]*b[1]+a[2]*b[2];
const add=(a,b)=>[a[0]+b[0],a[1]+b[1],a[2]+b[2]];
const diff=(a,b)=>[a[0]-b[0],a[1]-b[1],a[2]-b[2]];
const scale=(a,k)=>a.map(v=>v*k);
export function arrayPlane({tilt,azimuth,centerHeight=1.5,centerEast=0,centerNorth=0,widthM=2,lengthM=2}){
 if(![tilt,azimuth,centerHeight,centerEast,centerNorth,widthM,lengthM].every(finite)||tilt<0||tilt>90||azimuth<0||azimuth>360||widthM<=0||lengthM<=0)throw Error('Invalid array-plane dimensions, azimuth or tilt');
 const b=tilt*RAD,a=azimuth*RAD;
 return {center:[centerEast,centerNorth,centerHeight], normal:[Math.sin(b)*Math.sin(a),Math.sin(b)*Math.cos(a),Math.cos(b)], widthAxis:[Math.cos(a),-Math.sin(a),0], slantAxis:[-Math.cos(b)*Math.sin(a),-Math.cos(b)*Math.cos(a),Math.sin(b)], widthM,lengthM,tilt,azimuth};
}
export function obstructionBox(o){
 const {eastM,northM,widthEastM,widthNorthM,heightM,bottomM=0}=o;
 if(![eastM,northM,widthEastM,widthNorthM,heightM,bottomM].every(finite)||widthEastM<=0||widthNorthM<=0||heightM<=0||bottomM<0)throw Error('Obstruction dimensions must be finite and positive; bottom >=0');
 return {eastM,northM,widthEastM,widthNorthM,heightM,bottomM};
}
export function shadowPolygon(plane,box,sunElevation,sunAzimuth){
 if(!finite(sunElevation)||!finite(sunAzimuth))throw Error('Invalid solar position');
 if(sunElevation<=0)return [];
 const el=sunElevation*RAD,az=sunAzimuth*RAD;
 const S=[Math.cos(el)*Math.sin(az),Math.cos(el)*Math.cos(az),Math.sin(el)],nS=dot(plane.normal,S);
 if(nS<=1e-6)return [];
 const x0=box.eastM-box.widthEastM/2,x1=box.eastM+box.widthEastM/2;
 const y0=box.northM-box.widthNorthM/2,y1=box.northM+box.widthNorthM/2;
 const z0=box.bottomM,z1=z0+box.heightM;
 const vertices=[];for(const x of [x0,x1])for(const y of [y0,y1])for(const z of [z0,z1])vertices.push([x,y,z]);
 const edges=[];for(let i=0;i<8;i++)for(let j=i+1;j<8;j++){
  const d=diff(vertices[i],vertices[j]);if(d.filter(x=>Math.abs(x)>eps).length===1)edges.push([i,j]);
 }
 const h=vertices.map(v=>dot(plane.normal,diff(v,plane.center)));
 const valid=vertices.filter((v,i)=>h[i]>=-eps);
 for(const [i,j] of edges)if((h[i]<-eps&&h[j]>eps)||(h[i]>eps&&h[j]<-eps))valid.push(add(vertices[i],scale(diff(vertices[j],vertices[i]),h[i]/(h[i]-h[j]))));
 const planePts=valid.map(v=>{
  const t=Math.max(0,dot(plane.normal,diff(v,plane.center))/nS);
  const ground=diff(diff(v,scale(S,t)),plane.center);
  return [dot(ground,plane.widthAxis),dot(ground,plane.slantAxis)];
 });
 return convexHull(planePts);
}
function cross(a,b,c){return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])}
export function convexHull(points){
 const pts=points.filter(p=>p.every(finite)).sort((a,b)=>a[0]-b[0]||a[1]-b[1]);if(pts.length<3)return pts;
 const lower=[],upper=[];
 for(const p of pts){while(lower.length>=2&&cross(lower.at(-2),lower.at(-1),p)<=eps)lower.pop();lower.push(p)}
 for(let i=pts.length-1;i>=0;i--){const p=pts[i];while(upper.length>=2&&cross(upper.at(-2),upper.at(-1),p)<=eps)upper.pop();upper.push(p)}
 lower.pop();upper.pop();return [...lower,...upper];
}
export function insideConvex(p,polygon){
 if(polygon.length<3)return false;let sign=0;
 for(let i=0;i<polygon.length;i++){const c=cross(polygon[i],polygon[(i+1)%polygon.length],p);if(Math.abs(c)<=eps)continue;const s=Math.sign(c);if(sign&&s!==sign)return false;sign=s}
 return true;
}
export function obstructionMask(plane,boxes,elevation,azimuth,samples=20){
 if(!Number.isInteger(samples)||samples<4||samples>60)throw Error('Samples must be 4 to 60 per side');
 const polygons=boxes.map(o=>shadowPolygon(plane,obstructionBox(o),elevation,azimuth)).filter(x=>x.length>=3);
 if(!polygons.length)return {fraction:0,covered:0,samples:samples*samples,polygons:[]};
 let covered=0;
 for(let i=0;i<samples;i++)for(let j=0;j<samples;j++){
  const p=[((i+.5)/samples-.5)*plane.widthM,((j+.5)/samples-.5)*plane.lengthM];
  if(polygons.some(poly=>insideConvex(p,poly)))covered++;
 }
 return {fraction:covered/(samples*samples),covered,samples:samples*samples,polygons};
}
/** Obstruction direct-beam irradiance loss per module plane area; diffuse and electrical losses excluded. */
export function obstructionStudy(prepared,options){
 const {cfg,boxes,planeWidthM=2,planeLengthM=2,centerHeightM=1.5,samples=20}=options;
 if(!Array.isArray(prepared)||!prepared.length)throw Error('Run an hourly resource analysis before near-shading');
 if(!Array.isArray(boxes)||boxes.length>15)throw Error('Provide at most 15 obstruction boxes');
 const obstacles=boxes.map(obstructionBox);
 const plane=arrayPlane({tilt:cfg.tilt,azimuth:cfg.azimuth,widthM:planeWidthM,lengthM:planeLengthM,centerHeight:centerHeightM});
 const monthly=Array.from({length:12},(_,i)=>({month:i+1,unshadedPoa:0,beamUnshaded:0,obstructionLoss:0,remainingPoa:0}));
 let baseline=0,beam=0,loss=0,affectedHours=0,energySum=0;
 const hourly=[];
 for(const h of prepared){
  const direct=h.poa_direct_wm2,poa=h.poa_wm2;
  if(!finite(direct)||!finite(poa))throw Error('Hourly data lack component-resolved POA; recalculate resource');
  const f=direct>0&&h.solar_elevation_deg>0?obstructionMask(plane,obstacles,h.solar_elevation_deg,h.solar_azimuth_deg,samples).fraction:0;
  const removed=direct*f,rem=Math.max(0,poa-removed);
  const month=new Date(h.timestamp_utc).getUTCMonth(),m=monthly[month];
  m.unshadedPoa+=poa/1000;m.beamUnshaded+=direct/1000;m.obstructionLoss+=removed/1000;m.remainingPoa+=rem/1000;
  baseline+=poa/1000;beam+=direct/1000;loss+=removed/1000;energySum+=rem/1000;if(removed>0)affectedHours++;
  hourly.push({timestamp_utc:h.timestamp_utc,unshaded_poa_wm2:poa,unshaded_beam_wm2:direct,obstruction_shaded_fraction:f,obstruction_beam_loss_wm2:removed,screened_poa_wm2:rem});
 }
 return {baselinePoa:baseline,unshadedBeam:beam,obstructionLoss:loss,remainingPoa:energySum,lossPct:baseline?100*loss/baseline:0,affectedHours,monthly,hourly,options:{boxes:obstacles,planeWidthM,planeLengthM,centerHeightM,samples,tilt:cfg.tilt,azimuth:cfg.azimuth},limitations:['Geometric 3-D rectangular-prism line-of-sight screen on one tilted array plane; not a site CAD or tree-canopy model.','Counts union of shadows once. Only direct-beam component is removed. Diffuse-sky obstruction, reflected irradiance, moving equipment, electrical mismatch, bypass diodes and string/I–V behavior are excluded.','Do not add these losses to independently computed horizon or row losses without a combined-ray visibility model; physical obstructions and terrain can overlap.','Results are irradiation on a module plane, not DC/AC energy yield; dimensions, placement and obstruction heights must be verified by site survey.']};
}
function xorshift(seed){let x=(seed>>>0)||1;return ()=>{x^=x<<13;x^=x>>>17;x^=x<<5;return (x>>>0)/4294967296}}
export function empiricalExceedance(yearRecords,{bootstrap=600,seed=20261023,minYears=10}={}){
 if(!Array.isArray(yearRecords)||yearRecords.length<2)throw Error('At least two complete historical calendar years required');
 const years=[...yearRecords].sort((a,b)=>a.year-b.year);
 if(new Set(years.map(y=>y.year)).size!==years.length)throw Error('Duplicate annual year');
 if(years.some(y=>!Number.isInteger(y.year)||y.year<1900||y.year>2100))throw Error('Invalid annual weather source year');
 if(years.some(y=>y.hours!==((new Date(Date.UTC(y.year+1,0,1))-new Date(Date.UTC(y.year,0,1)))/3600000)))throw Error('Annual record count does not match leap/nonleap calendar year');
 if(years.some(y=>![8760,8784].includes(y.hours)))throw Error('Some annual histories are incomplete');
 if(!Number.isInteger(bootstrap)||bootstrap<0||bootstrap>2000)throw Error('Bootstrap iterations must be 0 to 2,000');
 const n=years.length,accepted=n>=minYears,random=xorshift(seed),metrics={};
 for(const key of ['ghi','dni','dhi','poa']){
  const xs=years.map(y=>y[key]);if(xs.some(x=>!finite(x)||x<0))throw Error('Nonfinite or negative annual '+key);
  const out={sampleYears:n,mean:xs.reduce((a,b)=>a+b,0)/n,p50:percentile(xs,.50),p75:percentile(xs,.25),p90:percentile(xs,.10),empiricalOnly:true};
  if(accepted&&bootstrap){
   const boot={p50:[],p75:[],p90:[]};for(let t=0;t<bootstrap;t++){
    const draw=Array.from({length:n},()=>xs[Math.floor(random()*n)]);
    boot.p50.push(percentile(draw,.5));boot.p75.push(percentile(draw,.25));boot.p90.push(percentile(draw,.1));
   }
   out.bootstrap95={};for(const key of ['p50','p75','p90'])out.bootstrap95[key]=[percentile(boot[key],.025),percentile(boot[key],.975)];
  }
  metrics[key]=out;
 }
 return {years:years.map(({year,hours,ghi,dni,dhi,poa})=>({year,hours,ghi,dni,dhi,poa})),metrics,sampleYears:n,thresholdMet:accepted,method:'Empirical exceedance of annual weather-model irradiation: Px is the (100−x)th percentile of complete yearly annual totals; percentile interpolated on order statistics; seeded resampling-with-replacement uncertainty intervals.',warnings:[...(!accepted?[`Only ${n} years. Require >=${minYears} comparable complete years before publishing P50/P75/P90 percentiles as a decision screen. Values withheld in the UI.`]:[]),'Not bankable P-values, a weather forecast, or plant-energy exceedance. Historical-year sampling cannot quantify dataset bias, long-term climate trend, instrument uncertainty, correlated weather years, or developer/model risk.','Bootstrap 95% limits represent sample variability only. They are not a full project uncertainty budget.','Avoid mixing models, changing locations, cherry-picked periods or different array assumptions between annual cases.']};
}
/** Paired same-month diagnostic, not accuracy when references differ in period. */
export function monthlySourceDiagnostics(sourceA,sourceB){
 if(sourceA?.length!==12||sourceB?.length!==12)throw Error('Both monthly resources must have 12 months');
 const metrics={};for(const key of ['ghi','poa']){
  const a=sourceA.map(m=>m[key]),b=sourceB.map(m=>m[key]);if(a.some(x=>!finite(x))||b.some(x=>!finite(x)))throw Error('Invalid monthly '+key);
  const dif=a.map((x,i)=>b[i]-x),n=12;
  metrics[key]={bias:dif.reduce((s,x)=>s+x,0)/n,mae:dif.reduce((s,x)=>s+Math.abs(x),0)/n,rmse:Math.sqrt(dif.reduce((s,x)=>s+x*x,0)/n),maxAbs:Math.max(...dif.map(Math.abs)),months:12};
 }
 return {metrics,warning:'Monthly diagnostics compare modeled climatologies only. RMSE/MAE relative to another model are disagreement metrics, not errors against verified measurements.'};
}
