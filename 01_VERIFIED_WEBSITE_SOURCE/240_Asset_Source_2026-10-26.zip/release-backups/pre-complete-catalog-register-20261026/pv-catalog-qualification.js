/** Batch 1 — Canonical PV module catalogue qualification engine.
 * Read-only: flags defects but never modifies canonical models.
 * Criteria are data-QA checks, NOT NEC compliance, certifications, or bankable device models.
 */
const numeric=(v)=>typeof v==='number' && Number.isFinite(v);
const norm=(v)=>String(v??'').trim().toLocaleLowerCase('en').replace(/\s+/g,' ');
export const QUALITY_VERSION='batch1-stc-rec-2026-10-24';
export const OEM_STC_CHECKS={
 'LR7-72HGD-585M':[585,51.89,43.79,14.25,13.36,21.7],
 'LR7-72HGD-590M':[590,52.00,43.90,14.33,13.44,21.8],
 'LR7-72HGD-595M':[595,52.11,44.01,14.41,13.52,22.0],
 'LR7-72HGD-600M':[600,52.22,44.12,14.49,13.60,22.2],
 'LR7-72HGD-605M':[605,52.33,44.23,14.57,13.68,22.4],
 'LR7-72HGD-610M':[610,52.44,44.34,14.65,13.76,22.6],
 'LR7-72HGD-615M':[615,52.55,44.44,14.73,13.84,22.8],
 'LR7-72HGD-620M':[620,52.66,44.55,14.81,13.92,23.0]
};
// Independent transcription checked directly against the manufacturer-hosted
// REC Alpha Pure-RX UL EN 6.2026 V7 (REF PM-DS-12-06/08.04.08.01) table.
// STC nameplate comparison only: not proof of certificate/listing nor SDM fit.
export const OEM_REC_STC_CHECKS={
 'REC450AA PURE-RX-DC':[450,65.6,54.3,8.81,8.29,21.6],
 'REC460AA PURE-RX-DC':[460,65.7,54.9,8.88,8.38,22.1],
 'REC470AA PURE-RX-DC':[470,65.7,55.4,8.95,8.49,22.6]
};
const OEM_REC_FAMILY='https://www.recgroup.com/sites/default/files/2026-03/DS_Alpha_Pure-RX_UL%20DC.pdf';
const OEM_FAMILY='https://static.longi.com/2_LR_7_72_HGD_585_620_M_V2_30_30_and_15_V05_EN_c6514bcafc.pdf';
const STC=['w','voc','vmp','isc','imp'];
export function sourceAssessment(record){
 const text=String(record?.source??'').trim();
 const match=text.match(/https?:\/\/[^\s|<>"']+/i);
 const url=match?.[0]||null;
 let validUrl=null;
 if(url){try {const u=new URL(url);if(['http:','https:'].includes(u.protocol))validUrl=u.href}catch{}}
 return {sourcePresent:!!text,link:validUrl,sourceKind:validUrl?'LINK_PRESENT_NOT_CHECKED':text?'INTERNAL_REFERENCE_NOT_INDEPENDENT':'SOURCE_MISSING'};
}
export function assessRecord(record,frequency=1){
 if(!record||typeof record!=='object')throw Error('Catalog record missing');
 const flags=[],f=x=>flags.push(x);
 for(const key of STC)if(!numeric(record[key])||record[key]<=0)f('INVALID_'+key.toUpperCase());
 if(numeric(record.voc)&&numeric(record.vmp)&&record.voc>0&&record.vmp>0&&record.voc<=record.vmp)f('VOC_NOT_ABOVE_VMP');
 if(numeric(record.isc)&&numeric(record.imp)&&record.isc>0&&record.imp>0&&record.isc<=record.imp)f('ISC_NOT_ABOVE_IMP');
 const validSTC=STC.every(k=>numeric(record[k])&&record[k]>0)&&record.voc>record.vmp&&record.isc>record.imp;
 if(validSTC&&Math.abs(record.vmp*record.imp/record.w-1)>.07)f('PMP_VMP_IMP_DISCREPANCY_ABOVE_7_PERCENT');
 if(frequency>1)f('REPEATED_MANUFACTURER_MODEL_NAME');
 const source=sourceAssessment(record);
 if(!source.sourcePresent)f('SOURCE_FIELD_BLANK');
 else if(!source.link)f('SOURCE_NOT_EXTERNAL_LINK');
 // Data source/OEM document URL does not by itself confirm exact model specifications.
 const stcSix=['w','voc','vmp','isc','imp','efficiency'];
 const isLongi=norm(record.maker)==='longi'&&Object.hasOwn(OEM_STC_CHECKS,String(record.model))&&
  source.link===OEM_FAMILY&&stcSix.every((k,i)=>numeric(record[k])&&Math.abs(record[k]-OEM_STC_CHECKS[record.model][i])<1e-8);
 const isRec=norm(record.maker)==='rec solar pte. ltd.'&&Object.hasOwn(OEM_REC_STC_CHECKS,String(record.model))&&
  source.link===OEM_REC_FAMILY&&stcSix.every((k,i)=>numeric(record[k])&&Math.abs(record[k]-OEM_REC_STC_CHECKS[record.model][i])<1e-8);
 const checked=isLongi||isRec;
 if(isLongi)f('OEM_STC_TRANSCRIPTION_6_FIELDS_MATCH_PRELIMINARY_V05');
 if(isRec)f('OEM_STC_TRANSCRIPTION_6_FIELDS_MATCH_REC_JUNE_2026_V7');
 // A complete calibrated SDM plus design approvals cannot be inferred from five-point STC data.
 const mandatorySDM=['ILrefA','I0refA','RsRefOhm','RshRefOhm','aRefV','alphaIscAperC','EgRefEv','dEgdTPerK'];
 const completeSDM=mandatorySDM.every(k=>numeric(record[k])&&(k==='RsRefOhm'||k==='dEgdTPerK'||k==='alphaIscAperC'||record[k]>0));
 return {id:String(record.id??''),maker:String(record.maker??''),model:String(record.model??''),validSTC,hasModelCoefficients:completeSDM,
   oemSTCTranscriptionChecked:checked,qualifiedForProduction:false,source,flags,
   powerProductDeltaPct:validSTC?100*(record.vmp*record.imp/record.w-1):null,
   qualification:'NOT_QUALIFIED_FOR_PRODUCTION',warning:'Record is a catalogue index only. OEM listing, revision, temperature coefficients, SDM parameter origin, cell tech, DC system voltage and input limits require independent verification.'};
}
export function auditCatalog(catalog){
 if(!catalog||!Array.isArray(catalog.models))throw Error('Expected canonical models array');
 const models=catalog.models;
 const counts=new Map();
 for(const r of models){const key=norm(r.maker)+'|'+norm(r.model);counts.set(key,(counts.get(key)||0)+1)}
 const summary={total:models.length,modelNamesDistinct:counts.size,repeatedNameRows:0,sourceFieldBlank:0,sourceNotExternalLink:0,linkedSources:0,invalidStcRows:0,powerMismatchRows:0,stcTranscriptionCheckedRows:0,sdmCoefficientCompleteRows:0,qualifiedProductionRows:0};
 const anomalySamples=[],checkedModels=[],makerSet=new Set();
 for(let i=0;i<models.length;i++){
  const r=models[i],key=norm(r.maker)+'|'+norm(r.model);makerSet.add(norm(r.maker));
  const a=assessRecord(r,counts.get(key));
  if(counts.get(key)>1)summary.repeatedNameRows++;
  if(!a.source.sourcePresent)summary.sourceFieldBlank++;
  if(a.source.sourcePresent&&!a.source.link)summary.sourceNotExternalLink++;
  if(a.source.link)summary.linkedSources++;
  if(!a.validSTC)summary.invalidStcRows++;
  if(a.flags.includes('PMP_VMP_IMP_DISCREPANCY_ABOVE_7_PERCENT'))summary.powerMismatchRows++;
  if(a.oemSTCTranscriptionChecked){summary.stcTranscriptionCheckedRows++;checkedModels.push(a.model)}
  if(a.hasModelCoefficients)summary.sdmCoefficientCompleteRows++;
  if(!a.validSTC||a.flags.includes('PMP_VMP_IMP_DISCREPANCY_ABOVE_7_PERCENT')||counts.get(key)>1){if(anomalySamples.length<250)anomalySamples.push({row:i+1,id:a.id,maker:a.maker,model:a.model,flags:a.flags.filter(f=>!f.startsWith('SOURCE_'))})}
 }
 summary.manufacturerLabelsDistinct=makerSet.size;
 return {version:QUALITY_VERSION,catalogOrigin:catalog.origin||'',declaredTotal:catalog.total??null,catalogSHA256:catalog.sha256||'',summary,checkedModels,anomalySamples,
  methodology:['Strict numeric positive STC fields','Voc > Vmp and Isc > Imp','Absolute |Vmp*Imp/Pmp - 1| above 7% is an audit-only anomaly threshold','Normalized case/whitespace manufacturer+model duplicate detection','Source links are references only, not evidence of reviewed datasheets','Eight LONGi Hi-MO 7 preliminary V05 entries and three REC Alpha Pure-RX June 2026 V7 entries individually compared against six manufacturer STC table values','No catalogue record automatically qualifies for detailed physics simulation']};
}
export function searchCatalog(catalog,phrase,limit=35){
 const q=norm(phrase);if(q.length<2)return [];
 const models=catalog.models||[],found=[];
 for(const r of models){if(norm(r.maker+' '+r.model+' '+r.id).includes(q)){found.push(r);if(found.length>=limit)break}}
 return found;
}
