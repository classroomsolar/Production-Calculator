/** Batch 1—lazy read-only qualification gate. No automatic product qualification. */
import {auditCatalog,assessRecord,searchCatalog,sourceAssessment} from './pv-catalog-qualification.js';
import {sha256Hex,validateSamOverlay} from './sam-cec-reference-overlay.js';
const byId=id=>document.getElementById(id);
const esc=x=>String(x??'').replace(/[&<>"']/g,k=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[k]));
const fmt=x=>Number(x||0).toLocaleString();
const panel=byId('pv15Section');
if(!panel)throw Error('PV production panel required for read-only catalogue qualification');
const tabs=panel.querySelector('.pv15-tabs');
if(!tabs)throw Error('PV production navigation missing');
const tab=document.createElement('button');tab.type='button';tab.dataset.catalog='quality';tab.textContent='Equipment data qualification · Batch 1';tabs.appendChild(tab);
const el=document.createElement('section');el.id='pvCatalogQuality';el.className='catalog-gate';el.hidden=true;
el.innerHTML=`<div class="catalog-banner"><strong>Engineering Master Database: READ ONLY</strong><p>Each product is indexed, NOT automatically approved for design. A catalog nameplate entry is not a calibrated PVsyst/CEC/PySAM five-parameter model. No catalogue fields are edited here.</p></div>
 <div class="catalog-actions"><button type="button" id="catalogLoad">Load &amp; audit full PV module index</button><button type="button" id="catalogExport" disabled>Export audit CSV</button><button type="button" id="catalogEvidence" disabled>Export audit JSON</button></div>
 <p class="catalog-status" id="catalogStatus" role="status" aria-live="polite">No catalogue loaded. All 26,000 records will be examined only when requested.</p>
 <div id="catalogSummary" class="catalog-summary"></div>
 <div id="samReferenceSummary" class="catalog-summary" role="status" aria-live="polite"></div>
 <p><a id="samReferenceAuditFile" href="./sam-cec-manufacturer-crosscheck-26000.csv" target="_blank" rel="noopener noreferrer" hidden>Download full 26,000-row SAM CEC reference comparison CSV</a></p>
 <label class="catalog-search-label">Find module by manufacturer, model or ID<input type="search" id="catalogSearch" disabled placeholder="e.g. LONGi LR7-72HGD-585M" autocomplete="off"></label>
 <div id="catalogMatches"></div><div id="catalogDetail"></div>
 <div class="catalog-disclaimer">Qualification criteria: positive numeric STC ratings; Voc &gt; Vmp; Isc &gt; Imp; Pmp versus Vmp × Imp consistency; source links and duplicate identities. The 7% discrepancy threshold flags data for review only. Verified temperature coefficients, module certifications, reverse-current protection, detailed five-parameter SDM and exact source revision must be separately established before production-model acceptance.</div>`;
panel.appendChild(el);
const state={catalog:null,audit:null,selected:null,sam:null,loading:false};
function show(){
 for(const x of panel.querySelectorAll('[data-pv15], [data-pv17]'))x.classList.remove('active');
 for(const id of ['pv15StringForm','pv15YieldForm','pv15AuditForm','pv17Lab','pv15Result']){const node=byId(id);if(node)node.hidden=true}
 tab.classList.add('active');el.hidden=false;
}
tab.addEventListener('click',show);
for(const b of panel.querySelectorAll('[data-pv15], [data-pv17]'))b.addEventListener('click',()=>{el.hidden=true;tab.classList.remove('active')});
const cards=[['total','Records inspected'],['manufacturerLabelsDistinct','Manufacturer labels'],['sourceFieldBlank','Blank sources'],['sourceNotExternalLink','Internal-only sources'],['invalidStcRows','Invalid STC rows'],['powerMismatchRows','7% STC mismatches'],['repeatedNameRows','Rows sharing make/model'],['stcTranscriptionCheckedRows','Manufacturer six-field STC table matches'],['sdmCoefficientCompleteRows','Complete diode parameter rows'],['qualifiedProductionRows','Automatically qualified products']];
function summaryMarkup(summary){return `<div class="catalog-stats">${cards.map(([k,name])=>`<div><small>${esc(name)}</small><strong>${fmt(summary[k])}</strong></div>`).join('')}</div><p class="catalog-summary-warning">Zero products are automatically approved. An OEM URL does not prove the model, temperature coefficients or inverter compatibility.</p>`}
async function load(){
 if(state.loading)return;state.loading=true;byId('catalogLoad').disabled=true;byId('catalogStatus').textContent='Reading original PV_MODULES catalogue and checking individual records. No edits or server uploads.';
 try{
  const response=await fetch('./master_pv_modules.json',{cache:'no-cache'});
  if(!response.ok)throw Error('Database HTTP '+response.status);
  const canonicalText=await response.text();
  const canonical=JSON.parse(canonicalText);
  const a=auditCatalog(canonical);
  state.sam=null;
  try{
   const rx=await fetch('./sam-cec-reference-overlay.json',{cache:'no-cache'});
   if(!rx.ok)throw Error('HTTP '+rx.status);
   const overlay=await rx.json();
   state.sam=validateSamOverlay(canonical,overlay,await sha256Hex(canonicalText));
   const st=state.sam.summary;
   byId('samReferenceSummary').innerHTML=`<p><strong>Read-only NLR/SAM CEC catalogue comparison:</strong> ${fmt(st.SAM_STC_5_FIELD_EXACT_0p01)} five-field STC matches (±0.01); ${fmt(st.SAM_STC_REVIEW_WITHIN_2PCT)} additional matches within 2% screening tolerance; ${fmt(st.SAM_STC_DISCREPANCY_OVER_2PCT)} discrepancies; ${fmt(st.SAM_AMBIGUOUS)} ambiguous; ${fmt(st.UNMATCHED)} unmatched. <strong>ZERO OEM products qualified by this exercise.</strong> This is a fitted SAM reference, not a reviewed manufacturer datasheet or product certification.</p>`;
   byId('samReferenceAuditFile').hidden=false;
  }catch(samError){byId('samReferenceSummary').textContent='Independent SAM comparison unavailable or mismatched; canonical STC audit remains usable. '+samError.message;byId('samReferenceAuditFile').hidden=true;}

  if(!Array.isArray(canonical.models)||canonical.models.length!==canonical.total)throw Error('Catalogue declared total and parsed record count differ');
  state.catalog=canonical;state.audit=a;
  byId('catalogSummary').innerHTML=summaryMarkup(a.summary);
  byId('catalogSearch').disabled=false;
  byId('catalogExport').disabled=false;byId('catalogEvidence').disabled=false;
  byId('catalogStatus').textContent=`Full read-only audit finished: ${fmt(a.summary.total)} records. Catalogue identity: ${a.catalogOrigin}. Product qualification is NOT established.`;
 }catch(e){byId('catalogStatus').textContent='AUDIT FAILED: '+e.message;state.catalog=null;state.audit=null}
 finally{state.loading=false;byId('catalogLoad').disabled=false}
}
function checkedStats(r){const q=assessRecord(r);const sam=state.sam?.statusForId(r.id)||'REFERENCE_NOT_LOADED';return `<div class="catalog-detail"><h3>${esc(r.maker)} — ${esc(r.model)}</h3><p>Catalog record: <code>${esc(r.id)}</code> · STC data: ${q.validSTC?'Basic numeric checks pass':'INVALID/INCOMPLETE'} · Manufacturer qualification: <b>NOT VERIFIED</b></p><table><thead><tr><th>Pmp W</th><th>Voc V</th><th>Vmp V</th><th>Isc A</th><th>Imp A</th><th>Efficiency %</th></tr></thead><tbody><tr>${['w','voc','vmp','isc','imp','efficiency'].map(k=>`<td>${esc(r[k])}</td>`).join('')}</tr></tbody></table><p>Source classification: ${esc(q.source.sourceKind)} ${q.source.link?`· <a href="${esc(q.source.link)}" target="_blank" rel="noopener noreferrer">Open referenced datasheet/link</a>`:''}</p><p>Flags: ${esc(q.flags.join('; ')||'No basic STC issue flagged')}</p><p>${q.oemSTCTranscriptionChecked?(q.flags.includes('OEM_STC_TRANSCRIPTION_6_FIELDS_MATCH_REC_JUNE_2026_V7')?'Six STC values matched a REC manufacturer-hosted June 2026 V7 table. This does NOT qualify the model for production physics, product listing or construction design.':'Six STC values matched the LONGi manufacturer-hosted preliminary V05 table. This does NOT qualify the model for production physics, product listing or construction design.'):'No independent manufacturer transcription check recorded for this model.'}</p><p><strong>SAM CEC source-library crosscheck:</strong> ${esc(sam)}. A SAM match is not manufacturer approval, listing or calibrated diode-model qualification.</p><p class="catalog-warning">Missing from the canonical schema: verified module temperature coefficients, module voltage limits and detailed diode-model parameters. This record cannot be selected as an approved input to the detailed yield engine.</p></div>`}
function results(){const q=byId('catalogSearch').value.trim();if(!state.catalog||q.length<2){byId('catalogMatches').textContent='Enter two or more characters';byId('catalogDetail').textContent='';return}
 const matches=searchCatalog(state.catalog,q,30);
 byId('catalogMatches').innerHTML=`<p>Displaying up to 30 indexed matches (${matches.length} shown). Selection opens a READ-ONLY record, not a production-model load.</p>${matches.map((r,i)=>`<button type="button" class="catalog-model" data-catalog-row="${i}">${esc(r.maker)} · ${esc(r.model)} · ${esc(r.w)} W</button>`).join('')}`;
 byId('catalogMatches').querySelectorAll('[data-catalog-row]').forEach(b=>b.addEventListener('click',()=>{const chosen=matches[Number(b.dataset.catalogRow)];state.selected=chosen;byId('catalogDetail').innerHTML=checkedStats(chosen)}));
}
byId('catalogLoad').addEventListener('click',load);
byId('catalogSearch').addEventListener('input',results);
function csv(rows){const val=x=>{let s=String(x??'');if(/^[=+@\t\r]/.test(s))s="'"+s;return /[",\n\r]/.test(s)?'"'+s.replaceAll('"','""')+'"':s};return rows.map(r=>r.map(val).join(',')).join('\r\n')}
function download(name,text,mime){const blob=new Blob([text],{type:mime}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),10000)}
byId('catalogExport').addEventListener('click',()=>{if(!state.audit)return;const h=['Source row','Catalog ID','Manufacturer','Model','Issue flags'];download('PV_MASTER_CATALOG_AUDIT_250_FIRST_ANOMALIES.csv',csv([h,...state.audit.anomalySamples.map(r=>[r.row,r.id,r.maker,r.model,r.flags.join('; ')])]),'text/csv')});
byId('catalogEvidence').addEventListener('click',()=>{if(state.audit)download('PV_MASTER_CATALOG_QUALIFICATION_AUDIT.json',JSON.stringify({...state.audit,reportScope:'Full catalogue counts; first 250 selected anomaly records. No original equipment data exported as a new master.',approval:'NOT QUALIFIED'},null,2),'application/json')});
window.PVCatalogAuditSheets=()=>{if(!state.audit)return [];return [['PV_CATALOG_BATCH1_QA',[['Metric','Count'],...Object.entries(state.audit.summary).filter(([,v])=>typeof v==='number')]],['PV_CATALOG_ANOMALIES',[['Source row','Catalog ID','Manufacturer','Model','Issue flags'],...state.audit.anomalySamples.map(x=>[x.row,x.id,x.maker,x.model,x.flags.join('; ')])]]];};
window.PVCatalogAuditReportHTML=()=>state.audit?`<h2>PV Master Database — read-only Batch 1 audit (not equipment approval)</h2><table>${Object.entries(state.audit.summary).filter(([,v])=>typeof v==='number').map(([k,v])=>`<tr><td>${esc(k)}</td><td>${fmt(v)}</td></tr>`).join('')}</table><p>Independent production/model qualification: NOT established. Source register and manufacturer datasheet audits required.</p>`:'';
window.PVCatalogQualificationState=()=>({audit:state.audit,sam:state.sam?.summary||null,selected:state.selected?.id||null});
