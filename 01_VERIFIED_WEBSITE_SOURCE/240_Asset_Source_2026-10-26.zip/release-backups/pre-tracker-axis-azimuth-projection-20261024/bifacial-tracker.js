/** Horizontal single-axis tracker / periodic 2-D bifacial research coupling.
 * Irradiance model is the same bounded fixed-tilt ray-screen evaluated at moving tracker rotations.
 * The 0.5-degree view-factor quantization is an approximation that must be benchmarked for each project.
 */
import {trackerAt,validateTrackerConfig} from './tracker-physics.js';
import {prepareBifacialGeometry,irradianceBifacialHour,validateBifacialConfig,inspectAnnualChronology} from './bifacial-vf.js';
const near=(a,b)=>Math.abs(a-b)<1e-10;
const R=Math.PI/180;
export function validateBifacialTracker(bifacial,tracking){
 const c=validateBifacialConfig(bifacial);
 if(!tracking||typeof tracking!=='object')throw Error('Tracker geometry/control required');
 if(tracking.axisTilt!==0||tracking.crossAxisTilt!==0)throw Error('Bifacial 2D tracker mode currently requires level, horizontal axis (axisTilt=crossAxisTilt=0)');
 const t=validateTrackerConfig({...tracking,widthM:c.widthM,pitchM:c.pitchM});
 if(t.minAngle<-75||t.maxAngle>75)throw Error('2D tracker model is bounded to ±75 degrees');
 if(c.heightM<=.5*c.widthM*Math.sin(Math.max(Math.abs(t.minAngle),Math.abs(t.maxAngle))*R)+.02)throw Error('Tracker rotational clearance insufficient at allowed angles');
 return {bifacial:c,tracking:t};
}
export function simulateBifacialTrackerYear(prepared,bifacial,tracking){
 const chronology=inspectAnnualChronology(prepared);
 const {bifacial:c,tracking:t}=validateBifacialTracker(bifacial,tracking);
 const cache=new Map(),tot={frontKWhM2:0,backKWhM2:0,backEffectiveKWhM2:0,totalEffectiveKWhM2:0,frontDirectKWhM2:0,frontSkyKWhM2:0,frontGroundKWhM2:0,backSkyKWhM2:0,backGroundKWhM2:0},vf={frontView:{sky:0,ground:0,row:0},backView:{sky:0,ground:0,row:0}};
 const monthly=Array.from({length:12},(_,i)=>({month:i+1,frontKWhM2:0,backKWhM2:0,effectiveKWhM2:0}));
 const hourly=[];let prev=null,daylight=0,backtracked=0,weatherClosureFlaggedHours=0;
 for(const row of prepared){
  const now=Date.parse(row.timestamp_utc);if(!Number.isFinite(now)||prev!==null&&now-prev!==3600000)throw Error('Non-contiguous UTC weather');prev=now;
  const zen=row._pos?.zenith,azi=row._pos?.azimuth;
  if(!Number.isFinite(zen)||!Number.isFinite(azi))throw Error('Upstream solar geometry required');
  const p=trackerAt(zen,azi,t);
  let v={front:0,back:0,backEffective:0,effective:0,frontBeam:0,frontDiffuseSky:0,frontGround:0,backDiffuseSky:0,backGround:0,shadedFrontFraction:0,shadedGroundFraction:0};
  if(!p.night){
   const dir=p.surfaceAzimuth<180?90:270;
   const quantizedAngle=Math.round(p.surfaceTilt*2)/2;
   const key=quantizedAngle+'|'+dir;
   if(!cache.has(key))cache.set(key,prepareBifacialGeometry({...c,tiltDeg:quantizedAngle,frontAzimuthDeg:dir}));
   const g=cache.get(key);
   const h={zenithDeg:zen,solarAzimuthDeg:azi,dni:row.dni_wm2,dhi:row.dhi_wm2,ghi:row.ghi_wm2};
   v=irradianceBifacialHour(g,h);daylight++;
   if(Math.abs(p.backtrackingCorrectionDeg)>1e-6)backtracked++;weatherClosureFlaggedHours+=v.weatherClosureFlag?1:0;
   for(const side of ['frontView','backView'])for(const key of ['sky','ground','row'])vf[side][key]+=g.geometry[side][key];
  }
  tot.frontKWhM2+=v.front/1000;tot.backKWhM2+=v.back/1000;tot.backEffectiveKWhM2+=v.backEffective/1000;tot.totalEffectiveKWhM2+=v.effective/1000;tot.frontDirectKWhM2+=v.frontBeam/1000;tot.frontSkyKWhM2+=v.frontDiffuseSky/1000;tot.frontGroundKWhM2+=v.frontGround/1000;tot.backSkyKWhM2+=v.backDiffuseSky/1000;tot.backGroundKWhM2+=v.backGround/1000;
  const m=monthly[new Date(now).getUTCMonth()];m.frontKWhM2+=v.front/1000;m.backKWhM2+=v.back/1000;m.effectiveKWhM2+=v.effective/1000;
  hourly.push({timestamp_utc:row.timestamp_utc,tracker_angle_deg:p.trackerTheta,tracker_tilt_deg:p.surfaceTilt,tracker_azimuth_deg:p.surfaceAzimuth,front_wm2:v.front,back_wm2:v.back,back_effective_wm2:v.backEffective,effective_wm2:v.effective,front_direct_wm2:v.frontBeam,front_sky_wm2:v.frontDiffuseSky,front_ground_wm2:v.frontGround,back_sky_wm2:v.backDiffuseSky,back_ground_wm2:v.backGround,front_shaded_fraction:v.shadedFrontFraction,ground_shaded_fraction:v.shadedGroundFraction,weather_closure_abs_wm2:v.weatherClosureWm2??0,weather_closure_flag:v.weatherClosureFlag??false});
 }
 tot.bifacialOpticalGainPct=tot.frontKWhM2?100*tot.backEffectiveKWhM2/tot.frontKWhM2:0;
 if(Math.abs(tot.frontKWhM2+tot.backEffectiveKWhM2-tot.totalEffectiveKWhM2)>1e-6)throw Error('Tracker bifacial annual energy balance error');
 for(const side of ['frontView','backView'])for(const k of ['sky','ground','row'])vf[side][k]=daylight?vf[side][k]/daylight:0;
 return {hours:prepared.length,chronology,config:c,tracking:t,geometry:{gcr:c.widthM/c.pitchM,...vf,representative:'Arithmetic mean of daylight-hour view factors',groundSkyViewMean:null},annual:tot,monthly,hourly,warnings:[
  ...(chronology.exactCalendarYearUTC?[]:['WARNING: 8760/8784-hour study is not aligned to one UTC calendar year; review EPW/source offset and monthly partitioning.']),
  'RESEARCH SCREEN: HORIZONTAL single-axis tracking only (level ground; axisTilt and crossAxisTilt exactly zero). Axis-end effects, row elevation variations, terrain, torque tube and wind stow are omitted.',
  `Moving-row view factors quantized to 0.5-degree tilt bins (${cache.size} cache geometries); beam incidence uses quantized plane orientation. Independent pvlib/field parity not established.`,
  'Rear optical irradiance uses isotropic sky, periodic ground, Lambertian albedo and user-supplied structural loss. No cell/mismatch/AC-yield conversion.',
  `Upstream GHI/DNI/DHI closure flagged ${weatherClosureFlaggedHours} of ${prepared.length} hours (same physical direct+diffuse components used for POA).`,
  'Tracker rotation/backtracking is sourced from the existing Batch 3 2D geometry screen; no plant controller or stow logic is included.'
 ],trackerDiagnostics:{daylightHours:daylight,backtrackedHours:backtracked,quantizedOrientations:cache.size},weatherDiagnostics:{closureFlaggedHours:weatherClosureFlaggedHours}};
}
