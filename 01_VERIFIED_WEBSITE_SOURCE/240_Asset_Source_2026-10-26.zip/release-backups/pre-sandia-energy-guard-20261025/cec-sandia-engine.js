/** Batch 2: published Sandia / CEC inverter curve, independent from the v1.7 PVWatts baseline.
 * Units: all powers W, input voltage V; output import is negative AC W at night.
 * Formula: Sandia PVPMC and pvlib.inverter.sandia.
 * Equipment records sourced to an exact public SAM Git blob; not OEM certification.
 */
export const CEC_MODEL_VERSION = 'batch2-sandia-1.0';
const finite = v => typeof v === 'number' && Number.isFinite(v);
const mandatory = ['Vac','Pso','Paco','Pdco','Vdco','C0','C1','C2','C3','Pnt','Vdcmax','Idcmax','Mppt_low','Mppt_high'];
export function validateCecRecord(model) {
  if (!model || typeof model.name !== 'string' || !model.name.trim()) throw Error('Model name required');
  for (const k of mandatory) if (!finite(model[k])) throw Error(`${k} must be a finite number`);
  for (const k of ['Vac','Paco','Pdco','Vdco','Vdcmax','Idcmax','Mppt_low','Mppt_high'])
    if(model[k] <= 0) throw Error(`Positive ${k} required`);
  if (model.Pso < 0 || model.Pnt < 0) throw Error('Consumption ratings must be nonnegative');
  if(model.Pdco <= model.Pso) throw Error('Pdco must exceed Pso');
  if(model.Mppt_high <= model.Mppt_low || model.Mppt_high > model.Vdcmax) throw Error('Invalid published voltage limits');
  return true;
}
export function sandiaCecInverter(model,dcPowerW,dcVoltageV,{enforceVoltage=true,enforceCurrent=true}={}) {
  validateCecRecord(model);
  if(!finite(dcPowerW) || dcPowerW < 0) throw Error('DC input power must be nonnegative watts');
  if(!finite(dcVoltageV) || dcVoltageV <= 0) throw Error('DC input voltage must be positive volts');
  const flags=[];
  const outsideMppt=dcVoltageV < model.Mppt_low || dcVoltageV > model.Mppt_high;
  const beyondMax=dcVoltageV>model.Vdcmax;
  const currentA=dcPowerW / dcVoltageV;
  // CEC Idcmax is library model parameter: not proof of hardware input-current listing.
  const currentOver=currentA > model.Idcmax*(1+1e-12);
  if(outsideMppt)flags.push('OUTSIDE_CEC_MPPT_RANGE');
  if(beyondMax)flags.push('EXCEEDS_CEC_MAX_DC_VOLTAGE');
  if(currentOver)flags.push('ABOVE_CEC_LIBRARY_IDCMAX');
  if(enforceVoltage && outsideMppt && dcPowerW>0) return {status:'SCREEN_FAILED',acPowerW:null,dcCurrentA:currentA,flags,warning:'Voltage outside published CEC MPPT data range: do not extrapolate'};
  if(enforceCurrent && currentOver && dcPowerW>0) return {status:'SCREEN_FAILED',acPowerW:null,dcCurrentA:currentA,flags,warning:'DC current above CEC library Idcmax; not necessarily an OEM absolute input current rating'};
  if(dcPowerW < model.Pso) return {status:'MODEL_EVALUATED',acPowerW:-Math.abs(model.Pnt),unclippedAcPowerW:null,dcCurrentA:currentA,clippedW:0,conversionW:0,flags,warning:'Negative AC watts represent inverter night/standby import'};
  const dV=dcVoltageV-model.Vdco;
  const A=model.Pdco*(1+model.C1*dV);
  const B=model.Pso*(1+model.C2*dV);
  const C=model.C0*(1+model.C3*dV);
  if(![A,B,C].every(Number.isFinite) || A<=B) throw Error('Sandia curve singular at selected voltage');
  const offset=dcPowerW-B;
  const raw=(model.Paco/(A-B)-C*(A-B))*offset+C*offset*offset;
  if(!finite(raw)) throw Error('Nonfinite Sandia AC result');
  const acPowerW=Math.min(model.Paco,raw);
  const clippedW=Math.max(0,raw-model.Paco);
  return {status:'MODEL_EVALUATED',acPowerW,unclippedAcPowerW:raw,clippedW,conversionW:dcPowerW-acPowerW-clippedW,dcCurrentA:currentA,flags,warning:'CEC/Sandia fitted inverter curve. IEC/UL listing, product revision, MPPT input channels, ambient derate and OEM limits unverified.'};
}
export function sandiaPowerCurve(model,{samples=25,voltageV=model.Vdco}={}) {
  validateCecRecord(model);
  if(!Number.isInteger(samples) || samples<2 || samples>500) throw Error('Curve size 2–500');
  const maxPower=Math.min(model.Pdco*1.15,model.Idcmax*voltageV);
  return Array.from({length:samples},(_,i)=>{
    const pdc=i/(samples-1)*maxPower;
    const x=sandiaCecInverter(model,pdc,voltageV,{enforceCurrent:false});
    return {pdcW:pdc,pacW:x.acPowerW,efficiencyPct:pdc>0&&x.acPowerW>=0?100*x.acPowerW/pdc:null};
  });
}
