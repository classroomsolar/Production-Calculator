/** Batch 2 optional annual CEC/Sandia inverter feasibility / energy comparison.
 * Does not alter v1.7's original hourly computation; inputs are its verified hourly DC stream.
 * Every published CEC voltage and current envelope must pass for annual yield to be accepted.
 * This does not re-solve the module I-V curve when CEC MPPT voltage limits differ.
 */
import {sandiaCecInverter,validateCecRecord} from './cec-sandia-engine.js';
import {cableResistance} from './pv-detailed-v17.js';
const finite=Number.isFinite;
const assert=(yes,msg)=>{if(!yes)throw Error(msg)};
export function compareAnnualCec({hourly,cec,plant,upstreamProvenance='unknown',requireFullYear=true}) {
  validateCecRecord(cec);
  assert(Array.isArray(hourly)&&hourly.length>0,'Original detailed hourly DC result required');
  if(requireFullYear)assert([8760,8784].includes(hourly.length),'Only complete year can be labeled annual');
  const {array,acCable,transformer,losses,inverter}=plant||{};
  assert(array&&acCable&&transformer&&losses&&inverter,'Original v1.7 configuration unavailable');
  const count=array.inverterCount,nModules=array.modulesPerString;
  assert(Number.isInteger(count)&&count>0&&Number.isInteger(nModules)&&nModules>0,'Array topology invalid');
  const originalACkW=inverter.pacKW*count,cecACkW=cec.Paco*count/1000;
  // Never silently compare systems with a different AC nameplate or line voltage.
  const compatiblePaco=Math.abs(cecACkW-originalACkW)<=Math.max(.01,originalACkW*.005);
  const compatibleVac=Math.abs(cec.Vac-acCable.voltageLL)<=Math.max(.1,cec.Vac*.005);
  const blocks=[];const summed=[];let totalBlocked=0,prev=null,nightHours=0;
  const rac=cableResistance(acCable,false);
  for(let idx=0;idx<hourly.length;idx++){
    const h=hourly[idx],ts=Date.parse(h.timestamp_utc);
    assert(finite(ts),'Invalid hourly UTC time');
    if(prev!==null)assert(ts-prev===3600000,'Missing/duplicate UTC hour in detailed source');
    prev=ts;
    const pdc=h.inverter_dc_kw,volts=h.module_vmp_v*nModules;
    assert(finite(pdc)&&pdc>=0&&finite(volts)&&volts>=0,'Invalid hourly DC stream');
    const perInverterW=1000*pdc/count;
    const off=perInverterW<=cec.Pso;
    const voltage=off?cec.Vdco:volts;
    const op=sandiaCecInverter(cec,perInverterW,voltage);
    if(op.status==='SCREEN_FAILED'){
      totalBlocked++;
      if(blocks.length<200)blocks.push({timestamp_utc:h.timestamp_utc,dcKW:pdc,dcVoltageV:voltage,flags:op.flags});
      continue;
    }
    if(op.acPowerW===null||!finite(op.acPowerW))throw Error('CEC model returned invalid AC output');
    if(off)nightHours++;
    const inverterACkW=op.acPowerW*count/1000;
    const currentA=Math.abs(inverterACkW)*1000/(Math.sqrt(3)*acCable.voltageLL*acCable.powerFactor);
    const acLosskW=3*currentA*currentA*rac/1000;
    // Output may be negative at night; AC distribution losses then increase import.
    const afterAcKW=inverterACkW-acLosskW;
    const transformerOn=transformer.energization==='always'||afterAcKW>0;
    const loadKW=transformer.loadLossRatedKW*(Math.abs(afterAcKW)/(transformer.ratedKVA*acCable.powerFactor))**2;
    const p0KW=transformerOn?transformer.noLoadKW:0;
    const beforeAvail=afterAcKW-loadKW-p0KW;
    const afterAvail=beforeAvail>0?beforeAvail*(1-losses.availabilityLossPct/100):beforeAvail;
    const cap=losses.exportCapKW;
    const exportKW=Math.max(0,cap===null||cap===undefined?afterAvail:Math.min(cap,afterAvail));
    const importKW=Math.max(0,-afterAvail),curtailmentKW=Math.max(0,afterAvail-exportKW);
    summed.push({timestamp_utc:h.timestamp_utc,dc_input_kw:pdc,dc_voltage_v:voltage,cec_ac_kw:inverterACkW,
      ac_cable_loss_kw:acLosskW,transformer_loss_kw:loadKW+p0KW,poi_export_kw:exportKW,grid_import_kw:importKW,curtailed_kw:curtailmentKW,
      cec_conversion_loss_kw:Math.max(0,pdc-inverterACkW),cec_night_import_kw:Math.max(0,-inverterACkW)});
  }
  if(blocks.length) return {status:'NOT_VALID_FOR_ANNUAL_YIELD',accepted:false,reason:'CEC inverter DC current or MPPT operating envelope exceeded. Re-optimize electrical topology; no extrapolated annual yield.',
    checkedHours:hourly.length,firstViolations:blocks,violationsRecorded:totalBlocked,model:cec.name,acRatingCompatible:compatiblePaco,acVoltageCompatible:compatibleVac,
    source:upstreamProvenance};
  // Separate AC nameplate and VAC variants cannot be called a like-for-like equipment-model comparison.
  if(!compatiblePaco||!compatibleVac)return {status:'NOT_LIKE_FOR_LIKE',accepted:false,reason:'Compared CEC inverter is not the same AC nameplate and nominal grid-voltage class as original v1.7 inverter. Study is blocked until plant config is matched.',
    model:cec.name,originalACkW,cecACkW,originalVac:acCable.voltageLL,cecVac:cec.Vac,checkedHours:hourly.length};
  const sum=k=>summed.reduce((v,r)=>v+r[k],0);
  const totalExport=sum('poi_export_kw'),totalImport=sum('grid_import_kw'),totalDC=sum('dc_input_kw');
  const totalAc=sum('cec_ac_kw');const totCable=sum('ac_cable_loss_kw'),totTx=sum('transformer_loss_kw'),totCurtail=sum('curtailed_kw');
  const totalAvail= summed.reduce((v,h)=>v+Math.max(0,h.cec_ac_kw-h.ac_cable_loss_kw-h.transformer_loss_kw)*losses.availabilityLossPct/100,0);
  // Approximate conservation tolerance handles positive availability; nighttime is separate import.
  const net=totalExport-totalImport;
  assert(finite(net),'Energy reconciliation overflow');
  const referenceResult={status:'EXPERIMENTAL_CEC_MODEL_ACCEPTED',accepted:true,source:upstreamProvenance,model:cec.name,sourceStatus:'HISTORICAL CEC FIT, NOT CURRENT OEM APPROVAL',
   nHours:hourly.length,nightHours,annual:{dcInputKWh:totalDC,inverterAcNetKWh:totalAc,poiExportKWh:totalExport,poiImportKWh:totalImport,netPoiKWh:net,
     acCableLossKWh:totCable,transformerLossKWh:totTx,curtailmentKWh:totCurtail,nominalAvailabilityKWh:totalAvail},
   priorAcNameplateKW:originalACkW,cecAcNameplateKW:cecACkW,annualHourly:summed,
   warnings:['Hourly DC input is produced by v1.7 module physics with its own MPPT constraints. CEC MPPT limits are separately screened but a different MPPT operating voltage does not trigger a new string I-V optimization.',
   'CEC coefficients are historical NLR/SAM fitted data, not current manufacturer approval. Thermal and grid-dependent inverter derating are absent.',
   'Exported and imported energy are shown separately. Nighttime CEC inverter consumption is not assumed to be zero.',
   'AC voltage and AC nameplate must match within 0.5% for the model substitution to be like-for-like.']};
  return referenceResult;
}
