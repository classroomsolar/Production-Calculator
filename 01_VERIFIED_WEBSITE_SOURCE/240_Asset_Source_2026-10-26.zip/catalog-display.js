/** Read-only catalogue search grouping: do NOT rewrite the 26,000-record source.
 * Group ONLY records having the same normalized make, model and exact five
 * STC nameplate values. Same model label with different power/electrical
 * parameters remains a distinct entry requiring source-revision review.
 */
const identity = value => String(value ?? '').trim().replace(/\s+/g, ' ').toUpperCase();
const rating = value => value === null || value === undefined || !Number.isFinite(Number(value)) ? 'UNSPECIFIED' : String(Number(value));
export function groupCatalogModels(records, maxResults=18) {
 if(!Array.isArray(records) || !Number.isInteger(maxResults) || maxResults<1 || maxResults>500)throw Error('Invalid catalogue search results');
 const byKey=new Map(),byName=new Map();
 for(const record of records) {
  if(!record || typeof record!=='object')continue;
  const name=identity(record.maker)+'\u0000'+identity(record.model);
  const key=name+'\u0000'+['w','voc','isc','vmp','imp'].map(k=>rating(record[k])).join('\u0000');
  let group=byKey.get(key);
  if(!group){group={record,ids:[],identicalRecords:0,modelNameHasDistinctRatings:false};byKey.set(key,group);byName.set(name,(byName.get(name)||0)+1)}
  group.identicalRecords++;
  if(record.id!==undefined&&group.ids.length<50)group.ids.push(record.id);
 }
 for(const [key,group] of byKey){const n=key.split('\u0000',2).join('\u0000');group.modelNameHasDistinctRatings=(byName.get(n)||0)>1;}
 return {totalRaw:records.length,totalDistinctElectricalListings:byKey.size,shown:[...byKey.values()].slice(0,maxResults)};
}
