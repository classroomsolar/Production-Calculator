/** Batch 4 true source-engine integration: Cable Thermal Studio ORIGINAL v3.6.2
 * Original 7 engine files retained byte-for-byte. This is a bounded frontend
 * for steady/cyclic/emergency thermal screening, NOT full IEC60287/60853 approval.
 */
import {BASE,DEFAULT_PROFILE,steady,cyclic,emergency} from './thermal-v362/thermal-engine.mjs';
const root=document.getElementById('pv15Section');const byId=id=>document.getElementById(id);
if(root){
 const tabs=root.querySelector('.pv15-tabs'),anchor=byId('pv15Result');
 if(tabs&&anchor){
 tabs.insertAdjacentHTML('beforeend','<button type="button" data-thermal-b4="thermal">Original Cable Thermal Engine · B4</button>');
 const numberInputs=[
 ['load_a','Total circuit / loaded set current (A)',BASE.load_a],
 ['ambient_c','Undisturbed earth temperature (°C)',BASE.ambient_c],
 ['max_temp_c','Maximum permissible conductor temperature (°C)',BASE.max_temp_c],
 ['soil_rho_km_w','Soil thermal resistivity (K·m/W)',BASE.soil_rho_km_w],
 ['burial_depth_m','Burial depth to cable center (m)',BASE.burial_depth_m],
 ['cable_od_m','Cable outside diameter (m)',BASE.cable_od_m],
 ['r20_ohm_m','Conductor DC resistance at 20°C (Ω/m)',BASE.r20_ohm_m],
 ['alpha_per_c','Conductor resistance temperature coefficient (1/°C)',BASE.alpha_per_c],
 ['ac_factor','AC resistance multiplier (Rac/Rdc)',BASE.ac_factor],
 ['dielectric_w_m','Dielectric heat loss per cable (W/m)',BASE.dielectric_w_m],
 ['r_internal_km_w','Conductor–surface thermal resistance (K·m/W)',BASE.r_internal_km_w],
 ['r_dielectric_internal_km_w','Dielectric thermal path (K·m/W)',BASE.r_dielectric_internal_km_w],
 ['group_multiplier','Verified mutual soil-heating multiplier (dimensionless)',BASE.group_multiplier],
 ['phases','Loaded cable conductors / phases',BASE.phases]
 ];
 const inputs=numberInputs.map(([k,l,v])=>`<label class="b4thermal-field">${l}<input id="b4th_${k}" type="number" step="any" value="${v}" required></label>`).join('');
 const panel=`<section id="thermalB4" class="b4thermal-section" hidden><h3>Cable Thermal Studio v3.6.2 — original source calculation kernel</h3>
 <p><strong>Original code imported byte-for-byte</strong> from your Cable Thermal Studio archive. The retained original 537-case runner passed locally. This is a construction-data <strong>SCREENING</strong> module, not an IEC 60287/60853 certificate, complete Neher–McGrath solver, OCPD approval or replacement of the original standalone workspace.</p>
 <label class="b4thermal-field">Cable manufacturer, model and source revision (required for engineering approval, not computation)<input id="b4th_provenance" type="text" placeholder="Manufacturer, catalog, construction revision and verification reference"></label>
 <div class="b4thermal-grid">${inputs}</div>
 <p><label>Study mode<select id="b4th_mode"><option value="steady">Continuous rating and conductor temperature</option><option value="cyclic">24-hour cyclic thermal RC screening</option><option value="emergency">Emergency short-time thermal RC screening</option></select></label></p>
 <div class="b4thermal-grid"><label>Number of cyclic days (1–30)<input id="b4th_days" type="number" value="3" min="1" max="30"></label><label>Emergency circuit current (A)<input id="b4th_emergencyA" type="number" value="900" min="0"></label><label>Emergency duration (hours)<input id="b4th_hours" type="number" value="2" min="0.001" max="168" step="any"></label></div>
 <p class="b4thermal-notice">Reference case only: 500 A, 90°C limit, 25°C soil, 1 K·m/W resistivity, 2.2377 entered grouping multiplier. The cable model and physical grouping factor MUST be verified for any real study. Transient functions use an approximate four-node screening model.</p>
 <p><button type="button" id="b4th_run">Calculate original thermal engine</button> <button type="button" id="b4th_json" disabled>Export thermal source audit JSON</button></p>
 <p role="status" id="b4th_status">Original v3.6.2 reference fixture loaded; no engineering calculation yet.</p><div id="b4th_results"></div>
 <p class="b4thermal-notice">The separate Cable Thermal Studio maintains 93 database worksheets and additional soil networks, controls and reports. Their contents are NOT silently copied into this calculator. <a href="https://headless-vmwfmgemqxl-classroomsolar-140e.wix-site-host.com/" target="_blank" rel="noopener noreferrer">Open full public Cable Thermal Studio</a>.</p></section>`;
 anchor.insertAdjacentHTML('afterend',panel);
 const section=byId('thermalB4'),button=tabs.querySelector('[data-thermal-b4]'),status=byId('b4th_status'),content=byId('b4th_results'),exp=byId('b4th_json');
 for(const other of tabs.querySelectorAll('button:not([data-thermal-b4])'))other.addEventListener('click',()=>{section.hidden=true;button.classList.remove('active')});
 button.addEventListener('click',()=>{for(const id of ['pv15StringForm','pv15YieldForm','pv15AuditForm','pv17Lab','trackerB3','financeB5','bessB4','electricalB4','mismatchB3']){const el=byId(id);if(el)el.hidden=true}anchor.hidden=true;for(const x of tabs.querySelectorAll('button'))x.classList.remove('active');button.classList.add('active');section.hidden=false});
 let latest=null;
 function readBase(){const x={};for(const [k] of numberInputs){const inp=byId('b4th_'+k);if(!inp.value.trim())throw Error(`Missing ${k}`);const v=Number(inp.value);if(!Number.isFinite(v))throw Error(`Non-numeric ${k}`);x[k]=v}return x}
 function invalidate(){latest=null;exp.disabled=true;content.replaceChildren();status.textContent='Inputs changed — previous thermal rating invalidated. Rerun required.'}
 section.querySelectorAll('input,select').forEach(e=>e.addEventListener('input',invalidate));
 section.querySelectorAll('select').forEach(e=>e.addEventListener('change',invalidate));
 function tableFor(r){const t=document.createElement('table');t.className='b4thermal-table';const keys=['status','ampacity_a','conductor_temp_c','temperature_margin_c','utilization','external_t4_km_w','total_heat_w_m','peak_conductor_c','final_conductor_c','release_label','converged'];
  for(const k of keys)if(r[k]!==undefined){const tr=document.createElement('tr'),a=document.createElement('th'),b=document.createElement('td');a.textContent=k;b.textContent=typeof r[k]==='number'?Number(r[k].toFixed(6)).toString():String(r[k]);tr.append(a,b);t.append(tr)}
  return t;}
 byId('b4th_run').addEventListener('click',()=>{try{const input=readBase();const mode=byId('b4th_mode').value;let result;
   if(mode==='steady')result=steady(input);
   else if(mode==='cyclic'){const days=Number(byId('b4th_days').value);result=cyclic(input,{},DEFAULT_PROFILE,days)}
   else if(mode==='emergency'){const current=Number(byId('b4th_emergencyA').value),hours=Number(byId('b4th_hours').value);result=emergency(input,{},current,hours)}
   else throw Error('Unsupported thermal method');
   if(!result||typeof result.status!=='string')throw Error('Missing source engine result/status');
   latest={input,mode,sourceLabel:byId('b4th_provenance').value.trim(),result,modelId:'CABLE_THERMAL_STUDIO_PRIVATE_SOURCE_V3.6.2',note:'Original source preserved; not complete IEC or Neher–McGrath engineering approval'};
   content.replaceChildren(tableFor(result));const issues=document.createElement('p');issues.textContent=(result.issues||[]).join(' | ')||'No source-engine model-input failures were returned; independent physical verification is still required.';content.append(issues);
   status.textContent=`ORIGINAL THERMAL MODEL — ${result.status} · ${mode.toUpperCase()} SCREEN ONLY · OEM/CODE APPROVAL NOT ESTABLISHED`;
   exp.disabled=false;
  }catch(e){latest=null;content.replaceChildren();exp.disabled=true;status.textContent='THERMAL CALCULATION REJECTED: '+e.message}});
 byId('b4th_json').addEventListener('click',()=>{if(!latest)return;const blob=new Blob([JSON.stringify({...latest,auditTimestampUTC:new Date().toISOString()},null,2)],{type:'application/json'});const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='original-cable-thermal-v362-screening-audit.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),5000)});
 window.SolarThermalOriginalB4State=()=>({result:latest?.result||null,mode:latest?.mode||null,source:latest?.sourceLabel||''});
 window.SolarThermalOriginalB4Sheets=()=>latest?[['Original Cable Thermal v362',Object.entries(latest.result).filter(([,v])=>typeof v==='string'||typeof v==='number'||typeof v==='boolean').map(([key,value])=>({key,value}))]]:[];
 window.SolarThermalOriginalB4ReportHTML=()=>latest?`<h2>Original Cable Thermal v3.6.2 · Thermal screen only</h2><p>Mode ${latest.mode}; source status ${latest.result.status}; continuous rating ${latest.result.ampacity_a??'n/a'} A. Full manufacturer/installation IEC and NEC approval NOT established.</p>`:'';
 }
}
