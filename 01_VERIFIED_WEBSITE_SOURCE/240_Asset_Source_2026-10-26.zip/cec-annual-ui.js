/** Optional Batch 2 feasibility: replace PVWatts conversion with historical CEC/Sandia fit.
 * Deliberately refuses full-year publication if ANY sunlit operating hour is outside
 * the CEC voltage/current model's fitted range. Never alters the original yield.
 */
import {compareAnnualCec} from './cec-annual-adapter.js';
const parent=document.getElementById('cecBatch2Bench');
if (!parent) throw Error('Batch 2 CEC reference panel missing');
const details=document.createElement('details');
details.className='cec-bench';details.id='cec-annual-coupling';
details.innerHTML=`<summary>Batch 2 · Hourly diode-to-CEC coupling feasibility (experimental)</summary>
<div class="cec-body"><p><strong>Validation gate, not an automatic inverter replacement.</strong> Reuses your last v1.7 detailed 8,760/8,784-hour DC stream and substitutes a historical CEC inverter fit. Requires a matching AC nameplate and nominal grid voltage. The study is refused if even one sunlit hour exceeds the published CEC DC current or MPPT voltage range; no extrapolated annual result is shown.</p>
<label>CEC inverter fit<select id="cec-annual-model" disabled><option>Load reference fits</option></select></label>
<div class="cec-actions"><button id="cec-annual-load" type="button">Load 6 source-linked CEC examples</button><button id="cec-annual-run" type="button" disabled>Check full-year CEC compatibility and simulate</button><button id="cec-annual-csv" type="button" disabled>Export accepted hourly CSV</button></div>
<p id="cec-annual-status" role="status" aria-live="polite">Requires the previous detailed v1.7 calculation. No equipment is approved automatically.</p><div id="cec-annual-out"></div>
<p class="cec-disclaimer">The upstream module operating voltage was optimized using the original v1.7 MPPT limits. No iterative re-optimization occurs for a different CEC voltage window. Fitted library coefficients are not a substitute for current OEM specifications, multiple MPPT channel ratings, reactive power operation or a bankable P50/P90 forecast.</p></div>`;
parent.append(details);
const el=x=>document.getElementById(x);const escaped=x=>String(x??'').replace(/[&<>"']/g,s=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[s]));
let models=null,accepted=null;
const clear=()=>{accepted=null;el('cec-annual-csv').disabled=true;el('cec-annual-out').textContent='';};
el('cec-annual-load').addEventListener('click',async()=>{
 clear();const status=el('cec-annual-status');status.textContent='Loading reference inverter fits…';
 try{const res=await fetch('./cec-inverter-library.json',{cache:'no-cache'});if(!res.ok)throw Error('Reference fetch HTTP '+res.status);
 const d=await res.json();if(!Array.isArray(d.models)||d.models.length!==6)throw Error('Source schema mismatch');models=d.models;
 el('cec-annual-model').innerHTML='<option value="" selected disabled>Choose a CEC inverter intentionally (no default)</option>'+models.map((m,i)=>`<option value="${i}">${escaped(m.name)}</option>`).join('');el('cec-annual-model').disabled=false;
 el('cec-annual-run').disabled=true;status.textContent='Six historical fits loaded. Select a named CEC model intentionally, then run the v1.7 detailed simulation.';
 }catch(e){status.textContent='REFERENCE LOAD FAILED: '+e.message}
});
el('cec-annual-model').addEventListener('change',()=>{clear();const raw=el('cec-annual-model').value;const idx=raw===''?NaN:Number(raw);const model=Number.isInteger(idx)?models?.[idx]:null;el('cec-annual-run').disabled=!model;el('cec-annual-status').textContent=model?'SELECTED CEC FIT: '+model.name+' · NOT OEM-QUALIFIED. Run v1.7 hourly study first.':'Choose a valid inverter fit before running annual screening.';});
let previousUpstream=null;
window.addEventListener('solarresource:updated',()=>{clear();previousUpstream=null;});
el('cec-annual-run').addEventListener('click',async()=>{
 clear();const status=el('cec-annual-status');status.textContent='Checking all hourly AC conversion operating constraints…';
 await new Promise(resolve=>requestAnimationFrame(resolve));
 try{const v17=window.SolarPV17State?.();if(!v17?.result?.hourly||!v17?.config)throw Error('Run v1.7 detailed hourly study; your previous result cannot be reused without its original input configuration.');
 const raw=el('cec-annual-model').value;const idx=raw===''?NaN:Number(raw);const model=Number.isInteger(idx)?models?.[idx]:null;if(!model)throw Error('Select a historical CEC inverter model explicitly');status.textContent='CHECKING SELECTED FIT: '+model.name+' (historical CEC fit)';
 const comparison=compareAnnualCec({hourly:v17.result.hourly,cec:model,plant:v17.config,upstreamProvenance:v17.source});
 if(!comparison.accepted){
  status.textContent='NOT ACCEPTED: '+comparison.reason;
  const checks=[['Model',comparison.model],['Checked hours',comparison.checkedHours],['Violation count',comparison.violationsRecorded],['AC nameplate compatible',comparison.acRatingCompatible],['AC grid voltage compatible',comparison.acVoltageCompatible],['Original AC kW',comparison.originalACkW],['CEC AC kW',comparison.cecACkW],['Original Vac',comparison.originalVac],['CEC Vac',comparison.cecVac]];
  el('cec-annual-out').innerHTML=`<table class="cec-table"><tbody>${checks.filter(([a,b])=>b!==undefined).map(([a,b])=>`<tr><th>${escaped(a)}</th><td>${escaped(b)}</td></tr>`).join('')}</tbody></table>`+
  (comparison.firstViolations?.length?`<p>${escaped(comparison.firstViolations.slice(0,4).map(x=>x.timestamp_utc+' '+x.flags.join('/')).join('; '))}</p>`:'');return;
 }
 accepted=comparison;previousUpstream=v17.result;
 const a=comparison.annual;const rows=[['CEC fitted inverter',comparison.model],['CEC-model POI export MWh',(a.poiExportKWh/1000).toFixed(4)],['CEC-model grid import kWh',a.poiImportKWh.toFixed(3)],['Original v1.7 POI export MWh',(v17.result.annual.poiExportKWh/1000).toFixed(4)],['Nighttime CEC consumption kWh',comparison.annualHourly.reduce((s,h)=>s+Math.max(0,-h.cec_ac_kw),0).toFixed(4)],['Verified annual hours',comparison.nHours]];
 el('cec-annual-out').innerHTML=`<table class="cec-table"><tbody>${rows.map(([k,val])=>`<tr><th>${escaped(k)}</th><td>${escaped(val)}</td></tr>`).join('')}</tbody></table>`;
 el('cec-annual-csv').disabled=false;
 status.textContent='EXPERIMENTAL RESEARCH ONLY: all operating envelopes passed at previously modeled Vmp; CEC-fit annual comparison calculated. NOT manufacturer- or bankable-qualified.';
 }catch(e){status.textContent='FULL-YEAR MODEL REJECTED: '+e.message}
});
el('cec-annual-csv').addEventListener('click',()=>{
 if(!accepted||window.SolarPV17State?.().result!==previousUpstream){clear();el('cec-annual-status').textContent='Upstream detailed result changed; rerun comparison.';return}
 const h=accepted.annualHourly,keys=Object.keys(h[0]||{});
 const data=[keys.join(','),...h.map(x=>keys.map(k=>String(x[k]??'')).join(','))].join('\r\n');
 const blob=new Blob([data],{type:'text/csv'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='BATCH2_CEC_HOURLY_RESEARCH_NOT_CERTIFIED.csv';document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),12000);
});
