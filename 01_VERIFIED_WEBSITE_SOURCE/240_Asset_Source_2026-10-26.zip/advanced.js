/** Solar Resource Studio v1.2 interactive engineering workbench. No cloud case storage. */
import {solar} from './engine.js';
import {computeEngineering,optimizeOrientation,sunEventsUTC,publicHourly,irradianceParts,dniExtraterrestrial} from './advanced-engine.js';
const $=id=>document.getElementById(id);
const fmt=(n,d=1)=>Number.isFinite(n)?n.toLocaleString(undefined,{maximumFractionDigits:d,minimumFractionDigits:d}):'—';
const esc=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fileBase=()=>String($('project')?.value||'solar_resource').replace(/[^a-z0-9_-]+/gi,'_').slice(0,42);
const source=()=>window.SolarResourceStudio?.getState?.()||null;
const state={key:null,analysis:null,opt:null,model:'reindl',geo:null,tab:'overview',hourlyDay:null};

function mountWorkbench(){
  const f=document.querySelector('main > footer');
  if(!f)throw Error('Expected site footer was not found: no advanced UI mounted');
  f.insertAdjacentHTML('beforebegin',`<section id="engineeringWorkbench" class="adv-workbench" aria-label="Advanced solar resource engineering">
  <div class="adv-top"><div><span class="eyebrow">ENGINEERING WORKBENCH · CALCULATOR 01</span><h2>Solar resource &amp; site engineering</h2><p>Hourly and annual resource · sun path · anisotropic POA · orientation optimization · climate engineering screens · data QC · Energy Yield handoff.</p></div><span class="status review" id="advStatus" role="status">INPUT REQUIRED</span></div>
  <div class="adv-settings">
    <label>POA diffuse-sky model<select id="advModel"><option value="reindl" selected>Reindl anisotropic + horizon</option><option value="haydavies">Hay–Davies anisotropic</option><option value="isotropic">Isotropic (original baseline)</option></select></label>
    <div class="adv-place-wrapper"><label>Find site by city or named location<input id="advPlaceSearch" type="search" placeholder="Search city or location" autocomplete="off"></label><button id="advPlaceButton" type="button">Find</button></div>
    <button id="advGeoButton" type="button" class="secondary" style="width:auto">Check terrain &amp; timezone</button>
  </div>
  <div id="advPlaces" class="adv-place-results" aria-live="polite"></div><div id="advGeoInfo" class="adv-geoinfo">Automatic geographic metadata is approximate; survey elevation takes precedence.</div>
  <div class="adv-tabs" role="tablist" aria-label="Engineering result sections">
    <button type="button" role="tab" data-adv-tab="overview" class="active" aria-selected="true">Resource overview</button>
    <button type="button" role="tab" data-adv-tab="geometry">Solar geometry</button>
    <button type="button" role="tab" data-adv-tab="orientation">Orientation study</button>
    <button type="button" role="tab" data-adv-tab="hourly">Hourly &amp; daily</button>
    <button type="button" role="tab" data-adv-tab="climate">Climate analysis</button>
    <button type="button" role="tab" data-adv-tab="quality">Quality &amp; traceability</button>
    <button type="button" role="tab" data-adv-tab="handoff">Reports &amp; handoff</button>
  </div>
  <div id="advContent" class="adv-content" role="tabpanel" aria-live="polite"><div class="adv-empty">Run a resource study to enable advanced engineering analysis.</div></div>
</section>
`);
}
mountWorkbench();

function csvEscape(x){const s=String(x??'');return /[",\n\r]/.test(s)?'"'+s.replace(/"/g,'""')+'"':s}
function toCsv(records){if(!records.length)return '';const columns=Object.keys(records[0]);return [columns.join(','),...records.map(r=>columns.map(k=>csvEscape(r[k])).join(','))].join('\r\n')}
function download(filename,content,type='text/csv;charset=utf-8'){
  const url=URL.createObjectURL(new Blob([content],{type}));const a=document.createElement('a');a.href=url;a.download=filename;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),5000);
}
function scalar(v){return Number.isFinite(v)?v.toFixed(2):'—'}
function rowsTable(rows,columns,limit=500){return `<div class="adv-table-wrap"><table class="adv-table"><thead><tr>${columns.map(([k,h])=>`<th>${esc(h)}</th>`).join('')}</tr></thead><tbody>${rows.slice(0,limit).map(r=>`<tr>${columns.map(([k])=>`<td>${typeof r[k]==='number'?fmt(r[k],2):esc(r[k]??'—')}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`;}
const mcols=[['month','Month (UTC)'],['hours','Hours'],['ghi','GHI kWh/m²'],['dni','DNI kWh/m²'],['dhi','DHI kWh/m²'],['poa','POA kWh/m²'],['beam','Direct POA'],['sky','Diffuse POA'],['ground','Ground POA'],['tempMean','Mean °C'],['windMean','Wind m/s'],['ktMean','Kt mean']];
const hcols=[['timestamp_utc','Hour UTC'],['ghi_wm2','GHI'],['dni_wm2','DNI'],['dhi_wm2','DHI'],['poa_wm2','POA'],['poa_direct_wm2','Direct POA'],['poa_sky_wm2','Sky POA'],['poa_ground_wm2','Ground POA'],['solar_elevation_deg','Sun el. °'],['solar_azimuth_deg','Sun az. °'],['aoi_deg','AOI °'],['temp_air_c','T °C'],['wind_speed_mps','Wind m/s'],['ghi_closure_wm2','Closure W/m²']];
function summaryKPIs(items){return `<div class="adv-metrics">${items.map(([name,value,unit])=>`<div class="adv-kpi"><span>${esc(name)}</span><b>${esc(value)}</b><small>${esc(unit)}</small></div>`).join('')}</div>`}
function empty(message='Run a validated weather study above to enable this analysis.'){
  $('advContent').innerHTML=`<div class="adv-empty">${esc(message)}</div>`;
}
function markPills(){document.querySelectorAll('[data-adv-tab]').forEach(b=>{b.classList.toggle('active',b.dataset.advTab===state.tab);b.setAttribute('aria-selected',String(b.dataset.advTab===state.tab))})}
function updateStatus(s){$('advStatus').textContent=s}
function ensure(){
  const s=source();if(!s?.result?.summary||!s.result.hourly?.length){state.analysis=null;state.key=null;state.opt=null;return false}
  if(state.key!==s.result||state.analysis?.model!==state.model){
    state.key=s.result;state.opt=null;
    state.analysis=computeEngineering(s.result,s.config,state.model);
    state.hourlyDay=state.analysis.daily[0]?.dateUTC||null;
  }
  return true;
}
function render(){markPills();try{
  if(!ensure()){updateStatus('INPUT REQUIRED');empty();return}
  const a=state.analysis;
  updateStatus(`${a.annual?'FULL-YEAR':'PARTIAL'} · ${a.stats.hours.toLocaleString()} HOURS · ${a.warningCount} REVIEW FLAGS`);
  ({overview,geometry,orientation,hourly,climate,quality,handoff}[state.tab]||overview)();
}catch(e){updateStatus('ADVANCED ANALYSIS ERROR');empty('Advanced calculation failed: '+e.message);console.error(e)}}
function overview(){const a=state.analysis,s=source();
  $('advContent').innerHTML=`<div class="adv-grid2"><div>${summaryKPIs([['GHI',fmt(a.stats.ghi,2),'kWh/m²'],['DNI',fmt(a.stats.dni,2),'kWh/m²'],['DHI',fmt(a.stats.dhi,2),'kWh/m²'],['POA '+state.model,fmt(a.stats.poa,2),'kWh/m²'],['Beam POA',fmt(a.stats.beam,2),'kWh/m²'],['Sky POA',fmt(a.stats.sky,2),'kWh/m²'],['Ground POA',fmt(a.stats.ground,2),'kWh/m²']])}</div>
    <div class="adv-note"><h3>Engineering interpretation</h3><p>These values describe incident weather and irradiance — not AC energy. The advanced POA calculations use <strong>${esc(state.model)}</strong> diffuse-sky transposition; the original dashboard remains isotropic as a baseline.</p><p>Source: ${esc(s.weatherInfo?.label||s.result.source)}. Samples: ${a.stats.hours.toLocaleString()}. ${a.annual?'Complete calendar-year record.':'Incomplete data — cannot infer annual irradiation.'}</p><p>Extraterrestrial DNI is computed from Earth–Sun distance; modeled clearness and GHI/DNI/DHI closure are screened hourly. Shading, soiling, spectral effects, horizon and electrical losses are not included.</p></div></div>
    <h3 class="adv-subhead">Monthly irradiation and climate</h3>${rowsTable(a.monthly,mcols)}
    <div class="adv-stackline"><span>${esc(a.annual?'Annual result':'Partial-period result')}</span><span>POA decomposition = beam + sky + ground</span><span>Baseline isotropic POA = ${fmt(s.result.summary.poa,2)} kWh/m²</span></div>`;
}
function geomGraph(day,lat,lon){const ts=Date.parse(`${day}T00:00:00Z`),xs=[],ys=[];
  for(let t=0;t<=96;t++){const el=solar(new Date(ts+t*900000),lat,lon).elevation;xs.push(22+(t/96)*756);ys.push(159-(el/90)*120)}
  const poly=xs.map((x,i)=>`${x.toFixed(1)},${ys[i].toFixed(1)}`).join(' ');
  return `<svg class="adv-solar-chart" viewBox="0 0 800 310" role="img" aria-label="Solar altitude versus UTC time"><line x1="22" x2="778" y1="159" y2="159" stroke="#84a9b2" stroke-dasharray="5 6"/><line x1="22" x2="778" y1="39" y2="39" stroke="#344859"/><line x1="22" x2="778" y1="279" y2="279" stroke="#344859"/><polyline fill="none" stroke="#55e3cf" stroke-width="3" points="${poly}"/>${[0,6,12,18,24].map(h=>`<text x="${22+h/24*756}" y="302" text-anchor="middle" fill="#bed3de" font-size="13">${String(h).padStart(2,'0')}:00</text>`).join('')}<text x="8" y="44" fill="#b2c5d2" font-size="11">+90°</text><text x="8" y="156" fill="#b2c5d2" font-size="11">0°</text><text x="8" y="271" fill="#b2c5d2" font-size="11">-90°</text></svg>`
}
function geometry(){const s=source(),a=state.analysis,defaultDay=a.daily[Math.floor(a.daily.length/2)]?.dateUTC,day=state.hourlyDay||defaultDay;const evt=sunEventsUTC(day,s.config.lat,s.config.lon);
  $('advContent').innerHTML=`<div class="adv-inline"><label>UTC calendar day <input type="date" id="advGeometryDate" min="${a.daily[0].dateUTC}" max="${a.daily.at(-1).dateUTC}" value="${day}"></label><div class="adv-hint">Solar time uses ${esc(String(s.config.offsetHours||0))} h irradiance sample offset for the hourly data, but the daily geometry curve uses true UTC instants.</div></div>
  ${summaryKPIs([['Sunrise (UTC)',evt.sunriseUTC||'—','geometric/refraction approx.'],['Solar noon (UTC)',evt.noonUTC||'—','daily peak UTC'],['Sunset (UTC)',evt.sunsetUTC||'—','geometric/refraction approx.'],['Noon altitude',fmt(evt.noonElevation,2)+'°','geometric solar position']])}
  ${geomGraph(day,s.config.lat,s.config.lon)}<p class="adv-disclaimer">UTC day boundaries can split local sunrise/sunset into adjacent dates. This is a preliminary solar-path screen (NOAA approximation), not NREL SPA, terrain horizon, or verified local civil sunrise.</p>`;
  $('advGeometryDate').addEventListener('change',e=>{state.hourlyDay=e.target.value;geometry()});
}
function orientation(){const a=state.analysis,s=source();
  if(!state.opt){$('advContent').innerHTML=`<div class="adv-note"><h3>Orientation sensitivity and optimization</h3><p>Evaluate fixed-plane array tilt from 0° to 90° (5° increments) and azimuth from 0° to 345° clockwise from north (15° increments), across ${a.stats.hours.toLocaleString()} resource hours. Comparison uses the selected <b>${esc(state.model)}</b> transposition model and the same weather.</p><button id="advOptimize" class="adv-action">Calculate 456 orientation scenarios</button><p class="adv-disclaimer">Optimizes incident POA irradiation only. It cannot determine maximum PV energy yield or account for shading, row spacing, site structures, snow, wind, cable lengths or layout restrictions.</p></div>`;
    $('advOptimize').addEventListener('click',()=>{updateStatus('CALCULATING ORIENTATION SWEEP');setTimeout(()=>{try{state.opt=optimizeOrientation(a.hourly,s.config,state.model,5,15);orientation();updateStatus(`ORIENTATION: ${state.opt.evaluated} SCENARIOS`) }catch(e){empty(e.message)}},0)});return}
  const opt=state.opt,baseline=a.stats.poa,best=opt.best;
  const rows=opt.scenarios.slice().sort((x,y)=>x.tilt-y.tilt||x.azimuth-y.azimuth);
  let matrix='<div class="adv-heat-scroll"><table class="adv-heat"><thead><tr><th>Tilt ↓ / Az →</th>'+opt.azimuths.map(v=>`<th>${v}°</th>`).join('')+'</tr></thead><tbody>';
  for(const tilt of opt.tilts){matrix+=`<tr><th>${tilt}°</th>`;for(const azi of opt.azimuths){const v=rows.find(r=>r.tilt===tilt&&r.azimuth===azi);const rat=v.poa/best.poa;matrix+=`<td><button class="adv-heatcell" style="background:rgba(85,227,207,${(0.05+0.62*Math.pow(rat,12)).toFixed(3)})" data-tilt="${tilt}" data-az="${azi}" title="Tilt ${tilt}°, Azimuth ${azi}°; POA ${v.poa.toFixed(2)} kWh/m²">${(v.poa/best.poa*100).toFixed(0)}%</button></td>`}matrix+='</tr>'}matrix+='</tbody></table></div>';
  $('advContent').innerHTML=`${summaryKPIs([['Best grid tilt',best.tilt+'°','from horizontal'],['Best grid azimuth',best.azimuth+'°','clockwise from north'],['Best grid POA',fmt(best.poa,2),'kWh/m²'],['Baseline POA',fmt(baseline,2),'kWh/m²'],['Gain from current',fmt(best.poa-baseline,2),'kWh/m²']])}
  <p class="adv-hint">The maximum shown is the best <b>evaluated grid point</b>, not a continuous optimum. Each heatmap cell is percent of best POA. Azimuth 0° = north, 90° = east, 180° = south, 270° = west.</p>${matrix}
  <div id="advChosen" class="adv-note">Select a grid cell for exact irradiation and input transfer.</div><h3 class="adv-subhead">Leading orientation scenarios</h3>${rowsTable(opt.scenarios.slice(0,15),[['tilt','Tilt °'],['azimuth','Azimuth °'],['poa','POA kWh/m²']])}<p class="adv-disclaimer">${esc(opt.disclaimer)} ${a.annual?'': 'This dataset is partial; annual optimum claims are not permitted.'}</p>`;
  $('advContent').querySelectorAll('[data-tilt]').forEach(b=>b.addEventListener('click',()=>{const tilt=+b.dataset.tilt,azimuth=+b.dataset.az,v=rows.find(r=>r.tilt===tilt&&r.azimuth===azimuth);$('advChosen').innerHTML=`<b>Tilt ${tilt}° · azimuth ${azimuth}°</b> — ${fmt(v.poa,2)} kWh/m² (${fmt(100*v.poa/best.poa,1)}% of best). <button id="advApplyAngle" class="adv-action">Apply tilt/azimuth to project inputs</button>`;$('advApplyAngle').addEventListener('click',()=>{$('tilt').value=tilt;$('azimuth').value=azimuth;$('tilt').dispatchEvent(new Event('change',{bubbles:true}));$('azimuth').dispatchEvent(new Event('change',{bubbles:true}));render();scrollTo({top:0,behavior:'smooth'})})}));
}
function hourly(){const a=state.analysis,day=state.hourlyDay||a.daily[0]?.dateUTC;const subset=a.hourly.filter(h=>h.timestamp_utc.startsWith(day));
  $('advContent').innerHTML=`<div class="adv-inline"><label>UTC day <input id="advHourDate" type="date" value="${day}" min="${a.daily[0].dateUTC}" max="${a.daily.at(-1).dateUTC}"></label><button id="advDayCSV" class="adv-action">↓ Export selected day CSV</button><span class="adv-hint">${subset.length} hourly rows; values in W/m² unless otherwise shown. Timestamps are UTC.</span></div>
  ${rowsTable(subset,hcols,30)}<h3 class="adv-subhead">Daily aggregation (UTC)</h3>${rowsTable(a.daily.slice(0,400),[['dateUTC','UTC date'],['hours','Hours'],['ghi','GHI kWh/m²'],['dni','DNI kWh/m²'],['dhi','DHI kWh/m²'],['poa','POA kWh/m²'],['tempMin','Min °C'],['tempMax','Max °C'],['windMax','Max wind m/s']])}`;
  $('advHourDate').addEventListener('change',e=>{state.hourlyDay=e.target.value;hourly()});
  $('advDayCSV').addEventListener('click',()=>download(`${fileBase()}_${day}_advanced.csv`,toCsv(subset.map(publicHourly))));
}
function histHTML(vals,label){const num=12,min=Math.min(...vals),max=Math.max(...vals),w=(max-min||1)/num,counts=Array(num).fill(0);for(const v of vals)counts[Math.min(num-1,Math.floor((v-min)/w))]++;
  const mx=Math.max(...counts);return `<h3 class="adv-subhead">${label} · hourly distribution</h3><div class="adv-hist">${counts.map((v,i)=>`<div title="${(min+i*w).toFixed(1)} – ${(min+(i+1)*w).toFixed(1)}: ${v} hours"><div class="adv-histbar" style="height:${Math.max(2,v/mx*100)}%"></div><small>${(min+i*w).toFixed(0)}</small></div>`).join('')}</div><p class="adv-hint">Bars show count of weather hours. The axis labels are bin lower limits in the source unit; not return-period extremes.</p>`;
}
function climate(){const a=state.analysis,t=a.stats.temperature,w=a.stats.wind;
  $('advContent').innerHTML=`${summaryKPIs([['Minimum air temp',fmt(t.min,1)+' °C','sample minimum'],['1st-percentile temp',fmt(t.p01,1)+' °C','cold screening'],['99th-percentile temp',fmt(t.p99,1)+' °C','hot screening'],['Maximum air temp',fmt(t.max,1)+' °C','sample maximum'],['90th-percentile wind',fmt(w.p90,1)+' m/s','10 m hourly'],['99th-percentile wind',fmt(w.p99,1)+' m/s','10 m hourly'],['Maximum hourly wind',fmt(w.max,1)+' m/s','10 m hourly']])}
  <div class="adv-grid2"><div>${histHTML(a.hourly.map(h=>h.temp_air_c),'Ambient temperature (°C)')}</div><div>${histHTML(a.hourly.map(h=>h.wind_speed_mps),'Weather wind speed (m/s)')}</div></div>
  <h3 class="adv-subhead">Monthly climate profile</h3>${rowsTable(a.monthly,[['month','Month (UTC)'],['tempMean','Mean air temp °C'],['windMean','Mean wind m/s'],['hours','Hours']])}
  <p class="adv-disclaimer">These are weather-hour descriptive statistics, not NEC/ASHRAE/equipment thermal design temperatures, structural ASCE 7/IBC basic wind speeds, or extreme-value return-period estimates. Those require separate authoritative design data and methods.</p>`;
}
function quality(){const a=state.analysis,s=source(),item=(k,v)=>`<tr><th>${esc(k)}</th><td>${esc(v)}</td></tr>`;
  $('advContent').innerHTML=`${summaryKPIs([['Validated hours',a.stats.hours.toLocaleString(),'UTC hourly sequence'],['Closure discrepancies',a.stats.closure,'GHI ≠ DHI + DNI·cosZ'],['Nighttime radiation flags',a.stats.night,'sun altitude below -6°'],['High Kt',a.stats.highKT,'Kt > 1.05'],['High DNI',a.stats.exceedsExtra,'DNI > 1.05 × extraterrestrial']])}
  <h3 class="adv-subhead">Data lineage and QA</h3><div class="adv-table-wrap"><table class="adv-table"><tbody>
  ${item('Project / study',s.config.project)}${item('Weather source',s.weatherInfo?.label||s.result.source)}${item('Source URL',s.weatherInfo?.url||'CSV uploaded locally')}${item('Retrieved at',s.weatherInfo?.obtained||'unknown')}${item('Source type',s.weatherInfo?.type||s.config.kind)}${item('Weather model',s.weatherInfo?.model||'not stated')}${item('PVGIS month origins',s.weatherInfo?.sourceYears?JSON.stringify(s.weatherInfo.sourceYears):'not applicable')}${item('Latitude, longitude',`${s.config.lat}°, ${s.config.lon}°`)}${item('Elevation m',s.config.elevation??s.weatherInfo?.elevation??'not provided')}${item('Timestamp offset',`${s.config.offsetHours||0} hours; input-to-position adjustment`)}${item('Primary QA status',s.result.status)}${item('Advanced POA model',state.model)}${item('Integrated units','Hourly-average W/m² × 1 h ÷ 1000 = kWh/m²')}${item('Local storage','Tab session only, expires in 24 h; no server study storage')}
  </tbody></table></div><h3 class="adv-subhead">Warnings and qualifications (${a.warnings.length})</h3><div class="adv-warnings">${a.warnings.length?a.warnings.map(w=>`<p>⚠ ${esc(w)}</p>`).join(''):'<p>No warnings from the automated screens; not equivalent to independent engineering certification.</p>'}</div>
  <button id="advSelfTest" class="adv-action">Run calculation smoke tests</button><span id="advSelfResult" class="adv-hint"></span><p class="adv-disclaimer">High Kt and irradiance closure can be affected by interval averaging, approximate solar-position model, horizon treatment and source conventions. Screening thresholds are diagnostics, not an IEC conformance test. Engineering sign-off requires benchmark comparisons and a real-site dataset.</p>`;
  $('advSelfTest').addEventListener('click',()=>{const r=selfTests();$('advSelfResult').textContent=` ${r.ok}/${r.total} internal unit and invariance checks passed${r.errors.length?' · '+r.errors.join('; '):''}`; $('advSelfResult').style.color=r.errors.length?'#ffaca5':'#75e5c0'});
}
function handoff(){const a=state.analysis,s=source();
  $('advContent').innerHTML=`<div class="adv-note"><h3>Energy Yield Calculator handoff</h3><p>Exports synchronized site coordinates, terrain assumption, timezone provenance, array orientation, weather source, QC, and timestamped GHI/DNI/DHI, ambient temperature and wind. The JSON export carries an explicit schema version. The separate Energy Yield Calculator may use these inputs to model DC/AC production, electrical losses and PV component performance.</p><p>Record count: ${a.hourly.length.toLocaleString()} · Advanced POA method: ${esc(state.model)} · Primary validation: ${esc(s.result.status)}.</p><div class="adv-inline"><button id="advHandoffJSON" class="adv-action">↓ Standardized JSON handoff</button><button id="advHandoffCSV" class="adv-action">↓ Extended hourly CSV</button><button id="advDailyCSV" class="adv-action">↓ Daily + monthly CSV</button><button id="advPrint" class="adv-action">⎙ Detailed engineering print</button></div></div><p class="adv-disclaimer">Weather records have not been independently validated for bankability or code design limits. No PV production, inverter performance, shading, structural load or financing prediction is included.</p>`;
  $('advHandoffJSON').addEventListener('click',()=>{const obj={schema:'solar-resource-site/1.2',createdUTC:new Date().toISOString(),project:s.config.project,site:{latitudeDeg:s.config.lat,longitudeDeg:s.config.lon,elevationM:s.config.elevation??s.weatherInfo?.elevation??null,timezone:s.weatherInfo?.timezone||state.geo?.timezone||null},array:{tiltDeg:s.config.tilt,azimuthDegNorth:s.config.azimuth,albedo:s.config.albedo},provenance:s.weatherInfo||{},method:{primary:s.result.metadata,advancedSkyModel:state.model},qa:{status:s.result.status,warnings:a.warnings,closureFlags:a.stats.closure,nightFlags:a.stats.night},units:{irradiance:'W/m2 hourly average',temp:'C',wind:'m/s',timestamps:'UTC ISO8601'},statistics:a.stats,monthly:a.monthly,hourly:a.hourly.map(publicHourly)};download(`${fileBase()}_energy_yield_handoff.json`,JSON.stringify(obj), 'application/json;charset=utf-8')});
  $('advHandoffCSV').addEventListener('click',()=>download(`${fileBase()}_advanced_hourly.csv`,toCsv(a.hourly.map(publicHourly))));
  $('advDailyCSV').addEventListener('click',()=>download(`${fileBase()}_daily_monthly.csv`,toCsv(a.daily)+ '\r\n\r\n' +toCsv(a.monthly)));
  $('advPrint').addEventListener('click',()=>window.SolarResourceStudio?.printReport?.());
}
/** Integrates workbook sheets into original exporter; original 3 sheets preserved. */
window.SolarAdvancedSheets=()=>{
  try{
    if(!ensure())return [];
    const a=state.analysis, s=source();
    const pairs=[['Parameter','Value'],['Weather source',s.weatherInfo?.label||s.result.source],['Base QA',s.result.status],['Advanced sky model',state.model],['Annual/partial',a.annual?'Full UTC year':'Partial series'],['GHI (kWh/m²)',a.stats.ghi],['DNI (kWh/m²)',a.stats.dni],['DHI (kWh/m²)',a.stats.dhi],['POA advanced (kWh/m²)',a.stats.poa],['Beam POA',a.stats.beam],['Diffuse sky POA',a.stats.sky],['Reflected ground POA',a.stats.ground],['Irradiance closure flags',a.stats.closure],['Night irradiance flags',a.stats.night],['Model limitations','Not an energy yield or bankable solar resource study']];
    const table=arr=>[Object.keys(arr[0]||{}),...arr.map(x=>Object.values(x))];
    return [['Engineering',pairs],['Climate_Daily',table(a.daily)],['POA_Models',table(a.monthly)],['Advanced_Hourly',table(a.hourly.map(publicHourly))],['QC_Notes',[['Warning'],...a.warnings.map(x=>[x])]]];
  }catch(e){console.warn('Advanced sheets unavailable:',e);return []}
};
window.SolarAdvancedReportHTML=()=>{
  try{if(!ensure())return '';const a=state.analysis;
    return `<h2>Additional resource engineering</h2><p>Advanced diffuse transposition method: ${esc(state.model)}; source QA status: ${esc(a.sourceStatus)}. Irradiance POA ${fmt(a.stats.poa,2)} kWh/m², comprising beam ${fmt(a.stats.beam,2)}, sky ${fmt(a.stats.sky,2)} and ground ${fmt(a.stats.ground,2)} kWh/m².</p><p>Temperature 1st/99th percentile ${fmt(a.stats.temperature.p01,1)} / ${fmt(a.stats.temperature.p99,1)} °C. Wind speed 90th/99th percentile ${fmt(a.stats.wind.p90,1)} / ${fmt(a.stats.wind.p99,1)} m/s. Closure flags ${a.stats.closure}; nighttime irradiance flags ${a.stats.night}.</p><h2>Advanced monthly irradiation</h2><table><thead><tr><th>UTC month</th><th>GHI</th><th>DNI</th><th>DHI</th><th>Advanced POA</th><th>Beam</th><th>Sky</th><th>Ground</th></tr></thead><tbody>${a.monthly.map(m=>`<tr><td>${m.month}</td><td>${fmt(m.ghi,1)}</td><td>${fmt(m.dni,1)}</td><td>${fmt(m.dhi,1)}</td><td>${fmt(m.poa,1)}</td><td>${fmt(m.beam,1)}</td><td>${fmt(m.sky,1)}</td><td>${fmt(m.ground,1)}</td></tr>`).join('')}</tbody></table><h2>Additional engineering warnings</h2>${a.warnings.map(w=>`<p class="warn">• ${esc(w)}</p>`).join('')}<p>Advanced POA uses established Hay–Davies or Reindl formulations when selected, with NOAA approximate solar position. Orientation, system production and code design remain outside this weather resource screen.</p>`;
  }catch{return ''}
};
function selfTests(){const errors=[],test=(label,ok)=>{if(!ok)errors.push(label)};
  const midday=solar(new Date('2026-03-20T12:00:00Z'),0,0),midnight=solar(new Date('2026-03-20T00:00:00Z'),0,0);
  test('equinox noon',midday.elevation>85);
  test('equinox night',midnight.elevation< -85);
  const x={zenith:30,elevation:60,azimuth:180,cosz:Math.cos(Math.PI/6)},ghi=900,dni=650,dhi=337.08;
  const iso=irradianceParts(ghi,dni,dhi,x,0,180,.2,'isotropic');
  const hay=irradianceParts(ghi,dni,dhi,x,0,180,.2,'haydavies');
  const rei=irradianceParts(ghi,dni,dhi,x,0,180,.2,'reindl');
  test('horizontal isotropic identity',Math.abs(iso.total-(dni*x.cosz+dhi))<1e-9);
  test('horizontal Hay identity',Math.abs(hay.total-(dni*x.cosz+dhi))<1e-9);
  test('horizontal Reindl identity',Math.abs(rei.total-(dni*x.cosz+dhi))<1e-9);
  test('nonnegative decomposition',Object.values(rei).slice(0,7).every(v=>v>=0));
  test('extraterrestrial plausible',dniExtraterrestrial(new Date('2026-06-21T12:00:00Z'))>1300);
  const eq=sunEventsUTC('2026-03-20',0,0);
  test('equinox sunrise exists',eq.sunriseUTC!==null);
  return {total:8,ok:8-errors.length,errors};
}
async function geoSearch(){const q=$('advPlaceSearch').value.trim(),box=$('advPlaces');if(q.length<3){box.textContent='Enter at least three characters.';return}
  box.textContent='Searching named places…';try{
    const api='https://geocoding-api.open-meteo.com/v1/search?'+new URLSearchParams({name:q,count:'6',language:'en',format:'json'});
    const response=await fetch(api);if(!response.ok)throw Error('HTTP '+response.status);
    const matches=(await response.json()).results||[];box.replaceChildren();
    for(const v of matches){const b=document.createElement('button');b.className='adv-place';b.textContent=[v.name,v.admin1,v.country].filter(Boolean).join(', ')+` (${v.latitude.toFixed(3)}, ${v.longitude.toFixed(3)})`;b.addEventListener('click',()=>{$('lat').value=v.latitude;$('lon').value=v.longitude;$('lat').dispatchEvent(new Event('change',{bubbles:true}));$('lon').dispatchEvent(new Event('change',{bubbles:true}));state.geo={place:v.name,timezone:v.timezone,elevationM:v.elevation};$('advGeoInfo').textContent=`${v.name} · timezone ${v.timezone||'unknown'} · approximate site elevation ${v.elevation??'unknown'} m; confirm survey elevations.`;box.replaceChildren();render()});box.append(b)}if(!matches.length)box.textContent='No matching places found.';
  }catch(e){box.textContent='Place search unavailable: '+e.message}
}
async function geoMeta(){const s=source(),lat=s?.config.lat??Number($('lat').value),lon=s?.config.lon??Number($('lon').value);
  $('advGeoInfo').textContent='Retrieving timezone and provider elevation…';try{
    const url='https://api.open-meteo.com/v1/forecast?'+new URLSearchParams({latitude:String(lat),longitude:String(lon),current:'temperature_2m',timezone:'auto',forecast_days:'1'});
    const response=await fetch(url);if(!response.ok)throw Error('HTTP '+response.status);
    const payload=await response.json();state.geo={timezone:payload.timezone,elevationM:payload.elevation};
    $('advGeoInfo').textContent=`Coordinates ${lat}°, ${lon}° · timezone ${payload.timezone||'unavailable'} · approximate terrain elevation ${payload.elevation??'unavailable'} m. Timezone is display metadata: the validated calculations remain UTC.`;
  }catch(e){$('advGeoInfo').textContent='Site metadata unavailable: '+e.message}
}
$('advModel').addEventListener('change',e=>{state.model=e.target.value;state.opt=null;render()});
$('advPlaceButton').addEventListener('click',geoSearch);
$('advPlaceSearch').addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();geoSearch()}});
$('advGeoButton').addEventListener('click',geoMeta);
document.querySelectorAll('[data-adv-tab]').forEach(b=>b.addEventListener('click',()=>{state.tab=b.dataset.advTab;render()}));
window.addEventListener('solarresource:updated',render);
render();
