// Transcrypt'ed from Python, 2026-10-06 14:55:50
import {AssertionError, AttributeError, BaseException, DeprecationWarning, Exception, IndexError, IterableError, KeyError, NotImplementedError, RuntimeWarning, StopIteration, UserWarning, ValueError, Warning, __JsIterator__, __PyIterator__, __Terminal__, __add__, __and__, __call__, __class__, __envir__, __eq__, __floordiv__, __ge__, __get__, __getcm__, __getitem__, __getslice__, __getsm__, __gt__, __i__, __iadd__, __iand__, __idiv__, __ijsmod__, __ilshift__, __imatmul__, __imod__, __imul__, __in__, __init__, __ior__, __ipow__, __irshift__, __isub__, __ixor__, __jsUsePyNext__, __jsmod__, __k__, __kwargtrans__, __le__, __lshift__, __lt__, __matmul__, __mergefields__, __mergekwargtrans__, __mod__, __mul__, __ne__, __neg__, __nest__, __or__, __pow__, __pragma__, __pyUseJsNext__, __rshift__, __setitem__, __setproperty__, __setslice__, __sort__, __specialattrib__, __sub__, __super__, __t__, __terminal__, __truediv__, __withblock__, __xor__, _sort, abs, all, any, assert, bin, bool, bytearray, bytes, callable, chr, delattr, dict, dir, divmod, filter, float, format, getattr, hasattr, hex, input, int, isinstance, issubclass, len, list, map, max, min, object, oct, ord, print, property, py_TypeError, py_enumerate, py_iter, py_metatype, py_next, py_reversed, py_typeof, range, repr, round, set, setattr, sorted, str, sum, tuple, zip} from './org.transcrypt.__runtime__.js';
var __name__ = 'math';
export var pi = Math.PI;
export var e = Math.E;
export var exp = Math.exp;
export var expm1 = function (x) {
	if (arguments.length) {
		var __ilastarg0__ = arguments.length - 1;
		if (arguments [__ilastarg0__] && arguments [__ilastarg0__].hasOwnProperty ("__kwargtrans__")) {
			var __allkwargs0__ = arguments [__ilastarg0__--];
			for (var __attrib0__ in __allkwargs0__) {
				switch (__attrib0__) {
					case 'x': var x = __allkwargs0__ [__attrib0__]; break;
				}
			}
		}
	}
	else {
	}
	return __sub__ ((function () {
		var __accu0__ = Math;
		return __call__ (__accu0__.exp, __accu0__, x);
	}) (), 1);
};
export var log = function (x, base) {
	if (arguments.length) {
		var __ilastarg0__ = arguments.length - 1;
		if (arguments [__ilastarg0__] && arguments [__ilastarg0__].hasOwnProperty ("__kwargtrans__")) {
			var __allkwargs0__ = arguments [__ilastarg0__--];
			for (var __attrib0__ in __allkwargs0__) {
				switch (__attrib0__) {
					case 'x': var x = __allkwargs0__ [__attrib0__]; break;
					case 'base': var base = __allkwargs0__ [__attrib0__]; break;
				}
			}
		}
	}
	else {
	}
	return (__t__ (base === undefined) ? (function () {
		var __accu0__ = Math;
		return __call__ (__accu0__.log, __accu0__, x);
	}) () : __truediv__ ((function () {
		var __accu0__ = Math;
		return __call__ (__accu0__.log, __accu0__, x);
	}) (), (function () {
		var __accu0__ = Math;
		return __call__ (__accu0__.log, __accu0__, base);
	}) ()));
};
export var log1p = function (x) {
	if (arguments.length) {
		var __ilastarg0__ = arguments.length - 1;
		if (arguments [__ilastarg0__] && arguments [__ilastarg0__].hasOwnProperty ("__kwargtrans__")) {
			var __allkwargs0__ = arguments [__ilastarg0__--];
			for (var __attrib0__ in __allkwargs0__) {
				switch (__attrib0__) {
					case 'x': var x = __allkwargs0__ [__attrib0__]; break;
				}
			}
		}
	}
	else {
	}
	return (function () {
		var __accu0__ = Math;
		return __call__ (__accu0__.log, __accu0__, __add__ (x, 1));
	}) ();
};
export var log2 = function (x) {
	if (arguments.length) {
		var __ilastarg0__ = arguments.length - 1;
		if (arguments [__ilastarg0__] && arguments [__ilastarg0__].hasOwnProperty ("__kwargtrans__")) {
			var __allkwargs0__ = arguments [__ilastarg0__--];
			for (var __attrib0__ in __allkwargs0__) {
				switch (__attrib0__) {
					case 'x': var x = __allkwargs0__ [__attrib0__]; break;
				}
			}
		}
	}
	else {
	}
	return __truediv__ ((function () {
		var __accu0__ = Math;
		return __call__ (__accu0__.log, __accu0__, x);
	}) (), Math.LN2);
};
export var log10 = function (x) {
	if (arguments.length) {
		var __ilastarg0__ = arguments.length - 1;
		if (arguments [__ilastarg0__] && arguments [__ilastarg0__].hasOwnProperty ("__kwargtrans__")) {
			var __allkwargs0__ = arguments [__ilastarg0__--];
			for (var __attrib0__ in __allkwargs0__) {
				switch (__attrib0__) {
					case 'x': var x = __allkwargs0__ [__attrib0__]; break;
				}
			}
		}
	}
	else {
	}
	return __truediv__ ((function () {
		var __accu0__ = Math;
		return __call__ (__accu0__.log, __accu0__, x);
	}) (), Math.LN10);
};
export var pow = Math.pow;
export var sqrt = Math.sqrt;
export var sin = Math.sin;
export var cos = Math.cos;
export var tan = Math.tan;
export var asin = Math.asin;
export var acos = Math.acos;
export var atan = Math.atan;
export var atan2 = Math.atan2;
export var hypot = Math.hypot;
export var degrees = function (x) {
	if (arguments.length) {
		var __ilastarg0__ = arguments.length - 1;
		if (arguments [__ilastarg0__] && arguments [__ilastarg0__].hasOwnProperty ("__kwargtrans__")) {
			var __allkwargs0__ = arguments [__ilastarg0__--];
			for (var __attrib0__ in __allkwargs0__) {
				switch (__attrib0__) {
					case 'x': var x = __allkwargs0__ [__attrib0__]; break;
				}
			}
		}
	}
	else {
	}
	return __truediv__ (__mul__ (x, 180), Math.PI);
};
export var radians = function (x) {
	if (arguments.length) {
		var __ilastarg0__ = arguments.length - 1;
		if (arguments [__ilastarg0__] && arguments [__ilastarg0__].hasOwnProperty ("__kwargtrans__")) {
			var __allkwargs0__ = arguments [__ilastarg0__--];
			for (var __attrib0__ in __allkwargs0__) {
				switch (__attrib0__) {
					case 'x': var x = __allkwargs0__ [__attrib0__]; break;
				}
			}
		}
	}
	else {
	}
	return __truediv__ (__mul__ (x, Math.PI), 180);
};
export var sinh = Math.sinh;
export var cosh = Math.cosh;
export var tanh = Math.tanh;
export var asinh = Math.asinh;
export var acosh = Math.acosh;
export var atanh = Math.atanh;
export var floor = Math.floor;
export var ceil = Math.ceil;
export var trunc = Math.trunc;
export var copysign = function (x, y) {
	if (arguments.length) {
		var __ilastarg0__ = arguments.length - 1;
		if (arguments [__ilastarg0__] && arguments [__ilastarg0__].hasOwnProperty ("__kwargtrans__")) {
			var __allkwargs0__ = arguments [__ilastarg0__--];
			for (var __attrib0__ in __allkwargs0__) {
				switch (__attrib0__) {
					case 'x': var x = __allkwargs0__ [__attrib0__]; break;
					case 'y': var y = __allkwargs0__ [__attrib0__]; break;
				}
			}
		}
	}
	else {
	}
	return (__t__ (__eq__ ((function () {
		var __accu0__ = Math;
		return __call__ (__accu0__.sign, __accu0__, x);
	}) (), (function () {
		var __accu0__ = Math;
		return __call__ (__accu0__.sign, __accu0__, y);
	}) ())) ? x : __neg__ (x));
};
export var isclose = function (a, b, rel_tol, abs_tol) {
	if (typeof rel_tol == 'undefined' || (rel_tol != null && rel_tol.hasOwnProperty ("__kwargtrans__"))) {;
		var rel_tol = 1e-09;
	};
	if (typeof abs_tol == 'undefined' || (abs_tol != null && abs_tol.hasOwnProperty ("__kwargtrans__"))) {;
		var abs_tol = 0.0;
	};
	if (arguments.length) {
		var __ilastarg0__ = arguments.length - 1;
		if (arguments [__ilastarg0__] && arguments [__ilastarg0__].hasOwnProperty ("__kwargtrans__")) {
			var __allkwargs0__ = arguments [__ilastarg0__--];
			for (var __attrib0__ in __allkwargs0__) {
				switch (__attrib0__) {
					case 'a': var a = __allkwargs0__ [__attrib0__]; break;
					case 'b': var b = __allkwargs0__ [__attrib0__]; break;
					case 'rel_tol': var rel_tol = __allkwargs0__ [__attrib0__]; break;
					case 'abs_tol': var abs_tol = __allkwargs0__ [__attrib0__]; break;
				}
			}
		}
	}
	else {
	}
	return __le__ ((function () {
		var __accu0__ = Math;
		return __call__ (__accu0__.abs, __accu0__, __sub__ (a, b));
	}) (), (function () {
		var __accu0__ = Math;
		return __call__ (__accu0__.max, __accu0__, __mul__ (rel_tol, (function () {
			var __accu1__ = Math;
			return __call__ (__accu1__.max, __accu1__, (function () {
				var __accu2__ = Math;
				return __call__ (__accu2__.abs, __accu2__, a);
			}) (), (function () {
				var __accu2__ = Math;
				return __call__ (__accu2__.abs, __accu2__, b);
			}) ());
		}) ()), abs_tol);
	}) ());
};
export var isnan = isNaN;
export var inf = Infinity;
export var nan = NaN;
export var modf = function (n) {
	var sign = (__t__ (__ge__ (n, 0)) ? 1 : __neg__ (1));
	var __left0__ = __call__ (divmod, null, __call__ (abs, null, n), 1);
	var f = __left0__ [0];
	var mod = __left0__ [1];
	return tuple ([__mul__ (mod, sign), __mul__ (f, sign)]);
};

//# sourceMappingURL=math.map