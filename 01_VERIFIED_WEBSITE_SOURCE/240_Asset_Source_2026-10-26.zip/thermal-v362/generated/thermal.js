// Transcrypt'ed from Python, 2026-10-11 07:01:11
import {AssertionError, AttributeError, BaseException, DeprecationWarning, Exception, IndexError, IterableError, KeyError, NotImplementedError, RuntimeWarning, StopIteration, UserWarning, ValueError, Warning, __JsIterator__, __PyIterator__, __Terminal__, __add__, __and__, __call__, __class__, __envir__, __eq__, __floordiv__, __ge__, __get__, __getcm__, __getitem__, __getslice__, __getsm__, __gt__, __i__, __iadd__, __iand__, __idiv__, __ijsmod__, __ilshift__, __imatmul__, __imod__, __imul__, __in__, __init__, __ior__, __ipow__, __irshift__, __isub__, __ixor__, __jsUsePyNext__, __jsmod__, __k__, __kwargtrans__, __le__, __lshift__, __lt__, __matmul__, __mergefields__, __mergekwargtrans__, __mod__, __mul__, __ne__, __neg__, __nest__, __or__, __pow__, __pragma__, __pyUseJsNext__, __rshift__, __setitem__, __setproperty__, __setslice__, __sort__, __specialattrib__, __sub__, __super__, __t__, __terminal__, __truediv__, __withblock__, __xor__, _sort, abs, all, any, assert, bin, bool, bytearray, bytes, callable, chr, delattr, dict, dir, divmod, filter, float, format, getattr, hasattr, hex, input, int, isinstance, issubclass, len, list, map, object, oct, ord, pow, print, property, py_TypeError, py_enumerate, py_iter, py_metatype, py_next, py_reversed, py_typeof, range, repr, round, set, setattr, sorted, str, sum, tuple, zip} from './org.transcrypt.__runtime__.js';
import {combinations, product} from './itertools.js';
import {hypot, log, pi, sqrt} from './math.js';
var __name__ = '__main__';
export var count_items = function (py_values, target) {
	if (arguments.length) {
		var __ilastarg0__ = arguments.length - 1;
		if (arguments [__ilastarg0__] && arguments [__ilastarg0__].hasOwnProperty ("__kwargtrans__")) {
			var __allkwargs0__ = arguments [__ilastarg0__--];
			for (var __attrib0__ in __allkwargs0__) {
				switch (__attrib0__) {
					case 'py_values': var py_values = __allkwargs0__ [__attrib0__]; break;
					case 'target': var target = __allkwargs0__ [__attrib0__]; break;
				}
			}
		}
	}
	else {
	}
	return __call__ (sum, null, (function () {
		var __accu0__ = [];
		var __iterable0__ = py_values;
		for (var __index0__ = 0; __index0__ < len (__iterable0__); __index0__++) {
			var v = __getitem__ (__iterable0__, __index0__);
			if (__t__ (__eq__ (v, target))) {
				(function () {
					var __accu1__ = __accu0__;
					return __call__ (__accu1__.append, __accu1__, 1);
				}) ();
			}
		}
		return py_iter (__accu0__);
	}) ());
};
export var merge_dicts = function () {
	if (arguments.length) {
		var __ilastarg0__ = arguments.length - 1;
		if (arguments [__ilastarg0__] && arguments [__ilastarg0__].hasOwnProperty ("__kwargtrans__")) {
			var __allkwargs0__ = arguments [__ilastarg0__--];
			for (var __attrib0__ in __allkwargs0__) {
			}
		}
		var parts = tuple ([].slice.apply (arguments).slice (0, __ilastarg0__ + 1));
	}
	else {
		var parts = tuple ();
	}
	var out = dict ({});
	var __iterable0__ = parts;
	for (var __index0__ = 0; __index0__ < len (__iterable0__); __index0__++) {
		var p = __getitem__ (__iterable0__, __index0__);
		(function () {
			var __accu0__ = out;
			return __call__ (__accu0__.py_update, __accu0__, p);
		}) ();
	}
	return out;
};
export var isfinite = function (v) {
	if (arguments.length) {
		var __ilastarg0__ = arguments.length - 1;
		if (arguments [__ilastarg0__] && arguments [__ilastarg0__].hasOwnProperty ("__kwargtrans__")) {
			var __allkwargs0__ = arguments [__ilastarg0__--];
			for (var __attrib0__ in __allkwargs0__) {
				switch (__attrib0__) {
					case 'v': var v = __allkwargs0__ [__attrib0__]; break;
				}
			}
		}
	}
	else {
	}
	return Number.isFinite(v);
};
export var asdict = function (value) {
	if (arguments.length) {
		var __ilastarg0__ = arguments.length - 1;
		if (arguments [__ilastarg0__] && arguments [__ilastarg0__].hasOwnProperty ("__kwargtrans__")) {
			var __allkwargs0__ = arguments [__ilastarg0__--];
			for (var __attrib0__ in __allkwargs0__) {
				switch (__attrib0__) {
					case 'value': var value = __allkwargs0__ [__attrib0__]; break;
				}
			}
		}
	}
	else {
	}
	if (__t__ (__call__ (hasattr, null, value, '__fields__'))) {
		return (function () {
			var __accu0__ = [];
			var __iterable0__ = value.__fields__;
			for (var __index0__ = 0; __index0__ < len (__iterable0__); __index0__++) {
				var k = __getitem__ (__iterable0__, __index0__);
				(function () {
					var __accu1__ = __accu0__;
					return __call__ (__accu1__.append, __accu1__, [k, __call__ (asdict, null, __call__ (getattr, null, value, k))]);
				}) ();
			}
			return dict (__accu0__);
		}) ();
	}
	if (__t__ (__call__ (isinstance, null, value, list))) {
		return (function () {
			var __accu0__ = [];
			var __iterable0__ = value;
			for (var __index0__ = 0; __index0__ < len (__iterable0__); __index0__++) {
				var v = __getitem__ (__iterable0__, __index0__);
				(function () {
					var __accu1__ = __accu0__;
					return __call__ (__accu1__.append, __accu1__, __call__ (asdict, null, v));
				}) ();
			}
			return __accu0__;
		}) ();
	}
	if (__t__ (__call__ (isinstance, null, value, dict))) {
		return (function () {
			var __accu0__ = [];
			var __iterable0__ = (function () {
				var __accu1__ = value;
				return __call__ (__accu1__.py_items, __accu1__);
			}) ();
			for (var __index0__ = 0; __index0__ < len (__iterable0__); __index0__++) {
				var __left0__ = __getitem__ (__iterable0__, __index0__);
				var k = __left0__ [0];
				var v = __left0__ [1];
				(function () {
					var __accu1__ = __accu0__;
					return __call__ (__accu1__.append, __accu1__, [k, __call__ (asdict, null, v)]);
				}) ();
			}
			return dict (__accu0__);
		}) ();
	}
	return value;
};
export var min = function () {
	var key = null;
	var py_default = null;
	if (arguments.length) {
		var __ilastarg0__ = arguments.length - 1;
		if (arguments [__ilastarg0__] && arguments [__ilastarg0__].hasOwnProperty ("__kwargtrans__")) {
			var __allkwargs0__ = arguments [__ilastarg0__--];
			for (var __attrib0__ in __allkwargs0__) {
				switch (__attrib0__) {
					case 'key': var key = __allkwargs0__ [__attrib0__]; break;
					case 'py_default': var py_default = __allkwargs0__ [__attrib0__]; break;
				}
			}
		}
		var args = tuple ([].slice.apply (arguments).slice (0, __ilastarg0__ + 1));
	}
	else {
		var args = tuple ();
	}
	var py_values = (__t__ (__eq__ (__call__ (len, null, args), 1)) ? __call__ (list, null, __getitem__ (args, 0)) : __call__ (list, null, args));
	if (__t__ (!__t__ ((py_values)))) {
		return py_default;
	}
	var best = __getitem__ (py_values, 0);
	var __iterable0__ = __getslice__ (py_values, 1, null, 1);
	for (var __index0__ = 0; __index0__ < len (__iterable0__); __index0__++) {
		var v = __getitem__ (__iterable0__, __index0__);
		if (__t__ (__lt__ ((__t__ (key) ? __call__ (key, null, v) : v), (__t__ (key) ? __call__ (key, null, best) : best)))) {
			var best = v;
		}
	}
	return best;
};
export var max = function () {
	var key = null;
	var py_default = null;
	if (arguments.length) {
		var __ilastarg0__ = arguments.length - 1;
		if (arguments [__ilastarg0__] && arguments [__ilastarg0__].hasOwnProperty ("__kwargtrans__")) {
			var __allkwargs0__ = arguments [__ilastarg0__--];
			for (var __attrib0__ in __allkwargs0__) {
				switch (__attrib0__) {
					case 'key': var key = __allkwargs0__ [__attrib0__]; break;
					case 'py_default': var py_default = __allkwargs0__ [__attrib0__]; break;
				}
			}
		}
		var args = tuple ([].slice.apply (arguments).slice (0, __ilastarg0__ + 1));
	}
	else {
		var args = tuple ();
	}
	var py_values = (__t__ (__eq__ (__call__ (len, null, args), 1)) ? __call__ (list, null, __getitem__ (args, 0)) : __call__ (list, null, args));
	if (__t__ (!__t__ ((py_values)))) {
		return py_default;
	}
	var best = __getitem__ (py_values, 0);
	var __iterable0__ = __getslice__ (py_values, 1, null, 1);
	for (var __index0__ = 0; __index0__ < len (__iterable0__); __index0__++) {
		var v = __getitem__ (__iterable0__, __index0__);
		if (__t__ (__gt__ ((__t__ (key) ? __call__ (key, null, v) : v), (__t__ (key) ? __call__ (key, null, best) : best)))) {
			var best = v;
		}
	}
	return best;
};
export var ThermalInput =  __class__ ('ThermalInput', [object], {
	__module__: __name__,
	get __init__ () {return __get__ (this, function (self, load_a, ambient_c, max_temp_c, soil_rho_km_w, burial_depth_m, cable_od_m, r20_ohm_m, alpha_per_c, ac_factor, dielectric_w_m, r_internal_km_w, r_dielectric_internal_km_w, group_multiplier, phases) {
		if (typeof load_a == 'undefined' || (load_a != null && load_a.hasOwnProperty ("__kwargtrans__"))) {;
			var load_a = 500.0;
		};
		if (typeof ambient_c == 'undefined' || (ambient_c != null && ambient_c.hasOwnProperty ("__kwargtrans__"))) {;
			var ambient_c = 25.0;
		};
		if (typeof max_temp_c == 'undefined' || (max_temp_c != null && max_temp_c.hasOwnProperty ("__kwargtrans__"))) {;
			var max_temp_c = 90.0;
		};
		if (typeof soil_rho_km_w == 'undefined' || (soil_rho_km_w != null && soil_rho_km_w.hasOwnProperty ("__kwargtrans__"))) {;
			var soil_rho_km_w = 1.0;
		};
		if (typeof burial_depth_m == 'undefined' || (burial_depth_m != null && burial_depth_m.hasOwnProperty ("__kwargtrans__"))) {;
			var burial_depth_m = 0.939165;
		};
		if (typeof cable_od_m == 'undefined' || (cable_od_m != null && cable_od_m.hasOwnProperty ("__kwargtrans__"))) {;
			var cable_od_m = 0.04953;
		};
		if (typeof r20_ohm_m == 'undefined' || (r20_ohm_m != null && r20_ohm_m.hasOwnProperty ("__kwargtrans__"))) {;
			var r20_ohm_m = 5.69e-05;
		};
		if (typeof alpha_per_c == 'undefined' || (alpha_per_c != null && alpha_per_c.hasOwnProperty ("__kwargtrans__"))) {;
			var alpha_per_c = 0.00403;
		};
		if (typeof ac_factor == 'undefined' || (ac_factor != null && ac_factor.hasOwnProperty ("__kwargtrans__"))) {;
			var ac_factor = 1.0251328070572212;
		};
		if (typeof dielectric_w_m == 'undefined' || (dielectric_w_m != null && dielectric_w_m.hasOwnProperty ("__kwargtrans__"))) {;
			var dielectric_w_m = 0.004114251237296077;
		};
		if (typeof r_internal_km_w == 'undefined' || (r_internal_km_w != null && r_internal_km_w.hasOwnProperty ("__kwargtrans__"))) {;
			var r_internal_km_w = 0.2721190225149088;
		};
		if (typeof r_dielectric_internal_km_w == 'undefined' || (r_dielectric_internal_km_w != null && r_dielectric_internal_km_w.hasOwnProperty ("__kwargtrans__"))) {;
			var r_dielectric_internal_km_w = 0.18199013568525835;
		};
		if (typeof group_multiplier == 'undefined' || (group_multiplier != null && group_multiplier.hasOwnProperty ("__kwargtrans__"))) {;
			var group_multiplier = 2.2377027287708477;
		};
		if (typeof phases == 'undefined' || (phases != null && phases.hasOwnProperty ("__kwargtrans__"))) {;
			var phases = 3;
		};
		if (arguments.length) {
			var __ilastarg0__ = arguments.length - 1;
			if (arguments [__ilastarg0__] && arguments [__ilastarg0__].hasOwnProperty ("__kwargtrans__")) {
				var __allkwargs0__ = arguments [__ilastarg0__--];
				for (var __attrib0__ in __allkwargs0__) {
					switch (__attrib0__) {
						case 'self': var self = __allkwargs0__ [__attrib0__]; break;
						case 'load_a': var load_a = __allkwargs0__ [__attrib0__]; break;
						case 'ambient_c': var ambient_c = __allkwargs0__ [__attrib0__]; break;
						case 'max_temp_c': var max_temp_c = __allkwargs0__ [__attrib0__]; break;
						case 'soil_rho_km_w': var soil_rho_km_w = __allkwargs0__ [__attrib0__]; break;
						case 'burial_depth_m': var burial_depth_m = __allkwargs0__ [__attrib0__]; break;
						case 'cable_od_m': var cable_od_m = __allkwargs0__ [__attrib0__]; break;
						case 'r20_ohm_m': var r20_ohm_m = __allkwargs0__ [__attrib0__]; break;
						case 'alpha_per_c': var alpha_per_c = __allkwargs0__ [__attrib0__]; break;
						case 'ac_factor': var ac_factor = __allkwargs0__ [__attrib0__]; break;
						case 'dielectric_w_m': var dielectric_w_m = __allkwargs0__ [__attrib0__]; break;
						case 'r_internal_km_w': var r_internal_km_w = __allkwargs0__ [__attrib0__]; break;
						case 'r_dielectric_internal_km_w': var r_dielectric_internal_km_w = __allkwargs0__ [__attrib0__]; break;
						case 'group_multiplier': var group_multiplier = __allkwargs0__ [__attrib0__]; break;
						case 'phases': var phases = __allkwargs0__ [__attrib0__]; break;
					}
				}
			}
		}
		else {
		}
		self.__fields__ = ['load_a', 'ambient_c', 'max_temp_c', 'soil_rho_km_w', 'burial_depth_m', 'cable_od_m', 'r20_ohm_m', 'alpha_per_c', 'ac_factor', 'dielectric_w_m', 'r_internal_km_w', 'r_dielectric_internal_km_w', 'group_multiplier', 'phases'];
		self.load_a = load_a;
		self.ambient_c = ambient_c;
		self.max_temp_c = max_temp_c;
		self.soil_rho_km_w = soil_rho_km_w;
		self.burial_depth_m = burial_depth_m;
		self.cable_od_m = cable_od_m;
		self.r20_ohm_m = r20_ohm_m;
		self.alpha_per_c = alpha_per_c;
		self.ac_factor = ac_factor;
		self.dielectric_w_m = dielectric_w_m;
		self.r_internal_km_w = r_internal_km_w;
		self.r_dielectric_internal_km_w = r_dielectric_internal_km_w;
		self.group_multiplier = group_multiplier;
		self.phases = phases;
	});}
});
export var validate_input = function (x) {
	if (arguments.length) {
		var __ilastarg0__ = arguments.length - 1;
		if (arguments [__ilastarg0__] && arguments [__ilastarg0__].hasOwnProperty ("__kwargtrans__")) {
			var __allkwargs0__ = arguments [__ilastarg0__--];
			for (var __attrib0__ in __allkwargs0__) {
				switch (__attrib0__) {
					case 'x': var x = __allkwargs0__ [__attrib0__]; break;
				}
			}
		}
	}
	else {
	}
	var issues = [];
	if (__t__ (__lt__ (x.load_a, 0))) {
		(function () {
			var __accu0__ = issues;
			return __call__ (__accu0__.append, __accu0__, 'Load current must be >= 0 A.');
		}) ();
	}
	if (__t__ (__ge__ (x.ambient_c, x.max_temp_c))) {
		(function () {
			var __accu0__ = issues;
			return __call__ (__accu0__.append, __accu0__, 'Ambient/earth temperature must be below maximum conductor temperature.');
		}) ();
	}
	if (__t__ (__le__ (x.soil_rho_km_w, 0))) {
		(function () {
			var __accu0__ = issues;
			return __call__ (__accu0__.append, __accu0__, 'Soil thermal resistivity must be > 0 K·m/W.');
		}) ();
	}
	if (__t__ (__le__ (x.cable_od_m, 0))) {
		(function () {
			var __accu0__ = issues;
			return __call__ (__accu0__.append, __accu0__, 'Cable outside diameter must be > 0 m.');
		}) ();
	}
	if (__t__ (__le__ (x.burial_depth_m, __truediv__ (x.cable_od_m, 2)))) {
		(function () {
			var __accu0__ = issues;
			return __call__ (__accu0__.append, __accu0__, 'Burial depth to cable center must exceed cable radius.');
		}) ();
	}
	if (__t__ (__le__ (x.r20_ohm_m, 0))) {
		(function () {
			var __accu0__ = issues;
			return __call__ (__accu0__.append, __accu0__, 'Conductor R20 must be > 0 Ω/m.');
		}) ();
	}
	if (__t__ (__le__ (x.alpha_per_c, 0))) {
		(function () {
			var __accu0__ = issues;
			return __call__ (__accu0__.append, __accu0__, 'Temperature coefficient must be > 0 /°C.');
		}) ();
	}
	if (__t__ (__le__ (x.ac_factor, 0))) {
		(function () {
			var __accu0__ = issues;
			return __call__ (__accu0__.append, __accu0__, 'AC resistance factor must be > 0.');
		}) ();
	}
	if (__t__ (__t__ (__lt__ (x.r_internal_km_w, 0)) || __lt__ (x.r_dielectric_internal_km_w, 0))) {
		(function () {
			var __accu0__ = issues;
			return __call__ (__accu0__.append, __accu0__, 'Internal thermal resistances must be >= 0.');
		}) ();
	}
	if (__t__ (__le__ (x.group_multiplier, 0))) {
		(function () {
			var __accu0__ = issues;
			return __call__ (__accu0__.append, __accu0__, 'Group/mutual-heating multiplier must be > 0.');
		}) ();
	}
	if (__t__ (__lt__ (x.dielectric_w_m, 0))) {
		(function () {
			var __accu0__ = issues;
			return __call__ (__accu0__.append, __accu0__, 'Dielectric heat must be >= 0 W/m.');
		}) ();
	}
	if (__t__ (!__in__ (x.phases, tuple ([1, 2, 3])))) {
		(function () {
			var __accu0__ = issues;
			return __call__ (__accu0__.append, __accu0__, 'Phases must be 1, 2, or 3.');
		}) ();
	}
	return issues;
};
export var external_t4 = function (x) {
	if (arguments.length) {
		var __ilastarg0__ = arguments.length - 1;
		if (arguments [__ilastarg0__] && arguments [__ilastarg0__].hasOwnProperty ("__kwargtrans__")) {
			var __allkwargs0__ = arguments [__ilastarg0__--];
			for (var __attrib0__ in __allkwargs0__) {
				switch (__attrib0__) {
					case 'x': var x = __allkwargs0__ [__attrib0__]; break;
				}
			}
		}
	}
	else {
	}
	var u = __truediv__ (__mul__ (2.0, x.burial_depth_m), x.cable_od_m);
	return __mul__ (__mul__ (__truediv__ (x.soil_rho_km_w, __mul__ (2.0, 3.141592653589793)), __call__ (log, null, __add__ (u, __call__ (sqrt, null, __sub__ (__mul__ (u, u), 1.0))))), x.group_multiplier);
};
export var rac_at_temp = function (x, temp_c) {
	if (arguments.length) {
		var __ilastarg0__ = arguments.length - 1;
		if (arguments [__ilastarg0__] && arguments [__ilastarg0__].hasOwnProperty ("__kwargtrans__")) {
			var __allkwargs0__ = arguments [__ilastarg0__--];
			for (var __attrib0__ in __allkwargs0__) {
				switch (__attrib0__) {
					case 'x': var x = __allkwargs0__ [__attrib0__]; break;
					case 'temp_c': var temp_c = __allkwargs0__ [__attrib0__]; break;
				}
			}
		}
	}
	else {
	}
	return __mul__ (__mul__ (x.r20_ohm_m, __add__ (1.0, __mul__ (x.alpha_per_c, __sub__ (temp_c, 20.0)))), x.ac_factor);
};
export var solve_steady = function (x, tol_c, max_iter) {
	if (typeof tol_c == 'undefined' || (tol_c != null && tol_c.hasOwnProperty ("__kwargtrans__"))) {;
		var tol_c = 1e-08;
	};
	if (typeof max_iter == 'undefined' || (max_iter != null && max_iter.hasOwnProperty ("__kwargtrans__"))) {;
		var max_iter = 200;
	};
	if (arguments.length) {
		var __ilastarg0__ = arguments.length - 1;
		if (arguments [__ilastarg0__] && arguments [__ilastarg0__].hasOwnProperty ("__kwargtrans__")) {
			var __allkwargs0__ = arguments [__ilastarg0__--];
			for (var __attrib0__ in __allkwargs0__) {
				switch (__attrib0__) {
					case 'x': var x = __allkwargs0__ [__attrib0__]; break;
					case 'tol_c': var tol_c = __allkwargs0__ [__attrib0__]; break;
					case 'max_iter': var max_iter = __allkwargs0__ [__attrib0__]; break;
				}
			}
		}
	}
	else {
	}
	var issues = __call__ (validate_input, null, x);
	if (__t__ (issues)) {
		return dict ({'status': 'INPUT REQUIRED', 'issues': issues, 'input': __call__ (asdict, null, x)});
	}
	var t4 = __call__ (external_t4, null, x);
	var r_factor = __add__ (x.r_internal_km_w, t4);
	var dielectric_r_factor = __add__ (x.r_dielectric_internal_km_w, t4);
	var rac_max = __call__ (rac_at_temp, null, x, x.max_temp_c);
	var available = __sub__ (__sub__ (x.max_temp_c, x.ambient_c), __mul__ (x.dielectric_w_m, dielectric_r_factor));
	var ampacity = (__t__ (__gt__ (available, 0)) ? __call__ (sqrt, null, __truediv__ (available, __mul__ (rac_max, r_factor))) : 0.0);
	var temp = x.ambient_c;
	var iterations = 0;
	var converged = false;
	var __iterable0__ = __call__ (list, null, __call__ (range, null, 1, __add__ (max_iter, 1)));
	for (var __index0__ = 0; __index0__ < len (__iterable0__); __index0__++) {
		var iterations = __getitem__ (__iterable0__, __index0__);
		var rac = __call__ (rac_at_temp, null, x, temp);
		var new_temp = __add__ (__add__ (x.ambient_c, __mul__ (__mul__ (__mul__ (x.load_a, x.load_a), rac), r_factor)), __mul__ (x.dielectric_w_m, dielectric_r_factor));
		if (__t__ (__t__ (!__t__ ((__call__ (isfinite, null, new_temp)))) || __gt__ (__call__ (abs, null, new_temp), 1000000.0))) {
			return dict ({'status': 'REVIEW REQUIRED', 'issues': ['Nonlinear temperature iteration diverged for this input combination.'], 'input': __call__ (asdict, null, x)});
		}
		if (__t__ (__le__ (__call__ (abs, null, __sub__ (new_temp, temp)), tol_c))) {
			var temp = new_temp;
			var converged = true;
			break;
		}
		var temp = new_temp;
	}
	var rac_actual = __call__ (rac_at_temp, null, x, temp);
	var conductor_heat_per_conductor = __mul__ (__mul__ (x.load_a, x.load_a), rac_actual);
	var conductor_heat_total = __mul__ (conductor_heat_per_conductor, x.phases);
	var dielectric_heat_total = __mul__ (x.dielectric_w_m, x.phases);
	var total_heat = __add__ (conductor_heat_total, dielectric_heat_total);
	var utilization = (__t__ (__gt__ (ampacity, 0)) ? __truediv__ (x.load_a, ampacity) : __call__ (float, null, 'inf'));
	var margin = __sub__ (x.max_temp_c, temp);
	if (__t__ (!__t__ ((converged)))) {
		var status = 'REVIEW REQUIRED';
		var issues = ['Adaptive conductor-temperature iteration did not meet tolerance.'];
	}
	else if (__t__ (__t__ (__gt__ (temp, x.max_temp_c)) || __gt__ (utilization, 1.0))) {
		var status = 'FAIL';
		var issues = ['Thermal limit exceeded at the entered load/environment.'];
	}
	else {
		var status = 'PASS';
		var issues = [];
	}
	return dict ({'status': status, 'issues': issues, 'ampacity_a': ampacity, 'conductor_temp_c': temp, 'temperature_margin_c': margin, 'utilization': utilization, 't4_km_w': t4, 'r_factor_km_w': r_factor, 'dielectric_r_factor_km_w': dielectric_r_factor, 'rac_ohm_m': rac_actual, 'conductor_heat_per_conductor_w_m': conductor_heat_per_conductor, 'conductor_heat_total_w_m': conductor_heat_total, 'dielectric_heat_total_w_m': dielectric_heat_total, 'total_heat_w_m': total_heat, 'iterations': iterations, 'converged': converged, 'input': __call__ (asdict, null, x)});
};
export var route_rating = function (base, segments) {
	if (arguments.length) {
		var __ilastarg0__ = arguments.length - 1;
		if (arguments [__ilastarg0__] && arguments [__ilastarg0__].hasOwnProperty ("__kwargtrans__")) {
			var __allkwargs0__ = arguments [__ilastarg0__--];
			for (var __attrib0__ in __allkwargs0__) {
				switch (__attrib0__) {
					case 'base': var base = __allkwargs0__ [__attrib0__]; break;
					case 'segments': var segments = __allkwargs0__ [__attrib0__]; break;
				}
			}
		}
	}
	else {
	}
	var results = [];
	var __iterable0__ = __call__ (list, null, __call__ (py_enumerate, null, segments, 1));
	for (var __index0__ = 0; __index0__ < len (__iterable0__); __index0__++) {
		var __left0__ = __getitem__ (__iterable0__, __index0__);
		var i = __left0__ [0];
		var seg = __left0__ [1];
		var x = __call__ (ThermalInput, null, __kwargtrans__ (__call__ (asdict, null, base)));
		var __iterable1__ = __call__ (list, null, tuple (['ambient_c', 'soil_rho_km_w', 'burial_depth_m', 'group_multiplier']));
		for (var __index1__ = 0; __index1__ < len (__iterable1__); __index1__++) {
			var field = __getitem__ (__iterable1__, __index1__);
			if (__t__ (__t__ (__in__ (field, seg)) && __getitem__ (seg, field) !== null)) {
				__call__ (setattr, null, x, field, __call__ (float, null, __getitem__ (seg, field)));
			}
		}
		var res = __call__ (solve_steady, null, x);
		(function () {
			var __accu0__ = results;
			return __call__ (__accu0__.append, __accu0__, __call__ (merge_dicts, null, dict ({'index': i}), dict ({'name': __t__ ((function () {
				var __accu1__ = seg;
				return __call__ (__accu1__.py_get, __accu1__, 'name');
			}) ()) || 'Segment {}'.format (i)}), dict ({'length_m': __call__ (float, null, __t__ ((function () {
				var __accu1__ = seg;
				return __call__ (__accu1__.py_get, __accu1__, 'length_m');
			}) ()) || 0)}), dict ({'installation': __t__ ((function () {
				var __accu1__ = seg;
				return __call__ (__accu1__.py_get, __accu1__, 'installation');
			}) ()) || 'DIRECT BURIED'}), res));
		}) ();
	}
	var valid = (function () {
		var __accu0__ = [];
		var __iterable0__ = __call__ (list, null, results);
		for (var __index0__ = 0; __index0__ < len (__iterable0__); __index0__++) {
			var r = __getitem__ (__iterable0__, __index0__);
			if (__t__ (__call__ (isinstance, null, (function () {
				var __accu1__ = r;
				return __call__ (__accu1__.py_get, __accu1__, 'ampacity_a');
			}) (), tuple ([int, float])))) {
				(function () {
					var __accu1__ = __accu0__;
					return __call__ (__accu1__.append, __accu1__, r);
				}) ();
			}
		}
		return __accu0__;
	}) ();
	var governing = (__t__ (valid) ? __call__ (min, null, valid, __kwargtrans__ ({key: (function __lambda__ (r) {
		if (arguments.length) {
			var __ilastarg0__ = arguments.length - 1;
			if (arguments [__ilastarg0__] && arguments [__ilastarg0__].hasOwnProperty ("__kwargtrans__")) {
				var __allkwargs0__ = arguments [__ilastarg0__--];
				for (var __attrib0__ in __allkwargs0__) {
					switch (__attrib0__) {
						case 'r': var r = __allkwargs0__ [__attrib0__]; break;
					}
				}
			}
		}
		else {
		}
		return __getitem__ (r, 'ampacity_a');
	})})) : null);
	return dict ({'status': (__t__ (__t__ (governing) && __call__ (all, null, (function () {
		var __accu0__ = [];
		var __iterable0__ = __call__ (list, null, valid);
		for (var __index0__ = 0; __index0__ < len (__iterable0__); __index0__++) {
			var r = __getitem__ (__iterable0__, __index0__);
			(function () {
				var __accu1__ = __accu0__;
				return __call__ (__accu1__.append, __accu1__, __in__ (__getitem__ (r, 'status'), tuple (['PASS', 'FAIL'])));
			}) ();
		}
		return py_iter (__accu0__);
	}) ())) ? 'PASS' : 'REVIEW REQUIRED'), 'governing_segment': governing, 'segments': results});
};
export var sensitivity = function (base, variable, py_values) {
	if (arguments.length) {
		var __ilastarg0__ = arguments.length - 1;
		if (arguments [__ilastarg0__] && arguments [__ilastarg0__].hasOwnProperty ("__kwargtrans__")) {
			var __allkwargs0__ = arguments [__ilastarg0__--];
			for (var __attrib0__ in __allkwargs0__) {
				switch (__attrib0__) {
					case 'base': var base = __allkwargs0__ [__attrib0__]; break;
					case 'variable': var variable = __allkwargs0__ [__attrib0__]; break;
					case 'py_values': var py_values = __allkwargs0__ [__attrib0__]; break;
				}
			}
		}
	}
	else {
	}
	var allowed = new set (['soil_rho_km_w', 'ambient_c', 'burial_depth_m', 'group_multiplier', 'load_a']);
	if (__t__ (!__in__ (variable, allowed))) {
		var __except0__ = __call__ (ValueError, null, 'Unsupported sensitivity variable: {}'.format (variable));
		__except0__.__cause__ = null;
		throw __except0__;
	}
	var out = [];
	var __iterable0__ = __call__ (list, null, py_values);
	for (var __index0__ = 0; __index0__ < len (__iterable0__); __index0__++) {
		var value = __getitem__ (__iterable0__, __index0__);
		var x = __call__ (ThermalInput, null, __kwargtrans__ (__call__ (asdict, null, base)));
		__call__ (setattr, null, x, variable, __call__ (float, null, value));
		var res = __call__ (solve_steady, null, x);
		(function () {
			var __accu0__ = out;
			return __call__ (__accu0__.append, __accu0__, dict ({'value': value, 'status': __getitem__ (res, 'status'), 'ampacity_a': (function () {
				var __accu1__ = res;
				return __call__ (__accu1__.py_get, __accu1__, 'ampacity_a');
			}) (), 'conductor_temp_c': (function () {
				var __accu1__ = res;
				return __call__ (__accu1__.py_get, __accu1__, 'conductor_temp_c');
			}) (), 'utilization': (function () {
				var __accu1__ = res;
				return __call__ (__accu1__.py_get, __accu1__, 'utilization');
			}) ()}));
		}) ();
	}
	return out;
};
export var parallel_sharing = function (total_current_a, parallel_sets, mode, worst_set_factor, set_currents_a, source) {
	if (typeof parallel_sets == 'undefined' || (parallel_sets != null && parallel_sets.hasOwnProperty ("__kwargtrans__"))) {;
		var parallel_sets = 1;
	};
	if (typeof mode == 'undefined' || (mode != null && mode.hasOwnProperty ("__kwargtrans__"))) {;
		var mode = 'AUTO';
	};
	if (typeof worst_set_factor == 'undefined' || (worst_set_factor != null && worst_set_factor.hasOwnProperty ("__kwargtrans__"))) {;
		var worst_set_factor = 1.0;
	};
	if (typeof set_currents_a == 'undefined' || (set_currents_a != null && set_currents_a.hasOwnProperty ("__kwargtrans__"))) {;
		var set_currents_a = null;
	};
	if (typeof source == 'undefined' || (source != null && source.hasOwnProperty ("__kwargtrans__"))) {;
		var source = null;
	};
	if (arguments.length) {
		var __ilastarg0__ = arguments.length - 1;
		if (arguments [__ilastarg0__] && arguments [__ilastarg0__].hasOwnProperty ("__kwargtrans__")) {
			var __allkwargs0__ = arguments [__ilastarg0__--];
			for (var __attrib0__ in __allkwargs0__) {
				switch (__attrib0__) {
					case 'total_current_a': var total_current_a = __allkwargs0__ [__attrib0__]; break;
					case 'parallel_sets': var parallel_sets = __allkwargs0__ [__attrib0__]; break;
					case 'mode': var mode = __allkwargs0__ [__attrib0__]; break;
					case 'worst_set_factor': var worst_set_factor = __allkwargs0__ [__attrib0__]; break;
					case 'set_currents_a': var set_currents_a = __allkwargs0__ [__attrib0__]; break;
					case 'source': var source = __allkwargs0__ [__attrib0__]; break;
				}
			}
		}
	}
	else {
	}
	var issues = [];
	if (__t__ (__lt__ (total_current_a, 0))) {
		(function () {
			var __accu0__ = issues;
			return __call__ (__accu0__.append, __accu0__, 'Total current must be >= 0 A.');
		}) ();
	}
	if (__t__ (__t__ (__lt__ (parallel_sets, 1)) || __ne__ (__call__ (int, null, parallel_sets), parallel_sets))) {
		(function () {
			var __accu0__ = issues;
			return __call__ (__accu0__.append, __accu0__, 'Parallel sets must be a positive integer.');
		}) ();
	}
	if (__t__ (issues)) {
		return dict ({'status': 'INPUT REQUIRED', 'issues': issues});
	}
	var n = __call__ (int, null, parallel_sets);
	var ideal = __truediv__ (total_current_a, n);
	var mode = (function () {
		var __accu0__ = (function () {
			var __accu1__ = __t__ (mode) || 'AUTO';
			return __call__ (__accu1__.strip, __accu1__);
		}) ();
		return __call__ (__accu0__.upper, __accu0__);
	}) ();
	var source = (function () {
		var __accu0__ = __t__ (source) || '';
		return __call__ (__accu0__.strip, __accu0__);
	}) ();
	var set_currents_a = __call__ (list, null, __t__ (set_currents_a) || []);
	if (__t__ (__eq__ (n, 1))) {
		var worst = total_current_a;
		var status = 'PASS';
		var warning = 'Single set: no current-sharing ambiguity.';
	}
	else if (__t__ (__in__ (mode, new set (['AUTO', ''])))) {
		return dict ({'status': 'INPUT REQUIRED', 'issues': ['Parallel sets require an explicitly verified current-sharing basis; equal sharing is not assumed automatically.'], 'ideal_current_per_set_a': ideal});
	}
	else if (__t__ (__in__ (mode, new set (['SYMMETRIC VERIFIED', 'SYMMETRIC'])))) {
		if (__t__ (!__t__ ((source)))) {
			return dict ({'status': 'INPUT REQUIRED', 'issues': ['Document the engineering basis for verified symmetric sharing.'], 'ideal_current_per_set_a': ideal});
		}
		var worst = ideal;
		var status = 'PASS';
		var warning = 'Equal sharing accepted only because symmetric sharing was explicitly verified.';
	}
	else if (__t__ (__in__ (mode, new set (['MANUAL WORST-SET FACTOR', 'FACTOR'])))) {
		if (__t__ (__t__ (__lt__ (worst_set_factor, 1)) || !__t__ ((__call__ (isfinite, null, worst_set_factor))))) {
			return dict ({'status': 'INPUT REQUIRED', 'issues': ['Worst-set factor must be >= 1.0.'], 'ideal_current_per_set_a': ideal});
		}
		if (__t__ (!__t__ ((source)))) {
			return dict ({'status': 'INPUT REQUIRED', 'issues': ['A source/basis is required for the worst-set factor.'], 'ideal_current_per_set_a': ideal});
		}
		var worst = __mul__ (ideal, worst_set_factor);
		var status = 'PASS';
		var warning = 'Worst-set factor accepted from documented source.';
	}
	else if (__t__ (__in__ (mode, new set (['VERIFIED SET CURRENTS', 'CURRENTS'])))) {
		if (__t__ (__t__ (__ne__ (__call__ (len, null, set_currents_a), n)) || __call__ (any, null, (function () {
			var __accu0__ = [];
			var __iterable0__ = __call__ (list, null, set_currents_a);
			for (var __index0__ = 0; __index0__ < len (__iterable0__); __index0__++) {
				var v = __getitem__ (__iterable0__, __index0__);
				(function () {
					var __accu1__ = __accu0__;
					return __call__ (__accu1__.append, __accu1__, __t__ (!__t__ ((__call__ (isfinite, null, v)))) || __lt__ (v, 0));
				}) ();
			}
			return py_iter (__accu0__);
		}) ()))) {
			return dict ({'status': 'INPUT REQUIRED', 'issues': ['Provide {} non-negative verified set currents.'.format (n)], 'ideal_current_per_set_a': ideal});
		}
		var manual_sum = __call__ (sum, null, set_currents_a);
		var tolerance = __call__ (max, null, 0.5, __mul__ (0.001, __call__ (max, null, total_current_a, 1.0)));
		if (__t__ (__gt__ (__call__ (abs, null, __sub__ (manual_sum, total_current_a)), tolerance))) {
			return dict ({'status': 'FAIL', 'issues': ['Verified set currents do not reconcile to the entered total current.'], 'ideal_current_per_set_a': ideal, 'manual_sum_a': manual_sum, 'sum_error_a': __sub__ (manual_sum, total_current_a)});
		}
		if (__t__ (!__t__ ((source)))) {
			return dict ({'status': 'INPUT REQUIRED', 'issues': ['A source/basis is required for verified set currents.'], 'ideal_current_per_set_a': ideal});
		}
		var worst = __call__ (max, null, set_currents_a);
		var status = 'PASS';
		var warning = 'Worst verified set current governs conductor heat.';
	}
	else if (__t__ (__in__ (mode, new set (['IEC 60287-1-3 REQUIRED', 'IEC REQUIRED'])))) {
		return dict ({'status': 'REVIEW REQUIRED', 'issues': ['Obtain an approved IEC 60287-1-3 current-sharing/circulating-current result for this physical layout.'], 'ideal_current_per_set_a': ideal});
	}
	else {
		return dict ({'status': 'INPUT REQUIRED', 'issues': ['Unsupported sharing mode: {}'.format (mode)], 'ideal_current_per_set_a': ideal});
	}
	var imbalance = (__t__ (__gt__ (ideal, 0)) ? __truediv__ (worst, ideal) : 0.0);
	var heat_multiplier = __mul__ (imbalance, imbalance);
	return dict ({'status': status, 'issues': [], 'warning': warning, 'total_current_a': total_current_a, 'parallel_sets': n, 'ideal_current_per_set_a': ideal, 'used_worst_set_current_a': worst, 'imbalance_factor': imbalance, 'i2r_heat_multiplier': heat_multiplier, 'source': __t__ (source) || null});
};
export var metallic_loss_gate = function () {
	var active = true;
	var cores = 1;
	var parallel_sets = 1;
	var arrangement = 'TREFOIL';
	var bonding = 'BOTH ENDS';
	var screen_r20_ohm_km = null;
	var lambda1_auto = null;
	var lambda1_override = null;
	var armour_model = 'NONE';
	var lambda2_override = null;
	var sharing_status = 'PASS';
	var active_circuit_count = 1;
	var verified_source = null;
	if (arguments.length) {
		var __ilastarg0__ = arguments.length - 1;
		if (arguments [__ilastarg0__] && arguments [__ilastarg0__].hasOwnProperty ("__kwargtrans__")) {
			var __allkwargs0__ = arguments [__ilastarg0__--];
			for (var __attrib0__ in __allkwargs0__) {
				switch (__attrib0__) {
					case 'active': var active = __allkwargs0__ [__attrib0__]; break;
					case 'cores': var cores = __allkwargs0__ [__attrib0__]; break;
					case 'parallel_sets': var parallel_sets = __allkwargs0__ [__attrib0__]; break;
					case 'arrangement': var arrangement = __allkwargs0__ [__attrib0__]; break;
					case 'bonding': var bonding = __allkwargs0__ [__attrib0__]; break;
					case 'screen_r20_ohm_km': var screen_r20_ohm_km = __allkwargs0__ [__attrib0__]; break;
					case 'lambda1_auto': var lambda1_auto = __allkwargs0__ [__attrib0__]; break;
					case 'lambda1_override': var lambda1_override = __allkwargs0__ [__attrib0__]; break;
					case 'armour_model': var armour_model = __allkwargs0__ [__attrib0__]; break;
					case 'lambda2_override': var lambda2_override = __allkwargs0__ [__attrib0__]; break;
					case 'sharing_status': var sharing_status = __allkwargs0__ [__attrib0__]; break;
					case 'active_circuit_count': var active_circuit_count = __allkwargs0__ [__attrib0__]; break;
					case 'verified_source': var verified_source = __allkwargs0__ [__attrib0__]; break;
				}
			}
		}
	}
	else {
	}
	if (__t__ (!__t__ ((active)))) {
		return dict ({'status': 'INACTIVE', 'lambda1': 0.0, 'lambda2': 0.0, 'thermal_loss_factor': 1.0, 'warning': 'Circuit inactive.'});
	}
	var arrangement = (function () {
		var __accu0__ = __t__ (arrangement) || 'TREFOIL';
		return __call__ (__accu0__.upper, __accu0__);
	}) ();
	var bonding = (function () {
		var __accu0__ = __t__ (bonding) || 'BOTH ENDS';
		return __call__ (__accu0__.upper, __accu0__);
	}) ();
	var armour = (function () {
		var __accu0__ = __t__ (armour_model) || 'NONE';
		return __call__ (__accu0__.upper, __accu0__);
	}) ();
	var source = (function () {
		var __accu0__ = __t__ (verified_source) || '';
		return __call__ (__accu0__.strip, __accu0__);
	}) ();
	var sharing = (function () {
		var __accu0__ = __t__ (sharing_status) || '';
		return __call__ (__accu0__.upper, __accu0__);
	}) ();
	var l1 = 0.0;
	var l2 = 0.0;
	var warnings = [];
	var status = 'PASS';
	var trigger = 'NONE';
	if (__t__ (__t__ (__gt__ (parallel_sets, 1)) && !__in__ (sharing, new set (['PASS', 'INACTIVE'])))) {
		var status = 'REVIEW REQUIRED';
		var trigger = 'PARALLEL SHARING UNRESOLVED';
		(function () {
			var __accu0__ = warnings;
			return __call__ (__accu0__.append, __accu0__, 'Parallel-set sharing must be resolved before accepting metallic/conductor heat.');
		}) ();
	}
	var iec_1_3_gate = __t__ (__gt__ (parallel_sets, 1)) && __t__ (__eq__ (bonding, 'BOTH ENDS')) && lambda1_override === null;
	var iec_1_2_gate = __t__ (__ge__ (active_circuit_count, 2)) && __t__ (__in__ (arrangement, new set (['FLAT', 'HORIZONTAL', 'VERTICAL']))) && lambda1_override === null;
	if (__t__ (iec_1_3_gate)) {
		var status = 'REVIEW REQUIRED';
		var trigger = 'IEC 60287-1-3 CASE';
		(function () {
			var __accu0__ = warnings;
			return __call__ (__accu0__.append, __accu0__, 'Parallel both-end bonded circuits require a verified IEC 60287-1-3/manufacturer result.');
		}) ();
	}
	if (__t__ (iec_1_2_gate)) {
		var status = 'REVIEW REQUIRED';
		var trigger = 'IEC 60287-1-2 CASE';
		(function () {
			var __accu0__ = warnings;
			return __call__ (__accu0__.append, __accu0__, 'Applicable multi-circuit flat arrangements require a verified sheath-loss method.');
		}) ();
	}
	if (__t__ (lambda1_override !== null)) {
		if (__t__ (__lt__ (lambda1_override, 0))) {
			return dict ({'status': 'INPUT REQUIRED', 'issues': ['λ1 override must be >= 0.']});
		}
		if (__t__ (!__t__ ((source)))) {
			return dict ({'status': 'INPUT REQUIRED', 'issues': ['Document the source/basis for the λ1 override.']});
		}
		var l1 = __call__ (float, null, lambda1_override);
	}
	else if (__t__ (lambda1_auto !== null)) {
		if (__t__ (__lt__ (lambda1_auto, 0))) {
			return dict ({'status': 'INPUT REQUIRED', 'issues': ['Automatic λ1 must be >= 0.']});
		}
		if (__t__ (__t__ (__eq__ (bonding, 'BOTH ENDS')) && (__t__ (screen_r20_ohm_km === null) || __le__ (screen_r20_ohm_km, 0)))) {
			var status = 'INPUT REQUIRED';
			var trigger = 'MISSING SCREEN R';
			(function () {
				var __accu0__ = warnings;
				return __call__ (__accu0__.append, __accu0__, 'Screen/sheath resistance is required before automatic both-end λ1 can be validated.');
			}) ();
		}
		else {
			var l1 = __call__ (float, null, lambda1_auto);
		}
	}
	else {
		if (__t__ (__t__ (__eq__ (bonding, 'BOTH ENDS')) && !__t__ ((__t__ (iec_1_3_gate) || iec_1_2_gate)))) {
			var status = 'INPUT REQUIRED';
			var trigger = 'MISSING SCREEN R';
			(function () {
				var __accu0__ = warnings;
				return __call__ (__accu0__.append, __accu0__, 'Screen/sheath resistance or a verified manual λ1 is required for both-end bonding.');
			}) ();
		}
		var l1 = 0.0;
	}
	var magnetic = __t__ (__call__ (any, null, (function () {
		var __accu0__ = [];
		var __iterable0__ = __call__ (list, null, tuple (['MAGNETIC', 'STEEL WIRE', 'STEEL TAPE']));
		for (var __index0__ = 0; __index0__ < len (__iterable0__); __index0__++) {
			var k = __getitem__ (__iterable0__, __index0__);
			(function () {
				var __accu1__ = __accu0__;
				return __call__ (__accu1__.append, __accu1__, __in__ (k, armour));
			}) ();
		}
		return py_iter (__accu0__);
	}) ())) && !__in__ ('NONMAGNETIC', armour);
	if (__t__ (lambda2_override !== null)) {
		if (__t__ (__lt__ (lambda2_override, 0))) {
			return dict ({'status': 'INPUT REQUIRED', 'issues': ['λ2 override must be >= 0.']});
		}
		if (__t__ (__t__ (!__t__ ((source))) && __ne__ (lambda2_override, 0))) {
			return dict ({'status': 'INPUT REQUIRED', 'issues': ['Document the source/basis for the λ2 override.']});
		}
		var l2 = __call__ (float, null, lambda2_override);
	}
	else if (__t__ (magnetic)) {
		var status = 'INPUT REQUIRED';
		var trigger = 'MAGNETIC ARMOUR INPUT REQUIRED';
		(function () {
			var __accu0__ = warnings;
			return __call__ (__accu0__.append, __accu0__, 'Magnetic armour requires a verified λ2; λ2 is never set equal to λ1 automatically.');
		}) ();
	}
	else {
		var l2 = 0.0;
	}
	return dict ({'status': status, 'issues': (__t__ (__ne__ (status, 'PASS')) ? warnings : []), 'warning': (__t__ (warnings) ? (function () {
		var __accu0__ = ' ';
		return __call__ (__accu0__.join, __accu0__, warnings);
	}) () : 'Metallic-loss inputs accepted.'), 'special_case_trigger': trigger, 'lambda1': l1, 'lambda2': l2, 'thermal_loss_factor': __add__ (__add__ (1.0, l1), l2), 'verified_source': __t__ (source) || null});
};
export var TransientInput =  __class__ ('TransientInput', [object], {
	__module__: __name__,
	get __init__ () {return __get__ (this, function (self, base_current_a, ambient_c, continuous_limit_c, emergency_limit_c, r20_ohm_m, alpha_per_c, ac_factor, dielectric_w_m, lambda1, lambda2, t1_km_w, t2_km_w, t3_km_w, t4_km_w, conductor_area_mm2, conductor_diameter_mm, insulation_outer_diameter_mm, cable_outer_diameter_mm, conductor_vol_heat_mj_m3k, insulation_vol_heat_mj_m3k, shell_vol_heat_mj_m3k, soil_vol_heat_mj_m3k, burial_depth_m, soil_mass_participation, timestep_min, gs_iterations) {
		if (typeof base_current_a == 'undefined' || (base_current_a != null && base_current_a.hasOwnProperty ("__kwargtrans__"))) {;
			var base_current_a = 500.0;
		};
		if (typeof ambient_c == 'undefined' || (ambient_c != null && ambient_c.hasOwnProperty ("__kwargtrans__"))) {;
			var ambient_c = 25.0;
		};
		if (typeof continuous_limit_c == 'undefined' || (continuous_limit_c != null && continuous_limit_c.hasOwnProperty ("__kwargtrans__"))) {;
			var continuous_limit_c = 90.0;
		};
		if (typeof emergency_limit_c == 'undefined' || (emergency_limit_c != null && emergency_limit_c.hasOwnProperty ("__kwargtrans__"))) {;
			var emergency_limit_c = 105.0;
		};
		if (typeof r20_ohm_m == 'undefined' || (r20_ohm_m != null && r20_ohm_m.hasOwnProperty ("__kwargtrans__"))) {;
			var r20_ohm_m = 5.69e-05;
		};
		if (typeof alpha_per_c == 'undefined' || (alpha_per_c != null && alpha_per_c.hasOwnProperty ("__kwargtrans__"))) {;
			var alpha_per_c = 0.00403;
		};
		if (typeof ac_factor == 'undefined' || (ac_factor != null && ac_factor.hasOwnProperty ("__kwargtrans__"))) {;
			var ac_factor = 1.0251328070572212;
		};
		if (typeof dielectric_w_m == 'undefined' || (dielectric_w_m != null && dielectric_w_m.hasOwnProperty ("__kwargtrans__"))) {;
			var dielectric_w_m = 0.004114251237296077;
		};
		if (typeof lambda1 == 'undefined' || (lambda1 != null && lambda1.hasOwnProperty ("__kwargtrans__"))) {;
			var lambda1 = 0.0;
		};
		if (typeof lambda2 == 'undefined' || (lambda2 != null && lambda2.hasOwnProperty ("__kwargtrans__"))) {;
			var lambda2 = 0.0;
		};
		if (typeof t1_km_w == 'undefined' || (t1_km_w != null && t1_km_w.hasOwnProperty ("__kwargtrans__"))) {;
			var t1_km_w = 0.18025777365930096;
		};
		if (typeof t2_km_w == 'undefined' || (t2_km_w != null && t2_km_w.hasOwnProperty ("__kwargtrans__"))) {;
			var t2_km_w = 0.0;
		};
		if (typeof t3_km_w == 'undefined' || (t3_km_w != null && t3_km_w.hasOwnProperty ("__kwargtrans__"))) {;
			var t3_km_w = 0.09186124885560788;
		};
		if (typeof t4_km_w == 'undefined' || (t4_km_w != null && t4_km_w.hasOwnProperty ("__kwargtrans__"))) {;
			var t4_km_w = 1.541570063174254;
		};
		if (typeof conductor_area_mm2 == 'undefined' || (conductor_area_mm2 != null && conductor_area_mm2.hasOwnProperty ("__kwargtrans__"))) {;
			var conductor_area_mm2 = 506.707;
		};
		if (typeof conductor_diameter_mm == 'undefined' || (conductor_diameter_mm != null && conductor_diameter_mm.hasOwnProperty ("__kwargtrans__"))) {;
			var conductor_diameter_mm = 29.26;
		};
		if (typeof insulation_outer_diameter_mm == 'undefined' || (insulation_outer_diameter_mm != null && insulation_outer_diameter_mm.hasOwnProperty ("__kwargtrans__"))) {;
			var insulation_outer_diameter_mm = 40.44;
		};
		if (typeof cable_outer_diameter_mm == 'undefined' || (cable_outer_diameter_mm != null && cable_outer_diameter_mm.hasOwnProperty ("__kwargtrans__"))) {;
			var cable_outer_diameter_mm = 49.53;
		};
		if (typeof conductor_vol_heat_mj_m3k == 'undefined' || (conductor_vol_heat_mj_m3k != null && conductor_vol_heat_mj_m3k.hasOwnProperty ("__kwargtrans__"))) {;
			var conductor_vol_heat_mj_m3k = 2.5;
		};
		if (typeof insulation_vol_heat_mj_m3k == 'undefined' || (insulation_vol_heat_mj_m3k != null && insulation_vol_heat_mj_m3k.hasOwnProperty ("__kwargtrans__"))) {;
			var insulation_vol_heat_mj_m3k = 2.4;
		};
		if (typeof shell_vol_heat_mj_m3k == 'undefined' || (shell_vol_heat_mj_m3k != null && shell_vol_heat_mj_m3k.hasOwnProperty ("__kwargtrans__"))) {;
			var shell_vol_heat_mj_m3k = 1.7;
		};
		if (typeof soil_vol_heat_mj_m3k == 'undefined' || (soil_vol_heat_mj_m3k != null && soil_vol_heat_mj_m3k.hasOwnProperty ("__kwargtrans__"))) {;
			var soil_vol_heat_mj_m3k = 1.6;
		};
		if (typeof burial_depth_m == 'undefined' || (burial_depth_m != null && burial_depth_m.hasOwnProperty ("__kwargtrans__"))) {;
			var burial_depth_m = 0.939165;
		};
		if (typeof soil_mass_participation == 'undefined' || (soil_mass_participation != null && soil_mass_participation.hasOwnProperty ("__kwargtrans__"))) {;
			var soil_mass_participation = 0.2;
		};
		if (typeof timestep_min == 'undefined' || (timestep_min != null && timestep_min.hasOwnProperty ("__kwargtrans__"))) {;
			var timestep_min = 15.0;
		};
		if (typeof gs_iterations == 'undefined' || (gs_iterations != null && gs_iterations.hasOwnProperty ("__kwargtrans__"))) {;
			var gs_iterations = 4;
		};
		if (arguments.length) {
			var __ilastarg0__ = arguments.length - 1;
			if (arguments [__ilastarg0__] && arguments [__ilastarg0__].hasOwnProperty ("__kwargtrans__")) {
				var __allkwargs0__ = arguments [__ilastarg0__--];
				for (var __attrib0__ in __allkwargs0__) {
					switch (__attrib0__) {
						case 'self': var self = __allkwargs0__ [__attrib0__]; break;
						case 'base_current_a': var base_current_a = __allkwargs0__ [__attrib0__]; break;
						case 'ambient_c': var ambient_c = __allkwargs0__ [__attrib0__]; break;
						case 'continuous_limit_c': var continuous_limit_c = __allkwargs0__ [__attrib0__]; break;
						case 'emergency_limit_c': var emergency_limit_c = __allkwargs0__ [__attrib0__]; break;
						case 'r20_ohm_m': var r20_ohm_m = __allkwargs0__ [__attrib0__]; break;
						case 'alpha_per_c': var alpha_per_c = __allkwargs0__ [__attrib0__]; break;
						case 'ac_factor': var ac_factor = __allkwargs0__ [__attrib0__]; break;
						case 'dielectric_w_m': var dielectric_w_m = __allkwargs0__ [__attrib0__]; break;
						case 'lambda1': var lambda1 = __allkwargs0__ [__attrib0__]; break;
						case 'lambda2': var lambda2 = __allkwargs0__ [__attrib0__]; break;
						case 't1_km_w': var t1_km_w = __allkwargs0__ [__attrib0__]; break;
						case 't2_km_w': var t2_km_w = __allkwargs0__ [__attrib0__]; break;
						case 't3_km_w': var t3_km_w = __allkwargs0__ [__attrib0__]; break;
						case 't4_km_w': var t4_km_w = __allkwargs0__ [__attrib0__]; break;
						case 'conductor_area_mm2': var conductor_area_mm2 = __allkwargs0__ [__attrib0__]; break;
						case 'conductor_diameter_mm': var conductor_diameter_mm = __allkwargs0__ [__attrib0__]; break;
						case 'insulation_outer_diameter_mm': var insulation_outer_diameter_mm = __allkwargs0__ [__attrib0__]; break;
						case 'cable_outer_diameter_mm': var cable_outer_diameter_mm = __allkwargs0__ [__attrib0__]; break;
						case 'conductor_vol_heat_mj_m3k': var conductor_vol_heat_mj_m3k = __allkwargs0__ [__attrib0__]; break;
						case 'insulation_vol_heat_mj_m3k': var insulation_vol_heat_mj_m3k = __allkwargs0__ [__attrib0__]; break;
						case 'shell_vol_heat_mj_m3k': var shell_vol_heat_mj_m3k = __allkwargs0__ [__attrib0__]; break;
						case 'soil_vol_heat_mj_m3k': var soil_vol_heat_mj_m3k = __allkwargs0__ [__attrib0__]; break;
						case 'burial_depth_m': var burial_depth_m = __allkwargs0__ [__attrib0__]; break;
						case 'soil_mass_participation': var soil_mass_participation = __allkwargs0__ [__attrib0__]; break;
						case 'timestep_min': var timestep_min = __allkwargs0__ [__attrib0__]; break;
						case 'gs_iterations': var gs_iterations = __allkwargs0__ [__attrib0__]; break;
					}
				}
			}
		}
		else {
		}
		self.__fields__ = ['base_current_a', 'ambient_c', 'continuous_limit_c', 'emergency_limit_c', 'r20_ohm_m', 'alpha_per_c', 'ac_factor', 'dielectric_w_m', 'lambda1', 'lambda2', 't1_km_w', 't2_km_w', 't3_km_w', 't4_km_w', 'conductor_area_mm2', 'conductor_diameter_mm', 'insulation_outer_diameter_mm', 'cable_outer_diameter_mm', 'conductor_vol_heat_mj_m3k', 'insulation_vol_heat_mj_m3k', 'shell_vol_heat_mj_m3k', 'soil_vol_heat_mj_m3k', 'burial_depth_m', 'soil_mass_participation', 'timestep_min', 'gs_iterations'];
		self.base_current_a = base_current_a;
		self.ambient_c = ambient_c;
		self.continuous_limit_c = continuous_limit_c;
		self.emergency_limit_c = emergency_limit_c;
		self.r20_ohm_m = r20_ohm_m;
		self.alpha_per_c = alpha_per_c;
		self.ac_factor = ac_factor;
		self.dielectric_w_m = dielectric_w_m;
		self.lambda1 = lambda1;
		self.lambda2 = lambda2;
		self.t1_km_w = t1_km_w;
		self.t2_km_w = t2_km_w;
		self.t3_km_w = t3_km_w;
		self.t4_km_w = t4_km_w;
		self.conductor_area_mm2 = conductor_area_mm2;
		self.conductor_diameter_mm = conductor_diameter_mm;
		self.insulation_outer_diameter_mm = insulation_outer_diameter_mm;
		self.cable_outer_diameter_mm = cable_outer_diameter_mm;
		self.conductor_vol_heat_mj_m3k = conductor_vol_heat_mj_m3k;
		self.insulation_vol_heat_mj_m3k = insulation_vol_heat_mj_m3k;
		self.shell_vol_heat_mj_m3k = shell_vol_heat_mj_m3k;
		self.soil_vol_heat_mj_m3k = soil_vol_heat_mj_m3k;
		self.burial_depth_m = burial_depth_m;
		self.soil_mass_participation = soil_mass_participation;
		self.timestep_min = timestep_min;
		self.gs_iterations = gs_iterations;
	});}
});
export var from_thermal = function (base) {
	var overrides = dict ();
	if (arguments.length) {
		var __ilastarg0__ = arguments.length - 1;
		if (arguments [__ilastarg0__] && arguments [__ilastarg0__].hasOwnProperty ("__kwargtrans__")) {
			var __allkwargs0__ = arguments [__ilastarg0__--];
			for (var __attrib0__ in __allkwargs0__) {
				switch (__attrib0__) {
					case 'base': var base = __allkwargs0__ [__attrib0__]; break;
					default: overrides [__attrib0__] = __allkwargs0__ [__attrib0__];
				}
			}
			delete overrides.__kwargtrans__;
		}
	}
	else {
	}
	var steady = __call__ (solve_steady, null, base);
	var t4 = __call__ (float, null, (function () {
		var __accu0__ = steady;
		return __call__ (__accu0__.py_get, __accu0__, 't4_km_w', 1.541570063174254);
	}) ());
	var data = __call__ (dict, null, __kwargtrans__ ({base_current_a: base.load_a, ambient_c: base.ambient_c, continuous_limit_c: base.max_temp_c, r20_ohm_m: base.r20_ohm_m, alpha_per_c: base.alpha_per_c, ac_factor: base.ac_factor, dielectric_w_m: base.dielectric_w_m, t4_km_w: t4, cable_outer_diameter_mm: __mul__ (base.cable_od_m, 1000.0), burial_depth_m: base.burial_depth_m}));
	(function () {
		var __accu0__ = data;
		return __call__ (__accu0__.py_update, __accu0__, overrides);
	}) ();
	return __call__ (TransientInput, null, __kwargtrans__ (data));
};
export var validate_transient = function (x) {
	if (arguments.length) {
		var __ilastarg0__ = arguments.length - 1;
		if (arguments [__ilastarg0__] && arguments [__ilastarg0__].hasOwnProperty ("__kwargtrans__")) {
			var __allkwargs0__ = arguments [__ilastarg0__--];
			for (var __attrib0__ in __allkwargs0__) {
				switch (__attrib0__) {
					case 'x': var x = __allkwargs0__ [__attrib0__]; break;
				}
			}
		}
	}
	else {
	}
	var issues = [];
	if (__t__ (__lt__ (x.base_current_a, 0))) {
		(function () {
			var __accu0__ = issues;
			return __call__ (__accu0__.append, __accu0__, 'Base current must be >= 0 A.');
		}) ();
	}
	if (__t__ (__ge__ (x.ambient_c, x.continuous_limit_c))) {
		(function () {
			var __accu0__ = issues;
			return __call__ (__accu0__.append, __accu0__, 'Ambient temperature must be below the continuous conductor limit.');
		}) ();
	}
	if (__t__ (__lt__ (x.emergency_limit_c, x.continuous_limit_c))) {
		(function () {
			var __accu0__ = issues;
			return __call__ (__accu0__.append, __accu0__, 'Emergency conductor limit should be >= continuous conductor limit.');
		}) ();
	}
	if (__t__ (__t__ (__le__ (x.r20_ohm_m, 0)) || __t__ (__le__ (x.alpha_per_c, 0)) || __le__ (x.ac_factor, 0))) {
		(function () {
			var __accu0__ = issues;
			return __call__ (__accu0__.append, __accu0__, 'Conductor electrical resistance inputs must be positive.');
		}) ();
	}
	if (__t__ (__lt__ (__call__ (min, null, x.t1_km_w, x.t2_km_w, x.t3_km_w, x.t4_km_w), 0))) {
		(function () {
			var __accu0__ = issues;
			return __call__ (__accu0__.append, __accu0__, 'Thermal resistances must be non-negative.');
		}) ();
	}
	if (__t__ (__t__ (__le__ (x.t1_km_w, 0)) || __le__ (x.t4_km_w, 0))) {
		(function () {
			var __accu0__ = issues;
			return __call__ (__accu0__.append, __accu0__, 'T1 and T4 must be > 0 for the four-node model.');
		}) ();
	}
	if (__t__ (__le__ (x.timestep_min, 0))) {
		(function () {
			var __accu0__ = issues;
			return __call__ (__accu0__.append, __accu0__, 'Transient time step must be > 0 min.');
		}) ();
	}
	if (__t__ (__lt__ (x.gs_iterations, 1))) {
		(function () {
			var __accu0__ = issues;
			return __call__ (__accu0__.append, __accu0__, 'Gauss-Seidel iterations per step must be >= 1.');
		}) ();
	}
	if (__t__ (__le__ (x.conductor_area_mm2, 0))) {
		(function () {
			var __accu0__ = issues;
			return __call__ (__accu0__.append, __accu0__, 'Conductor area must be > 0 mm².');
		}) ();
	}
	if (__t__ (!__t__ (((__lt__ (0, x.conductor_diameter_mm) && __lt__ (x.conductor_diameter_mm, x.insulation_outer_diameter_mm) && __lt__ (x.insulation_outer_diameter_mm, x.cable_outer_diameter_mm)))))) {
		(function () {
			var __accu0__ = issues;
			return __call__ (__accu0__.append, __accu0__, 'Cable diameters must satisfy conductor < insulation OD < cable OD.');
		}) ();
	}
	if (__t__ (__le__ (__call__ (min, null, x.conductor_vol_heat_mj_m3k, x.insulation_vol_heat_mj_m3k, x.shell_vol_heat_mj_m3k, x.soil_vol_heat_mj_m3k), 0))) {
		(function () {
			var __accu0__ = issues;
			return __call__ (__accu0__.append, __accu0__, 'Volumetric heat capacities must be > 0.');
		}) ();
	}
	if (__t__ (__le__ (x.burial_depth_m, __truediv__ (x.cable_outer_diameter_mm, 2000.0)))) {
		(function () {
			var __accu0__ = issues;
			return __call__ (__accu0__.append, __accu0__, 'Burial depth must exceed cable radius.');
		}) ();
	}
	if (__t__ (!__t__ (((__lt__ (0, x.soil_mass_participation) && __le__ (x.soil_mass_participation, 2)))))) {
		(function () {
			var __accu0__ = issues;
			return __call__ (__accu0__.append, __accu0__, 'Soil thermal-mass participation factor must be > 0 and <= 2 for this screening model.');
		}) ();
	}
	if (__t__ (__t__ (__lt__ (x.lambda1, 0)) || __lt__ (x.lambda2, 0))) {
		(function () {
			var __accu0__ = issues;
			return __call__ (__accu0__.append, __accu0__, 'Metallic loss factors λ1/λ2 must be >= 0.');
		}) ();
	}
	return issues;
};
export var network_quantities = function (x) {
	if (arguments.length) {
		var __ilastarg0__ = arguments.length - 1;
		if (arguments [__ilastarg0__] && arguments [__ilastarg0__].hasOwnProperty ("__kwargtrans__")) {
			var __allkwargs0__ = arguments [__ilastarg0__--];
			for (var __attrib0__ in __allkwargs0__) {
				switch (__attrib0__) {
					case 'x': var x = __allkwargs0__ [__attrib0__]; break;
				}
			}
		}
	}
	else {
	}
	var r12 = __truediv__ (x.t1_km_w, 2.0);
	var r23 = __add__ (__add__ (__truediv__ (x.t1_km_w, 2.0), x.t2_km_w), x.t3_km_w);
	var r34 = __truediv__ (x.t4_km_w, 2.0);
	var r4a = __truediv__ (x.t4_km_w, 2.0);
	if (__t__ (__le__ (__call__ (min, null, r12, r23, r34, r4a), 0))) {
		var __except0__ = __call__ (ValueError, null, 'Four-node thermal ladder requires positive path resistances.');
		__except0__.__cause__ = null;
		throw __except0__;
	}
	var __left0__ = tuple ([__truediv__ (1.0, r12), __truediv__ (1.0, r23), __truediv__ (1.0, r34), __truediv__ (1.0, r4a)]);
	var g12 = __left0__ [0];
	var g23 = __left0__ [1];
	var g34 = __left0__ [2];
	var g4a = __left0__ [3];
	var c_conductor = __mul__ (x.conductor_area_mm2, x.conductor_vol_heat_mj_m3k);
	var c_insulation = __mul__ (__mul__ (__truediv__ (pi, 4.0), __sub__ (__pow__ (x.insulation_outer_diameter_mm, 2), __pow__ (x.conductor_diameter_mm, 2))), x.insulation_vol_heat_mj_m3k);
	var c_shell = __mul__ (__mul__ (__truediv__ (pi, 4.0), __sub__ (__pow__ (x.cable_outer_diameter_mm, 2), __pow__ (x.insulation_outer_diameter_mm, 2))), x.shell_vol_heat_mj_m3k);
	var cable_radius_m = __truediv__ (x.cable_outer_diameter_mm, 2000.0);
	var effective_radius_m = __call__ (max, null, cable_radius_m, __mul__ (x.burial_depth_m, x.soil_mass_participation));
	var c_soil = __mul__ (__mul__ (__mul__ (pi, __sub__ (__pow__ (effective_radius_m, 2), __pow__ (cable_radius_m, 2))), x.soil_vol_heat_mj_m3k), 1000000.0);
	var dt_s = __mul__ (x.timestep_min, 60.0);
	return dict ({'r12': r12, 'r23': r23, 'r34': r34, 'r4a': r4a, 'g12': g12, 'g23': g23, 'g34': g34, 'g4a': g4a, 'c_conductor': c_conductor, 'c_insulation': c_insulation, 'c_shell': c_shell, 'c_soil': c_soil, 'dt_s': dt_s});
};
export var _rac = function (x, temp_c) {
	if (arguments.length) {
		var __ilastarg0__ = arguments.length - 1;
		if (arguments [__ilastarg0__] && arguments [__ilastarg0__].hasOwnProperty ("__kwargtrans__")) {
			var __allkwargs0__ = arguments [__ilastarg0__--];
			for (var __attrib0__ in __allkwargs0__) {
				switch (__attrib0__) {
					case 'x': var x = __allkwargs0__ [__attrib0__]; break;
					case 'temp_c': var temp_c = __allkwargs0__ [__attrib0__]; break;
				}
			}
		}
	}
	else {
	}
	return __mul__ (__mul__ (x.r20_ohm_m, __add__ (1.0, __mul__ (x.alpha_per_c, __sub__ (temp_c, 20.0)))), x.ac_factor);
};
export var steady_nodes = function (x) {
	if (arguments.length) {
		var __ilastarg0__ = arguments.length - 1;
		if (arguments [__ilastarg0__] && arguments [__ilastarg0__].hasOwnProperty ("__kwargtrans__")) {
			var __allkwargs0__ = arguments [__ilastarg0__--];
			for (var __attrib0__ in __allkwargs0__) {
				switch (__attrib0__) {
					case 'x': var x = __allkwargs0__ [__attrib0__]; break;
				}
			}
		}
	}
	else {
	}
	var q = __call__ (network_quantities, null, x);
	var tc = x.ambient_c;
	var __iterable0__ = __call__ (list, null, __call__ (range, null, 200));
	for (var __index0__ = 0; __index0__ < len (__iterable0__); __index0__++) {
		var _ = __getitem__ (__iterable0__, __index0__);
		var qc = __mul__ (__pow__ (x.base_current_a, 2), __call__ (_rac, null, x, tc));
		var qm = __mul__ (qc, __add__ (x.lambda1, x.lambda2));
		var total = __add__ (__add__ (qc, x.dielectric_w_m), qm);
		var tsoil = __add__ (x.ambient_c, __mul__ (total, __getitem__ (q, 'r4a')));
		var tshell = __add__ (tsoil, __mul__ (total, __getitem__ (q, 'r34')));
		var ti = __add__ (tshell, __mul__ (__add__ (qc, x.dielectric_w_m), __getitem__ (q, 'r23')));
		var new_tc = __add__ (ti, __mul__ (qc, __getitem__ (q, 'r12')));
		if (__t__ (__le__ (__call__ (abs, null, __sub__ (new_tc, tc)), 1e-10))) {
			var tc = new_tc;
			break;
		}
		var tc = new_tc;
	}
	return __call__ (merge_dicts, null, dict ({'tc': tc}), dict ({'ti': ti}), dict ({'tshell': tshell}), dict ({'tsoil': tsoil}), dict ({'qc': qc}), dict ({'qm': qm}), dict ({'qd': x.dielectric_w_m}), q);
};
export var step_implicit = function (x, old, current_a, dt_s) {
	if (typeof dt_s == 'undefined' || (dt_s != null && dt_s.hasOwnProperty ("__kwargtrans__"))) {;
		var dt_s = null;
	};
	if (arguments.length) {
		var __ilastarg0__ = arguments.length - 1;
		if (arguments [__ilastarg0__] && arguments [__ilastarg0__].hasOwnProperty ("__kwargtrans__")) {
			var __allkwargs0__ = arguments [__ilastarg0__--];
			for (var __attrib0__ in __allkwargs0__) {
				switch (__attrib0__) {
					case 'x': var x = __allkwargs0__ [__attrib0__]; break;
					case 'old': var old = __allkwargs0__ [__attrib0__]; break;
					case 'current_a': var current_a = __allkwargs0__ [__attrib0__]; break;
					case 'dt_s': var dt_s = __allkwargs0__ [__attrib0__]; break;
				}
			}
		}
	}
	else {
	}
	var q = __call__ (network_quantities, null, x);
	var dt = (__t__ (dt_s === null) ? __getitem__ (q, 'dt_s') : dt_s);
	if (__t__ (__t__ (!__t__ ((__call__ (isfinite, null, dt)))) || __le__ (dt, 0))) {
		var __except0__ = __call__ (ValueError, null, 'Implicit thermal step duration must be finite and positive.');
		__except0__.__cause__ = null;
		throw __except0__;
	}
	var rac = __call__ (_rac, null, x, __getitem__ (old, 'tc'));
	var qc = __mul__ (__pow__ (current_a, 2), rac);
	var qd = x.dielectric_w_m;
	var qm = __mul__ (qc, __add__ (x.lambda1, x.lambda2));
	var rhs = [__add__ (__mul__ (__truediv__ (__getitem__ (q, 'c_conductor'), dt), __getitem__ (old, 'tc')), qc), __add__ (__mul__ (__truediv__ (__getitem__ (q, 'c_insulation'), dt), __getitem__ (old, 'ti')), qd), __add__ (__mul__ (__truediv__ (__getitem__ (q, 'c_shell'), dt), __getitem__ (old, 'tshell')), qm), __add__ (__mul__ (__truediv__ (__getitem__ (q, 'c_soil'), dt), __getitem__ (old, 'tsoil')), __mul__ (x.ambient_c, __getitem__ (q, 'g4a')))];
	var diagonal = [__add__ (__truediv__ (__getitem__ (q, 'c_conductor'), dt), __getitem__ (q, 'g12')), __add__ (__add__ (__truediv__ (__getitem__ (q, 'c_insulation'), dt), __getitem__ (q, 'g12')), __getitem__ (q, 'g23')), __add__ (__add__ (__truediv__ (__getitem__ (q, 'c_shell'), dt), __getitem__ (q, 'g23')), __getitem__ (q, 'g34')), __add__ (__add__ (__truediv__ (__getitem__ (q, 'c_soil'), dt), __getitem__ (q, 'g34')), __getitem__ (q, 'g4a'))];
	var off_diagonal = [__neg__ (__getitem__ (q, 'g12')), __neg__ (__getitem__ (q, 'g23')), __neg__ (__getitem__ (q, 'g34'))];
	var __iterable0__ = __call__ (list, null, __call__ (range, null, 1, 4));
	for (var __index0__ = 0; __index0__ < len (__iterable0__); __index0__++) {
		var i = __getitem__ (__iterable0__, __index0__);
		var factor = __truediv__ (__getitem__ (off_diagonal, __sub__ (i, 1)), __getitem__ (diagonal, __sub__ (i, 1)));
		__setitem__ (diagonal, i, __call__ (__isub__, null, __getitem__ (diagonal, i), __mul__ (factor, __getitem__ (off_diagonal, __sub__ (i, 1)))));
		__setitem__ (rhs, i, __call__ (__isub__, null, __getitem__ (rhs, i), __mul__ (factor, __getitem__ (rhs, __sub__ (i, 1)))));
	}
	var temperatures = [0.0, 0.0, 0.0, __truediv__ (__getitem__ (rhs, 3), __getitem__ (diagonal, 3))];
	var __iterable0__ = __call__ (list, null, __call__ (range, null, 2, __neg__ (1), __neg__ (1)));
	for (var __index0__ = 0; __index0__ < len (__iterable0__); __index0__++) {
		var i = __getitem__ (__iterable0__, __index0__);
		__setitem__ (temperatures, i, __truediv__ (__sub__ (__getitem__ (rhs, i), __mul__ (__getitem__ (off_diagonal, i), __getitem__ (temperatures, __add__ (i, 1)))), __getitem__ (diagonal, i)));
	}
	var __left0__ = temperatures;
	var tc = __left0__ [0];
	var ti = __left0__ [1];
	var tshell = __left0__ [2];
	var tsoil = __left0__ [3];
	return dict ({'tc': tc, 'ti': ti, 'tshell': tshell, 'tsoil': tsoil, 'current_a': current_a, 'rac_ohm_m': rac, 'qc_w_m': qc, 'qd_w_m': qd, 'qm_w_m': qm, 'total_heat_w_m': __add__ (__add__ (qc, qd), qm)});
};
export var simulate_profile = function (x, profile, days) {
	if (typeof days == 'undefined' || (days != null && days.hasOwnProperty ("__kwargtrans__"))) {;
		var days = 7;
	};
	if (arguments.length) {
		var __ilastarg0__ = arguments.length - 1;
		if (arguments [__ilastarg0__] && arguments [__ilastarg0__].hasOwnProperty ("__kwargtrans__")) {
			var __allkwargs0__ = arguments [__ilastarg0__--];
			for (var __attrib0__ in __allkwargs0__) {
				switch (__attrib0__) {
					case 'x': var x = __allkwargs0__ [__attrib0__]; break;
					case 'profile': var profile = __allkwargs0__ [__attrib0__]; break;
					case 'days': var days = __allkwargs0__ [__attrib0__]; break;
				}
			}
		}
	}
	else {
	}
	var issues = __call__ (validate_transient, null, x);
	var vals = __call__ (list, null, profile);
	if (__t__ (__ne__ (__call__ (len, null, vals), 24))) {
		(function () {
			var __accu0__ = issues;
			return __call__ (__accu0__.append, __accu0__, 'Cyclic profile must contain exactly 24 hourly multipliers.');
		}) ();
	}
	if (__t__ (__call__ (any, null, (function () {
		var __accu0__ = [];
		var __iterable0__ = __call__ (list, null, vals);
		for (var __index0__ = 0; __index0__ < len (__iterable0__); __index0__++) {
			var v = __getitem__ (__iterable0__, __index0__);
			(function () {
				var __accu1__ = __accu0__;
				return __call__ (__accu1__.append, __accu1__, __lt__ (v, 0));
			}) ();
		}
		return py_iter (__accu0__);
	}) ()))) {
		(function () {
			var __accu0__ = issues;
			return __call__ (__accu0__.append, __accu0__, 'Cyclic load multipliers must be >= 0.');
		}) ();
	}
	if (__t__ (__t__ (__lt__ (days, 1)) || __gt__ (days, 365))) {
		(function () {
			var __accu0__ = issues;
			return __call__ (__accu0__.append, __accu0__, 'Days must be between 1 and 365.');
		}) ();
	}
	if (__t__ (issues)) {
		return dict ({'status': 'INPUT REQUIRED', 'issues': issues, 'input': __call__ (asdict, null, x)});
	}
	var start = __call__ (steady_nodes, null, x);
	var state = __call__ (dict, null, start);
	var points = [];
	var day_peaks = [];
	var day_end_states = [];
	var __iterable0__ = __call__ (list, null, __call__ (range, null, days));
	for (var __index0__ = 0; __index0__ < len (__iterable0__); __index0__++) {
		var day_index = __getitem__ (__iterable0__, __index0__);
		var current_peak = __getitem__ (state, 'tc');
		var __iterable1__ = __call__ (list, null, __call__ (range, null, 24));
		for (var __index1__ = 0; __index1__ < len (__iterable1__); __index1__++) {
			var hour = __getitem__ (__iterable1__, __index1__);
			var elapsed_in_hour_min = 0.0;
			var mult = __getitem__ (vals, hour);
			var current = __mul__ (x.base_current_a, mult);
			while (__t__ (__lt__ (elapsed_in_hour_min, 60.0))) {
				var step_min = __call__ (min, null, x.timestep_min, __sub__ (60.0, elapsed_in_hour_min));
				var state = __call__ (step_implicit, null, x, state, current, __mul__ (step_min, 60.0));
				var elapsed_in_hour_min = __call__ (__iadd__, null, elapsed_in_hour_min, step_min);
				var elapsed_h = __add__ (__add__ (__mul__ (day_index, 24), hour), __truediv__ (elapsed_in_hour_min, 60.0));
				var current_peak = __call__ (max, null, current_peak, __getitem__ (state, 'tc'));
				(function () {
					var __accu0__ = points;
					return __call__ (__accu0__.append, __accu0__, dict ({'elapsed_h': elapsed_h, 'day': __add__ (day_index, 1), 'hour': hour, 'load_multiplier': mult, 'current_a': current, 'conductor_c': __getitem__ (state, 'tc'), 'insulation_c': __getitem__ (state, 'ti'), 'shell_c': __getitem__ (state, 'tshell'), 'soil_c': __getitem__ (state, 'tsoil')}));
				}) ();
			}
		}
		(function () {
			var __accu0__ = day_peaks;
			return __call__ (__accu0__.append, __accu0__, current_peak);
		}) ();
		(function () {
			var __accu0__ = day_end_states;
			return __call__ (__accu0__.append, __accu0__, [__getitem__ (state, 'tc'), __getitem__ (state, 'ti'), __getitem__ (state, 'tshell'), __getitem__ (state, 'tsoil')]);
		}) ();
	}
	var max_temp = __call__ (max, null, day_peaks);
	var last_day_peak = __getitem__ (day_peaks, __neg__ (1));
	var periodic_delta = (__t__ (__ge__ (__call__ (len, null, day_peaks), 2)) ? __call__ (abs, null, __sub__ (__getitem__ (day_peaks, __neg__ (1)), __getitem__ (day_peaks, __neg__ (2)))) : null);
	var full_state_delta = (__t__ (__ge__ (__call__ (len, null, day_end_states), 2)) ? __call__ (max, null, (function () {
		var __accu0__ = [];
		var __iterable0__ = __call__ (list, null, __call__ (range, null, 4));
		for (var __index0__ = 0; __index0__ < len (__iterable0__); __index0__++) {
			var i = __getitem__ (__iterable0__, __index0__);
			(function () {
				var __accu1__ = __accu0__;
				return __call__ (__accu1__.append, __accu1__, __call__ (abs, null, __sub__ (__getitem__ (__getitem__ (day_end_states, __neg__ (1)), i), __getitem__ (__getitem__ (day_end_states, __neg__ (2)), i))));
			}) ();
		}
		return py_iter (__accu0__);
	}) ()) : null);
	var periodic_status = (__t__ (full_state_delta === null) ? 'INPUT REQUIRED' : (__t__ (__le__ (full_state_delta, 0.05)) ? 'PASS' : (__t__ (__le__ (full_state_delta, 0.1)) ? 'REVIEW REQUIRED' : 'FAIL')));
	var thermal_status = (__t__ (__le__ (max_temp, x.continuous_limit_c)) ? 'PASS' : 'FAIL');
	var status = (__t__ (__t__ (__eq__ (thermal_status, 'FAIL')) || __eq__ (periodic_status, 'FAIL')) ? 'FAIL' : (__t__ (__ne__ (periodic_status, 'PASS')) ? 'REVIEW REQUIRED' : 'PASS'));
	var result_issues = (__t__ (__eq__ (thermal_status, 'PASS')) ? [] : ['Cyclic profile exceeds continuous conductor temperature limit.']);
	if (__t__ (__eq__ (periodic_status, 'INPUT REQUIRED'))) {
		(function () {
			var __accu0__ = result_issues;
			return __call__ (__accu0__.append, __accu0__, 'At least two whole days are required to assess full-state periodic closure.');
		}) ();
	}
	else if (__t__ (__ne__ (periodic_status, 'PASS'))) {
		(function () {
			var __accu0__ = result_issues;
			return __call__ (__accu0__.append, __accu0__, 'Full-state periodic temperature change exceeds 0.05°C; extend the simulation before accepting a converged cycle.');
		}) ();
	}
	return dict ({'status': status, 'thermal_status': thermal_status, 'periodic_status': periodic_status, 'issues': result_issues, 'release_label': 'IEC 60853-ORIENTED SCREENING / VERIFY AGAINST LICENSED BENCHMARK', 'screening_note': 'Four-node thermal screening with conductor losses frozen at the previous step temperature; numerical periodic closure does not validate a project rating.', 'solver': 'DIRECT TRIDIAGONAL / FROZEN LOSS', 'start': start, 'points': points, 'day_peaks_c': day_peaks, 'day_end_temperatures_c': day_end_states, 'peak_conductor_c': max_temp, 'last_day_peak_c': last_day_peak, 'daily_peak_change_c': periodic_delta, 'periodic_day_peak_delta_c': periodic_delta, 'full_state_day_change_c': full_state_delta, 'continuous_margin_c': __sub__ (x.continuous_limit_c, max_temp), 'input': __call__ (asdict, null, x)});
};
export var simulate_emergency = function (x, current_a, duration_h) {
	if (typeof duration_h == 'undefined' || (duration_h != null && duration_h.hasOwnProperty ("__kwargtrans__"))) {;
		var duration_h = 12.0;
	};
	if (arguments.length) {
		var __ilastarg0__ = arguments.length - 1;
		if (arguments [__ilastarg0__] && arguments [__ilastarg0__].hasOwnProperty ("__kwargtrans__")) {
			var __allkwargs0__ = arguments [__ilastarg0__--];
			for (var __attrib0__ in __allkwargs0__) {
				switch (__attrib0__) {
					case 'x': var x = __allkwargs0__ [__attrib0__]; break;
					case 'current_a': var current_a = __allkwargs0__ [__attrib0__]; break;
					case 'duration_h': var duration_h = __allkwargs0__ [__attrib0__]; break;
				}
			}
		}
	}
	else {
	}
	var issues = __call__ (validate_transient, null, x);
	if (__t__ (__lt__ (current_a, 0))) {
		(function () {
			var __accu0__ = issues;
			return __call__ (__accu0__.append, __accu0__, 'Emergency current must be >= 0 A.');
		}) ();
	}
	if (__t__ (__t__ (__le__ (duration_h, 0)) || __gt__ (duration_h, 168))) {
		(function () {
			var __accu0__ = issues;
			return __call__ (__accu0__.append, __accu0__, 'Emergency duration must be > 0 and <= 168 h.');
		}) ();
	}
	if (__t__ (issues)) {
		return dict ({'status': 'INPUT REQUIRED', 'issues': issues, 'input': __call__ (asdict, null, x)});
	}
	var state = __call__ (steady_nodes, null, x);
	var start = __call__ (dict, null, state);
	var points = [];
	var elapsed_s = 0.0;
	var duration_s = __mul__ (duration_h, 3600.0);
	while (__t__ (__lt__ (elapsed_s, duration_s))) {
		var step_s = __call__ (min, null, __mul__ (x.timestep_min, 60.0), __sub__ (duration_s, elapsed_s));
		var state = __call__ (step_implicit, null, x, state, current_a, step_s);
		var elapsed_s = __call__ (__iadd__, null, elapsed_s, step_s);
		(function () {
			var __accu0__ = points;
			return __call__ (__accu0__.append, __accu0__, dict ({'elapsed_h': __truediv__ (elapsed_s, 3600.0), 'conductor_c': __getitem__ (state, 'tc'), 'insulation_c': __getitem__ (state, 'ti'), 'shell_c': __getitem__ (state, 'tshell'), 'soil_c': __getitem__ (state, 'tsoil')}));
		}) ();
	}
	var peak = __call__ (max, null, __getitem__ (start, 'tc'), __call__ (max, null, (function () {
		var __accu0__ = [];
		var __iterable0__ = __call__ (list, null, points);
		for (var __index0__ = 0; __index0__ < len (__iterable0__); __index0__++) {
			var p = __getitem__ (__iterable0__, __index0__);
			(function () {
				var __accu1__ = __accu0__;
				return __call__ (__accu1__.append, __accu1__, __getitem__ (p, 'conductor_c'));
			}) ();
		}
		return py_iter (__accu0__);
	}) ()));
	var status = (__t__ (__le__ (peak, x.emergency_limit_c)) ? 'PASS' : 'LIMIT');
	return dict ({'status': status, 'issues': (__t__ (__eq__ (status, 'PASS')) ? [] : ['Emergency conductor temperature limit exceeded.']), 'release_label': 'IEC 60853-ORIENTED SCREENING / VERIFY AGAINST LICENSED BENCHMARK', 'screening_note': 'Four-node thermal screening with conductor losses frozen at the previous step temperature; this is not a validated IEC 60853 project rating.', 'solver': 'DIRECT TRIDIAGONAL / FROZEN LOSS', 'current_a': current_a, 'duration_h': duration_h, 'start_conductor_c': __getitem__ (start, 'tc'), 'final_conductor_c': __getitem__ (__getitem__ (points, __neg__ (1)), 'conductor_c'), 'peak_conductor_c': peak, 'margin_to_emergency_c': __sub__ (x.emergency_limit_c, peak), 'points': points, 'input': __call__ (asdict, null, x)});
};
export var emergency_rating = function (x, duration_h, start_a, stop_a, increment_a) {
	if (typeof duration_h == 'undefined' || (duration_h != null && duration_h.hasOwnProperty ("__kwargtrans__"))) {;
		var duration_h = 2.0;
	};
	if (typeof start_a == 'undefined' || (start_a != null && start_a.hasOwnProperty ("__kwargtrans__"))) {;
		var start_a = null;
	};
	if (typeof stop_a == 'undefined' || (stop_a != null && stop_a.hasOwnProperty ("__kwargtrans__"))) {;
		var stop_a = null;
	};
	if (typeof increment_a == 'undefined' || (increment_a != null && increment_a.hasOwnProperty ("__kwargtrans__"))) {;
		var increment_a = 50.0;
	};
	if (arguments.length) {
		var __ilastarg0__ = arguments.length - 1;
		if (arguments [__ilastarg0__] && arguments [__ilastarg0__].hasOwnProperty ("__kwargtrans__")) {
			var __allkwargs0__ = arguments [__ilastarg0__--];
			for (var __attrib0__ in __allkwargs0__) {
				switch (__attrib0__) {
					case 'x': var x = __allkwargs0__ [__attrib0__]; break;
					case 'duration_h': var duration_h = __allkwargs0__ [__attrib0__]; break;
					case 'start_a': var start_a = __allkwargs0__ [__attrib0__]; break;
					case 'stop_a': var stop_a = __allkwargs0__ [__attrib0__]; break;
					case 'increment_a': var increment_a = __allkwargs0__ [__attrib0__]; break;
				}
			}
		}
	}
	else {
	}
	var issues = __call__ (validate_transient, null, x);
	if (__t__ (__le__ (duration_h, 0))) {
		(function () {
			var __accu0__ = issues;
			return __call__ (__accu0__.append, __accu0__, 'Emergency rating duration must be > 0 h.');
		}) ();
	}
	if (__t__ (__le__ (increment_a, 0))) {
		(function () {
			var __accu0__ = issues;
			return __call__ (__accu0__.append, __accu0__, 'Current scan increment must be > 0 A.');
		}) ();
	}
	if (__t__ (issues)) {
		return dict ({'status': 'INPUT REQUIRED', 'issues': issues});
	}
	var start = (__t__ (start_a !== null) ? start_a : __call__ (max, null, 0.0, x.base_current_a));
	var stop = (__t__ (stop_a !== null) ? stop_a : __call__ (max, null, __add__ (start, increment_a), __mul__ (x.base_current_a, 3.0)));
	var rows = [];
	var best = null;
	var a = start;
	while (__t__ (__le__ (a, __add__ (stop, 1e-09)))) {
		var sim = __call__ (simulate_emergency, null, x, a, duration_h);
		var tc = (function () {
			var __accu0__ = sim;
			return __call__ (__accu0__.py_get, __accu0__, 'peak_conductor_c');
		}) ();
		var finite_peak = __t__ (__call__ (isinstance, null, tc, tuple ([int, float]))) && __call__ (isfinite, null, tc);
		var row_status = (__t__ (__t__ (__eq__ ((function () {
			var __accu0__ = sim;
			return __call__ (__accu0__.py_get, __accu0__, 'status');
		}) (), 'PASS')) && __t__ (finite_peak) && __le__ (tc, x.emergency_limit_c)) ? 'PASS' : 'LIMIT');
		(function () {
			var __accu0__ = rows;
			return __call__ (__accu0__.append, __accu0__, dict ({'current_a': a, 'conductor_c': tc, 'status': row_status, 'final_conductor_c': (function () {
				var __accu1__ = sim;
				return __call__ (__accu1__.py_get, __accu1__, 'final_conductor_c');
			}) (), 'margin_c': (__t__ (finite_peak) ? __sub__ (x.emergency_limit_c, tc) : null)}));
		}) ();
		if (__t__ (__eq__ (row_status, 'PASS'))) {
			var best = __getitem__ (rows, __neg__ (1));
		}
		var a = __call__ (__iadd__, null, a, increment_a);
	}
	var next_limit = __call__ (py_next, null, (function () {
		var __accu0__ = [];
		var __iterable0__ = __call__ (list, null, rows);
		for (var __index0__ = 0; __index0__ < len (__iterable0__); __index0__++) {
			var r = __getitem__ (__iterable0__, __index0__);
			if (__t__ (__t__ (best) && __t__ (__gt__ (__getitem__ (r, 'current_a'), __getitem__ (best, 'current_a'))) && __eq__ (__getitem__ (r, 'status'), 'LIMIT'))) {
				(function () {
					var __accu1__ = __accu0__;
					return __call__ (__accu1__.append, __accu1__, r);
				}) ();
			}
		}
		return py_iter (__accu0__);
	}) (), null);
	return dict ({'status': (__t__ (best) ? 'PASS' : 'REVIEW REQUIRED'), 'duration_h': duration_h, 'screening_rating_a': (__t__ (best) ? __getitem__ (best, 'current_a') : null), 'temp_at_rating_c': (__t__ (best) ? __getitem__ (best, 'conductor_c') : null), 'next_limit_a': (__t__ (next_limit) ? __getitem__ (next_limit, 'current_a') : null), 'next_limit_temp_c': (__t__ (next_limit) ? __getitem__ (next_limit, 'conductor_c') : null), 'rows': rows, 'resolution_a': increment_a, 'temperature_basis': 'PEAK INCLUDING INITIAL STATE', 'release_label': 'IEC 60853-ORIENTED SCREENING / VERIFY AGAINST LICENSED BENCHMARK'});
};
export var DEFAULT_24H_PROFILE = [0.65, 0.6, 0.58, 0.58, 0.6, 0.65, 0.72, 0.82, 0.9, 0.95, 1.0, 1.0, 0.98, 0.95, 0.92, 0.9, 0.92, 0.98, 1.05, 1.1, 1.05, 0.95, 0.82, 0.72];
export var Zone =  __class__ ('Zone', [object], {
	__module__: __name__,
	get __init__ () {return __get__ (this, function (self, zone_id, active, kind, xmin_m, xmax_m, ymin_m, ymax_m, moist_rho_km_w, dry_eligible) {
		if (typeof active == 'undefined' || (active != null && active.hasOwnProperty ("__kwargtrans__"))) {;
			var active = true;
		};
		if (typeof kind == 'undefined' || (kind != null && kind.hasOwnProperty ("__kwargtrans__"))) {;
			var kind = 'BACKFILL';
		};
		if (typeof xmin_m == 'undefined' || (xmin_m != null && xmin_m.hasOwnProperty ("__kwargtrans__"))) {;
			var xmin_m = __neg__ (0.6);
		};
		if (typeof xmax_m == 'undefined' || (xmax_m != null && xmax_m.hasOwnProperty ("__kwargtrans__"))) {;
			var xmax_m = 0.6;
		};
		if (typeof ymin_m == 'undefined' || (ymin_m != null && ymin_m.hasOwnProperty ("__kwargtrans__"))) {;
			var ymin_m = 0.55;
		};
		if (typeof ymax_m == 'undefined' || (ymax_m != null && ymax_m.hasOwnProperty ("__kwargtrans__"))) {;
			var ymax_m = 1.35;
		};
		if (typeof moist_rho_km_w == 'undefined' || (moist_rho_km_w != null && moist_rho_km_w.hasOwnProperty ("__kwargtrans__"))) {;
			var moist_rho_km_w = 0.8;
		};
		if (typeof dry_eligible == 'undefined' || (dry_eligible != null && dry_eligible.hasOwnProperty ("__kwargtrans__"))) {;
			var dry_eligible = true;
		};
		if (arguments.length) {
			var __ilastarg0__ = arguments.length - 1;
			if (arguments [__ilastarg0__] && arguments [__ilastarg0__].hasOwnProperty ("__kwargtrans__")) {
				var __allkwargs0__ = arguments [__ilastarg0__--];
				for (var __attrib0__ in __allkwargs0__) {
					switch (__attrib0__) {
						case 'self': var self = __allkwargs0__ [__attrib0__]; break;
						case 'zone_id': var zone_id = __allkwargs0__ [__attrib0__]; break;
						case 'active': var active = __allkwargs0__ [__attrib0__]; break;
						case 'kind': var kind = __allkwargs0__ [__attrib0__]; break;
						case 'xmin_m': var xmin_m = __allkwargs0__ [__attrib0__]; break;
						case 'xmax_m': var xmax_m = __allkwargs0__ [__attrib0__]; break;
						case 'ymin_m': var ymin_m = __allkwargs0__ [__attrib0__]; break;
						case 'ymax_m': var ymax_m = __allkwargs0__ [__attrib0__]; break;
						case 'moist_rho_km_w': var moist_rho_km_w = __allkwargs0__ [__attrib0__]; break;
						case 'dry_eligible': var dry_eligible = __allkwargs0__ [__attrib0__]; break;
					}
				}
			}
		}
		else {
		}
		self.__fields__ = ['zone_id', 'active', 'kind', 'xmin_m', 'xmax_m', 'ymin_m', 'ymax_m', 'moist_rho_km_w', 'dry_eligible'];
		self.zone_id = zone_id;
		self.active = active;
		self.kind = kind;
		self.xmin_m = xmin_m;
		self.xmax_m = xmax_m;
		self.ymin_m = ymin_m;
		self.ymax_m = ymax_m;
		self.moist_rho_km_w = moist_rho_km_w;
		self.dry_eligible = dry_eligible;
	});}
});
export var HeatSource =  __class__ ('HeatSource', [object], {
	__module__: __name__,
	get __init__ () {return __get__ (this, function (self, source_id, active, x_m, y_m, heat_w_m, kind) {
		if (typeof active == 'undefined' || (active != null && active.hasOwnProperty ("__kwargtrans__"))) {;
			var active = true;
		};
		if (typeof x_m == 'undefined' || (x_m != null && x_m.hasOwnProperty ("__kwargtrans__"))) {;
			var x_m = 0.0;
		};
		if (typeof y_m == 'undefined' || (y_m != null && y_m.hasOwnProperty ("__kwargtrans__"))) {;
			var y_m = 1.0;
		};
		if (typeof heat_w_m == 'undefined' || (heat_w_m != null && heat_w_m.hasOwnProperty ("__kwargtrans__"))) {;
			var heat_w_m = 0.0;
		};
		if (typeof kind == 'undefined' || (kind != null && kind.hasOwnProperty ("__kwargtrans__"))) {;
			var kind = 'CABLE';
		};
		if (arguments.length) {
			var __ilastarg0__ = arguments.length - 1;
			if (arguments [__ilastarg0__] && arguments [__ilastarg0__].hasOwnProperty ("__kwargtrans__")) {
				var __allkwargs0__ = arguments [__ilastarg0__--];
				for (var __attrib0__ in __allkwargs0__) {
					switch (__attrib0__) {
						case 'self': var self = __allkwargs0__ [__attrib0__]; break;
						case 'source_id': var source_id = __allkwargs0__ [__attrib0__]; break;
						case 'active': var active = __allkwargs0__ [__attrib0__]; break;
						case 'x_m': var x_m = __allkwargs0__ [__attrib0__]; break;
						case 'y_m': var y_m = __allkwargs0__ [__attrib0__]; break;
						case 'heat_w_m': var heat_w_m = __allkwargs0__ [__attrib0__]; break;
						case 'kind': var kind = __allkwargs0__ [__attrib0__]; break;
					}
				}
			}
		}
		else {
		}
		self.__fields__ = ['source_id', 'active', 'x_m', 'y_m', 'heat_w_m', 'kind'];
		self.source_id = source_id;
		self.active = active;
		self.x_m = x_m;
		self.y_m = y_m;
		self.heat_w_m = heat_w_m;
		self.kind = kind;
	});}
});
export var Field2DInput =  __class__ ('Field2DInput', [object], {
	__module__: __name__,
	get __init__ () {return __get__ (this, function (self, width_m, depth_m, nodes_x, nodes_y, ambient_c, omega, iterations_per_pass, convergence_tol_c, native_rho_km_w, dry_rho_km_w, dry_threshold_c, dryout_on, max_dry_passes, zones, sources) {
		if (typeof width_m == 'undefined' || (width_m != null && width_m.hasOwnProperty ("__kwargtrans__"))) {;
			var width_m = 3.0;
		};
		if (typeof depth_m == 'undefined' || (depth_m != null && depth_m.hasOwnProperty ("__kwargtrans__"))) {;
			var depth_m = 3.0;
		};
		if (typeof nodes_x == 'undefined' || (nodes_x != null && nodes_x.hasOwnProperty ("__kwargtrans__"))) {;
			var nodes_x = 13;
		};
		if (typeof nodes_y == 'undefined' || (nodes_y != null && nodes_y.hasOwnProperty ("__kwargtrans__"))) {;
			var nodes_y = 13;
		};
		if (typeof ambient_c == 'undefined' || (ambient_c != null && ambient_c.hasOwnProperty ("__kwargtrans__"))) {;
			var ambient_c = 25.0;
		};
		if (typeof omega == 'undefined' || (omega != null && omega.hasOwnProperty ("__kwargtrans__"))) {;
			var omega = 1.7;
		};
		if (typeof iterations_per_pass == 'undefined' || (iterations_per_pass != null && iterations_per_pass.hasOwnProperty ("__kwargtrans__"))) {;
			var iterations_per_pass = 35;
		};
		if (typeof convergence_tol_c == 'undefined' || (convergence_tol_c != null && convergence_tol_c.hasOwnProperty ("__kwargtrans__"))) {;
			var convergence_tol_c = 0.001;
		};
		if (typeof native_rho_km_w == 'undefined' || (native_rho_km_w != null && native_rho_km_w.hasOwnProperty ("__kwargtrans__"))) {;
			var native_rho_km_w = 1.0;
		};
		if (typeof dry_rho_km_w == 'undefined' || (dry_rho_km_w != null && dry_rho_km_w.hasOwnProperty ("__kwargtrans__"))) {;
			var dry_rho_km_w = 2.5;
		};
		if (typeof dry_threshold_c == 'undefined' || (dry_threshold_c != null && dry_threshold_c.hasOwnProperty ("__kwargtrans__"))) {;
			var dry_threshold_c = 35.0;
		};
		if (typeof dryout_on == 'undefined' || (dryout_on != null && dryout_on.hasOwnProperty ("__kwargtrans__"))) {;
			var dryout_on = true;
		};
		if (typeof max_dry_passes == 'undefined' || (max_dry_passes != null && max_dry_passes.hasOwnProperty ("__kwargtrans__"))) {;
			var max_dry_passes = 8;
		};
		if (typeof zones == 'undefined' || (zones != null && zones.hasOwnProperty ("__kwargtrans__"))) {;
			var zones = null;
		};
		if (typeof sources == 'undefined' || (sources != null && sources.hasOwnProperty ("__kwargtrans__"))) {;
			var sources = null;
		};
		if (arguments.length) {
			var __ilastarg0__ = arguments.length - 1;
			if (arguments [__ilastarg0__] && arguments [__ilastarg0__].hasOwnProperty ("__kwargtrans__")) {
				var __allkwargs0__ = arguments [__ilastarg0__--];
				for (var __attrib0__ in __allkwargs0__) {
					switch (__attrib0__) {
						case 'self': var self = __allkwargs0__ [__attrib0__]; break;
						case 'width_m': var width_m = __allkwargs0__ [__attrib0__]; break;
						case 'depth_m': var depth_m = __allkwargs0__ [__attrib0__]; break;
						case 'nodes_x': var nodes_x = __allkwargs0__ [__attrib0__]; break;
						case 'nodes_y': var nodes_y = __allkwargs0__ [__attrib0__]; break;
						case 'ambient_c': var ambient_c = __allkwargs0__ [__attrib0__]; break;
						case 'omega': var omega = __allkwargs0__ [__attrib0__]; break;
						case 'iterations_per_pass': var iterations_per_pass = __allkwargs0__ [__attrib0__]; break;
						case 'convergence_tol_c': var convergence_tol_c = __allkwargs0__ [__attrib0__]; break;
						case 'native_rho_km_w': var native_rho_km_w = __allkwargs0__ [__attrib0__]; break;
						case 'dry_rho_km_w': var dry_rho_km_w = __allkwargs0__ [__attrib0__]; break;
						case 'dry_threshold_c': var dry_threshold_c = __allkwargs0__ [__attrib0__]; break;
						case 'dryout_on': var dryout_on = __allkwargs0__ [__attrib0__]; break;
						case 'max_dry_passes': var max_dry_passes = __allkwargs0__ [__attrib0__]; break;
						case 'zones': var zones = __allkwargs0__ [__attrib0__]; break;
						case 'sources': var sources = __allkwargs0__ [__attrib0__]; break;
					}
				}
			}
		}
		else {
		}
		self.__fields__ = ['width_m', 'depth_m', 'nodes_x', 'nodes_y', 'ambient_c', 'omega', 'iterations_per_pass', 'convergence_tol_c', 'native_rho_km_w', 'dry_rho_km_w', 'dry_threshold_c', 'dryout_on', 'max_dry_passes', 'zones', 'sources'];
		self.width_m = width_m;
		self.depth_m = depth_m;
		self.nodes_x = nodes_x;
		self.nodes_y = nodes_y;
		self.ambient_c = ambient_c;
		self.omega = omega;
		self.iterations_per_pass = iterations_per_pass;
		self.convergence_tol_c = convergence_tol_c;
		self.native_rho_km_w = native_rho_km_w;
		self.dry_rho_km_w = dry_rho_km_w;
		self.dry_threshold_c = dry_threshold_c;
		self.dryout_on = dryout_on;
		self.max_dry_passes = max_dry_passes;
		self.zones = (__t__ (zones === null) ? [] : zones);
		self.sources = (__t__ (sources === null) ? [] : sources);
	});}
});
export var default_field_input = function (total_heat_w_m) {
	if (typeof total_heat_w_m == 'undefined' || (total_heat_w_m != null && total_heat_w_m.hasOwnProperty ("__kwargtrans__"))) {;
		var total_heat_w_m = 49.96713103209095;
	};
	if (arguments.length) {
		var __ilastarg0__ = arguments.length - 1;
		if (arguments [__ilastarg0__] && arguments [__ilastarg0__].hasOwnProperty ("__kwargtrans__")) {
			var __allkwargs0__ = arguments [__ilastarg0__--];
			for (var __attrib0__ in __allkwargs0__) {
				switch (__attrib0__) {
					case 'total_heat_w_m': var total_heat_w_m = __allkwargs0__ [__attrib0__]; break;
				}
			}
		}
	}
	else {
	}
	var each = __truediv__ (total_heat_w_m, 3.0);
	return __call__ (Field2DInput, null, __kwargtrans__ ({zones: [__call__ (Zone, null, 'Z1')], sources: [__call__ (HeatSource, null, 'SRC1', __kwargtrans__ ({x_m: __neg__ (0.25), y_m: 1.0, heat_w_m: each})), __call__ (HeatSource, null, 'SRC2', __kwargtrans__ ({x_m: 0.25, y_m: 1.0, heat_w_m: each})), __call__ (HeatSource, null, 'SRC3', __kwargtrans__ ({x_m: 0.0, y_m: 0.75, heat_w_m: each}))]}));
};
export var _as_zone = function (z) {
	if (arguments.length) {
		var __ilastarg0__ = arguments.length - 1;
		if (arguments [__ilastarg0__] && arguments [__ilastarg0__].hasOwnProperty ("__kwargtrans__")) {
			var __allkwargs0__ = arguments [__ilastarg0__--];
			for (var __attrib0__ in __allkwargs0__) {
				switch (__attrib0__) {
					case 'z': var z = __allkwargs0__ [__attrib0__]; break;
				}
			}
		}
	}
	else {
	}
	return (__t__ (__call__ (isinstance, null, z, Zone)) ? z : __call__ (Zone, null, __kwargtrans__ (z)));
};
export var _as_source = function (s) {
	if (arguments.length) {
		var __ilastarg0__ = arguments.length - 1;
		if (arguments [__ilastarg0__] && arguments [__ilastarg0__].hasOwnProperty ("__kwargtrans__")) {
			var __allkwargs0__ = arguments [__ilastarg0__--];
			for (var __attrib0__ in __allkwargs0__) {
				switch (__attrib0__) {
					case 's': var s = __allkwargs0__ [__attrib0__]; break;
				}
			}
		}
	}
	else {
	}
	return (__t__ (__call__ (isinstance, null, s, HeatSource)) ? s : __call__ (HeatSource, null, __kwargtrans__ (s)));
};
export var validate_field = function (x) {
	if (arguments.length) {
		var __ilastarg0__ = arguments.length - 1;
		if (arguments [__ilastarg0__] && arguments [__ilastarg0__].hasOwnProperty ("__kwargtrans__")) {
			var __allkwargs0__ = arguments [__ilastarg0__--];
			for (var __attrib0__ in __allkwargs0__) {
				switch (__attrib0__) {
					case 'x': var x = __allkwargs0__ [__attrib0__]; break;
				}
			}
		}
	}
	else {
	}
	var issues = [];
	if (__t__ (__t__ (__le__ (x.width_m, 0)) || __le__ (x.depth_m, 0))) {
		(function () {
			var __accu0__ = issues;
			return __call__ (__accu0__.append, __accu0__, 'Domain width/depth must be > 0 m.');
		}) ();
	}
	if (__t__ (__t__ (__lt__ (x.nodes_x, 5)) || __t__ (__lt__ (x.nodes_y, 5)) || __t__ (__gt__ (x.nodes_x, 101)) || __gt__ (x.nodes_y, 101))) {
		(function () {
			var __accu0__ = issues;
			return __call__ (__accu0__.append, __accu0__, 'Grid nodes must be between 5 and 101 per axis.');
		}) ();
	}
	if (__t__ (!__t__ (((__lt__ (0, x.omega) && __lt__ (x.omega, 2)))))) {
		(function () {
			var __accu0__ = issues;
			return __call__ (__accu0__.append, __accu0__, 'SOR relaxation factor must satisfy 0 < ω < 2.');
		}) ();
	}
	if (__t__ (__t__ (__lt__ (x.iterations_per_pass, 1)) || __gt__ (x.iterations_per_pass, 20000))) {
		(function () {
			var __accu0__ = issues;
			return __call__ (__accu0__.append, __accu0__, 'Iterations per pass must be between 1 and 20000.');
		}) ();
	}
	if (__t__ (__le__ (x.native_rho_km_w, 0))) {
		(function () {
			var __accu0__ = issues;
			return __call__ (__accu0__.append, __accu0__, 'Native-soil thermal resistivity must be > 0 K·m/W.');
		}) ();
	}
	if (__t__ (__t__ (x.dryout_on) && __lt__ (x.dry_rho_km_w, x.native_rho_km_w))) {
		(function () {
			var __accu0__ = issues;
			return __call__ (__accu0__.append, __accu0__, 'Dried-soil thermal resistivity must be >= native-soil thermal resistivity.');
		}) ();
	}
	if (__t__ (__t__ (x.dryout_on) && __le__ (x.dry_threshold_c, x.ambient_c))) {
		(function () {
			var __accu0__ = issues;
			return __call__ (__accu0__.append, __accu0__, 'Dry-out threshold should be above ambient temperature.');
		}) ();
	}
	var __iterable0__ = __call__ (list, null, x.zones);
	for (var __index0__ = 0; __index0__ < len (__iterable0__); __index0__++) {
		var z0 = __getitem__ (__iterable0__, __index0__);
		var z = __call__ (_as_zone, null, z0);
		if (__t__ (!__t__ ((z.active)))) {
			continue;
		}
		if (__t__ (__le__ (z.moist_rho_km_w, 0))) {
			(function () {
				var __accu0__ = issues;
				return __call__ (__accu0__.append, __accu0__, 'Zone {}: thermal resistivity must be > 0.'.format (z.zone_id));
			}) ();
		}
		if (__t__ (__t__ (__gt__ (z.xmin_m, z.xmax_m)) || __gt__ (z.ymin_m, z.ymax_m))) {
			(function () {
				var __accu0__ = issues;
				return __call__ (__accu0__.append, __accu0__, 'Zone {}: invalid rectangle bounds.'.format (z.zone_id));
			}) ();
		}
	}
	var active_sources = (function () {
		var __accu0__ = [];
		var __iterable0__ = __call__ (list, null, x.sources);
		for (var __index0__ = 0; __index0__ < len (__iterable0__); __index0__++) {
			var s = __getitem__ (__iterable0__, __index0__);
			if (__t__ (__call__ (_as_source, null, s).active)) {
				(function () {
					var __accu1__ = __accu0__;
					return __call__ (__accu1__.append, __accu1__, __call__ (_as_source, null, s));
				}) ();
			}
		}
		return __accu0__;
	}) ();
	if (__t__ (!__t__ ((active_sources)))) {
		(function () {
			var __accu0__ = issues;
			return __call__ (__accu0__.append, __accu0__, 'At least one active heat source is required.');
		}) ();
	}
	if (__t__ (__call__ (any, null, (function () {
		var __accu0__ = [];
		var __iterable0__ = __call__ (list, null, active_sources);
		for (var __index0__ = 0; __index0__ < len (__iterable0__); __index0__++) {
			var s = __getitem__ (__iterable0__, __index0__);
			(function () {
				var __accu1__ = __accu0__;
				return __call__ (__accu1__.append, __accu1__, __lt__ (s.heat_w_m, 0));
			}) ();
		}
		return py_iter (__accu0__);
	}) ()))) {
		(function () {
			var __accu0__ = issues;
			return __call__ (__accu0__.append, __accu0__, 'Heat-source values must be >= 0 W/m.');
		}) ();
	}
	return issues;
};
export var _harmonic = function (a, b) {
	if (arguments.length) {
		var __ilastarg0__ = arguments.length - 1;
		if (arguments [__ilastarg0__] && arguments [__ilastarg0__].hasOwnProperty ("__kwargtrans__")) {
			var __allkwargs0__ = arguments [__ilastarg0__--];
			for (var __attrib0__ in __allkwargs0__) {
				switch (__attrib0__) {
					case 'a': var a = __allkwargs0__ [__attrib0__]; break;
					case 'b': var b = __allkwargs0__ [__attrib0__]; break;
				}
			}
		}
	}
	else {
	}
	return (__t__ (__t__ (__gt__ (a, 0)) && __gt__ (b, 0)) ? __truediv__ (__mul__ (__mul__ (2.0, a), b), __add__ (a, b)) : 0.0);
};
export var _grid_setup = function (x) {
	if (arguments.length) {
		var __ilastarg0__ = arguments.length - 1;
		if (arguments [__ilastarg0__] && arguments [__ilastarg0__].hasOwnProperty ("__kwargtrans__")) {
			var __allkwargs0__ = arguments [__ilastarg0__--];
			for (var __attrib0__ in __allkwargs0__) {
				switch (__attrib0__) {
					case 'x': var x = __allkwargs0__ [__attrib0__]; break;
				}
			}
		}
	}
	else {
	}
	var dx = __truediv__ (x.width_m, __sub__ (x.nodes_x, 1));
	var dy = __truediv__ (x.depth_m, __sub__ (x.nodes_y, 1));
	var xs = (function () {
		var __accu0__ = [];
		var __iterable0__ = __call__ (list, null, __call__ (range, null, x.nodes_x));
		for (var __index0__ = 0; __index0__ < len (__iterable0__); __index0__++) {
			var i = __getitem__ (__iterable0__, __index0__);
			(function () {
				var __accu1__ = __accu0__;
				return __call__ (__accu1__.append, __accu1__, __add__ (__truediv__ (__neg__ (x.width_m), 2.0), __mul__ (i, dx)));
			}) ();
		}
		return __accu0__;
	}) ();
	var ys = (function () {
		var __accu0__ = [];
		var __iterable0__ = __call__ (list, null, __call__ (range, null, x.nodes_y));
		for (var __index0__ = 0; __index0__ < len (__iterable0__); __index0__++) {
			var j = __getitem__ (__iterable0__, __index0__);
			(function () {
				var __accu1__ = __accu0__;
				return __call__ (__accu1__.append, __accu1__, __mul__ (j, dy));
			}) ();
		}
		return __accu0__;
	}) ();
	var rho = (function () {
		var __accu0__ = [];
		var __iterable0__ = __call__ (list, null, ys);
		for (var __index0__ = 0; __index0__ < len (__iterable0__); __index0__++) {
			var _ = __getitem__ (__iterable0__, __index0__);
			(function () {
				var __accu1__ = __accu0__;
				return __call__ (__accu1__.append, __accu1__, (function () {
					var __accu2__ = [];
					var __iterable1__ = __call__ (list, null, xs);
					for (var __index1__ = 0; __index1__ < len (__iterable1__); __index1__++) {
						var _ = __getitem__ (__iterable1__, __index1__);
						(function () {
							var __accu3__ = __accu2__;
							return __call__ (__accu3__.append, __accu3__, x.native_rho_km_w);
						}) ();
					}
					return __accu2__;
				}) ());
			}) ();
		}
		return __accu0__;
	}) ();
	var eligible = (function () {
		var __accu0__ = [];
		var __iterable0__ = __call__ (list, null, ys);
		for (var __index0__ = 0; __index0__ < len (__iterable0__); __index0__++) {
			var _ = __getitem__ (__iterable0__, __index0__);
			(function () {
				var __accu1__ = __accu0__;
				return __call__ (__accu1__.append, __accu1__, (function () {
					var __accu2__ = [];
					var __iterable1__ = __call__ (list, null, xs);
					for (var __index1__ = 0; __index1__ < len (__iterable1__); __index1__++) {
						var _ = __getitem__ (__iterable1__, __index1__);
						(function () {
							var __accu3__ = __accu2__;
							return __call__ (__accu3__.append, __accu3__, true);
						}) ();
					}
					return __accu2__;
				}) ());
			}) ();
		}
		return __accu0__;
	}) ();
	var zone_ids = (function () {
		var __accu0__ = [];
		var __iterable0__ = __call__ (list, null, ys);
		for (var __index0__ = 0; __index0__ < len (__iterable0__); __index0__++) {
			var _ = __getitem__ (__iterable0__, __index0__);
			(function () {
				var __accu1__ = __accu0__;
				return __call__ (__accu1__.append, __accu1__, (function () {
					var __accu2__ = [];
					var __iterable1__ = __call__ (list, null, xs);
					for (var __index1__ = 0; __index1__ < len (__iterable1__); __index1__++) {
						var _ = __getitem__ (__iterable1__, __index1__);
						(function () {
							var __accu3__ = __accu2__;
							return __call__ (__accu3__.append, __accu3__, 'NATIVE');
						}) ();
					}
					return __accu2__;
				}) ());
			}) ();
		}
		return __accu0__;
	}) ();
	var __iterable0__ = __call__ (list, null, __call__ (py_enumerate, null, ys));
	for (var __index0__ = 0; __index0__ < len (__iterable0__); __index0__++) {
		var __left0__ = __getitem__ (__iterable0__, __index0__);
		var j = __left0__ [0];
		var y = __left0__ [1];
		var __iterable1__ = __call__ (list, null, __call__ (py_enumerate, null, xs));
		for (var __index1__ = 0; __index1__ < len (__iterable1__); __index1__++) {
			var __left0__ = __getitem__ (__iterable1__, __index1__);
			var i = __left0__ [0];
			var xx = __left0__ [1];
			var __iterable2__ = __call__ (list, null, x.zones);
			for (var __index2__ = 0; __index2__ < len (__iterable2__); __index2__++) {
				var z0 = __getitem__ (__iterable2__, __index2__);
				var z = __call__ (_as_zone, null, z0);
				if (__t__ (__t__ (z.active) && __t__ ((__le__ (z.xmin_m, xx) && __le__ (xx, z.xmax_m))) && (__le__ (z.ymin_m, y) && __le__ (y, z.ymax_m)))) {
					__setitem__ (__getitem__ (rho, j), i, z.moist_rho_km_w);
					__setitem__ (__getitem__ (eligible, j), i, z.dry_eligible);
					__setitem__ (__getitem__ (zone_ids, j), i, z.zone_id);
				}
			}
		}
	}
	var q = (function () {
		var __accu0__ = [];
		var __iterable0__ = __call__ (list, null, ys);
		for (var __index0__ = 0; __index0__ < len (__iterable0__); __index0__++) {
			var _ = __getitem__ (__iterable0__, __index0__);
			(function () {
				var __accu1__ = __accu0__;
				return __call__ (__accu1__.append, __accu1__, (function () {
					var __accu2__ = [];
					var __iterable1__ = __call__ (list, null, xs);
					for (var __index1__ = 0; __index1__ < len (__iterable1__); __index1__++) {
						var _ = __getitem__ (__iterable1__, __index1__);
						(function () {
							var __accu3__ = __accu2__;
							return __call__ (__accu3__.append, __accu3__, 0.0);
						}) ();
					}
					return __accu2__;
				}) ());
			}) ();
		}
		return __accu0__;
	}) ();
	var placed_sources = [];
	var __iterable0__ = __call__ (list, null, x.sources);
	for (var __index0__ = 0; __index0__ < len (__iterable0__); __index0__++) {
		var s0 = __getitem__ (__iterable0__, __index0__);
		var s = __call__ (_as_source, null, s0);
		if (__t__ (!__t__ ((s.active)))) {
			continue;
		}
		var i = __call__ (min, null, __call__ (range, null, x.nodes_x), __kwargtrans__ ({key: (function __lambda__ (k) {
			if (arguments.length) {
				var __ilastarg0__ = arguments.length - 1;
				if (arguments [__ilastarg0__] && arguments [__ilastarg0__].hasOwnProperty ("__kwargtrans__")) {
					var __allkwargs0__ = arguments [__ilastarg0__--];
					for (var __attrib0__ in __allkwargs0__) {
						switch (__attrib0__) {
							case 'k': var k = __allkwargs0__ [__attrib0__]; break;
						}
					}
				}
			}
			else {
			}
			return __call__ (abs, null, __sub__ (__getitem__ (xs, k), s.x_m));
		})}));
		var j = __call__ (min, null, __call__ (range, null, x.nodes_y), __kwargtrans__ ({key: (function __lambda__ (k) {
			if (arguments.length) {
				var __ilastarg0__ = arguments.length - 1;
				if (arguments [__ilastarg0__] && arguments [__ilastarg0__].hasOwnProperty ("__kwargtrans__")) {
					var __allkwargs0__ = arguments [__ilastarg0__--];
					for (var __attrib0__ in __allkwargs0__) {
						switch (__attrib0__) {
							case 'k': var k = __allkwargs0__ [__attrib0__]; break;
						}
					}
				}
			}
			else {
			}
			return __call__ (abs, null, __sub__ (__getitem__ (ys, k), s.y_m));
		})}));
		__setitem__ (__getitem__ (q, j), i, __call__ (__iadd__, null, __getitem__ (__getitem__ (q, j), i), s.heat_w_m));
		(function () {
			var __accu0__ = placed_sources;
			return __call__ (__accu0__.append, __accu0__, dict ({'source_id': s.source_id, 'requested_x_m': s.x_m, 'requested_y_m': s.y_m, 'grid_x_m': __getitem__ (xs, i), 'grid_y_m': __getitem__ (ys, j), 'i': i, 'j': j, 'heat_w_m': s.heat_w_m}));
		}) ();
	}
	return tuple ([xs, ys, dx, dy, rho, eligible, zone_ids, q, placed_sources]);
};
export var _solve_once = function (x, rho, q, initial) {
	if (typeof initial == 'undefined' || (initial != null && initial.hasOwnProperty ("__kwargtrans__"))) {;
		var initial = null;
	};
	if (arguments.length) {
		var __ilastarg0__ = arguments.length - 1;
		if (arguments [__ilastarg0__] && arguments [__ilastarg0__].hasOwnProperty ("__kwargtrans__")) {
			var __allkwargs0__ = arguments [__ilastarg0__--];
			for (var __attrib0__ in __allkwargs0__) {
				switch (__attrib0__) {
					case 'x': var x = __allkwargs0__ [__attrib0__]; break;
					case 'rho': var rho = __allkwargs0__ [__attrib0__]; break;
					case 'q': var q = __allkwargs0__ [__attrib0__]; break;
					case 'initial': var initial = __allkwargs0__ [__attrib0__]; break;
				}
			}
		}
	}
	else {
	}
	var __left0__ = tuple ([x.nodes_x, x.nodes_y]);
	var nx = __left0__ [0];
	var ny = __left0__ [1];
	var dx = __truediv__ (x.width_m, __sub__ (nx, 1));
	var dy = __truediv__ (x.depth_m, __sub__ (ny, 1));
	var k = (function () {
		var __accu0__ = [];
		var __iterable0__ = __call__ (list, null, __call__ (range, null, ny));
		for (var __index0__ = 0; __index0__ < len (__iterable0__); __index0__++) {
			var j = __getitem__ (__iterable0__, __index0__);
			(function () {
				var __accu1__ = __accu0__;
				return __call__ (__accu1__.append, __accu1__, (function () {
					var __accu2__ = [];
					var __iterable1__ = __call__ (list, null, __call__ (range, null, nx));
					for (var __index1__ = 0; __index1__ < len (__iterable1__); __index1__++) {
						var i = __getitem__ (__iterable1__, __index1__);
						(function () {
							var __accu3__ = __accu2__;
							return __call__ (__accu3__.append, __accu3__, __truediv__ (1.0, __getitem__ (__getitem__ (rho, j), i)));
						}) ();
					}
					return __accu2__;
				}) ());
			}) ();
		}
		return __accu0__;
	}) ();
	var t = (__t__ (initial === null) ? (function () {
		var __accu0__ = [];
		var __iterable0__ = __call__ (list, null, __call__ (range, null, ny));
		for (var __index0__ = 0; __index0__ < len (__iterable0__); __index0__++) {
			var _ = __getitem__ (__iterable0__, __index0__);
			(function () {
				var __accu1__ = __accu0__;
				return __call__ (__accu1__.append, __accu1__, (function () {
					var __accu2__ = [];
					var __iterable1__ = __call__ (list, null, __call__ (range, null, nx));
					for (var __index1__ = 0; __index1__ < len (__iterable1__); __index1__++) {
						var _ = __getitem__ (__iterable1__, __index1__);
						(function () {
							var __accu3__ = __accu2__;
							return __call__ (__accu3__.append, __accu3__, x.ambient_c);
						}) ();
					}
					return __accu2__;
				}) ());
			}) ();
		}
		return __accu0__;
	}) () : (function () {
		var __accu0__ = [];
		var __iterable0__ = __call__ (list, null, initial);
		for (var __index0__ = 0; __index0__ < len (__iterable0__); __index0__++) {
			var row = __getitem__ (__iterable0__, __index0__);
			(function () {
				var __accu1__ = __accu0__;
				return __call__ (__accu1__.append, __accu1__, __getslice__ (row, null, null, 1));
			}) ();
		}
		return __accu0__;
	}) ());
	var __iterable0__ = __call__ (list, null, __call__ (range, null, nx));
	for (var __index0__ = 0; __index0__ < len (__iterable0__); __index0__++) {
		var i = __getitem__ (__iterable0__, __index0__);
		__setitem__ (__getitem__ (t, 0), i, x.ambient_c);
		__setitem__ (__getitem__ (t, __neg__ (1)), i, x.ambient_c);
	}
	var __iterable0__ = __call__ (list, null, __call__ (range, null, ny));
	for (var __index0__ = 0; __index0__ < len (__iterable0__); __index0__++) {
		var j = __getitem__ (__iterable0__, __index0__);
		__setitem__ (__getitem__ (t, j), 0, x.ambient_c);
		__setitem__ (__getitem__ (t, j), __neg__ (1), x.ambient_c);
	}
	var history = [];
	var max_delta = __call__ (float, null, 'inf');
	var __iterable0__ = __call__ (list, null, __call__ (range, null, 1, __add__ (x.iterations_per_pass, 1)));
	for (var __index0__ = 0; __index0__ < len (__iterable0__); __index0__++) {
		var it = __getitem__ (__iterable0__, __index0__);
		var max_delta = 0.0;
		var __iterable1__ = __call__ (list, null, __call__ (range, null, 1, __sub__ (ny, 1)));
		for (var __index1__ = 0; __index1__ < len (__iterable1__); __index1__++) {
			var j = __getitem__ (__iterable1__, __index1__);
			var __iterable2__ = __call__ (list, null, __call__ (range, null, 1, __sub__ (nx, 1)));
			for (var __index2__ = 0; __index2__ < len (__iterable2__); __index2__++) {
				var i = __getitem__ (__iterable2__, __index2__);
				var kc = __getitem__ (__getitem__ (k, j), i);
				var ge = __truediv__ (__mul__ (__call__ (_harmonic, null, kc, __getitem__ (__getitem__ (k, j), __add__ (i, 1))), dy), dx);
				var gw = __truediv__ (__mul__ (__call__ (_harmonic, null, kc, __getitem__ (__getitem__ (k, j), __sub__ (i, 1))), dy), dx);
				var gn = __truediv__ (__mul__ (__call__ (_harmonic, null, kc, __getitem__ (__getitem__ (k, __sub__ (j, 1)), i)), dx), dy);
				var gs = __truediv__ (__mul__ (__call__ (_harmonic, null, kc, __getitem__ (__getitem__ (k, __add__ (j, 1)), i)), dx), dy);
				var denom = __add__ (__add__ (__add__ (ge, gw), gn), gs);
				var raw = __truediv__ (__add__ (__add__ (__add__ (__add__ (__mul__ (ge, __getitem__ (__getitem__ (t, j), __add__ (i, 1))), __mul__ (gw, __getitem__ (__getitem__ (t, j), __sub__ (i, 1)))), __mul__ (gn, __getitem__ (__getitem__ (t, __sub__ (j, 1)), i))), __mul__ (gs, __getitem__ (__getitem__ (t, __add__ (j, 1)), i))), __getitem__ (__getitem__ (q, j), i)), denom);
				var py_new = __add__ (__getitem__ (__getitem__ (t, j), i), __mul__ (x.omega, __sub__ (raw, __getitem__ (__getitem__ (t, j), i))));
				var max_delta = __call__ (max, null, max_delta, __call__ (abs, null, __sub__ (py_new, __getitem__ (__getitem__ (t, j), i))));
				__setitem__ (__getitem__ (t, j), i, py_new);
			}
		}
		(function () {
			var __accu0__ = history;
			return __call__ (__accu0__.append, __accu0__, max_delta);
		}) ();
		if (__t__ (!__t__ ((__call__ (isfinite, null, max_delta))))) {
			break;
		}
	}
	return tuple ([t, max_delta, history]);
};
export var _boundary_heat = function (x, rho, t) {
	if (arguments.length) {
		var __ilastarg0__ = arguments.length - 1;
		if (arguments [__ilastarg0__] && arguments [__ilastarg0__].hasOwnProperty ("__kwargtrans__")) {
			var __allkwargs0__ = arguments [__ilastarg0__--];
			for (var __attrib0__ in __allkwargs0__) {
				switch (__attrib0__) {
					case 'x': var x = __allkwargs0__ [__attrib0__]; break;
					case 'rho': var rho = __allkwargs0__ [__attrib0__]; break;
					case 't': var t = __allkwargs0__ [__attrib0__]; break;
				}
			}
		}
	}
	else {
	}
	var __left0__ = tuple ([x.nodes_x, x.nodes_y]);
	var nx = __left0__ [0];
	var ny = __left0__ [1];
	var dx = __truediv__ (x.width_m, __sub__ (nx, 1));
	var dy = __truediv__ (x.depth_m, __sub__ (ny, 1));
	var k = (function () {
		var __accu0__ = [];
		var __iterable0__ = __call__ (list, null, __call__ (range, null, ny));
		for (var __index0__ = 0; __index0__ < len (__iterable0__); __index0__++) {
			var j = __getitem__ (__iterable0__, __index0__);
			(function () {
				var __accu1__ = __accu0__;
				return __call__ (__accu1__.append, __accu1__, (function () {
					var __accu2__ = [];
					var __iterable1__ = __call__ (list, null, __call__ (range, null, nx));
					for (var __index1__ = 0; __index1__ < len (__iterable1__); __index1__++) {
						var i = __getitem__ (__iterable1__, __index1__);
						(function () {
							var __accu3__ = __accu2__;
							return __call__ (__accu3__.append, __accu3__, __truediv__ (1.0, __getitem__ (__getitem__ (rho, j), i)));
						}) ();
					}
					return __accu2__;
				}) ());
			}) ();
		}
		return __accu0__;
	}) ();
	var total = 0.0;
	var __iterable0__ = __call__ (list, null, __call__ (range, null, 1, __sub__ (nx, 1)));
	for (var __index0__ = 0; __index0__ < len (__iterable0__); __index0__++) {
		var i = __getitem__ (__iterable0__, __index0__);
		var total = __call__ (__iadd__, null, total, __mul__ (__truediv__ (__mul__ (__call__ (_harmonic, null, __getitem__ (__getitem__ (k, 1), i), __getitem__ (__getitem__ (k, 0), i)), dx), dy), __sub__ (__getitem__ (__getitem__ (t, 1), i), x.ambient_c)));
		var total = __call__ (__iadd__, null, total, __mul__ (__truediv__ (__mul__ (__call__ (_harmonic, null, __getitem__ (__getitem__ (k, __sub__ (ny, 2)), i), __getitem__ (__getitem__ (k, __sub__ (ny, 1)), i)), dx), dy), __sub__ (__getitem__ (__getitem__ (t, __sub__ (ny, 2)), i), x.ambient_c)));
	}
	var __iterable0__ = __call__ (list, null, __call__ (range, null, 1, __sub__ (ny, 1)));
	for (var __index0__ = 0; __index0__ < len (__iterable0__); __index0__++) {
		var j = __getitem__ (__iterable0__, __index0__);
		var total = __call__ (__iadd__, null, total, __mul__ (__truediv__ (__mul__ (__call__ (_harmonic, null, __getitem__ (__getitem__ (k, j), 1), __getitem__ (__getitem__ (k, j), 0)), dy), dx), __sub__ (__getitem__ (__getitem__ (t, j), 1), x.ambient_c)));
		var total = __call__ (__iadd__, null, total, __mul__ (__truediv__ (__mul__ (__call__ (_harmonic, null, __getitem__ (__getitem__ (k, j), __sub__ (nx, 2)), __getitem__ (__getitem__ (k, j), __sub__ (nx, 1))), dy), dx), __sub__ (__getitem__ (__getitem__ (t, j), __sub__ (nx, 2)), x.ambient_c)));
	}
	return total;
};
export var solve_field = function (x) {
	if (arguments.length) {
		var __ilastarg0__ = arguments.length - 1;
		if (arguments [__ilastarg0__] && arguments [__ilastarg0__].hasOwnProperty ("__kwargtrans__")) {
			var __allkwargs0__ = arguments [__ilastarg0__--];
			for (var __attrib0__ in __allkwargs0__) {
				switch (__attrib0__) {
					case 'x': var x = __allkwargs0__ [__attrib0__]; break;
				}
			}
		}
	}
	else {
	}
	var issues = __call__ (validate_field, null, x);
	if (__t__ (issues)) {
		return dict ({'status': 'INPUT REQUIRED', 'issues': issues, 'input': __call__ (asdict, null, x)});
	}
	var __left0__ = __call__ (_grid_setup, null, x);
	var xs = __left0__ [0];
	var ys = __left0__ [1];
	var dx = __left0__ [2];
	var dy = __left0__ [3];
	var moist_rho = __left0__ [4];
	var eligible = __left0__ [5];
	var zone_ids = __left0__ [6];
	var q = __left0__ [7];
	var placed = __left0__ [8];
	var source_heat = __call__ (sum, null, (function () {
		var __accu0__ = [];
		var __iterable0__ = __call__ (list, null, q);
		for (var __index0__ = 0; __index0__ < len (__iterable0__); __index0__++) {
			var row = __getitem__ (__iterable0__, __index0__);
			(function () {
				var __accu1__ = __accu0__;
				return __call__ (__accu1__.append, __accu1__, __call__ (sum, null, row));
			}) ();
		}
		return py_iter (__accu0__);
	}) ());
	var __left0__ = __call__ (_solve_once, null, x, moist_rho, q);
	var moist_t = __left0__ [0];
	var moist_delta = __left0__ [1];
	var moist_hist = __left0__ [2];
	var moist_max = __call__ (max, null, (function () {
		var __accu0__ = [];
		var __iterable0__ = __call__ (list, null, moist_t);
		for (var __index0__ = 0; __index0__ < len (__iterable0__); __index0__++) {
			var row = __getitem__ (__iterable0__, __index0__);
			(function () {
				var __accu1__ = __accu0__;
				return __call__ (__accu1__.append, __accu1__, __call__ (max, null, row));
			}) ();
		}
		return py_iter (__accu0__);
	}) ());
	var final_t = moist_t;
	var final_rho = (function () {
		var __accu0__ = [];
		var __iterable0__ = __call__ (list, null, moist_rho);
		for (var __index0__ = 0; __index0__ < len (__iterable0__); __index0__++) {
			var r = __getitem__ (__iterable0__, __index0__);
			(function () {
				var __accu1__ = __accu0__;
				return __call__ (__accu1__.append, __accu1__, __getslice__ (r, null, null, 1));
			}) ();
		}
		return __accu0__;
	}) ();
	var dry_flags = (function () {
		var __accu0__ = [];
		var __iterable0__ = __call__ (list, null, __call__ (range, null, x.nodes_y));
		for (var __index0__ = 0; __index0__ < len (__iterable0__); __index0__++) {
			var _ = __getitem__ (__iterable0__, __index0__);
			(function () {
				var __accu1__ = __accu0__;
				return __call__ (__accu1__.append, __accu1__, (function () {
					var __accu2__ = [];
					var __iterable1__ = __call__ (list, null, __call__ (range, null, x.nodes_x));
					for (var __index1__ = 0; __index1__ < len (__iterable1__); __index1__++) {
						var _ = __getitem__ (__iterable1__, __index1__);
						(function () {
							var __accu3__ = __accu2__;
							return __call__ (__accu3__.append, __accu3__, false);
						}) ();
					}
					return __accu2__;
				}) ());
			}) ();
		}
		return __accu0__;
	}) ();
	var dry_pass_records = [];
	var stable = true;
	if (__t__ (x.dryout_on)) {
		var stable = false;
		var previous_flags = null;
		var __break0__ = false;
		var __iterable0__ = __call__ (list, null, __call__ (range, null, 1, __add__ (x.max_dry_passes, 1)));
		for (var __index0__ = 0; __index0__ < len (__iterable0__); __index0__++) {
			var p = __getitem__ (__iterable0__, __index0__);
			var flags = (function () {
				var __accu0__ = [];
				var __iterable1__ = __call__ (list, null, __call__ (range, null, x.nodes_y));
				for (var __index1__ = 0; __index1__ < len (__iterable1__); __index1__++) {
					var j = __getitem__ (__iterable1__, __index1__);
					(function () {
						var __accu1__ = __accu0__;
						return __call__ (__accu1__.append, __accu1__, (function () {
							var __accu2__ = [];
							var __iterable2__ = __call__ (list, null, __call__ (range, null, x.nodes_x));
							for (var __index2__ = 0; __index2__ < len (__iterable2__); __index2__++) {
								var i = __getitem__ (__iterable2__, __index2__);
								(function () {
									var __accu3__ = __accu2__;
									return __call__ (__accu3__.append, __accu3__, __t__ (__getitem__ (__getitem__ (eligible, j), i)) && __ge__ (__getitem__ (__getitem__ (final_t, j), i), x.dry_threshold_c));
								}) ();
							}
							return __accu2__;
						}) ());
					}) ();
				}
				return __accu0__;
			}) ();
			var mismatch = (__t__ (previous_flags === null) ? 0 : __call__ (sum, null, (function () {
				var __accu0__ = [];
				var __iterable1__ = __call__ (list, null, __call__ (range, null, x.nodes_y));
				for (var __index1__ = 0; __index1__ < len (__iterable1__); __index1__++) {
					var j = __getitem__ (__iterable1__, __index1__);
					var __iterable2__ = __call__ (list, null, __call__ (range, null, x.nodes_x));
					for (var __index2__ = 0; __index2__ < len (__iterable2__); __index2__++) {
						var i = __getitem__ (__iterable2__, __index2__);
						if (__t__ (__ne__ (__getitem__ (__getitem__ (flags, j), i), __getitem__ (__getitem__ (previous_flags, j), i)))) {
							(function () {
								var __accu1__ = __accu0__;
								return __call__ (__accu1__.append, __accu1__, 1);
							}) ();
						}
					}
				}
				return py_iter (__accu0__);
			}) ()));
			var final_rho = (function () {
				var __accu0__ = [];
				var __iterable1__ = __call__ (list, null, __call__ (range, null, x.nodes_y));
				for (var __index1__ = 0; __index1__ < len (__iterable1__); __index1__++) {
					var j = __getitem__ (__iterable1__, __index1__);
					(function () {
						var __accu1__ = __accu0__;
						return __call__ (__accu1__.append, __accu1__, (function () {
							var __accu2__ = [];
							var __iterable2__ = __call__ (list, null, __call__ (range, null, x.nodes_x));
							for (var __index2__ = 0; __index2__ < len (__iterable2__); __index2__++) {
								var i = __getitem__ (__iterable2__, __index2__);
								(function () {
									var __accu3__ = __accu2__;
									return __call__ (__accu3__.append, __accu3__, (__t__ (__getitem__ (__getitem__ (flags, j), i)) ? x.dry_rho_km_w : __getitem__ (__getitem__ (moist_rho, j), i)));
								}) ();
							}
							return __accu2__;
						}) ());
					}) ();
				}
				return __accu0__;
			}) ();
			var __left0__ = __call__ (_solve_once, null, x, final_rho, q, __kwargtrans__ ({initial: final_t}));
			var final_t = __left0__ [0];
			var delta = __left0__ [1];
			var hist = __left0__ [2];
			var dry_count = __call__ (sum, null, (function () {
				var __accu0__ = [];
				var __iterable1__ = __call__ (list, null, flags);
				for (var __index1__ = 0; __index1__ < len (__iterable1__); __index1__++) {
					var row = __getitem__ (__iterable1__, __index1__);
					(function () {
						var __accu1__ = __accu0__;
						return __call__ (__accu1__.append, __accu1__, __call__ (sum, null, (function () {
							var __accu2__ = [];
							var __iterable2__ = __call__ (list, null, row);
							for (var __index2__ = 0; __index2__ < len (__iterable2__); __index2__++) {
								var v = __getitem__ (__iterable2__, __index2__);
								if (__t__ (v)) {
									(function () {
										var __accu3__ = __accu2__;
										return __call__ (__accu3__.append, __accu3__, 1);
									}) ();
								}
							}
							return py_iter (__accu2__);
						}) ()));
					}) ();
				}
				return py_iter (__accu0__);
			}) ());
			(function () {
				var __accu0__ = dry_pass_records;
				return __call__ (__accu0__.append, __accu0__, dict ({'pass': p, 'dry_cells': dry_count, 'map_change_count': mismatch, 'max_temp_c': __call__ (max, null, (function () {
					var __accu1__ = [];
					var __iterable1__ = __call__ (list, null, final_t);
					for (var __index1__ = 0; __index1__ < len (__iterable1__); __index1__++) {
						var row = __getitem__ (__iterable1__, __index1__);
						(function () {
							var __accu2__ = __accu1__;
							return __call__ (__accu2__.append, __accu2__, __call__ (max, null, row));
						}) ();
					}
					return py_iter (__accu1__);
				}) ()), 'final_delta_c': delta}));
			}) ();
			if (__t__ (__t__ (previous_flags !== null) && __eq__ (mismatch, 0))) {
				var stable = true;
				var dry_flags = flags;
				__break0__ = true;
				break;
			}
			var previous_flags = flags;
			var dry_flags = flags;
		}
		if (!__break0__) {
			var stable = false;
		}
	}
	var final_delta = (__t__ (dry_pass_records) ? __getitem__ (__getitem__ (dry_pass_records, __neg__ (1)), 'final_delta_c') : moist_delta);
	var final_max = __call__ (max, null, (function () {
		var __accu0__ = [];
		var __iterable0__ = __call__ (list, null, final_t);
		for (var __index0__ = 0; __index0__ < len (__iterable0__); __index0__++) {
			var row = __getitem__ (__iterable0__, __index0__);
			(function () {
				var __accu1__ = __accu0__;
				return __call__ (__accu1__.append, __accu1__, __call__ (max, null, row));
			}) ();
		}
		return py_iter (__accu0__);
	}) ());
	var dry_count = __call__ (sum, null, (function () {
		var __accu0__ = [];
		var __iterable0__ = __call__ (list, null, dry_flags);
		for (var __index0__ = 0; __index0__ < len (__iterable0__); __index0__++) {
			var row = __getitem__ (__iterable0__, __index0__);
			(function () {
				var __accu1__ = __accu0__;
				return __call__ (__accu1__.append, __accu1__, __call__ (sum, null, (function () {
					var __accu2__ = [];
					var __iterable1__ = __call__ (list, null, row);
					for (var __index1__ = 0; __index1__ < len (__iterable1__); __index1__++) {
						var v = __getitem__ (__iterable1__, __index1__);
						if (__t__ (v)) {
							(function () {
								var __accu3__ = __accu2__;
								return __call__ (__accu3__.append, __accu3__, 1);
							}) ();
						}
					}
					return py_iter (__accu2__);
				}) ()));
			}) ();
		}
		return py_iter (__accu0__);
	}) ());
	var boundary_heat = __call__ (_boundary_heat, null, x, final_rho, final_t);
	var imbalance = __sub__ (boundary_heat, source_heat);
	var asym = 0.0;
	var __iterable0__ = __call__ (list, null, __call__ (range, null, x.nodes_y));
	for (var __index0__ = 0; __index0__ < len (__iterable0__); __index0__++) {
		var j = __getitem__ (__iterable0__, __index0__);
		var __iterable1__ = __call__ (list, null, __call__ (range, null, x.nodes_x));
		for (var __index1__ = 0; __index1__ < len (__iterable1__); __index1__++) {
			var i = __getitem__ (__iterable1__, __index1__);
			var asym = __call__ (max, null, asym, __call__ (abs, null, __sub__ (__getitem__ (__getitem__ (final_t, j), i), __getitem__ (__getitem__ (final_t, j), __sub__ (__sub__ (x.nodes_x, 1), i)))));
		}
	}
	var converged = __le__ (final_delta, x.convergence_tol_c);
	var energy_ok = __le__ (__call__ (abs, null, imbalance), __call__ (max, null, 0.01, __mul__ (0.0005, __call__ (max, null, source_heat, 1.0))));
	if (__t__ (__t__ (!__t__ ((converged))) || !__t__ ((stable)))) {
		var status = 'REVIEW REQUIRED';
	}
	else if (__t__ (!__t__ ((energy_ok)))) {
		var status = 'REVIEW REQUIRED';
	}
	else {
		var status = 'PASS';
	}
	var cells = [];
	var __iterable0__ = __call__ (list, null, __call__ (py_enumerate, null, ys));
	for (var __index0__ = 0; __index0__ < len (__iterable0__); __index0__++) {
		var __left0__ = __getitem__ (__iterable0__, __index0__);
		var j = __left0__ [0];
		var y = __left0__ [1];
		var __iterable1__ = __call__ (list, null, __call__ (py_enumerate, null, xs));
		for (var __index1__ = 0; __index1__ < len (__iterable1__); __index1__++) {
			var __left0__ = __getitem__ (__iterable1__, __index1__);
			var i = __left0__ [0];
			var xx = __left0__ [1];
			(function () {
				var __accu0__ = cells;
				return __call__ (__accu0__.append, __accu0__, dict ({'x_m': xx, 'y_m': y, 'temperature_c': __getitem__ (__getitem__ (final_t, j), i), 'rho_km_w': __getitem__ (__getitem__ (final_rho, j), i), 'dry': __getitem__ (__getitem__ (dry_flags, j), i), 'zone': __getitem__ (__getitem__ (zone_ids, j), i), 'source_w_m': __getitem__ (__getitem__ (q, j), i)}));
			}) ();
		}
	}
	return dict ({'status': status, 'issues': (__t__ (__eq__ (status, 'PASS')) ? [] : ['Numerical convergence, dry-map stability, or energy-balance review is required.']), 'release_label': 'FDM THERMAL SCREENING / VERIFY AGAINST CIGRE TB 963 OR OTHER APPROVED BENCHMARK', 'moist_max_c': moist_max, 'final_max_c': final_max, 'dry_cells': dry_count, 'final_delta_c': final_delta, 'source_heat_w_m': source_heat, 'boundary_heat_w_m': boundary_heat, 'energy_imbalance_w_m': imbalance, 'left_right_asymmetry_c': asym, 'dry_map_stable': stable, 'mesh_independence': 'NOT RUN — REVIEW REQUIRED', 'domain_independence': 'NOT RUN — REVIEW REQUIRED', 'dx_m': dx, 'dy_m': dy, 'x_coordinates_m': xs, 'y_coordinates_m': ys, 'cells': cells, 'placed_sources': placed, 'dry_passes': dry_pass_records, 'convergence_history': moist_hist, 'input': __call__ (asdict, null, x)});
};
export var radial_layer_rth = function (rho_km_w, outer_d_m, inner_d_m) {
	if (arguments.length) {
		var __ilastarg0__ = arguments.length - 1;
		if (arguments [__ilastarg0__] && arguments [__ilastarg0__].hasOwnProperty ("__kwargtrans__")) {
			var __allkwargs0__ = arguments [__ilastarg0__--];
			for (var __attrib0__ in __allkwargs0__) {
				switch (__attrib0__) {
					case 'rho_km_w': var rho_km_w = __allkwargs0__ [__attrib0__]; break;
					case 'outer_d_m': var outer_d_m = __allkwargs0__ [__attrib0__]; break;
					case 'inner_d_m': var inner_d_m = __allkwargs0__ [__attrib0__]; break;
				}
			}
		}
	}
	else {
	}
	if (__t__ (__t__ (__le__ (rho_km_w, 0)) || __t__ (__le__ (outer_d_m, inner_d_m)) || __le__ (inner_d_m, 0))) {
		var __except0__ = __call__ (ValueError, null, 'Invalid radial-layer geometry/resistivity.');
		__except0__.__cause__ = null;
		throw __except0__;
	}
	return __mul__ (__truediv__ (rho_km_w, __mul__ (2.0, pi)), __call__ (log, null, __truediv__ (outer_d_m, inner_d_m)));
};
export var image_soil_rth = function (rho_km_w, center_depth_m, outside_d_m) {
	if (arguments.length) {
		var __ilastarg0__ = arguments.length - 1;
		if (arguments [__ilastarg0__] && arguments [__ilastarg0__].hasOwnProperty ("__kwargtrans__")) {
			var __allkwargs0__ = arguments [__ilastarg0__--];
			for (var __attrib0__ in __allkwargs0__) {
				switch (__attrib0__) {
					case 'rho_km_w': var rho_km_w = __allkwargs0__ [__attrib0__]; break;
					case 'center_depth_m': var center_depth_m = __allkwargs0__ [__attrib0__]; break;
					case 'outside_d_m': var outside_d_m = __allkwargs0__ [__attrib0__]; break;
				}
			}
		}
	}
	else {
	}
	if (__t__ (__t__ (__le__ (rho_km_w, 0)) || __t__ (__le__ (outside_d_m, 0)) || __le__ (center_depth_m, __truediv__ (outside_d_m, 2.0)))) {
		var __except0__ = __call__ (ValueError, null, 'Invalid soil image-method geometry/resistivity.');
		__except0__.__cause__ = null;
		throw __except0__;
	}
	var u = __truediv__ (__mul__ (2.0, center_depth_m), outside_d_m);
	return __mul__ (__truediv__ (rho_km_w, __mul__ (2.0, pi)), __call__ (log, null, __add__ (u, __call__ (sqrt, null, __sub__ (__mul__ (u, u), 1.0)))));
};
export var conduit_t4 = function (cable_od_m, duct_id_m, duct_od_m, wall_rho, fill_rho, soil_rho, center_depth_m, group_multiplier) {
	if (typeof group_multiplier == 'undefined' || (group_multiplier != null && group_multiplier.hasOwnProperty ("__kwargtrans__"))) {;
		var group_multiplier = 1.0;
	};
	if (arguments.length) {
		var __ilastarg0__ = arguments.length - 1;
		if (arguments [__ilastarg0__] && arguments [__ilastarg0__].hasOwnProperty ("__kwargtrans__")) {
			var __allkwargs0__ = arguments [__ilastarg0__--];
			for (var __attrib0__ in __allkwargs0__) {
				switch (__attrib0__) {
					case 'cable_od_m': var cable_od_m = __allkwargs0__ [__attrib0__]; break;
					case 'duct_id_m': var duct_id_m = __allkwargs0__ [__attrib0__]; break;
					case 'duct_od_m': var duct_od_m = __allkwargs0__ [__attrib0__]; break;
					case 'wall_rho': var wall_rho = __allkwargs0__ [__attrib0__]; break;
					case 'fill_rho': var fill_rho = __allkwargs0__ [__attrib0__]; break;
					case 'soil_rho': var soil_rho = __allkwargs0__ [__attrib0__]; break;
					case 'center_depth_m': var center_depth_m = __allkwargs0__ [__attrib0__]; break;
					case 'group_multiplier': var group_multiplier = __allkwargs0__ [__attrib0__]; break;
				}
			}
		}
	}
	else {
	}
	var fill = __call__ (radial_layer_rth, null, fill_rho, duct_id_m, cable_od_m);
	var wall = __call__ (radial_layer_rth, null, wall_rho, duct_od_m, duct_id_m);
	var soil = __call__ (image_soil_rth, null, soil_rho, center_depth_m, duct_od_m);
	var t4 = __mul__ (__add__ (__add__ (fill, wall), soil), group_multiplier);
	return dict ({'fill_rth': fill, 'wall_rth': wall, 'soil_rth': soil, 't4_km_w': t4});
};
export var hdd_t4 = function (cable_od_m, casing_id_m, casing_od_m, wall_rho, fill_rho, soil_rho, center_depth_m) {
	if (arguments.length) {
		var __ilastarg0__ = arguments.length - 1;
		if (arguments [__ilastarg0__] && arguments [__ilastarg0__].hasOwnProperty ("__kwargtrans__")) {
			var __allkwargs0__ = arguments [__ilastarg0__--];
			for (var __attrib0__ in __allkwargs0__) {
				switch (__attrib0__) {
					case 'cable_od_m': var cable_od_m = __allkwargs0__ [__attrib0__]; break;
					case 'casing_id_m': var casing_id_m = __allkwargs0__ [__attrib0__]; break;
					case 'casing_od_m': var casing_od_m = __allkwargs0__ [__attrib0__]; break;
					case 'wall_rho': var wall_rho = __allkwargs0__ [__attrib0__]; break;
					case 'fill_rho': var fill_rho = __allkwargs0__ [__attrib0__]; break;
					case 'soil_rho': var soil_rho = __allkwargs0__ [__attrib0__]; break;
					case 'center_depth_m': var center_depth_m = __allkwargs0__ [__attrib0__]; break;
				}
			}
		}
	}
	else {
	}
	var fill = __call__ (radial_layer_rth, null, fill_rho, casing_id_m, cable_od_m);
	var wall = __call__ (radial_layer_rth, null, wall_rho, casing_od_m, casing_id_m);
	var soil = __call__ (image_soil_rth, null, soil_rho, center_depth_m, casing_od_m);
	return dict ({'fill_rth': fill, 'wall_rth': wall, 'soil_rth': soil, 't4_km_w': __add__ (__add__ (fill, wall), soil)});
};
export var crossing_handoff = function (crossing) {
	if (arguments.length) {
		var __ilastarg0__ = arguments.length - 1;
		if (arguments [__ilastarg0__] && arguments [__ilastarg0__].hasOwnProperty ("__kwargtrans__")) {
			var __allkwargs0__ = arguments [__ilastarg0__--];
			for (var __attrib0__ in __allkwargs0__) {
				switch (__attrib0__) {
					case 'crossing': var crossing = __allkwargs0__ [__attrib0__]; break;
				}
			}
		}
	}
	else {
	}
	var c = __t__ (crossing) || dict ({});
	var active = __call__ (bool, null, (function () {
		var __accu0__ = c;
		return __call__ (__accu0__.py_get, __accu0__, 'active', false);
	}) ());
	if (__t__ (__t__ (!__t__ ((active))) || __eq__ ((function () {
		var __accu0__ = __call__ (str, null, (function () {
			var __accu1__ = c;
			return __call__ (__accu1__.py_get, __accu1__, 'method', 'NONE');
		}) ());
		return __call__ (__accu0__.upper, __accu0__);
	}) (), 'NONE'))) {
		return dict ({'status': 'PASS', 'delta_t_c': 0.0, 'rating_factor': 1.0, 'warning': 'No crossing penalty.'});
	}
	var method = (function () {
		var __accu0__ = __call__ (str, null, __t__ ((function () {
			var __accu1__ = c;
			return __call__ (__accu1__.py_get, __accu1__, 'method');
		}) ()) || '');
		return __call__ (__accu0__.upper, __accu0__);
	}) ();
	var delta = __call__ (float, null, __t__ ((function () {
		var __accu0__ = c;
		return __call__ (__accu0__.py_get, __accu0__, 'delta_t_c');
	}) ()) || 0.0);
	var factor = __call__ (float, null, __t__ ((function () {
		var __accu0__ = c;
		return __call__ (__accu0__.py_get, __accu0__, 'rating_factor');
	}) ()) || 1.0);
	var source = (function () {
		var __accu0__ = __call__ (str, null, __t__ ((function () {
			var __accu1__ = c;
			return __call__ (__accu1__.py_get, __accu1__, 'source');
		}) ()) || '');
		return __call__ (__accu0__.strip, __accu0__);
	}) ();
	if (__t__ (__eq__ (method, 'IEC 60287-3-3 REQUIRED'))) {
		return dict ({'status': 'REVIEW REQUIRED', 'delta_t_c': 0.0, 'rating_factor': 1.0, 'warning': 'Obtain an approved IEC 60287-3-3 or numerical crossing result.'});
	}
	if (__t__ (!__t__ ((source)))) {
		return dict ({'status': 'INPUT REQUIRED', 'delta_t_c': delta, 'rating_factor': factor, 'warning': 'Verified crossing inputs require a source/study reference.'});
	}
	if (__t__ (__t__ (__lt__ (delta, 0)) || !__t__ (((__lt__ (0, factor) && __le__ (factor, 1.0)))))) {
		return dict ({'status': 'INPUT REQUIRED', 'delta_t_c': delta, 'rating_factor': factor, 'warning': 'Crossing ΔT must be >=0 and rating factor must be >0 and <=1.'});
	}
	if (__t__ (__eq__ (method, 'VERIFIED DELTA-T'))) {
		return dict ({'status': 'PASS', 'delta_t_c': delta, 'rating_factor': 1.0, 'warning': 'Verified crossing ΔT applied.', 'source': source});
	}
	if (__t__ (__eq__ (method, 'VERIFIED RATING FACTOR'))) {
		return dict ({'status': 'REVIEW REQUIRED', 'delta_t_c': 0.0, 'rating_factor': factor, 'warning': 'Rating factor alone does not reproduce local conductor temperature; review required.', 'source': source});
	}
	if (__t__ (__eq__ (method, 'VERIFIED BOTH'))) {
		return dict ({'status': 'PASS', 'delta_t_c': delta, 'rating_factor': factor, 'warning': 'Verified crossing ΔT and rating factor applied.', 'source': source});
	}
	return dict ({'status': 'INPUT REQUIRED', 'delta_t_c': delta, 'rating_factor': factor, 'warning': 'Unsupported crossing method: {}'.format (method)});
};
export var hdd_handoff = function (hdd, cable_od_m) {
	if (arguments.length) {
		var __ilastarg0__ = arguments.length - 1;
		if (arguments [__ilastarg0__] && arguments [__ilastarg0__].hasOwnProperty ("__kwargtrans__")) {
			var __allkwargs0__ = arguments [__ilastarg0__--];
			for (var __attrib0__ in __allkwargs0__) {
				switch (__attrib0__) {
					case 'hdd': var hdd = __allkwargs0__ [__attrib0__]; break;
					case 'cable_od_m': var cable_od_m = __allkwargs0__ [__attrib0__]; break;
				}
			}
		}
	}
	else {
	}
	var h = __t__ (hdd) || dict ({});
	var active = __call__ (bool, null, (function () {
		var __accu0__ = h;
		return __call__ (__accu0__.py_get, __accu0__, 'active', false);
	}) ());
	var method = (function () {
		var __accu0__ = __call__ (str, null, (function () {
			var __accu1__ = h;
			return __call__ (__accu1__.py_get, __accu1__, 'method', 'NONE');
		}) ());
		return __call__ (__accu0__.upper, __accu0__);
	}) ();
	if (__t__ (__t__ (!__t__ ((active))) || __eq__ (method, 'NONE'))) {
		return dict ({'status': 'PASS', 't4_km_w': null, 'warning': 'No HDD/casing.'});
	}
	if (__t__ (__eq__ (method, 'VERIFIED T4'))) {
		var t4 = __call__ (float, null, __t__ ((function () {
			var __accu0__ = h;
			return __call__ (__accu0__.py_get, __accu0__, 'verified_t4_km_w');
		}) ()) || 0.0);
		var source = (function () {
			var __accu0__ = __call__ (str, null, __t__ ((function () {
				var __accu1__ = h;
				return __call__ (__accu1__.py_get, __accu1__, 'source');
			}) ()) || '');
			return __call__ (__accu0__.strip, __accu0__);
		}) ();
		if (__t__ (__t__ (__le__ (t4, 0)) || !__t__ ((source)))) {
			return dict ({'status': 'INPUT REQUIRED', 't4_km_w': null, 'warning': 'Verified HDD T4 requires a positive T4 and source/study reference.'});
		}
		return dict ({'status': 'PASS', 't4_km_w': t4, 'warning': 'Verified HDD T4 accepted.', 'source': source});
	}
	if (__t__ (__eq__ (method, 'SIMPLE SOLID-FILLED SINGLE CABLE'))) {
		try {
			var parts = __call__ (hdd_t4, null, __kwargtrans__ ({cable_od_m: __call__ (float, null, __t__ ((function () {
				var __accu0__ = h;
				return __call__ (__accu0__.py_get, __accu0__, 'cable_od_m');
			}) ()) || cable_od_m), casing_id_m: __call__ (float, null, (function () {
				var __accu0__ = h;
				return __call__ (__accu0__.py_get, __accu0__, 'casing_id_m');
			}) ()), casing_od_m: __call__ (float, null, (function () {
				var __accu0__ = h;
				return __call__ (__accu0__.py_get, __accu0__, 'casing_od_m');
			}) ()), wall_rho: __call__ (float, null, (function () {
				var __accu0__ = h;
				return __call__ (__accu0__.py_get, __accu0__, 'wall_rho_km_w');
			}) ()), fill_rho: __call__ (float, null, (function () {
				var __accu0__ = h;
				return __call__ (__accu0__.py_get, __accu0__, 'fill_rho_km_w');
			}) ()), soil_rho: __call__ (float, null, (function () {
				var __accu0__ = h;
				return __call__ (__accu0__.py_get, __accu0__, 'soil_rho_km_w');
			}) ()), center_depth_m: __call__ (float, null, (function () {
				var __accu0__ = h;
				return __call__ (__accu0__.py_get, __accu0__, 'center_depth_m');
			}) ())}));
		}
		catch (__except0__) {
			if (isinstance (__except0__, Exception)) {
				var e = __except0__;
				return dict ({'status': 'INPUT REQUIRED', 't4_km_w': null, 'warning': __call__ (str, null, e)});
			}
			else {
				throw __except0__;
			}
		}
		return __call__ (merge_dicts, null, dict ({'status': 'REVIEW REQUIRED'}), parts, dict ({'warning': 'Concentric solid-filled single-cable result is a screening calculation; verify for issued design.'}));
	}
	if (__t__ (__eq__ (method, 'AIR / MULTIDUCT / MULTICIRCUIT'))) {
		return dict ({'status': 'REVIEW REQUIRED', 't4_km_w': null, 'warning': 'Air-filled/multiduct/multicircuit casing requires verified T4/FDM/FEM.'});
	}
	return dict ({'status': 'INPUT REQUIRED', 't4_km_w': null, 'warning': 'Unsupported HDD method: {}'.format (method)});
};
export var solve_route = function (base, segments) {
	if (arguments.length) {
		var __ilastarg0__ = arguments.length - 1;
		if (arguments [__ilastarg0__] && arguments [__ilastarg0__].hasOwnProperty ("__kwargtrans__")) {
			var __allkwargs0__ = arguments [__ilastarg0__--];
			for (var __attrib0__ in __allkwargs0__) {
				switch (__attrib0__) {
					case 'base': var base = __allkwargs0__ [__attrib0__]; break;
					case 'segments': var segments = __allkwargs0__ [__attrib0__]; break;
				}
			}
		}
	}
	else {
	}
	var rows = [];
	var __iterable0__ = __call__ (list, null, __call__ (py_enumerate, null, segments, 1));
	for (var __index0__ = 0; __index0__ < len (__iterable0__); __index0__++) {
		var __left0__ = __getitem__ (__iterable0__, __index0__);
		var idx = __left0__ [0];
		var seg = __left0__ [1];
		var active = __call__ (bool, null, (function () {
			var __accu0__ = seg;
			return __call__ (__accu0__.py_get, __accu0__, 'active', true);
		}) ());
		var py_name = __call__ (str, null, __t__ ((function () {
			var __accu0__ = seg;
			return __call__ (__accu0__.py_get, __accu0__, 'name');
		}) ()) || __t__ ((function () {
			var __accu0__ = seg;
			return __call__ (__accu0__.py_get, __accu0__, 'segment_id');
		}) ()) || 'Segment {}'.format (idx));
		if (__t__ (!__t__ ((active)))) {
			(function () {
				var __accu0__ = rows;
				return __call__ (__accu0__.append, __accu0__, dict ({'index': idx, 'name': py_name, 'status': 'INACTIVE', 'final_status': 'INACTIVE'}));
			}) ();
			continue;
		}
		var x = __call__ (ThermalInput, null, __kwargtrans__ (__call__ (asdict, null, base)));
		x.load_a = __call__ (float, null, (function () {
			var __accu0__ = seg;
			return __call__ (__accu0__.py_get, __accu0__, 'load_a', x.load_a);
		}) ());
		x.ambient_c = __call__ (float, null, (function () {
			var __accu0__ = seg;
			return __call__ (__accu0__.py_get, __accu0__, 'ambient_c', x.ambient_c);
		}) ());
		x.soil_rho_km_w = __call__ (float, null, (function () {
			var __accu0__ = seg;
			return __call__ (__accu0__.py_get, __accu0__, 'soil_rho_km_w', x.soil_rho_km_w);
		}) ());
		x.burial_depth_m = __call__ (float, null, (function () {
			var __accu0__ = seg;
			return __call__ (__accu0__.py_get, __accu0__, 'burial_depth_m', x.burial_depth_m);
		}) ());
		x.group_multiplier = __call__ (float, null, (function () {
			var __accu0__ = seg;
			return __call__ (__accu0__.py_get, __accu0__, 'group_multiplier', x.group_multiplier);
		}) ());
		var install = (function () {
			var __accu0__ = __call__ (str, null, __t__ ((function () {
				var __accu1__ = seg;
				return __call__ (__accu1__.py_get, __accu1__, 'installation');
			}) ()) || 'DIRECT BURIED');
			return __call__ (__accu0__.upper, __accu0__);
		}) ();
		var raw_length_m = (function () {
			var __accu0__ = seg;
			return __call__ (__accu0__.py_get, __accu0__, 'length_m');
		}) ();
		var raw_length_ft = (function () {
			var __accu0__ = seg;
			return __call__ (__accu0__.py_get, __accu0__, 'length_ft');
		}) ();
		if (__t__ (!__in__ (raw_length_m, tuple ([null, ''])))) {
			var length_m = __call__ (float, null, raw_length_m);
			var length_ft = (__t__ (!__in__ (raw_length_ft, tuple ([null, '']))) ? __call__ (float, null, raw_length_ft) : __truediv__ (length_m, 0.3048));
		}
		else if (__t__ (!__in__ (raw_length_ft, tuple ([null, ''])))) {
			var length_ft = __call__ (float, null, raw_length_ft);
			var length_m = __mul__ (length_ft, 0.3048);
		}
		else {
			var length_m = 0.0;
			var length_ft = 0.0;
		}
		var cross = __call__ (crossing_handoff, null, (function () {
			var __accu0__ = seg;
			return __call__ (__accu0__.py_get, __accu0__, 'crossing');
		}) ());
		x.ambient_c = __call__ (__iadd__, null, x.ambient_c, __call__ (float, null, __t__ ((function () {
			var __accu0__ = cross;
			return __call__ (__accu0__.py_get, __accu0__, 'delta_t_c');
		}) ()) || 0.0));
		var t4_override = null;
		var install_gate = 'PASS';
		var install_warning = '';
		var t4_details = dict ({});
		try {
			if (__t__ (__eq__ (install, 'DIRECT BURIED'))) {
				// pass;
			}
			else if (__t__ (__in__ (install, new set (['CONDUIT', 'CONDUIT SOLID-FILLED'])))) {
				var t4_details = __call__ (conduit_t4, null, __kwargtrans__ ({cable_od_m: x.cable_od_m, duct_id_m: __call__ (float, null, (function () {
					var __accu0__ = seg;
					return __call__ (__accu0__.py_get, __accu0__, 'duct_id_m');
				}) ()), duct_od_m: __call__ (float, null, (function () {
					var __accu0__ = seg;
					return __call__ (__accu0__.py_get, __accu0__, 'duct_od_m');
				}) ()), wall_rho: __call__ (float, null, (function () {
					var __accu0__ = seg;
					return __call__ (__accu0__.py_get, __accu0__, 'duct_wall_rho_km_w');
				}) ()), fill_rho: __call__ (float, null, (function () {
					var __accu0__ = seg;
					return __call__ (__accu0__.py_get, __accu0__, 'solid_fill_rho_km_w');
				}) ()), soil_rho: x.soil_rho_km_w, center_depth_m: x.burial_depth_m, group_multiplier: __call__ (float, null, (function () {
					var __accu0__ = seg;
					return __call__ (__accu0__.py_get, __accu0__, 'conduit_group_multiplier', x.group_multiplier);
				}) ())}));
				var t4_override = __getitem__ (t4_details, 't4_km_w');
				var install_gate = 'REVIEW REQUIRED';
				var install_warning = 'Solid-filled conduit analytical result is screening unless project geometry/method is verified.';
			}
			else if (__t__ (__in__ (install, new set (['VERIFIED / FDM T4', 'VERIFIED T4'])))) {
				var t4_override = __call__ (float, null, __t__ ((function () {
					var __accu0__ = seg;
					return __call__ (__accu0__.py_get, __accu0__, 'verified_t4_km_w');
				}) ()) || 0.0);
				if (__t__ (__t__ (__le__ (t4_override, 0)) || !__t__ (((function () {
					var __accu0__ = __call__ (str, null, __t__ ((function () {
						var __accu1__ = seg;
						return __call__ (__accu1__.py_get, __accu1__, 't4_source');
					}) ()) || '');
					return __call__ (__accu0__.strip, __accu0__);
				}) ())))) {
					var install_gate = 'INPUT REQUIRED';
					var install_warning = 'Verified/FDM T4 requires a positive T4 and source.';
				}
			}
			else if (__t__ (__in__ (install, new set (['HDD / CASING', 'HDD', 'CASING'])))) {
				var hh = __call__ (hdd_handoff, null, (function () {
					var __accu0__ = seg;
					return __call__ (__accu0__.py_get, __accu0__, 'hdd');
				}) (), x.cable_od_m);
				var t4_override = (function () {
					var __accu0__ = hh;
					return __call__ (__accu0__.py_get, __accu0__, 't4_km_w');
				}) ();
				var install_gate = __getitem__ (hh, 'status');
				var install_warning = (function () {
					var __accu0__ = hh;
					return __call__ (__accu0__.py_get, __accu0__, 'warning', '');
				}) ();
				var t4_details = hh;
			}
			else {
				var install_gate = 'INPUT REQUIRED';
				var install_warning = 'Unsupported installation type: {}'.format (install);
			}
		}
		catch (__except0__) {
			if (isinstance (__except0__, Exception)) {
				var e = __except0__;
				var install_gate = 'INPUT REQUIRED';
				var install_warning = __call__ (str, null, e);
			}
			else {
				throw __except0__;
			}
		}
		if (__t__ (__t__ (t4_override !== null) && __gt__ (t4_override, 0))) {
			var x1 = __call__ (ThermalInput, null, __kwargtrans__ (__call__ (asdict, null, x)));
			x1.group_multiplier = 1.0;
			var isolated = __call__ (external_t4, null, x1);
			x.group_multiplier = (__t__ (__gt__ (isolated, 0)) ? __truediv__ (t4_override, isolated) : 1.0);
		}
		var result = __call__ (solve_steady, null, x);
		var amp_before = (function () {
			var __accu0__ = result;
			return __call__ (__accu0__.py_get, __accu0__, 'ampacity_a');
		}) ();
		var factor = __call__ (float, null, __t__ ((function () {
			var __accu0__ = cross;
			return __call__ (__accu0__.py_get, __accu0__, 'rating_factor');
		}) ()) || 1.0);
		var final_ampacity = (__t__ (__call__ (isinstance, null, amp_before, tuple ([int, float]))) ? __mul__ (amp_before, factor) : null);
		var utilization = (__t__ (__t__ (final_ampacity) && __gt__ (final_ampacity, 0)) ? __truediv__ (x.load_a, final_ampacity) : (function () {
			var __accu0__ = result;
			return __call__ (__accu0__.py_get, __accu0__, 'utilization');
		}) ());
		var gates = [install_gate, (function () {
			var __accu0__ = cross;
			return __call__ (__accu0__.py_get, __accu0__, 'status', 'PASS');
		}) ()];
		var short_transition = __t__ (__gt__ (length_ft, 0)) && __lt__ (length_ft, 50);
		if (__t__ (short_transition)) {
			(function () {
				var __accu0__ = gates;
				return __call__ (__accu0__.append, __accu0__, 'REVIEW REQUIRED');
			}) ();
		}
		if (__t__ (__eq__ ((function () {
			var __accu0__ = result;
			return __call__ (__accu0__.py_get, __accu0__, 'status');
		}) (), 'FAIL'))) {
			var final_status = 'FAIL';
		}
		else if (__t__ (__t__ (__call__ (any, null, (function () {
			var __accu0__ = [];
			var __iterable1__ = __call__ (list, null, gates);
			for (var __index1__ = 0; __index1__ < len (__iterable1__); __index1__++) {
				var g = __getitem__ (__iterable1__, __index1__);
				(function () {
					var __accu1__ = __accu0__;
					return __call__ (__accu1__.append, __accu1__, __eq__ (g, 'INPUT REQUIRED'));
				}) ();
			}
			return py_iter (__accu0__);
		}) ())) || __eq__ ((function () {
			var __accu0__ = result;
			return __call__ (__accu0__.py_get, __accu0__, 'status');
		}) (), 'INPUT REQUIRED'))) {
			var final_status = 'INPUT REQUIRED';
		}
		else if (__t__ (__t__ (__call__ (any, null, (function () {
			var __accu0__ = [];
			var __iterable1__ = __call__ (list, null, gates);
			for (var __index1__ = 0; __index1__ < len (__iterable1__); __index1__++) {
				var g = __getitem__ (__iterable1__, __index1__);
				(function () {
					var __accu1__ = __accu0__;
					return __call__ (__accu1__.append, __accu1__, __eq__ (g, 'REVIEW REQUIRED'));
				}) ();
			}
			return py_iter (__accu0__);
		}) ())) || __eq__ ((function () {
			var __accu0__ = result;
			return __call__ (__accu0__.py_get, __accu0__, 'status');
		}) (), 'REVIEW REQUIRED'))) {
			var final_status = 'REVIEW REQUIRED';
		}
		else {
			var final_status = (__t__ (__t__ (utilization !== null) && __le__ (utilization, 1)) ? 'PASS' : 'FAIL');
		}
		(function () {
			var __accu0__ = rows;
			return __call__ (__accu0__.append, __accu0__, dict ({'index': idx, 'name': py_name, 'description': (function () {
				var __accu1__ = seg;
				return __call__ (__accu1__.py_get, __accu1__, 'description', '');
			}) (), 'active': true, 'installation': install, 'length_m': length_m, 'length_ft': length_ft, 'load_a': x.load_a, 'ambient_effective_c': x.ambient_c, 't4_used_km_w': (function () {
				var __accu1__ = result;
				return __call__ (__accu1__.py_get, __accu1__, 't4_km_w');
			}) (), 'ampacity_before_factor_a': amp_before, 'crossing_rating_factor': factor, 'final_ampacity_a': final_ampacity, 'conductor_temp_c': (function () {
				var __accu1__ = result;
				return __call__ (__accu1__.py_get, __accu1__, 'conductor_temp_c');
			}) (), 'temperature_margin_c': (function () {
				var __accu1__ = result;
				return __call__ (__accu1__.py_get, __accu1__, 'temperature_margin_c');
			}) (), 'utilization': utilization, 'base_status': (function () {
				var __accu1__ = result;
				return __call__ (__accu1__.py_get, __accu1__, 'status');
			}) (), 'install_gate': install_gate, 'crossing_gate': (function () {
				var __accu1__ = cross;
				return __call__ (__accu1__.py_get, __accu1__, 'status');
			}) (), 'short_transition_review': short_transition, 'final_status': final_status, 'installation_warning': install_warning, 'crossing_warning': (function () {
				var __accu1__ = cross;
				return __call__ (__accu1__.py_get, __accu1__, 'warning', '');
			}) (), 't4_details': t4_details}));
		}) ();
	}
	var active = (function () {
		var __accu0__ = [];
		var __iterable0__ = __call__ (list, null, rows);
		for (var __index0__ = 0; __index0__ < len (__iterable0__); __index0__++) {
			var r = __getitem__ (__iterable0__, __index0__);
			if (__t__ (__ne__ ((function () {
				var __accu1__ = r;
				return __call__ (__accu1__.py_get, __accu1__, 'final_status');
			}) (), 'INACTIVE'))) {
				(function () {
					var __accu1__ = __accu0__;
					return __call__ (__accu1__.append, __accu1__, r);
				}) ();
			}
		}
		return __accu0__;
	}) ();
	var valid_amp = (function () {
		var __accu0__ = [];
		var __iterable0__ = __call__ (list, null, active);
		for (var __index0__ = 0; __index0__ < len (__iterable0__); __index0__++) {
			var r = __getitem__ (__iterable0__, __index0__);
			if (__t__ (__call__ (isinstance, null, (function () {
				var __accu1__ = r;
				return __call__ (__accu1__.py_get, __accu1__, 'final_ampacity_a');
			}) (), tuple ([int, float])))) {
				(function () {
					var __accu1__ = __accu0__;
					return __call__ (__accu1__.append, __accu1__, r);
				}) ();
			}
		}
		return __accu0__;
	}) ();
	var valid_temp = (function () {
		var __accu0__ = [];
		var __iterable0__ = __call__ (list, null, active);
		for (var __index0__ = 0; __index0__ < len (__iterable0__); __index0__++) {
			var r = __getitem__ (__iterable0__, __index0__);
			if (__t__ (__call__ (isinstance, null, (function () {
				var __accu1__ = r;
				return __call__ (__accu1__.py_get, __accu1__, 'conductor_temp_c');
			}) (), tuple ([int, float])))) {
				(function () {
					var __accu1__ = __accu0__;
					return __call__ (__accu1__.append, __accu1__, r);
				}) ();
			}
		}
		return __accu0__;
	}) ();
	var governing = (__t__ (valid_amp) ? __call__ (min, null, valid_amp, __kwargtrans__ ({key: (function __lambda__ (r) {
		if (arguments.length) {
			var __ilastarg0__ = arguments.length - 1;
			if (arguments [__ilastarg0__] && arguments [__ilastarg0__].hasOwnProperty ("__kwargtrans__")) {
				var __allkwargs0__ = arguments [__ilastarg0__--];
				for (var __attrib0__ in __allkwargs0__) {
					switch (__attrib0__) {
						case 'r': var r = __allkwargs0__ [__attrib0__]; break;
					}
				}
			}
		}
		else {
		}
		return __getitem__ (r, 'final_ampacity_a');
	})})) : null);
	var hottest = (__t__ (valid_temp) ? __call__ (max, null, valid_temp, __kwargtrans__ ({key: (function __lambda__ (r) {
		if (arguments.length) {
			var __ilastarg0__ = arguments.length - 1;
			if (arguments [__ilastarg0__] && arguments [__ilastarg0__].hasOwnProperty ("__kwargtrans__")) {
				var __allkwargs0__ = arguments [__ilastarg0__--];
				for (var __attrib0__ in __allkwargs0__) {
					switch (__attrib0__) {
						case 'r': var r = __allkwargs0__ [__attrib0__]; break;
					}
				}
			}
		}
		else {
		}
		return __getitem__ (r, 'conductor_temp_c');
	})})) : null);
	var statuses = (function () {
		var __accu0__ = [];
		var __iterable0__ = __call__ (list, null, active);
		for (var __index0__ = 0; __index0__ < len (__iterable0__); __index0__++) {
			var r = __getitem__ (__iterable0__, __index0__);
			(function () {
				var __accu1__ = __accu0__;
				return __call__ (__accu1__.append, __accu1__, __getitem__ (r, 'final_status'));
			}) ();
		}
		return __accu0__;
	}) ();
	var overall = 'PASS';
	if (__t__ (__in__ ('FAIL', statuses))) {
		var overall = 'FAIL';
	}
	else if (__t__ (__in__ ('INPUT REQUIRED', statuses))) {
		var overall = 'INPUT REQUIRED';
	}
	else if (__t__ (__in__ ('REVIEW REQUIRED', statuses))) {
		var overall = 'REVIEW REQUIRED';
	}
	return dict ({'status': overall, 'release_label': 'ROUTE THERMAL SCREENING / VERIFY SPECIAL CROSSINGS, CASINGS AND SHORT TRANSITIONS', 'active_segments': __call__ (len, null, active), 'total_length_m': __call__ (sum, null, (function () {
		var __accu0__ = [];
		var __iterable0__ = __call__ (list, null, active);
		for (var __index0__ = 0; __index0__ < len (__iterable0__); __index0__++) {
			var r = __getitem__ (__iterable0__, __index0__);
			(function () {
				var __accu1__ = __accu0__;
				return __call__ (__accu1__.append, __accu1__, (function () {
					var __accu2__ = r;
					return __call__ (__accu2__.py_get, __accu2__, 'length_m', 0.0);
				}) ());
			}) ();
		}
		return py_iter (__accu0__);
	}) ()), 'governing_segment': governing, 'hottest_segment': hottest, 'segments': rows, 'status_counts': (function () {
		var __accu0__ = [];
		var __iterable0__ = __call__ (list, null, __call__ (sorted, null, __call__ (set, null, statuses)));
		for (var __index0__ = 0; __index0__ < len (__iterable0__); __index0__++) {
			var s = __getitem__ (__iterable0__, __index0__);
			(function () {
				var __accu1__ = __accu0__;
				return __call__ (__accu1__.append, __accu1__, [s, __call__ (count_items, null, statuses, s)]);
			}) ();
		}
		return dict (__accu0__);
	}) ()});
};
export var scenario_manager = function (base, scenarios) {
	if (arguments.length) {
		var __ilastarg0__ = arguments.length - 1;
		if (arguments [__ilastarg0__] && arguments [__ilastarg0__].hasOwnProperty ("__kwargtrans__")) {
			var __allkwargs0__ = arguments [__ilastarg0__--];
			for (var __attrib0__ in __allkwargs0__) {
				switch (__attrib0__) {
					case 'base': var base = __allkwargs0__ [__attrib0__]; break;
					case 'scenarios': var scenarios = __allkwargs0__ [__attrib0__]; break;
				}
			}
		}
	}
	else {
	}
	var rows = [];
	var __iterable0__ = __call__ (list, null, __call__ (py_enumerate, null, scenarios, 1));
	for (var __index0__ = 0; __index0__ < len (__iterable0__); __index0__++) {
		var __left0__ = __getitem__ (__iterable0__, __index0__);
		var i = __left0__ [0];
		var s = __left0__ [1];
		if (__t__ (!__t__ ((__call__ (bool, null, (function () {
			var __accu0__ = s;
			return __call__ (__accu0__.py_get, __accu0__, 'active', true);
		}) ()))))) {
			(function () {
				var __accu0__ = rows;
				return __call__ (__accu0__.append, __accu0__, dict ({'index': i, 'name': (function () {
					var __accu1__ = s;
					return __call__ (__accu1__.py_get, __accu1__, 'name', 'Scenario {}'.format (i));
				}) (), 'status': 'INACTIVE'}));
			}) ();
			continue;
		}
		var x = __call__ (ThermalInput, null, __kwargtrans__ (__call__ (asdict, null, base)));
		var __iterable1__ = __call__ (list, null, tuple (['load_a', 'ambient_c', 'soil_rho_km_w', 'burial_depth_m', 'group_multiplier']));
		for (var __index1__ = 0; __index1__ < len (__iterable1__); __index1__++) {
			var field = __getitem__ (__iterable1__, __index1__);
			if (__t__ ((function () {
				var __accu0__ = s;
				return __call__ (__accu0__.py_get, __accu0__, field);
			}) () !== null)) {
				__call__ (setattr, null, x, field, __call__ (float, null, __getitem__ (s, field)));
			}
		}
		var verified_t4 = (function () {
			var __accu0__ = s;
			return __call__ (__accu0__.py_get, __accu0__, 'verified_t4_km_w');
		}) ();
		if (__t__ (!__in__ (verified_t4, tuple ([null, '', 0, 0.0])))) {
			var tmp = __call__ (ThermalInput, null, __kwargtrans__ (__call__ (asdict, null, x)));
			tmp.group_multiplier = 1.0;
			var iso = __call__ (external_t4, null, tmp);
			x.group_multiplier = (__t__ (__gt__ (iso, 0)) ? __truediv__ (__call__ (float, null, verified_t4), iso) : 1.0);
		}
		var res = __call__ (solve_steady, null, x);
		(function () {
			var __accu0__ = rows;
			return __call__ (__accu0__.append, __accu0__, __call__ (merge_dicts, null, dict ({'index': i}), dict ({'name': (function () {
				var __accu1__ = s;
				return __call__ (__accu1__.py_get, __accu1__, 'name', 'Scenario {}'.format (i));
			}) ()}), dict ({'source': (function () {
				var __accu1__ = s;
				return __call__ (__accu1__.py_get, __accu1__, 'source');
			}) ()}), dict ({'note': (function () {
				var __accu1__ = s;
				return __call__ (__accu1__.py_get, __accu1__, 'note');
			}) ()}), res));
		}) ();
	}
	var active = (function () {
		var __accu0__ = [];
		var __iterable0__ = __call__ (list, null, rows);
		for (var __index0__ = 0; __index0__ < len (__iterable0__); __index0__++) {
			var r = __getitem__ (__iterable0__, __index0__);
			if (__t__ (__ne__ ((function () {
				var __accu1__ = r;
				return __call__ (__accu1__.py_get, __accu1__, 'status');
			}) (), 'INACTIVE'))) {
				(function () {
					var __accu1__ = __accu0__;
					return __call__ (__accu1__.append, __accu1__, r);
				}) ();
			}
		}
		return __accu0__;
	}) ();
	var worst_amp = __call__ (min, null, (function () {
		var __accu0__ = [];
		var __iterable0__ = __call__ (list, null, active);
		for (var __index0__ = 0; __index0__ < len (__iterable0__); __index0__++) {
			var r = __getitem__ (__iterable0__, __index0__);
			if (__t__ (__call__ (isinstance, null, (function () {
				var __accu1__ = r;
				return __call__ (__accu1__.py_get, __accu1__, 'ampacity_a');
			}) (), tuple ([int, float])))) {
				(function () {
					var __accu1__ = __accu0__;
					return __call__ (__accu1__.append, __accu1__, r);
				}) ();
			}
		}
		return py_iter (__accu0__);
	}) (), __kwargtrans__ ({key: (function __lambda__ (r) {
		if (arguments.length) {
			var __ilastarg0__ = arguments.length - 1;
			if (arguments [__ilastarg0__] && arguments [__ilastarg0__].hasOwnProperty ("__kwargtrans__")) {
				var __allkwargs0__ = arguments [__ilastarg0__--];
				for (var __attrib0__ in __allkwargs0__) {
					switch (__attrib0__) {
						case 'r': var r = __allkwargs0__ [__attrib0__]; break;
					}
				}
			}
		}
		else {
		}
		return __getitem__ (r, 'ampacity_a');
	}), py_default: null}));
	var hottest = __call__ (max, null, (function () {
		var __accu0__ = [];
		var __iterable0__ = __call__ (list, null, active);
		for (var __index0__ = 0; __index0__ < len (__iterable0__); __index0__++) {
			var r = __getitem__ (__iterable0__, __index0__);
			if (__t__ (__call__ (isinstance, null, (function () {
				var __accu1__ = r;
				return __call__ (__accu1__.py_get, __accu1__, 'conductor_temp_c');
			}) (), tuple ([int, float])))) {
				(function () {
					var __accu1__ = __accu0__;
					return __call__ (__accu1__.append, __accu1__, r);
				}) ();
			}
		}
		return py_iter (__accu0__);
	}) (), __kwargtrans__ ({key: (function __lambda__ (r) {
		if (arguments.length) {
			var __ilastarg0__ = arguments.length - 1;
			if (arguments [__ilastarg0__] && arguments [__ilastarg0__].hasOwnProperty ("__kwargtrans__")) {
				var __allkwargs0__ = arguments [__ilastarg0__--];
				for (var __attrib0__ in __allkwargs0__) {
					switch (__attrib0__) {
						case 'r': var r = __allkwargs0__ [__attrib0__]; break;
					}
				}
			}
		}
		else {
		}
		return __getitem__ (r, 'conductor_temp_c');
	}), py_default: null}));
	return dict ({'rows': rows, 'lowest_ampacity_scenario': worst_amp, 'hottest_scenario': hottest});
};
export var thermal_optimizer = function (base, soil_rhos, ambients_c, depths_m, group_factors, load_a, min_margin_c, max_utilization) {
	if (typeof group_factors == 'undefined' || (group_factors != null && group_factors.hasOwnProperty ("__kwargtrans__"))) {;
		var group_factors = null;
	};
	if (typeof load_a == 'undefined' || (load_a != null && load_a.hasOwnProperty ("__kwargtrans__"))) {;
		var load_a = null;
	};
	if (typeof min_margin_c == 'undefined' || (min_margin_c != null && min_margin_c.hasOwnProperty ("__kwargtrans__"))) {;
		var min_margin_c = 0.0;
	};
	if (typeof max_utilization == 'undefined' || (max_utilization != null && max_utilization.hasOwnProperty ("__kwargtrans__"))) {;
		var max_utilization = 1.0;
	};
	if (arguments.length) {
		var __ilastarg0__ = arguments.length - 1;
		if (arguments [__ilastarg0__] && arguments [__ilastarg0__].hasOwnProperty ("__kwargtrans__")) {
			var __allkwargs0__ = arguments [__ilastarg0__--];
			for (var __attrib0__ in __allkwargs0__) {
				switch (__attrib0__) {
					case 'base': var base = __allkwargs0__ [__attrib0__]; break;
					case 'soil_rhos': var soil_rhos = __allkwargs0__ [__attrib0__]; break;
					case 'ambients_c': var ambients_c = __allkwargs0__ [__attrib0__]; break;
					case 'depths_m': var depths_m = __allkwargs0__ [__attrib0__]; break;
					case 'group_factors': var group_factors = __allkwargs0__ [__attrib0__]; break;
					case 'load_a': var load_a = __allkwargs0__ [__attrib0__]; break;
					case 'min_margin_c': var min_margin_c = __allkwargs0__ [__attrib0__]; break;
					case 'max_utilization': var max_utilization = __allkwargs0__ [__attrib0__]; break;
				}
			}
		}
	}
	else {
	}
	var group_factors = __t__ (group_factors) || [base.group_multiplier];
	var candidates = [];
	var baseline = dict ({'soil_rho_km_w': base.soil_rho_km_w, 'ambient_c': base.ambient_c, 'burial_depth_m': base.burial_depth_m, 'group_multiplier': base.group_multiplier});
	var __iterable0__ = __call__ (list, null, __call__ (py_enumerate, null, __call__ (product, null, soil_rhos, ambients_c, depths_m, group_factors), 1));
	for (var __index0__ = 0; __index0__ < len (__iterable0__); __index0__++) {
		var __left0__ = __getitem__ (__iterable0__, __index0__);
		var idx = __left0__ [0];
		var rho = __left0__ [1][0];
		var amb = __left0__ [1][1];
		var depth = __left0__ [1][2];
		var gf = __left0__ [1][3];
		var x = __call__ (ThermalInput, null, __kwargtrans__ (__call__ (asdict, null, base)));
		x.soil_rho_km_w = __call__ (float, null, rho);
		x.ambient_c = __call__ (float, null, amb);
		x.burial_depth_m = __call__ (float, null, depth);
		x.group_multiplier = __call__ (float, null, gf);
		if (__t__ (load_a !== null)) {
			x.load_a = __call__ (float, null, load_a);
		}
		var res = __call__ (solve_steady, null, x);
		var effort = __add__ (__add__ (__add__ (__truediv__ (__call__ (abs, null, __sub__ (x.soil_rho_km_w, __getitem__ (baseline, 'soil_rho_km_w'))), __call__ (max, null, __getitem__ (baseline, 'soil_rho_km_w'), 1e-09)), __truediv__ (__call__ (abs, null, __sub__ (x.ambient_c, __getitem__ (baseline, 'ambient_c'))), 10.0)), __truediv__ (__call__ (abs, null, __sub__ (x.burial_depth_m, __getitem__ (baseline, 'burial_depth_m'))), __call__ (max, null, __getitem__ (baseline, 'burial_depth_m'), 1e-09))), __truediv__ (__call__ (abs, null, __sub__ (x.group_multiplier, __getitem__ (baseline, 'group_multiplier'))), __call__ (max, null, __getitem__ (baseline, 'group_multiplier'), 1e-09)));
		var feasible = __t__ (__eq__ ((function () {
			var __accu0__ = res;
			return __call__ (__accu0__.py_get, __accu0__, 'status');
		}) (), 'PASS')) && __t__ (__ge__ ((function () {
			var __accu0__ = res;
			return __call__ (__accu0__.py_get, __accu0__, 'temperature_margin_c', __neg__ (1000000000.0));
		}) (), min_margin_c)) && __le__ ((function () {
			var __accu0__ = res;
			return __call__ (__accu0__.py_get, __accu0__, 'utilization', 1000000000.0);
		}) (), max_utilization);
		(function () {
			var __accu0__ = candidates;
			return __call__ (__accu0__.append, __accu0__, __call__ (merge_dicts, null, dict ({'candidate': 'OPT-{}'.format (idx)}), dict ({'soil_rho_km_w': rho}), dict ({'ambient_c': amb}), dict ({'burial_depth_m': depth}), dict ({'group_multiplier': gf}), dict ({'effort_index': effort}), dict ({'feasible': feasible}), res));
		}) ();
	}
	var feasible_rows = (function () {
		var __accu0__ = [];
		var __iterable0__ = __call__ (list, null, candidates);
		for (var __index0__ = 0; __index0__ < len (__iterable0__); __index0__++) {
			var c = __getitem__ (__iterable0__, __index0__);
			if (__t__ (__getitem__ (c, 'feasible'))) {
				(function () {
					var __accu1__ = __accu0__;
					return __call__ (__accu1__.append, __accu1__, c);
				}) ();
			}
		}
		return __accu0__;
	}) ();
	var best = (__t__ (feasible_rows) ? __call__ (min, null, feasible_rows, __kwargtrans__ ({key: (function __lambda__ (c) {
		if (arguments.length) {
			var __ilastarg0__ = arguments.length - 1;
			if (arguments [__ilastarg0__] && arguments [__ilastarg0__].hasOwnProperty ("__kwargtrans__")) {
				var __allkwargs0__ = arguments [__ilastarg0__--];
				for (var __attrib0__ in __allkwargs0__) {
					switch (__attrib0__) {
						case 'c': var c = __allkwargs0__ [__attrib0__]; break;
					}
				}
			}
		}
		else {
		}
		return tuple ([__getitem__ (c, 'effort_index'), __neg__ ((function () {
			var __accu0__ = c;
			return __call__ (__accu0__.py_get, __accu0__, 'temperature_margin_c', __neg__ (1000000000.0));
		}) ())]);
	})})) : null);
	return dict ({'status': (__t__ (best) ? 'PASS' : 'REVIEW REQUIRED'), 'candidate_count': __call__ (len, null, candidates), 'passing_candidates': __call__ (len, null, feasible_rows), 'selected': best, 'candidates': candidates, 'note': 'Optimizer is decision support. Re-run the selected physical design in the detailed thermal engine.'});
};
export var duct_position_optimizer = function (ducts, cable_count, min_spacing_m) {
	if (typeof cable_count == 'undefined' || (cable_count != null && cable_count.hasOwnProperty ("__kwargtrans__"))) {;
		var cable_count = 3;
	};
	if (typeof min_spacing_m == 'undefined' || (min_spacing_m != null && min_spacing_m.hasOwnProperty ("__kwargtrans__"))) {;
		var min_spacing_m = 0.0;
	};
	if (arguments.length) {
		var __ilastarg0__ = arguments.length - 1;
		if (arguments [__ilastarg0__] && arguments [__ilastarg0__].hasOwnProperty ("__kwargtrans__")) {
			var __allkwargs0__ = arguments [__ilastarg0__--];
			for (var __attrib0__ in __allkwargs0__) {
				switch (__attrib0__) {
					case 'ducts': var ducts = __allkwargs0__ [__attrib0__]; break;
					case 'cable_count': var cable_count = __allkwargs0__ [__attrib0__]; break;
					case 'min_spacing_m': var min_spacing_m = __allkwargs0__ [__attrib0__]; break;
				}
			}
		}
	}
	else {
	}
	var available = (function () {
		var __accu0__ = [];
		var __iterable0__ = __call__ (list, null, ducts);
		for (var __index0__ = 0; __index0__ < len (__iterable0__); __index0__++) {
			var d = __getitem__ (__iterable0__, __index0__);
			if (__t__ (__call__ (bool, null, (function () {
				var __accu1__ = d;
				return __call__ (__accu1__.py_get, __accu1__, 'available', true);
			}) ()))) {
				(function () {
					var __accu1__ = __accu0__;
					return __call__ (__accu1__.append, __accu1__, d);
				}) ();
			}
		}
		return __accu0__;
	}) ();
	if (__t__ (__t__ (__lt__ (cable_count, 1)) || __gt__ (cable_count, __call__ (len, null, available)))) {
		return dict ({'status': 'INPUT REQUIRED', 'issues': ['Cable count must be between 1 and the number of available duct positions.']});
	}
	var rows = [];
	var __iterable0__ = __call__ (list, null, __call__ (py_enumerate, null, __call__ (combinations, null, available, cable_count), 1));
	for (var __index0__ = 0; __index0__ < len (__iterable0__); __index0__++) {
		var __left0__ = __getitem__ (__iterable0__, __index0__);
		var idx = __left0__ [0];
		var combo = __left0__ [1];
		var pair_distances = [];
		var score = 0.0;
		var __iterable1__ = __call__ (list, null, __call__ (combinations, null, combo, 2));
		for (var __index1__ = 0; __index1__ < len (__iterable1__); __index1__++) {
			var __left0__ = __getitem__ (__iterable1__, __index1__);
			var a = __left0__ [0];
			var b = __left0__ [1];
			var d = __call__ (hypot, null, __sub__ (__call__ (float, null, __getitem__ (a, 'x_m')), __call__ (float, null, __getitem__ (b, 'x_m'))), __sub__ (__call__ (float, null, __getitem__ (a, 'y_m')), __call__ (float, null, __getitem__ (b, 'y_m'))));
			(function () {
				var __accu0__ = pair_distances;
				return __call__ (__accu0__.append, __accu0__, d);
			}) ();
			var score = __call__ (__iadd__, null, score, (__t__ (__gt__ (d, 0)) ? __truediv__ (1.0, d) : __call__ (float, null, 'inf')));
		}
		var min_d = (__t__ (pair_distances) ? __call__ (min, null, pair_distances) : __call__ (float, null, 'inf'));
		var eligible = __ge__ (min_d, min_spacing_m);
		(function () {
			var __accu0__ = rows;
			return __call__ (__accu0__.append, __accu0__, dict ({'combo': 'C{}'.format (idx), 'ducts': (function () {
				var __accu1__ = [];
				var __iterable1__ = __call__ (list, null, combo);
				for (var __index1__ = 0; __index1__ < len (__iterable1__); __index1__++) {
					var d = __getitem__ (__iterable1__, __index1__);
					(function () {
						var __accu2__ = __accu1__;
						return __call__ (__accu2__.append, __accu2__, __t__ ((function () {
							var __accu3__ = d;
							return __call__ (__accu3__.py_get, __accu3__, 'id');
						}) ()) || (function () {
							var __accu3__ = d;
							return __call__ (__accu3__.py_get, __accu3__, 'name');
						}) ());
					}) ();
				}
				return __accu1__;
			}) (), 'coupling_score': score, 'min_spacing_m': min_d, 'status': (__t__ (eligible) ? 'ELIGIBLE' : 'REJECTED')}));
		}) ();
	}
	var eligible_rows = (function () {
		var __accu0__ = [];
		var __iterable0__ = __call__ (list, null, rows);
		for (var __index0__ = 0; __index0__ < len (__iterable0__); __index0__++) {
			var r = __getitem__ (__iterable0__, __index0__);
			if (__t__ (__eq__ (__getitem__ (r, 'status'), 'ELIGIBLE'))) {
				(function () {
					var __accu1__ = __accu0__;
					return __call__ (__accu1__.append, __accu1__, r);
				}) ();
			}
		}
		return __accu0__;
	}) ();
	var best = (__t__ (eligible_rows) ? __call__ (min, null, eligible_rows, __kwargtrans__ ({key: (function __lambda__ (r) {
		if (arguments.length) {
			var __ilastarg0__ = arguments.length - 1;
			if (arguments [__ilastarg0__] && arguments [__ilastarg0__].hasOwnProperty ("__kwargtrans__")) {
				var __allkwargs0__ = arguments [__ilastarg0__--];
				for (var __attrib0__ in __allkwargs0__) {
					switch (__attrib0__) {
						case 'r': var r = __allkwargs0__ [__attrib0__]; break;
					}
				}
			}
		}
		else {
		}
		return tuple ([__getitem__ (r, 'coupling_score'), __neg__ (__getitem__ (r, 'min_spacing_m'))]);
	})})) : null);
	return dict ({'status': (__t__ (best) ? 'PASS' : 'REVIEW REQUIRED'), 'combinations': __call__ (len, null, rows), 'eligible_layouts': __call__ (len, null, eligible_rows), 'best': best, 'rows': rows, 'release_label': 'SCREENING ONLY — RE-RUN CHOSEN LAYOUT IN THE DETAILED IEC/FDM THERMAL ENGINE'});
};
export var default_3x3_ducts = function (spacing_m, center_depth_m) {
	if (typeof spacing_m == 'undefined' || (spacing_m != null && spacing_m.hasOwnProperty ("__kwargtrans__"))) {;
		var spacing_m = 0.2;
	};
	if (typeof center_depth_m == 'undefined' || (center_depth_m != null && center_depth_m.hasOwnProperty ("__kwargtrans__"))) {;
		var center_depth_m = 1.0;
	};
	if (arguments.length) {
		var __ilastarg0__ = arguments.length - 1;
		if (arguments [__ilastarg0__] && arguments [__ilastarg0__].hasOwnProperty ("__kwargtrans__")) {
			var __allkwargs0__ = arguments [__ilastarg0__--];
			for (var __attrib0__ in __allkwargs0__) {
				switch (__attrib0__) {
					case 'spacing_m': var spacing_m = __allkwargs0__ [__attrib0__]; break;
					case 'center_depth_m': var center_depth_m = __allkwargs0__ [__attrib0__]; break;
				}
			}
		}
	}
	else {
	}
	var out = [];
	var k = 1;
	var __iterable0__ = __call__ (list, null, tuple ([__sub__ (center_depth_m, spacing_m), center_depth_m, __add__ (center_depth_m, spacing_m)]));
	for (var __index0__ = 0; __index0__ < len (__iterable0__); __index0__++) {
		var y = __getitem__ (__iterable0__, __index0__);
		var __iterable1__ = __call__ (list, null, tuple ([__neg__ (spacing_m), 0.0, spacing_m]));
		for (var __index1__ = 0; __index1__ < len (__iterable1__); __index1__++) {
			var x = __getitem__ (__iterable1__, __index1__);
			(function () {
				var __accu0__ = out;
				return __call__ (__accu0__.append, __accu0__, dict ({'id': 'D{}'.format (k), 'x_m': x, 'y_m': y, 'available': true}));
			}) ();
			var k = __call__ (__iadd__, null, k, 1);
		}
	}
	return out;
};
export var Suite =  __class__ ('Suite', [object], {
	__module__: __name__,
	get __init__ () {return __get__ (this, function (self) {
		if (arguments.length) {
			var __ilastarg0__ = arguments.length - 1;
			if (arguments [__ilastarg0__] && arguments [__ilastarg0__].hasOwnProperty ("__kwargtrans__")) {
				var __allkwargs0__ = arguments [__ilastarg0__--];
				for (var __attrib0__ in __allkwargs0__) {
					switch (__attrib0__) {
						case 'self': var self = __allkwargs0__ [__attrib0__]; break;
					}
				}
			}
		}
		else {
		}
		self.rows = [];
	});},
	get add () {return __get__ (this, function (self, block, test, passed, calculated, criterion, note) {
		if (typeof calculated == 'undefined' || (calculated != null && calculated.hasOwnProperty ("__kwargtrans__"))) {;
			var calculated = null;
		};
		if (typeof criterion == 'undefined' || (criterion != null && criterion.hasOwnProperty ("__kwargtrans__"))) {;
			var criterion = '';
		};
		if (typeof note == 'undefined' || (note != null && note.hasOwnProperty ("__kwargtrans__"))) {;
			var note = '';
		};
		if (arguments.length) {
			var __ilastarg0__ = arguments.length - 1;
			if (arguments [__ilastarg0__] && arguments [__ilastarg0__].hasOwnProperty ("__kwargtrans__")) {
				var __allkwargs0__ = arguments [__ilastarg0__--];
				for (var __attrib0__ in __allkwargs0__) {
					switch (__attrib0__) {
						case 'self': var self = __allkwargs0__ [__attrib0__]; break;
						case 'block': var block = __allkwargs0__ [__attrib0__]; break;
						case 'test': var test = __allkwargs0__ [__attrib0__]; break;
						case 'passed': var passed = __allkwargs0__ [__attrib0__]; break;
						case 'calculated': var calculated = __allkwargs0__ [__attrib0__]; break;
						case 'criterion': var criterion = __allkwargs0__ [__attrib0__]; break;
						case 'note': var note = __allkwargs0__ [__attrib0__]; break;
					}
				}
			}
		}
		else {
		}
		(function () {
			var __accu0__ = self.rows;
			return __call__ (__accu0__.append, __accu0__, dict ({'id': __add__ (__call__ (len, null, self.rows), 1), 'block': block, 'test': test, 'status': (__t__ (passed) ? 'PASS' : 'FAIL'), 'calculated': calculated, 'criterion': criterion, 'note': note}));
		}) ();
	});}
});
export var _baseline = function () {
	if (arguments.length) {
		var __ilastarg0__ = arguments.length - 1;
		if (arguments [__ilastarg0__] && arguments [__ilastarg0__].hasOwnProperty ("__kwargtrans__")) {
			var __allkwargs0__ = arguments [__ilastarg0__--];
			for (var __attrib0__ in __allkwargs0__) {
			}
		}
	}
	else {
	}
	return __call__ (ThermalInput, null);
};
export var _root_ampacity = function (x) {
	if (arguments.length) {
		var __ilastarg0__ = arguments.length - 1;
		if (arguments [__ilastarg0__] && arguments [__ilastarg0__].hasOwnProperty ("__kwargtrans__")) {
			var __allkwargs0__ = arguments [__ilastarg0__--];
			for (var __attrib0__ in __allkwargs0__) {
				switch (__attrib0__) {
					case 'x': var x = __allkwargs0__ [__attrib0__]; break;
				}
			}
		}
	}
	else {
	}
	var __left0__ = tuple ([0.0, 100.0]);
	var lo = __left0__ [0];
	var hi = __left0__ [1];
	var temp_at = function (current) {
		if (arguments.length) {
			var __ilastarg0__ = arguments.length - 1;
			if (arguments [__ilastarg0__] && arguments [__ilastarg0__].hasOwnProperty ("__kwargtrans__")) {
				var __allkwargs0__ = arguments [__ilastarg0__--];
				for (var __attrib0__ in __allkwargs0__) {
					switch (__attrib0__) {
						case 'current': var current = __allkwargs0__ [__attrib0__]; break;
					}
				}
			}
		}
		else {
		}
		var xx = __call__ (ThermalInput, null, __kwargtrans__ (__call__ (asdict, null, x)));
		xx.load_a = current;
		return __call__ (float, null, (function () {
			var __accu0__ = __call__ (solve_steady, null, xx);
			return __call__ (__accu0__.py_get, __accu0__, 'conductor_temp_c', 1000000000.0);
		}) ());
	};
	while (__t__ (__t__ (__lt__ (__call__ (temp_at, null, hi), x.max_temp_c)) && __lt__ (hi, 10000))) {
		var hi = __call__ (__imul__, null, hi, 2);
	}
	var __iterable0__ = __call__ (list, null, __call__ (range, null, 80));
	for (var __index0__ = 0; __index0__ < len (__iterable0__); __index0__++) {
		var _ = __getitem__ (__iterable0__, __index0__);
		var mid = __truediv__ (__add__ (lo, hi), 2);
		if (__t__ (__gt__ (__call__ (temp_at, null, mid), x.max_temp_c))) {
			var hi = mid;
		}
		else {
			var lo = mid;
		}
	}
	return __truediv__ (__add__ (lo, hi), 2);
};
export var run_full_qa = function () {
	if (arguments.length) {
		var __ilastarg0__ = arguments.length - 1;
		if (arguments [__ilastarg0__] && arguments [__ilastarg0__].hasOwnProperty ("__kwargtrans__")) {
			var __allkwargs0__ = arguments [__ilastarg0__--];
			for (var __attrib0__ in __allkwargs0__) {
			}
		}
	}
	else {
	}
	var s = __call__ (Suite, null);
	var base = __call__ (_baseline, null);
	var b = __call__ (solve_steady, null, base);
	(function () {
		var __accu0__ = s;
		return __call__ (__accu0__.add, __accu0__, 'CORE_GOLDEN', 'Baseline status', __eq__ (__getitem__ (b, 'status'), 'PASS'), __getitem__ (b, 'status'), 'PASS');
	}) ();
	(function () {
		var __accu0__ = s;
		return __call__ (__accu0__.add, __accu0__, 'CORE_GOLDEN', 'Baseline ampacity', __lt__ (__call__ (abs, null, __sub__ (__getitem__ (b, 'ampacity_a'), 692.220438564634)), 1e-06), __getitem__ (b, 'ampacity_a'), '692.220438564634 ±1e-6 A');
	}) ();
	(function () {
		var __accu0__ = s;
		return __call__ (__accu0__.add, __accu0__, 'CORE_GOLDEN', 'Baseline conductor temperature', __lt__ (__call__ (abs, null, __sub__ (__getitem__ (b, 'conductor_temp_c'), 55.2079093061)), 1e-05), __getitem__ (b, 'conductor_temp_c'), '55.2079093061 ±1e-5 °C');
	}) ();
	(function () {
		var __accu0__ = s;
		return __call__ (__accu0__.add, __accu0__, 'CORE_GOLDEN', 'Baseline T4', __lt__ (__call__ (abs, null, __sub__ (__getitem__ (b, 't4_km_w'), 1.541570063174254)), 1e-09), __getitem__ (b, 't4_km_w'), '1.541570063174254');
	}) ();
	(function () {
		var __accu0__ = s;
		return __call__ (__accu0__.add, __accu0__, 'CORE_GOLDEN', 'Temperature margin', __lt__ (__call__ (abs, null, __sub__ (__getitem__ (b, 'temperature_margin_c'), __sub__ (90, __getitem__ (b, 'conductor_temp_c')))), 1e-10), __getitem__ (b, 'temperature_margin_c'), '90 - conductor temperature');
	}) ();
	(function () {
		var __accu0__ = s;
		return __call__ (__accu0__.add, __accu0__, 'CORE_GOLDEN', 'Utilization', __lt__ (__call__ (abs, null, __sub__ (__getitem__ (b, 'utilization'), __truediv__ (500, __getitem__ (b, 'ampacity_a')))), 1e-12), __getitem__ (b, 'utilization'), 'load/ampacity');
	}) ();
	(function () {
		var __accu0__ = s;
		return __call__ (__accu0__.add, __accu0__, 'CORE_GOLDEN', 'Positive heat', __gt__ (__getitem__ (b, 'total_heat_w_m'), 0), __getitem__ (b, 'total_heat_w_m'), '>0 W/m');
	}) ();
	(function () {
		var __accu0__ = s;
		return __call__ (__accu0__.add, __accu0__, 'CORE_GOLDEN', 'Adaptive convergence', __t__ (__getitem__ (b, 'converged')) && __gt__ (__getitem__ (b, 'iterations'), 0), __getitem__ (b, 'iterations'), 'converged');
	}) ();
	(function () {
		var __accu0__ = s;
		return __call__ (__accu0__.add, __accu0__, 'CORE_GOLDEN', 'Soil rho monotonic', __gt__ (__getitem__ (__call__ (solve_steady, null, __call__ (ThermalInput, null, __kwargtrans__ ({soil_rho_km_w: 0.6}))), 'ampacity_a'), __getitem__ (__call__ (solve_steady, null, __call__ (ThermalInput, null, __kwargtrans__ ({soil_rho_km_w: 2}))), 'ampacity_a')), null, 'ampacity(.6) > ampacity(2.0)');
	}) ();
	(function () {
		var __accu0__ = s;
		return __call__ (__accu0__.add, __accu0__, 'CORE_GOLDEN', 'Ambient monotonic', __gt__ (__getitem__ (__call__ (solve_steady, null, __call__ (ThermalInput, null, __kwargtrans__ ({ambient_c: 20}))), 'ampacity_a'), __getitem__ (__call__ (solve_steady, null, __call__ (ThermalInput, null, __kwargtrans__ ({ambient_c: 40}))), 'ampacity_a')), null, 'ampacity(20°C) > ampacity(40°C)');
	}) ();
	(function () {
		var __accu0__ = s;
		return __call__ (__accu0__.add, __accu0__, 'CORE_GOLDEN', 'Invalid physical input controlled', __eq__ (__getitem__ (__call__ (solve_steady, null, __call__ (ThermalInput, null, __kwargtrans__ ({soil_rho_km_w: __neg__ (1)}))), 'status'), 'INPUT REQUIRED'), null, 'INPUT REQUIRED');
	}) ();
	var checks = [tuple (['Higher group heating lowers ampacity', __gt__ (__getitem__ (__call__ (solve_steady, null, __call__ (ThermalInput, null, __kwargtrans__ ({group_multiplier: 1}))), 'ampacity_a'), __getitem__ (__call__ (solve_steady, null, __call__ (ThermalInput, null, __kwargtrans__ ({group_multiplier: 3}))), 'ampacity_a'))]), tuple (['Deeper burial lowers ampacity', __gt__ (__getitem__ (__call__ (solve_steady, null, __call__ (ThermalInput, null, __kwargtrans__ ({burial_depth_m: 0.6}))), 'ampacity_a'), __getitem__ (__call__ (solve_steady, null, __call__ (ThermalInput, null, __kwargtrans__ ({burial_depth_m: 1.5}))), 'ampacity_a'))]), tuple (['Higher load raises temperature', __gt__ (__getitem__ (__call__ (solve_steady, null, __call__ (ThermalInput, null, __kwargtrans__ ({load_a: 700}))), 'conductor_temp_c'), __getitem__ (__call__ (solve_steady, null, __call__ (ThermalInput, null, __kwargtrans__ ({load_a: 300}))), 'conductor_temp_c'))]), tuple (['Zero load remains near ambient', __lt__ (__call__ (abs, null, __sub__ (__getitem__ (__call__ (solve_steady, null, __call__ (ThermalInput, null, __kwargtrans__ ({load_a: 0}))), 'conductor_temp_c'), __add__ (25, __mul__ (__truediv__ (__getitem__ (b, 'dielectric_heat_total_w_m'), 3), __getitem__ (b, 'dielectric_r_factor_km_w'))))), 1e-05)]), tuple (['Rac rises with temperature', __gt__ (__call__ (rac_at_temp, null, base, 90), __call__ (rac_at_temp, null, base, 20))]), tuple (['External T4 positive', __gt__ (__call__ (external_t4, null, base), 0)]), tuple (['Bad burial controlled', __eq__ (__getitem__ (__call__ (solve_steady, null, __call__ (ThermalInput, null, __kwargtrans__ ({burial_depth_m: 0.01}))), 'status'), 'INPUT REQUIRED')]), tuple (['Ambient >= limit controlled', __eq__ (__getitem__ (__call__ (solve_steady, null, __call__ (ThermalInput, null, __kwargtrans__ ({ambient_c: 90}))), 'status'), 'INPUT REQUIRED')])];
	var __iterable0__ = __call__ (list, null, checks);
	for (var __index0__ = 0; __index0__ < len (__iterable0__); __index0__++) {
		var __left0__ = __getitem__ (__iterable0__, __index0__);
		var py_name = __left0__ [0];
		var passed = __left0__ [1];
		(function () {
			var __accu0__ = s;
			return __call__ (__accu0__.add, __accu0__, 'INVARIANT', py_name, __call__ (bool, null, passed), __kwargtrans__ ({criterion: 'physics/control invariant'}));
		}) ();
	}
	var p1 = __call__ (parallel_sharing, null, 500, 1, 'AUTO');
	var p2 = __call__ (parallel_sharing, null, 1000, 2, 'SYMMETRIC VERIFIED', __kwargtrans__ ({source: 'verified identical geometry'}));
	var p3 = __call__ (parallel_sharing, null, 1000, 2, 'MANUAL WORST-SET FACTOR', __kwargtrans__ ({worst_set_factor: 1.1, source: 'verified study'}));
	var p4 = __call__ (parallel_sharing, null, 1000, 2, 'VERIFIED SET CURRENTS', __kwargtrans__ ({set_currents_a: [530, 470], source: 'verified study'}));
	var p5 = __call__ (parallel_sharing, null, 1000, 2, 'VERIFIED SET CURRENTS', __kwargtrans__ ({set_currents_a: [600, 500], source: 'verified study'}));
	var tests2 = [tuple (['Single-set baseline', __t__ (__eq__ (__getitem__ (p1, 'status'), 'PASS')) && __lt__ (__call__ (abs, null, __sub__ (__getitem__ (p1, 'used_worst_set_current_a'), 500)), 1e-09)]), tuple (['Two sets symmetric verified', __t__ (__eq__ (__getitem__ (p2, 'status'), 'PASS')) && __lt__ (__call__ (abs, null, __sub__ (__getitem__ (p2, 'used_worst_set_current_a'), 500)), 1e-09)]), tuple (['Manual worst-set factor', __t__ (__eq__ (__getitem__ (p3, 'status'), 'PASS')) && __lt__ (__call__ (abs, null, __sub__ (__getitem__ (p3, 'i2r_heat_multiplier'), 1.21)), 1e-12)]), tuple (['Verified currents worst set', __t__ (__eq__ (__getitem__ (p4, 'status'), 'PASS')) && __lt__ (__call__ (abs, null, __sub__ (__getitem__ (p4, 'used_worst_set_current_a'), 530)), 1e-09)]), tuple (['Bad current sum fails', __eq__ (__getitem__ (p5, 'status'), 'FAIL')]), tuple (['IEC 60287-1-3 special case gates', __eq__ (__getitem__ (__call__ (metallic_loss_gate, null, __kwargtrans__ ({parallel_sets: 2, bonding: 'BOTH ENDS', lambda1_override: null, screen_r20_ohm_km: 1, sharing_status: 'PASS'})), 'status'), 'REVIEW REQUIRED')]), tuple (['IEC 60287-1-2 flat two-circuit case gates', __eq__ (__getitem__ (__call__ (metallic_loss_gate, null, __kwargtrans__ ({active_circuit_count: 2, arrangement: 'FLAT', bonding: 'SINGLE POINT', sharing_status: 'PASS'})), 'status'), 'REVIEW REQUIRED')]), tuple (['Magnetic armour needs lambda2', __eq__ (__getitem__ (__call__ (metallic_loss_gate, null, __kwargtrans__ ({bonding: 'SINGLE POINT', armour_model: 'MAGNETIC SINGLE-CORE'})), 'status'), 'INPUT REQUIRED')]), tuple (['Both-end missing screen R gates', __eq__ (__getitem__ (__call__ (metallic_loss_gate, null, __kwargtrans__ ({bonding: 'BOTH ENDS', lambda1_auto: 0.1, screen_r20_ohm_km: 0})), 'status'), 'INPUT REQUIRED')]), tuple (['Documented manual lambda accepted', __in__ (__getitem__ (__call__ (metallic_loss_gate, null, __kwargtrans__ ({parallel_sets: 2, bonding: 'BOTH ENDS', lambda1_override: 0.18, lambda2_override: 0, verified_source: 'verified IEC calc', sharing_status: 'PASS'})), 'status'), new set (['PASS', 'REVIEW REQUIRED']))])];
	var __iterable0__ = __call__ (list, null, tests2);
	for (var __index0__ = 0; __index0__ < len (__iterable0__); __index0__++) {
		var __left0__ = __getitem__ (__iterable0__, __index0__);
		var py_name = __left0__ [0];
		var passed = __left0__ [1];
		(function () {
			var __accu0__ = s;
			return __call__ (__accu0__.add, __accu0__, 'LOSS_SHARING', py_name, __call__ (bool, null, passed), __kwargtrans__ ({criterion: 'Session-2 safety gate'}));
		}) ();
	}
	var tx = __call__ (from_thermal, null, base);
	var cyc = __call__ (simulate_profile, null, tx, DEFAULT_24H_PROFILE, 7);
	var em625 = __call__ (simulate_emergency, null, tx, 625, 2);
	var er = __call__ (emergency_rating, null, tx, 2, 500, 1500, 50);
	var steady_start = __getitem__ (__getitem__ (cyc, 'start'), 'tc');
	var ttests = [tuple (['Steady-state closure', __lt__ (__call__ (abs, null, __sub__ (steady_start, __getitem__ (b, 'conductor_temp_c'))), 0.001), steady_start, '<0.001°C']), tuple (['Periodic cyclic closure', __t__ (__getitem__ (cyc, 'full_state_day_change_c') !== null) && __le__ (__getitem__ (cyc, 'full_state_day_change_c'), 0.05), __getitem__ (cyc, 'full_state_day_change_c'), 'all four nodes <=0.05°C']), tuple (['Sample cyclic peak', __lt__ (__getitem__ (cyc, 'last_day_peak_c'), 90), __getitem__ (cyc, 'last_day_peak_c'), '<90°C']), tuple (['Emergency heating direction', __gt__ (__getitem__ (em625, 'final_conductor_c'), __getitem__ (em625, 'start_conductor_c')), __sub__ (__getitem__ (em625, 'final_conductor_c'), __getitem__ (em625, 'start_conductor_c')), '>0°C']), tuple (['Emergency scan monotonicity', __call__ (all, null, (function () {
		var __accu0__ = [];
		var __iterable0__ = __call__ (list, null, __call__ (range, null, __sub__ (__call__ (len, null, __getitem__ (er, 'rows')), 1)));
		for (var __index0__ = 0; __index0__ < len (__iterable0__); __index0__++) {
			var i = __getitem__ (__iterable0__, __index0__);
			(function () {
				var __accu1__ = __accu0__;
				return __call__ (__accu1__.append, __accu1__, __lt__ (__getitem__ (__getitem__ (__getitem__ (er, 'rows'), i), 'conductor_c'), __getitem__ (__getitem__ (__getitem__ (er, 'rows'), __add__ (i, 1)), 'conductor_c')));
			}) ();
		}
		return py_iter (__accu0__);
	}) ()), null, 'strictly increasing']), tuple (['2-h rating bracket', __t__ (__eq__ (__getitem__ (er, 'screening_rating_a'), 950)) && __eq__ (__getitem__ (er, 'next_limit_a'), 1000), tuple ([__getitem__ (er, 'screening_rating_a'), __getitem__ (er, 'next_limit_a')]), '950 PASS / 1000 LIMIT; exact implicit four-node solve']), tuple (['Resistance feedback', __t__ (__gt__ (tx.alpha_per_c, 0)) && __gt__ (__call__ (rac_at_temp, null, base, 90), __call__ (rac_at_temp, null, base, 55)), tx.alpha_per_c, '>0']), tuple (['Controlled release wording', __t__ (__in__ ('SCREENING', __getitem__ (cyc, 'release_label'))) && __in__ ('VERIFY', __getitem__ (cyc, 'release_label')), __getitem__ (cyc, 'release_label'), 'contains SCREENING / VERIFY'])];
	var __iterable0__ = __call__ (list, null, ttests);
	for (var __index0__ = 0; __index0__ < len (__iterable0__); __index0__++) {
		var __left0__ = __getitem__ (__iterable0__, __index0__);
		var py_name = __left0__ [0];
		var passed = __left0__ [1];
		var calc = __left0__ [2];
		var crit = __left0__ [3];
		(function () {
			var __accu0__ = s;
			return __call__ (__accu0__.add, __accu0__, 'TRANSIENT', py_name, __call__ (bool, null, passed), calc, crit);
		}) ();
	}
	var fx = __call__ (default_field_input, null, __getitem__ (b, 'total_heat_w_m'));
	var field = __call__ (solve_field, null, fx);
	var ftests = [tuple (['Final convergence', __le__ (__getitem__ (field, 'final_delta_c'), 0.001), __getitem__ (field, 'final_delta_c'), '<=0.001°C']), tuple (['Energy balance', __le__ (__call__ (abs, null, __getitem__ (field, 'energy_imbalance_w_m')), 0.01), __getitem__ (field, 'energy_imbalance_w_m'), '<=0.01 W/m']), tuple (['Dry-out direction', __ge__ (__getitem__ (field, 'final_max_c'), __getitem__ (field, 'moist_max_c')), __sub__ (__getitem__ (field, 'final_max_c'), __getitem__ (field, 'moist_max_c')), '>=0°C']), tuple (['Source reconciliation', __lt__ (__call__ (abs, null, __sub__ (__getitem__ (field, 'source_heat_w_m'), __getitem__ (b, 'total_heat_w_m'))), 0.001), __sub__ (__getitem__ (field, 'source_heat_w_m'), __getitem__ (b, 'total_heat_w_m')), '<=0.001 W/m']), tuple (['Dry-map stability', __getitem__ (field, 'dry_map_stable'), __getitem__ (field, 'dry_map_stable'), 'True']), tuple (['Symmetry sanity', __lt__ (__getitem__ (field, 'left_right_asymmetry_c'), 0.01), __getitem__ (field, 'left_right_asymmetry_c'), '<0.01°C']), tuple (['Dry cell baseline', __eq__ (__getitem__ (field, 'dry_cells'), 9), __getitem__ (field, 'dry_cells'), '9']), tuple (['Baseline moist max', __lt__ (__call__ (abs, null, __sub__ (__getitem__ (field, 'moist_max_c'), 39.153884)), 0.001), __getitem__ (field, 'moist_max_c'), '39.153884 ±0.001°C']), tuple (['Controlled release wording', __t__ (__in__ ('SCREENING', __getitem__ (field, 'release_label'))) && __in__ ('VERIFY', __getitem__ (field, 'release_label')), __getitem__ (field, 'release_label'), 'contains SCREENING / VERIFY'])];
	var __iterable0__ = __call__ (list, null, ftests);
	for (var __index0__ = 0; __index0__ < len (__iterable0__); __index0__++) {
		var __left0__ = __getitem__ (__iterable0__, __index0__);
		var py_name = __left0__ [0];
		var passed = __left0__ [1];
		var calc = __left0__ [2];
		var crit = __left0__ [3];
		(function () {
			var __accu0__ = s;
			return __call__ (__accu0__.add, __accu0__, 'FIELD2D', py_name, __call__ (bool, null, passed), calc, crit);
		}) ();
	}
	var c = __call__ (conduit_t4, null, 0.04953, 0.1016, 0.1143, 6, 1.5, 1, 1, 1.5);
	var h = __call__ (hdd_t4, null, 0.04953, 0.15, 0.168, 3.5, 1.5, 1, 2);
	var route = __call__ (solve_route, null, base, [dict ({'name': 'SEG-01', 'length_ft': 1000, 'installation': 'DIRECT BURIED'}), dict ({'name': 'SEG-02', 'length_ft': 300, 'installation': 'CONDUIT SOLID-FILLED', 'burial_depth_m': 1, 'duct_id_m': 0.1016, 'duct_od_m': 0.1143, 'duct_wall_rho_km_w': 6, 'solid_fill_rho_km_w': 1.5, 'conduit_group_multiplier': 1.5}), dict ({'name': 'SEG-03', 'length_ft': 450, 'installation': 'VERIFIED / FDM T4', 'burial_depth_m': 1, 'verified_t4_km_w': 1.25, 't4_source': 'approved FDM'}), dict ({'name': 'SEG-04', 'length_ft': 600, 'installation': 'HDD / CASING', 'burial_depth_m': 2, 'hdd': dict ({'active': true, 'method': 'SIMPLE SOLID-FILLED SINGLE CABLE', 'casing_id_m': 0.15, 'casing_od_m': 0.168, 'wall_rho_km_w': 3.5, 'fill_rho_km_w': 1.5, 'soil_rho_km_w': 1, 'center_depth_m': 2})}), dict ({'name': 'SEG-05', 'length_ft': 100, 'installation': 'DIRECT BURIED', 'crossing': dict ({'active': true, 'method': 'VERIFIED BOTH', 'delta_t_c': 5, 'rating_factor': 0.95, 'source': 'approved study'})}), dict ({'name': 'SEG-06', 'length_ft': 800, 'installation': 'HDD / CASING', 'burial_depth_m': 2.5, 'hdd': dict ({'active': true, 'method': 'VERIFIED T4', 'verified_t4_km_w': 1.8, 'source': 'approved thermal study'})})]);
	var rtests = [tuple (['Conduit fill Rth', __lt__ (__call__ (abs, null, __sub__ (__getitem__ (c, 'fill_rth'), 0.17152088154791548)), 1e-10)]), tuple (['Conduit total T4', __lt__ (__call__ (abs, null, __sub__ (__getitem__ (c, 't4_km_w'), 1.2745449097518637)), 1e-10)]), tuple (['HDD fill Rth', __lt__ (__call__ (abs, null, __sub__ (__getitem__ (h, 'fill_rth'), 0.2645290628855009)), 1e-10)]), tuple (['HDD total T4', __lt__ (__call__ (abs, null, __sub__ (__getitem__ (h, 't4_km_w'), 0.9424403036949013)), 1e-10)]), tuple (['Crossing verified both', __eq__ (__getitem__ (__call__ (crossing_handoff, null, dict ({'active': true, 'method': 'VERIFIED BOTH', 'delta_t_c': 5, 'rating_factor': 0.95, 'source': 'approved'})), 'status'), 'PASS')]), tuple (['Crossing factor-only review', __eq__ (__getitem__ (__call__ (crossing_handoff, null, dict ({'active': true, 'method': 'VERIFIED RATING FACTOR', 'rating_factor': 0.92, 'source': 'approved'})), 'status'), 'REVIEW REQUIRED')]), tuple (['Route governing segment', __eq__ (__getitem__ (__getitem__ (route, 'governing_segment'), 'name'), 'SEG-05')]), tuple (['Route governing ampacity', __lt__ (__call__ (abs, null, __sub__ (__getitem__ (__getitem__ (route, 'governing_segment'), 'final_ampacity_a'), 631.8078185768177)), 1e-05)]), tuple (['Route has review gates', __eq__ (__getitem__ (route, 'status'), 'REVIEW REQUIRED')]), tuple (['Short transition review', __eq__ (__getitem__ (__getitem__ (__getitem__ (__call__ (solve_route, null, base, [dict ({'name': 'short', 'length_ft': 25, 'installation': 'DIRECT BURIED'})]), 'segments'), 0), 'final_status'), 'REVIEW REQUIRED')])];
	var __iterable0__ = __call__ (list, null, rtests);
	for (var __index0__ = 0; __index0__ < len (__iterable0__); __index0__++) {
		var __left0__ = __getitem__ (__iterable0__, __index0__);
		var py_name = __left0__ [0];
		var passed = __left0__ [1];
		(function () {
			var __accu0__ = s;
			return __call__ (__accu0__.add, __accu0__, 'ROUTE', py_name, __call__ (bool, null, passed), __kwargtrans__ ({criterion: 'Session-5 route/special-installation behavior'}));
		}) ();
	}
	var opt = __call__ (thermal_optimizer, null, base, [0.75, 1, 1.25], [25, 30, 35], [0.75, 0.939165, 1.25]);
	var ducts = __call__ (duct_position_optimizer, null, __call__ (default_3x3_ducts, null, 0.2, 1.0), 3);
	var scen = __call__ (scenario_manager, null, base, [dict ({'name': 'BASE'}), dict ({'name': 'HOT', 'ambient_c': 35}), dict ({'name': 'RHO2', 'soil_rho_km_w': 2})]);
	var otests = [tuple (['Optimizer enumerates 27', __eq__ (__getitem__ (opt, 'candidate_count'), 27)]), tuple (['Optimizer finds feasible', __gt__ (__getitem__ (opt, 'passing_candidates'), 0)]), tuple (['Baseline candidate present', __call__ (any, null, (function () {
		var __accu0__ = [];
		var __iterable0__ = __call__ (list, null, __getitem__ (opt, 'candidates'));
		for (var __index0__ = 0; __index0__ < len (__iterable0__); __index0__++) {
			var c = __getitem__ (__iterable0__, __index0__);
			(function () {
				var __accu1__ = __accu0__;
				return __call__ (__accu1__.append, __accu1__, __t__ (__lt__ (__call__ (abs, null, __sub__ (__getitem__ (c, 'soil_rho_km_w'), 1)), 1e-12)) && __t__ (__lt__ (__call__ (abs, null, __sub__ (__getitem__ (c, 'ambient_c'), 25)), 1e-12)) && __lt__ (__call__ (abs, null, __sub__ (__getitem__ (c, 'burial_depth_m'), 0.939165)), 1e-12));
			}) ();
		}
		return py_iter (__accu0__);
	}) ())]), tuple (['Duct optimizer enumerates 84', __eq__ (__getitem__ (ducts, 'combinations'), 84)]), tuple (['Duct best score baseline', __lt__ (__call__ (abs, null, __sub__ (__getitem__ (__getitem__ (ducts, 'best'), 'coupling_score'), 6.767766952966369)), 1e-10)]), tuple (['Duct best spacing baseline', __lt__ (__call__ (abs, null, __sub__ (__getitem__ (__getitem__ (ducts, 'best'), 'min_spacing_m'), 0.4)), 1e-10)]), tuple (['Scenario BASE closes', __lt__ (__call__ (abs, null, __sub__ (__getitem__ (__call__ (py_next, null, (function () {
		var __accu0__ = [];
		var __iterable0__ = __call__ (list, null, __getitem__ (scen, 'rows'));
		for (var __index0__ = 0; __index0__ < len (__iterable0__); __index0__++) {
			var r = __getitem__ (__iterable0__, __index0__);
			if (__t__ (__eq__ (__getitem__ (r, 'name'), 'BASE'))) {
				(function () {
					var __accu1__ = __accu0__;
					return __call__ (__accu1__.append, __accu1__, r);
				}) ();
			}
		}
		return py_iter (__accu0__);
	}) ()), 'ampacity_a'), __getitem__ (b, 'ampacity_a'))), 1e-08)]), tuple (['Hot scenario hotter', __gt__ (__getitem__ (__call__ (py_next, null, (function () {
		var __accu0__ = [];
		var __iterable0__ = __call__ (list, null, __getitem__ (scen, 'rows'));
		for (var __index0__ = 0; __index0__ < len (__iterable0__); __index0__++) {
			var r = __getitem__ (__iterable0__, __index0__);
			if (__t__ (__eq__ (__getitem__ (r, 'name'), 'HOT'))) {
				(function () {
					var __accu1__ = __accu0__;
					return __call__ (__accu1__.append, __accu1__, r);
				}) ();
			}
		}
		return py_iter (__accu0__);
	}) ()), 'conductor_temp_c'), __getitem__ (b, 'conductor_temp_c'))]), tuple (['High-rho scenario lower ampacity', __lt__ (__getitem__ (__call__ (py_next, null, (function () {
		var __accu0__ = [];
		var __iterable0__ = __call__ (list, null, __getitem__ (scen, 'rows'));
		for (var __index0__ = 0; __index0__ < len (__iterable0__); __index0__++) {
			var r = __getitem__ (__iterable0__, __index0__);
			if (__t__ (__eq__ (__getitem__ (r, 'name'), 'RHO2'))) {
				(function () {
					var __accu1__ = __accu0__;
					return __call__ (__accu1__.append, __accu1__, r);
				}) ();
			}
		}
		return py_iter (__accu0__);
	}) ()), 'ampacity_a'), __getitem__ (b, 'ampacity_a'))])];
	var __iterable0__ = __call__ (list, null, otests);
	for (var __index0__ = 0; __index0__ < len (__iterable0__); __index0__++) {
		var __left0__ = __getitem__ (__iterable0__, __index0__);
		var py_name = __left0__ [0];
		var passed = __left0__ [1];
		(function () {
			var __accu0__ = s;
			return __call__ (__accu0__.add, __accu0__, 'OPTIMIZATION', py_name, __call__ (bool, null, passed), __kwargtrans__ ({criterion: 'Session-6 decision-support behavior'}));
		}) ();
	}
	var states = new set (['PASS', 'FAIL', 'INPUT REQUIRED', 'REVIEW REQUIRED']);
	var combos = __call__ (list, null, __call__ (product, null, [0.4, 0.6, 1, 1.5, 2, 2.5, 3], [10, 25, 35, 45, 60], [0.3, 0.6, 0.939165, 1.5], [1, 2.2377027287708477, 4], [0, 300, 500, 700, 900]));
	var __iterable0__ = __call__ (list, null, __call__ (py_enumerate, null, __getslice__ (combos, null, 120, 1), 1));
	for (var __index0__ = 0; __index0__ < len (__iterable0__); __index0__++) {
		var __left0__ = __getitem__ (__iterable0__, __index0__);
		var i = __left0__ [0];
		var rho = __left0__ [1][0];
		var amb = __left0__ [1][1];
		var dep = __left0__ [1][2];
		var gf = __left0__ [1][3];
		var load = __left0__ [1][4];
		var res = __call__ (solve_steady, null, __call__ (ThermalInput, null, __kwargtrans__ ({soil_rho_km_w: rho, ambient_c: amb, burial_depth_m: dep, group_multiplier: gf, load_a: load})));
		var passed = __t__ (__in__ (__getitem__ (res, 'status'), states)) && (__t__ (__eq__ (__getitem__ (res, 'status'), 'INPUT REQUIRED')) || __call__ (all, null, (function () {
			var __accu0__ = [];
			var __iterable1__ = __call__ (list, null, [(function () {
				var __accu1__ = res;
				return __call__ (__accu1__.py_get, __accu1__, 'ampacity_a', 0);
			}) (), (function () {
				var __accu1__ = res;
				return __call__ (__accu1__.py_get, __accu1__, 'conductor_temp_c', 0);
			}) ()]);
			for (var __index1__ = 0; __index1__ < len (__iterable1__); __index1__++) {
				var v = __getitem__ (__iterable1__, __index1__);
				(function () {
					var __accu1__ = __accu0__;
					return __call__ (__accu1__.append, __accu1__, __call__ (isfinite, null, v));
				}) ();
			}
			return py_iter (__accu0__);
		}) ()));
		(function () {
			var __accu0__ = s;
			return __call__ (__accu0__.add, __accu0__, 'STRESS_A', 'Direct stress {}'.format (i), passed, __getitem__ (res, 'status'), 'controlled engineering state');
		}) ();
	}
	var invalids = [__call__ (dict, null, __kwargtrans__ ({soil_rho_km_w: __neg__ (1)})), __call__ (dict, null, __kwargtrans__ ({soil_rho_km_w: 0})), __call__ (dict, null, __kwargtrans__ ({cable_od_m: 0})), __call__ (dict, null, __kwargtrans__ ({burial_depth_m: 0.001})), __call__ (dict, null, __kwargtrans__ ({r20_ohm_m: 0})), __call__ (dict, null, __kwargtrans__ ({alpha_per_c: 0})), __call__ (dict, null, __kwargtrans__ ({ac_factor: 0})), __call__ (dict, null, __kwargtrans__ ({group_multiplier: 0})), __call__ (dict, null, __kwargtrans__ ({dielectric_w_m: __neg__ (1)})), __call__ (dict, null, __kwargtrans__ ({ambient_c: 90}))];
	var __iterable0__ = __call__ (list, null, __call__ (range, null, 40));
	for (var __index0__ = 0; __index0__ < len (__iterable0__); __index0__++) {
		var i = __getitem__ (__iterable0__, __index0__);
		var res = __call__ (solve_steady, null, __call__ (ThermalInput, null, __kwargtrans__ (__getitem__ (invalids, __mod__ (i, __call__ (len, null, invalids))))));
		(function () {
			var __accu0__ = s;
			return __call__ (__accu0__.add, __accu0__, 'STRESS_A', 'Invalid input {}'.format (__add__ (i, 1)), __eq__ (__getitem__ (res, 'status'), 'INPUT REQUIRED'), __getitem__ (res, 'status'), 'INPUT REQUIRED');
		}) ();
	}
	var __iterable0__ = __call__ (list, null, __call__ (range, null, 20));
	for (var __index0__ = 0; __index0__ < len (__iterable0__); __index0__++) {
		var i = __getitem__ (__iterable0__, __index0__);
		var mode = __getitem__ (['AUTO', 'SYMMETRIC VERIFIED', 'MANUAL WORST-SET FACTOR', 'VERIFIED SET CURRENTS', 'IEC 60287-1-3 REQUIRED'], __mod__ (i, 5));
		var kwargs = dict ({'source': 'study'});
		if (__t__ (__eq__ (mode, 'MANUAL WORST-SET FACTOR'))) {
			__setitem__ (kwargs, 'worst_set_factor', 1.1);
		}
		if (__t__ (__eq__ (mode, 'VERIFIED SET CURRENTS'))) {
			__setitem__ (kwargs, 'set_currents_a', [520, 480]);
		}
		var res = __call__ (parallel_sharing, null, 1000, 2, mode, __kwargtrans__ (kwargs));
		(function () {
			var __accu0__ = s;
			return __call__ (__accu0__.add, __accu0__, 'STRESS_A', 'Sharing case {}'.format (__add__ (i, 1)), __in__ (__getitem__ (res, 'status'), states), __getitem__ (res, 'status'), 'controlled state');
		}) ();
	}
	var __iterable0__ = __call__ (list, null, __call__ (range, null, 20));
	for (var __index0__ = 0; __index0__ < len (__iterable0__); __index0__++) {
		var i = __getitem__ (__iterable0__, __index0__);
		var length = __getitem__ ([10, 49, 50, 100, 600], __mod__ (i, 5));
		var res = __call__ (solve_route, null, base, [dict ({'name': 'stress', 'length_ft': length, 'installation': 'DIRECT BURIED'})]);
		var expected = (__t__ (__lt__ (length, 50)) ? 'REVIEW REQUIRED' : 'PASS');
		(function () {
			var __accu0__ = s;
			return __call__ (__accu0__.add, __accu0__, 'STRESS_A', 'Route length case {}'.format (__add__ (i, 1)), __eq__ (__getitem__ (__getitem__ (__getitem__ (res, 'segments'), 0), 'final_status'), expected), __getitem__ (__getitem__ (__getitem__ (res, 'segments'), 0), 'final_status'), expected);
		}) ();
	}
	var combos2 = __call__ (list, null, __call__ (product, null, [0.55, 0.8, 1.2, 1.8, 2.8], [15, 30, 40, 55], [0.45, 0.8, 1.2, 2.0], [1.0, 1.5, 3.0], [250, 600, 850]));
	var __iterable0__ = __call__ (list, null, __call__ (py_enumerate, null, __getslice__ (combos2, null, 80, 1), 1));
	for (var __index0__ = 0; __index0__ < len (__iterable0__); __index0__++) {
		var __left0__ = __getitem__ (__iterable0__, __index0__);
		var i = __left0__ [0];
		var rho = __left0__ [1][0];
		var amb = __left0__ [1][1];
		var dep = __left0__ [1][2];
		var gf = __left0__ [1][3];
		var load = __left0__ [1][4];
		var res = __call__ (solve_steady, null, __call__ (ThermalInput, null, __kwargtrans__ ({soil_rho_km_w: rho, ambient_c: amb, burial_depth_m: dep, group_multiplier: gf, load_a: load})));
		(function () {
			var __accu0__ = s;
			return __call__ (__accu0__.add, __accu0__, 'STRESS_B', 'Environmental case {}'.format (i), __in__ (__getitem__ (res, 'status'), states), __getitem__ (res, 'status'), 'controlled state');
		}) ();
	}
	var __iterable0__ = __call__ (list, null, __call__ (range, null, 40));
	for (var __index0__ = 0; __index0__ < len (__iterable0__); __index0__++) {
		var i = __getitem__ (__iterable0__, __index0__);
		var current = __add__ (400, __mul__ (i, 20));
		var sim = __call__ (simulate_emergency, null, tx, current, 2);
		var passed = __t__ (__in__ (__getitem__ (sim, 'status'), new set (['PASS', 'LIMIT']))) && __call__ (isfinite, null, __getitem__ (sim, 'final_conductor_c'));
		(function () {
			var __accu0__ = s;
			return __call__ (__accu0__.add, __accu0__, 'STRESS_B', 'Transient case {}'.format (__add__ (i, 1)), passed, __getitem__ (sim, 'status'), 'finite controlled transient result');
		}) ();
	}
	var __iterable0__ = __call__ (list, null, __call__ (range, null, 20));
	for (var __index0__ = 0; __index0__ < len (__iterable0__); __index0__++) {
		var i = __getitem__ (__iterable0__, __index0__);
		var method = __getitem__ (['VERIFIED BOTH', 'VERIFIED DELTA-T', 'VERIFIED RATING FACTOR', 'IEC 60287-3-3 REQUIRED'], __mod__ (i, 4));
		var res = __call__ (crossing_handoff, null, dict ({'active': true, 'method': method, 'delta_t_c': 3, 'rating_factor': 0.95, 'source': 'study'}));
		(function () {
			var __accu0__ = s;
			return __call__ (__accu0__.add, __accu0__, 'STRESS_B', 'Crossing case {}'.format (__add__ (i, 1)), __in__ (__getitem__ (res, 'status'), states), __getitem__ (res, 'status'), 'controlled crossing state');
		}) ();
	}
	var __iterable0__ = __call__ (list, null, __call__ (range, null, 20));
	for (var __index0__ = 0; __index0__ < len (__iterable0__); __index0__++) {
		var i = __getitem__ (__iterable0__, __index0__);
		try {
			var rr = __call__ (hdd_t4, null, 0.04953, __add__ (0.1, __mul__ (0.005, i)), __add__ (0.125, __mul__ (0.005, i)), 3.5, 1.2, 1.2, 1.8);
			var passed = __t__ (__gt__ (__getitem__ (rr, 't4_km_w'), 0)) && __call__ (isfinite, null, __getitem__ (rr, 't4_km_w'));
			var calc = __getitem__ (rr, 't4_km_w');
		}
		catch (__except0__) {
			if (isinstance (__except0__, Exception)) {
				var passed = false;
				var calc = null;
			}
			else {
				throw __except0__;
			}
		}
		(function () {
			var __accu0__ = s;
			return __call__ (__accu0__.add, __accu0__, 'STRESS_B', 'HDD radial case {}'.format (__add__ (i, 1)), passed, calc, '>0 finite T4');
		}) ();
	}
	var __iterable0__ = __call__ (list, null, __call__ (range, null, 20));
	for (var __index0__ = 0; __index0__ < len (__iterable0__); __index0__++) {
		var i = __getitem__ (__iterable0__, __index0__);
		var sp = __add__ (0.1, __mul__ (0.01, i));
		var dd = __call__ (duct_position_optimizer, null, __call__ (default_3x3_ducts, null, sp, 1.0), 3);
		(function () {
			var __accu0__ = s;
			return __call__ (__accu0__.add, __accu0__, 'STRESS_B', 'Duct optimizer case {}'.format (__add__ (i, 1)), __t__ (__eq__ (__getitem__ (dd, 'combinations'), 84)) && __getitem__ (dd, 'best') !== null, __getitem__ (__getitem__ (dd, 'best'), 'coupling_score'), '84 combos + best');
		}) ();
	}
	var __iterable0__ = __call__ (list, null, __call__ (range, null, 20));
	for (var __index0__ = 0; __index0__ < len (__iterable0__); __index0__++) {
		var i = __getitem__ (__iterable0__, __index0__);
		var rho = __add__ (0.7, __mul__ (0.05, i));
		var oo = __call__ (thermal_optimizer, null, base, [rho], [25, 35], [0.75, 0.939165, 1.25]);
		(function () {
			var __accu0__ = s;
			return __call__ (__accu0__.add, __accu0__, 'STRESS_B', 'Thermal optimizer case {}'.format (__add__ (i, 1)), __eq__ (__getitem__ (oo, 'candidate_count'), 6), __getitem__ (oo, 'candidate_count'), '6 candidates');
		}) ();
	}
	var cnum = 0;
	var __iterable0__ = __call__ (list, null, __call__ (product, null, [0.6, 1, 1.5, 2], [15, 25, 35], [0.6, 0.939165, 1.5], [1, 2.2377027287708477]));
	for (var __index0__ = 0; __index0__ < len (__iterable0__); __index0__++) {
		var __left0__ = __getitem__ (__iterable0__, __index0__);
		var rho = __left0__ [0];
		var amb = __left0__ [1];
		var dep = __left0__ [2];
		var gf = __left0__ [3];
		var x = __call__ (ThermalInput, null, __kwargtrans__ ({soil_rho_km_w: rho, ambient_c: amb, burial_depth_m: dep, group_multiplier: gf}));
		var a = __getitem__ (__call__ (solve_steady, null, x), 'ampacity_a');
		var root = __call__ (_root_ampacity, null, x);
		var rel = __truediv__ (__call__ (abs, null, __sub__ (root, a)), a);
		(function () {
			var __accu0__ = s;
			return __call__ (__accu0__.add, __accu0__, 'CROSS_METHOD', 'Cross-method {}'.format (__add__ (cnum, 1)), __le__ (rel, 1e-08), tuple ([a, root, rel]), 'relative error <=1e-8');
		}) ();
		var cnum = __call__ (__iadd__, null, cnum, 1);
	}
	var passes = __call__ (sum, null, (function () {
		var __accu0__ = [];
		var __iterable0__ = __call__ (list, null, s.rows);
		for (var __index0__ = 0; __index0__ < len (__iterable0__); __index0__++) {
			var r = __getitem__ (__iterable0__, __index0__);
			if (__t__ (__eq__ (__getitem__ (r, 'status'), 'PASS'))) {
				(function () {
					var __accu1__ = __accu0__;
					return __call__ (__accu1__.append, __accu1__, 1);
				}) ();
			}
		}
		return py_iter (__accu0__);
	}) ());
	var fails = __sub__ (__call__ (len, null, s.rows), passes);
	var blocks = dict ({});
	var __iterable0__ = __call__ (list, null, s.rows);
	for (var __index0__ = 0; __index0__ < len (__iterable0__); __index0__++) {
		var r = __getitem__ (__iterable0__, __index0__);
		var bname = __getitem__ (r, 'block');
		if (__t__ (!__in__ (bname, blocks))) {
			__setitem__ (blocks, bname, dict ({'tests': 0, 'pass': 0, 'fail': 0}));
		}
		__setitem__ (__getitem__ (blocks, bname), 'tests', __call__ (__iadd__, null, __getitem__ (__getitem__ (blocks, bname), 'tests'), 1));
		if (__t__ (__eq__ (__getitem__ (r, 'status'), 'PASS'))) {
			__setitem__ (__getitem__ (blocks, bname), 'pass', __call__ (__iadd__, null, __getitem__ (__getitem__ (blocks, bname), 'pass'), 1));
		}
		else {
			__setitem__ (__getitem__ (blocks, bname), 'fail', __call__ (__iadd__, null, __getitem__ (__getitem__ (blocks, bname), 'fail'), 1));
		}
	}
	return dict ({'status': (__t__ (__eq__ (fails, 0)) ? 'PASS' : 'FAIL'), 'tests': __call__ (len, null, s.rows), 'pass': passes, 'fail': fails, 'pass_rate': __truediv__ (passes, __call__ (len, null, s.rows)), 'blocks': blocks, 'rows': s.rows});
};

//# sourceMappingURL=thermal.map