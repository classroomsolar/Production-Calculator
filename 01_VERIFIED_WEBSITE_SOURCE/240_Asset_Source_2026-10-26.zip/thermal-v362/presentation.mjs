const finite=v=>typeof v==='number'&&Number.isFinite(v);

export function formationOffsets(count,spacing,arrangement='TREFOIL'){
 if(count===1)return [[0,0]];
 if(count===2)return arrangement==='VERTICAL'?[[0,-spacing/2],[0,spacing/2]]:[[-spacing/2,0],[spacing/2,0]];
 return arrangement==='TREFOIL'?[[-spacing/2,spacing*Math.sqrt(3)/6],[spacing/2,spacing*Math.sqrt(3)/6],[0,-spacing*Math.sqrt(3)/3]]:arrangement==='VERTICAL'?[[0,-spacing],[0,0],[0,spacing]]:[[-spacing,0],[0,0],[spacing,0]];
}

export function formationName(study){const s=study.settings;if(s.arrangement==='CUSTOM')return 'Custom coordinates';if(s.system!=='AC 3PH')return s.arrangement==='VERTICAL'?'Vertical pair':'Horizontal pair';return s.arrangement==='TREFOIL'?'Trefoil':s.arrangement==='VERTICAL'?'Vertical':'Horizontal / flat';}

export function methodBasis(study){
 const s=study.settings,physical=s.group_mode==='PHYSICAL GEOMETRY';
 return {name:physical?'Coupled soil image-source model':'Workbook steady-state thermal network',load_basis:physical?'Each visible circuit row is one positioned cable set; enter its actual current.':'Total circuit current is converted to the worst loaded parallel set.',soil_basis:physical?'Direct burial in homogeneous soil; every cable position contributes mutual heating.':s.installation==='DIRECT BURIED'?'Soil image-source resistance multiplied by an entered, verified grouping factor.':s.installation==='SOLID-FILLED CONDUIT'?'Concentric solid-filled conduit screening resistance.':'External thermal resistance supplied by a verified project study.',construction_basis:[s.thermal_model,s.ac_model,s.dielectric_model].includes('GEOMETRY')?'Selected round single-core properties calculated from the finalized IEC60287_ENGINE workbook equations.':'User-supplied thermal paths and loss factors.',neher_mcgrath:false,neher_mcgrath_note:'Related thermal-resistance principles are used. A complete Neher–McGrath rating engine, including daily load/loss-factor treatment, is not implemented.',transient_basis:'Cyclic and emergency calculations use the retained four-node thermal-capacitance screening model.',equation:'θ − θearth = I² Rac(θ) Rthermal + Wd Rdielectric'};
}

export function cableMaterial(row){const raw=String(row.Conductor_Material||row.Conductor_Material_Inferred||'');return /copper|\bcu\b/i.test(raw)?'COPPER':/alum|\bal\b/i.test(raw)?'ALUMINUM':'OTHER';}
export function cableVoltage(row){const direct=Number(row.Voltage_Rating_V),v=direct>0?direct:Number(row.Rated_kV)*1000;return Number.isFinite(v)&&v>0?v:null;}

export function enteredLayout(study){
 const s=study.settings,count=s.system==='AC 3PH'?3:2,spacing=s.phase_spacing_m,physical=s.group_mode==='PHYSICAL GEOMETRY';
 const circuits=physical?s.circuits.filter(c=>c.active!==false):[{name:'Cable set',x_m:0,depth_m:study.input.burial_depth_m}];
 const points=[];
 for(const [circuit,c] of circuits.entries()){
  const offsets=s.arrangement==='CUSTOM'?c.offsets:finite(spacing)&&spacing>0?formationOffsets(count,spacing,s.arrangement):null;
  if(!finite(c.x_m)||!finite(c.depth_m)||!Array.isArray(offsets)||offsets.length!==count)continue;
  offsets.forEach((p,phase)=>{if(Array.isArray(p)&&p.length===2&&p.every(finite))points.push({name:c.name,circuit,phase,x_m:c.x_m+p[0],y_m:c.depth_m+p[1]});});
 }
 return points;
}

export function restoreDeviceCases(rows,validate){
 const cases=[];let rejected=0;
 for(const row of Array.isArray(rows)?rows:[]){try{
  if(!row||typeof row!=='object'||typeof row.id!=='string'||typeof row.name!=='string'||typeof row.updated!=='string'||!Number.isFinite(Date.parse(row.updated)))throw new Error('Invalid saved case');
  const result=row.result&&['PASS','FAIL','LIMIT','INPUT REQUIRED','REVIEW REQUIRED'].includes(row.result.status)?row.result:null;
  cases.push({...row,result,study:validate(row.study)});
 }catch{rejected++;}}
 return {cases,rejected};
}
