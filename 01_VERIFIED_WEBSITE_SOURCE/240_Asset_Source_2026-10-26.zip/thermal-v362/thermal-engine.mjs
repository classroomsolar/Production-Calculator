import * as e from './generated/thermal.js';
import {dict,__kwargtrans__} from './generated/org.transcrypt.__runtime__.js';
import {formationOffsets} from './presentation.mjs';

export const BASE={load_a:500,ambient_c:25,max_temp_c:90,soil_rho_km_w:1,burial_depth_m:.939165,cable_od_m:.04953,r20_ohm_m:.0000569,alpha_per_c:.00403,ac_factor:1.0251328070572212,dielectric_w_m:.004114251237296077,r_internal_km_w:.2721190225149088,r_dielectric_internal_km_w:.18199013568525835,group_multiplier:2.2377027287708477,phases:3};
export const DEFAULT_PROFILE=[.65,.6,.58,.58,.6,.65,.72,.82,.9,.95,1,1,.98,.95,.92,.9,.92,.98,1.05,1.1,1.05,.95,.82,.72];
export const priority=(...statuses)=>['FAIL','INPUT REQUIRED','REVIEW REQUIRED','PASS'].find(s=>statuses.map(v=>v==='LIMIT'?'FAIL':v).includes(s))||'INPUT REQUIRED';
export const py=v=>Array.isArray(v)?v.map(py):v&&typeof v==='object'?dict(Object.fromEntries(Object.entries(v).map(([k,x])=>[k,py(x)]))):v;
const kw=o=>__kwargtrans__(py(o));
const clean=v=>JSON.parse(JSON.stringify(v));
const thermal=x=>e.ThermalInput(kw(x));
export function steady(x){
  const labels={load_a:'Load current',ambient_c:'Earth temperature',max_temp_c:'Conductor limit',soil_rho_km_w:'Soil resistivity',burial_depth_m:'Center burial depth',cable_od_m:'Cable diameter',r20_ohm_m:'Rdc at 20°C',alpha_per_c:'Resistance temperature coefficient',ac_factor:'AC resistance factor',dielectric_w_m:'Dielectric heat',r_internal_km_w:'Internal thermal resistance',r_dielectric_internal_km_w:'Dielectric thermal path',group_multiplier:'Mutual heating factor',phases:'Number of loaded conductors'};
  const issues=Object.keys(BASE).filter(k=>typeof x[k]!=='number'||!Number.isFinite(x[k])).map(k=>`${labels[k]}: enter a finite numeric value.`);
  if(issues.length)return {status:'INPUT REQUIRED',issues,input:x};
  if(1+x.alpha_per_c*(x.ambient_c-20)<=0)return {status:'INPUT REQUIRED',issues:['Resistance temperature correction must remain positive.'],input:x};
  const factor=x.metallic_factor??1;
  if(!Number.isFinite(factor)||factor<1)return {status:'INPUT REQUIRED',issues:['Metallic heat multiplier must be finite and at least one.']};
  const precheck=clean(e.validate_input(thermal(x)));if(precheck.length)return {status:'INPUT REQUIRED',issues:precheck,input:x};
  // Metallic heat traverses T4; dielectric heat is not multiplied by λ.
  const external=clean(e.external_t4(thermal(x)));
  const effective={...x,r_internal_km_w:x.r_internal_km_w+(factor-1)*external};
  const r=clean(e.solve_steady(thermal(effective)));r.input=x;
  if(typeof r.conductor_heat_total_w_m==='number'){r.metallic_heat_total_w_m=r.conductor_heat_total_w_m*(factor-1);r.total_heat_w_m+=r.metallic_heat_total_w_m;}
  if(r.status==='REVIEW REQUIRED'){
    // The rating is independent of the load-temperature iteration. An overload
    // remains a failure even when a near-runaway iteration reaches its limit.
    const rating=Number.isFinite(r.ampacity_a)?r.ampacity_a:clean(e.solve_steady(thermal({...effective,load_a:0}))).ampacity_a;
    const overloaded=Number.isFinite(rating)&&x.load_a>rating;
    return {...r,status:overloaded?'FAIL':'REVIEW REQUIRED',ampacity_a:rating,utilization:rating>0?x.load_a/rating:null,converged:false,conductor_temp_c:null,temperature_margin_c:null,rac_ohm_m:null,conductor_heat_per_conductor_w_m:null,conductor_heat_total_w_m:null,dielectric_heat_total_w_m:null,metallic_heat_total_w_m:null,total_heat_w_m:null,issues:[overloaded?'Load exceeds continuous ampacity. The temperature solver did not converge; reduce load before evaluating conductor temperature.':'The temperature solver did not converge. No temperature or heat output is accepted.']};
  }
  return r;
}
export function sharing(o){if(!Number.isFinite(o.total_current_a)||!Number.isInteger(o.parallel_sets)||o.parallel_sets<1)return {status:'INPUT REQUIRED',issues:['Enter a finite circuit load and a positive integer number of parallel sets.']};return clean(e.parallel_sharing(kw(o)));}
export function metallic(o){for(const k of ['lambda1_override','lambda2_override','screen_r20_ohm_km'])if(o[k]!==null&&o[k]!==undefined&&!Number.isFinite(o[k]))return {status:'INPUT REQUIRED',issues:[`${k} must be finite.`]};return clean(e.metallic_loss_gate(kw(o)));}
function transientGuard(x,o){
 const base=steady(x);if(base.status==='INPUT REQUIRED')return base;
 if(!o||typeof o!=='object'||Array.isArray(o)||Object.values(o).some(v=>typeof v!=='number'||!Number.isFinite(v)))return {status:'INPUT REQUIRED',issues:['Every transient construction override must be a finite number.']};
 if(o.timestep_min!==undefined&&(!(o.timestep_min>=1)||o.timestep_min>60)||o.gs_iterations!==undefined&&(!Number.isInteger(o.gs_iterations)||o.gs_iterations<1||o.gs_iterations>100))return {status:'INPUT REQUIRED',issues:['Time step must be 1–60 min; iteration count must be an integer 1–100.']};
 return null;
}
export function cyclic(x,o,profile,days){const gate=transientGuard(x,o);if(gate)return gate;if(!Number.isInteger(days)||days<1||days>30||!Array.isArray(profile)||profile.length!==24||profile.some(v=>!Number.isFinite(v)||v<0))return {status:'INPUT REQUIRED',issues:['Use 1–30 whole days and exactly 24 non-negative hourly load multipliers.']};return clean(e.simulate_profile(e.from_thermal(thermal(x),kw(o)),profile,days));}
export function emergency(x,o,current,duration){const gate=transientGuard(x,o);if(gate)return gate;if(!Number.isFinite(current)||current<0||!Number.isFinite(duration)||duration<=0||duration>168)return {status:'INPUT REQUIRED',issues:['Enter non-negative finite current and duration >0 to 168 h.']};return clean(e.simulate_emergency(e.from_thermal(thermal(x),kw(o)),current,duration));}
export function transientTimeStepCheck(x,o,current,duration,tolerance=1){
 if(typeof tolerance!=='number'||!Number.isFinite(tolerance)||tolerance<=0)return {status:'INPUT REQUIRED',issues:['The time-step comparison tolerance must be a positive finite temperature difference.']};
 const initial=emergency(x,o,current,duration);if(initial.status==='INPUT REQUIRED')return initial;
 const entered=initial.input.timestep_min,steps=[...new Set([entered,Math.max(1,entered/2),Math.max(1,entered/4)])];
 const simulations=steps.map((step,i)=>i===0?initial:emergency(x,{...o,timestep_min:step},current,duration));
 const invalid=simulations.find(v=>v.status==='INPUT REQUIRED');if(invalid)return invalid;
 if(simulations.some(v=>!Number.isFinite(v.peak_conductor_c)||!Number.isFinite(v.final_conductor_c)))return {status:'REVIEW REQUIRED',issues:['Finite peak and final temperatures are required for a time-step comparison.'],rows:[],tolerance_c:tolerance};
 const finest=simulations.at(-1),rows=simulations.map((v,i)=>({timestep_min:steps[i],effective_max_timestep_min:Math.min(steps[i],duration*60),integration_steps:v.points.length,peak_conductor_c:v.peak_conductor_c,final_conductor_c:v.final_conductor_c,difference_to_finest_c:Math.max(Math.abs(v.peak_conductor_c-finest.peak_conductor_c),Math.abs(v.final_conductor_c-finest.final_conductor_c)),duty_status:v.status}));
 const assessed=new Set(rows.map(r=>r.effective_max_timestep_min)).size>1,difference=assessed?rows[0].difference_to_finest_c:null,status=assessed&&difference<=tolerance?'PASS':'REVIEW REQUIRED';
 return {status,rows,entered_timestep_min:entered,finest_timestep_min:steps.at(-1),entered_step_difference_c:difference,tolerance_c:tolerance,current_a:current,duration_h:duration,
  issues:!assessed?[rows.length===1?'The entered step is already at the 1-minute input limit; a one-step result cannot establish time-step independence.':'Every tested setting uses the same single partial integration step for this short duty. No time-step-independence result is available from an unchanged solver schedule.']:difference>tolerance?['The entered step differs materially from the refined result. Reduce the entered time step and rerun the emergency screening.']:[],
  release_label:'TIME-STEP COMPARISON / FOUR-NODE SCREENING',
  note:'Compares peak and final conductor temperatures at the entered and refined time steps. A small difference does not validate the cable/soil model or a full IEC 60853 method. Duty status is reported separately from this numerical comparison.'};
}
export function emergencyRating(x,o,duration,start,stop,step){const gate=transientGuard(x,o);if(gate)return gate;if(![duration,start,stop,step].every(Number.isFinite)||duration<=0||duration>168||start<0||stop<start||step<=0||(stop-start)/step>500)return {status:'INPUT REQUIRED',issues:['Check emergency duration, increasing current range and positive scan step (≤500 points).']};return clean(e.emergency_rating(e.from_thermal(thermal(x),kw(o)),duration,start,stop,step));}
export const defaultField=heat=>clean(e.asdict(e.default_field_input(heat)));
const nearestGridNode=(value,start,spacing,count)=>{
 let nearest=0;
 for(let i=1;i<count;i++)if(Math.abs(start+i*spacing-value)<Math.abs(start+nearest*spacing-value))nearest=i;
 return nearest;
};
export function field(o){
 if(!o||typeof o!=='object'||!Array.isArray(o.zones)||!Array.isArray(o.sources)||o.zones.length>30||o.sources.length>60||[...o.zones,...o.sources].some(r=>!r||typeof r!=='object'||Array.isArray(r)))return {status:'INPUT REQUIRED',issues:['Provide valid zone/source objects, domain controls and at most 30 zones / 60 heat sources.']};
 if(typeof o.dryout_on!=='boolean'||o.sources.some(s=>'active' in s&&typeof s.active!=='boolean')||o.zones.some(z=>['active','dry_eligible'].some(k=>k in z&&typeof z[k]!=='boolean')))return {status:'INPUT REQUIRED',issues:['Dry-out, source-active and zone-active/drying switches must be true or false booleans.']};
 const fields=['width_m','depth_m','nodes_x','nodes_y','ambient_c','omega','iterations_per_pass','convergence_tol_c','native_rho_km_w','dry_rho_km_w','dry_threshold_c','max_dry_passes'];
 if(fields.some(k=>typeof o[k]!=='number'||!Number.isFinite(o[k]))||!['nodes_x','nodes_y','iterations_per_pass','max_dry_passes'].every(k=>Number.isInteger(o[k]))||o.nodes_x>51||o.nodes_y>51||o.iterations_per_pass>2000||o.max_dry_passes<1||o.max_dry_passes>15||o.convergence_tol_c<=0)return {status:'INPUT REQUIRED',issues:['Use finite field controls: integer mesh ≤51 nodes/axis, 1–2,000 iterations/pass, 1–15 dry passes and positive tolerance.']};
 if(o.sources.some(s=>s.active!==false&&(!['x_m','y_m','heat_w_m'].every(k=>typeof s[k]==='number'&&Number.isFinite(s[k]))||Math.abs(s.x_m)>=o.width_m/2||s.y_m<=0||s.y_m>=o.depth_m)))return {status:'INPUT REQUIRED',issues:['Active heat sources need finite values and must be strictly inside the domain.']};
 if(o.sources.some(s=>{
  if(s.active===false)return false;
  const i=nearestGridNode(s.x_m,-o.width_m/2,o.width_m/(o.nodes_x-1),o.nodes_x),j=nearestGridNode(s.y_m,0,o.depth_m/(o.nodes_y-1),o.nodes_y);
  return i===0||i===o.nodes_x-1||j===0||j===o.nodes_y-1;
 }))return {status:'INPUT REQUIRED',issues:['A heat source maps to a fixed-temperature boundary node on this mesh. Refine the mesh, enlarge the domain or move the source farther from its edge before solving.']};
 if(o.zones.some(z=>z.active!==false&&!['xmin_m','xmax_m','ymin_m','ymax_m','moist_rho_km_w'].every(k=>typeof z[k]==='number'&&Number.isFinite(z[k]))))return {status:'INPUT REQUIRED',issues:['Every active zone needs finite bounds and resistivity.']};
 return clean(e.solve_field(e.Field2DInput(kw(o))));
}
export function fieldIndependence(o){
 const initial=field(o);if(initial.status==='INPUT REQUIRED')return initial;
 const refine={...o,nodes_x:2*o.nodes_x-1,nodes_y:2*o.nodes_y-1};if(refine.nodes_x>51||refine.nodes_y>51)return {status:'INPUT REQUIRED',issues:['Use ≤26 nodes/axis in the base mesh before doubling resolution.']};
 const refined=field(refine),expanded=field({...refine,width_m:o.width_m*1.5,depth_m:o.depth_m*1.5,nodes_x:Math.min(51,Math.round(refine.nodes_x*1.5)),nodes_y:Math.min(51,Math.round(refine.nodes_y*1.5))});
 const rows=[['Base',initial],['Refined mesh',refined],['Expanded domain',expanded]].map(([name,r])=>({name,status:r.status,maximum_temperature_c:r.final_max_c,energy_imbalance_w_m:r.energy_imbalance_w_m,converged:r.converged,iterations:r.iterations}));
 return {status:priority('REVIEW REQUIRED',initial.status,refined.status,expanded.status),rows,issues:['Compare source-cell temperatures and heat balance before accepting a T4 handoff. Point heat sources move between cells as the mesh changes; mesh maxima are screening diagnostics, not cable surface resistance.'],base:initial,refined_mesh:refined,expanded_domain:expanded};
}
const selectRow=(rows,key,descending=false)=>rows.filter(r=>Number.isFinite(r[key])).sort((a,b)=>descending?b[key]-a[key]:a[key]-b[key])[0]||null;
export function route(x,segs){
 if(!Array.isArray(segs)||!segs.length||segs.length>50||segs.some(s=>!s||typeof s!=='object'||Array.isArray(s)))return {status:'INPUT REQUIRED',issues:['Enter 1–50 valid route segment objects.']};
 for(const [i,s] of segs.entries())for(const k of ['load_a','ambient_c','soil_rho_km_w','burial_depth_m','group_multiplier','length_m','length_ft'])if(k in s&&!Number.isFinite(s[k]))return {status:'INPUT REQUIRED',issues:[`Segment ${i+1}: ${k} must be finite.`]};
 const out=clean(e.solve_route(thermal(x),py(segs)));
 out.segments=out.segments.map((row,i)=>{
  if(row.final_status==='INACTIVE')return row;
  const unresolved=row.install_gate==='INPUT REQUIRED'||row.crossing_gate==='INPUT REQUIRED'||(['HDD / CASING','HDD','CASING'].includes(row.installation)&&!Number.isFinite(row.t4_details?.t4_km_w));
  if(unresolved)return {...row,final_status:'INPUT REQUIRED',ampacity_before_factor_a:null,final_ampacity_a:null,conductor_temp_c:null,temperature_margin_c:null,utilization:null};
  const seg=segs[i];let input={...x,load_a:row.load_a,ambient_c:row.ambient_effective_c,soil_rho_km_w:seg.soil_rho_km_w??x.soil_rho_km_w,burial_depth_m:seg.burial_depth_m??x.burial_depth_m};
  if(Number.isFinite(row.t4_used_km_w))input=setT4(input,row.t4_used_km_w);
  const res=steady(input),amp=Number.isFinite(res.ampacity_a)?res.ampacity_a*row.crossing_rating_factor:null,util=amp>0?row.load_a/amp:null;
  return {...row,ampacity_before_factor_a:res.ampacity_a??null,final_ampacity_a:amp,conductor_temp_c:res.conductor_temp_c??null,temperature_margin_c:res.temperature_margin_c??null,utilization:util,base_status:res.status,final_status:priority(res.status,row.install_gate,row.crossing_gate,row.short_transition_review?'REVIEW REQUIRED':'PASS',util!==null&&util>1?'FAIL':'PASS')};
 });
 const active=out.segments.filter(r=>r.final_status!=='INACTIVE');out.status=active.length?priority(...active.map(r=>r.final_status)):'INPUT REQUIRED';out.governing_segment=selectRow(active,'final_ampacity_a');out.hottest_segment=selectRow(active,'conductor_temp_c',true);out.status_counts=Object.fromEntries([...new Set(active.map(r=>r.final_status))].map(s=>[s,active.filter(r=>r.final_status===s).length]));return out;
}
export const sensitivity=(x,variable,values)=>values.map(value=>({value,...steady({...x,[variable]:value})}));
export function scenarios(x,scenarios){
 if(!Array.isArray(scenarios)||!scenarios.length||scenarios.length>100||scenarios.some(s=>!s||typeof s!=='object'||Array.isArray(s)))return {status:'INPUT REQUIRED',issues:['Enter 1–100 valid scenario objects.']};
 const rows=scenarios.map((s,i)=>{
  const label={index:i+1,name:s.name||`Scenario ${i+1}`,source:s.source,note:s.note};if(s.active===false)return {...label,status:'INACTIVE'};
  let input={...x};for(const k of ['load_a','ambient_c','soil_rho_km_w','burial_depth_m','group_multiplier'])if(k in s)input[k]=s[k];
  if(s.verified_t4_km_w!==undefined){if(!(s.verified_t4_km_w>0)||!Number.isFinite(s.verified_t4_km_w)||!String(s.source||'').trim())return {...label,status:'INPUT REQUIRED',issues:['A verified T4 scenario requires a positive finite T4 and source.']};input=setT4(input,s.verified_t4_km_w);}
  return {...label,...steady(input)};
 });const active=rows.filter(r=>r.status!=='INACTIVE');return {status:active.length?priority(...active.map(r=>r.status)):'INPUT REQUIRED',rows,lowest_ampacity_scenario:selectRow(active,'ampacity_a'),hottest_scenario:selectRow(active,'conductor_temp_c',true)};
}
export function optimize(x,rhos,ambients,depths,groups,margin=0){
 if(!Number.isFinite(margin)||rhos.length*ambients.length*depths.length*groups.length>1000)return {status:'INPUT REQUIRED',issues:['Use a finite temperature margin and at most 1,000 combinations.']};
 const candidates=[];for(const rho of rhos)for(const ambient of ambients)for(const depth of depths)for(const group of groups){
  const res=steady({...x,soil_rho_km_w:rho,ambient_c:ambient,burial_depth_m:depth,group_multiplier:group});
  const effort=Math.abs(rho-x.soil_rho_km_w)/Math.max(x.soil_rho_km_w,1e-9)+Math.abs(ambient-x.ambient_c)/10+Math.abs(depth-x.burial_depth_m)/Math.max(x.burial_depth_m,1e-9)+Math.abs(group-x.group_multiplier)/Math.max(x.group_multiplier,1e-9);
  candidates.push({candidate:`OPT-${String(candidates.length+1).padStart(3,'0')}`,soil_rho_km_w:rho,ambient_c:ambient,burial_depth_m:depth,group_multiplier:group,effort_index:effort,feasible:res.status==='PASS'&&res.temperature_margin_c>=margin&&res.utilization<=1,...res});
 }const feasible=candidates.filter(r=>r.feasible),selected=feasible.sort((a,b)=>a.effort_index-b.effort_index||b.temperature_margin_c-a.temperature_margin_c)[0]||null;
 return {status:selected?'PASS':candidates.some(r=>r.status==='INPUT REQUIRED')?'INPUT REQUIRED':'REVIEW REQUIRED',candidate_count:candidates.length,passing_candidates:feasible.length,selected,candidates,note:'Decision support: recalculate the selected physical design in the detailed thermal engine.'};
}
export const ductOptimize=(spacing,depth,count,minSpacing)=>clean(e.duct_position_optimizer(e.default_3x3_ducts(spacing,depth),count,minSpacing));
export function defaultDuctLayout(spacing,depth){return Number.isFinite(spacing)&&spacing>0&&Number.isFinite(depth)&&depth>spacing?clean(e.default_3x3_ducts(spacing,depth)):[];}
export function ductLayoutOptimize(ducts,count,minSpacing){
 if(!Array.isArray(ducts)||!ducts.length||ducts.length>12||!Number.isInteger(count)||count<1||!Number.isFinite(minSpacing)||minSpacing<0||ducts.some(d=>!d||typeof d.id!=='string'||!d.id.trim()||typeof d.available!=='boolean'||![d.x_m,d.y_m].every(Number.isFinite)||d.y_m<=0)||new Set(ducts.map(d=>d.id)).size!==ducts.length)return {status:'INPUT REQUIRED',issues:['Use 1–12 uniquely named duct positions with finite coordinates, positive center depths, availability flags, positive integer occupancy and non-negative minimum spacing.']};
 const active=ducts.filter(d=>d.available);
 if(active.some((d,i)=>active.slice(0,i).some(p=>Math.hypot(d.x_m-p.x_m,d.y_m-p.y_m)<1e-9)))return {status:'INPUT REQUIRED',issues:['Available duct coordinates must be distinct.']};
 return clean(e.duct_position_optimizer(py(ducts),count,minSpacing));
}
export const qa=()=>clean(e.run_full_qa());
export function conduitT4(x,o){return clean(e.conduit_t4(x.cable_od_m,o.duct_id_m,o.duct_od_m,o.wall_rho,o.fill_rho,x.soil_rho_km_w,x.burial_depth_m,x.group_multiplier));}
export function setT4(x,t4){const iso=clean(e.external_t4(thermal({...x,group_multiplier:1})));return {...x,group_multiplier:t4/iso};}

const num=(r,k)=>{const n=Number(r[k]);return r[k]!==undefined&&r[k]!==null&&r[k]!==''&&Number.isFinite(n)?n:null;};
export function cableMapping(r,materials=[]){
 const material=r.Conductor_Material||r.Conductor_Material_Inferred||'';
 const materialRef=materials.find(m=>/alum|\bal\b/i.test(material)&&m.Material_ID==='AL_1350');
 const referenceAlpha=materialRef?num(materialRef,'Temp_Coeff_degC'):null;
 const coefficientTemp=materialRef&&/@\s*25/.test(materialRef.Resistivity_Unit_Temp||'')?25:20;
 const alpha=referenceAlpha>0?referenceAlpha/(1-referenceAlpha*(coefficientTemp-20)):/copper|\bcu\b/i.test(material)?.00393:/alum|\bal\b/i.test(material)?.00403:null;
 const coefficient_basis=materialRef?`Master Database / CONDUCTOR_MATERIALS / ${materialRef.Material_ID}; material reference, verify alloy and coefficient temperature.`:'Retained thermal-method material reference; verify the exact product coefficient.';
 const unit=(r.Diameter_Unit||'').trim().toLowerCase();
 const legacyOD=num(r,'Cable_OD');
 const od=num(r,'OD_in')>0?num(r,'OD_in')*.0254:legacyOD>0?(/^(in|inch|inches)$/.test(unit)?legacyOD*.0254:/^mm$/.test(unit)?legacyOD/1000:/^cm$/.test(unit)?legacyOD/100:/^(m|meter|metre)$/.test(unit)?legacyOD:null):null;
 const legacyR=num(r,'Rdc_25c');const ru=(r.Rdc_Unit||'').trim().toLowerCase();let raw=null,temp=null,basis='';
 if(num(r,'Rdc_ohm_kft')>0){raw=num(r,'Rdc_ohm_kft')/304.8;const match=String(r.Conductor_Resistivity_Basis||'').match(/(?:@|at|at\s*)\s*(20|25)\s*(?:°|deg|c)/i);temp=match?Number(match[1]):null;basis='Rdc_ohm_kft ÷ 304.8';}
 else if(legacyR>0){if(/^micro-ohm\/ft$/.test(ru))raw=legacyR*1e-6/.3048;else if(/^micro-ohm\/m$/.test(ru))raw=legacyR*1e-6;else if(/ohm\/(1000|kft)/.test(ru))raw=legacyR/304.8;else if(/ohm\/km/.test(ru))raw=legacyR/1000;else if(ru==='ohm/m')raw=legacyR;temp=25;basis=`Rdc_25c (${r.Rdc_Unit||'unit missing'}) converted explicitly to Ω/m`;}
 const resistance=raw!==null&&temp!==null&&alpha!==null?raw/(1+alpha*(temp-20)):null;
 const maxTemp=num(r,'Ug_Conductor_Temp_deg_C')??num(r,'Temp_Rating_deg_C')??num(r,'Temp_Rating_degC');
 const length=(value,unit)=>value===null?null:/^(in|inch|inches)$/i.test(unit)?value*.0254:/^mm$/i.test(unit)?value/1000:/^cm$/i.test(unit)?value/100:/^mil(s)?$/i.test(unit)?value*.0000254:/^m$/i.test(unit)?value:null;
 const dc=length(num(r,'Conductor_OD'),r.Diameter_Unit||''),th=length(num(r,'Insulation_Thickness'),r.Thickness_Unit||''),di=dc>0&&th>0?dc+2*th:null;
 // Preserve the source's micro prefix. Zero stays explicit so the existing
 // construction input gate can reject it rather than derive a replacement.
 const microfarads=num(r,'Capacitance_uF_mi');
 const construction={enclosing_cores:null,screen_alpha:null,conductor_diameter_m:dc,insulation_od_m:di,sheath_mean_diameter_m:null,insulation_rho:null,jacket_rho:null,ks:null,kp:null,epsr:null,tan_delta:null,capacitance_nf_km:microfarads!==null?microfarads*1000/1.609344:null,screen_r20_ohm_km:null};
 const published={ampacity_a:num(r,'Direct_Burial_Ampacity_A')??num(r,'Base_Ampacity_A'),ambient_c:num(r,'Ug_Ambient_Temp_deg_C'),max_temp_c:maxTemp,soil_rho_recorded:num(r,'Soil_Thermal_Resistivity'),soil_rho_unit:'Verify the workbook/source unit before importing',manufacturer:r.Manufacturer||r.Family,source:r.Source_Reference||`Master Database / CABLES / ${r.Cable_ID}`};
 return {construction,published,values:{cable_od_m:od,r20_ohm_m:resistance,alpha_per_c:alpha,max_temp_c:maxTemp,ac_factor:null,dielectric_w_m:null,r_internal_km_w:null,r_dielectric_internal_km_w:null},resistance_raw_ohm_m:raw,resistance_reference_c:temp,resistance_basis:basis,coefficient_basis,material,voltage_v:num(r,'Voltage_Rating_V')>0?num(r,'Voltage_Rating_V'):num(r,'Rated_kV')>0?num(r,'Rated_kV')*1000:null,frequency_hz:num(r,'Frequency_Hz'),source:r.Source_Reference||`Master Database / CABLES / ${r.Cable_ID}`,verification:r.Verification_Status||'Record requires project review',label:[r.Manufacturer||r.Family,r.Conductor_Size||r.Size_kcmil,r.Cable_Type||r.Insulation_Jacket].filter(Boolean).join(' · '),notes:['Only recorded cable properties are imported. Project earth temperature and soil remain unchanged.','Internal thermal paths, AC losses and dielectric losses require construction data. Published ampacity is retained as a reference, without assuming matching conditions.']};
}

export function geometry(base,options){
 const circuits=(options.circuits||[]).filter(c=>c.active!==false),issues=[];
 if(!circuits.length||circuits.length>20)return {status:'INPUT REQUIRED',issues:['Use 1–20 active circuits.']};
 const d=base.cable_od_m,spacing=options.phase_spacing_m;
 if(options.arrangement!=='CUSTOM'&&(!(spacing>=d)||!Number.isFinite(spacing)))return {status:'INPUT REQUIRED',issues:['Phase center spacing must be at least the cable diameter.']};
 const check=steady({...base,load_a:0});if(check.status==='INPUT REQUIRED')return check;
 const positions=[];
 circuits.forEach((c,ci)=>{
  if(![c.x_m,c.depth_m,c.load_a].every(v=>typeof v==='number'&&Number.isFinite(v))||c.load_a<0){issues.push(`${c.name}: enter finite position, depth and non-negative load.`);return;}
  const offsets=options.arrangement==='CUSTOM'?c.offsets:formationOffsets(base.phases,spacing,options.arrangement);
  if(!Array.isArray(offsets)||offsets.length!==base.phases||offsets.some(p=>!Array.isArray(p)||p.length!==2||p.some(v=>typeof v!=='number'||!Number.isFinite(v)))){issues.push(`${c.name}: enter ${base.phases} custom phase offsets, X and depth in meters.`);return;}
  offsets.forEach(([dx,dy],phase)=>positions.push({x_m:c.x_m+dx,y_m:c.depth_m+dy,circuit:ci,phase,load_a:c.load_a,name:c.name}));
 });
 for(let i=0;i<positions.length;i++){const a=positions[i];if(a.y_m<=d/2)issues.push(`${a.name}: all cables must remain fully underground.`);for(let j=0;j<i;j++)if(Math.hypot(a.x_m-positions[j].x_m,a.y_m-positions[j].y_m)<d*(1-1e-8))issues.push('Cable positions overlap; increase circuit or phase spacing.');}
 const fixed=options.rating_mode==='FIXED NEIGHBORS';
 if(!fixed&&circuits[0].load_a===0)issues.push('Circuit 1 needs a positive load for proportional rating. Use fixed neighbors to rate an unloaded circuit.');
 if(issues.length)return {status:'INPUT REQUIRED',issues:[...new Set(issues)]};
 const matrix=positions.map((a,i)=>positions.map((b,j)=>base.soil_rho_km_w/(2*Math.PI)*(i===j?Math.acosh(2*a.y_m/d):Math.log(Math.hypot(a.x_m-b.x_m,a.y_m+b.y_m)/Math.hypot(a.x_m-b.x_m,a.y_m-b.y_m)))));
 const solveAt=loads=>{let temps=positions.map(()=>base.ambient_c),history=[];for(let it=0;it<400;it++){
  const heat=positions.map((p,i)=>loads[p.circuit]**2*base.r20_ohm_m*(1+base.alpha_per_c*(temps[i]-20))*base.ac_factor);
  const next=positions.map((p,i)=>base.ambient_c+heat[i]*base.r_internal_km_w+base.dielectric_w_m*base.r_dielectric_internal_km_w+matrix[i].reduce((t,r,j)=>t+r*(heat[j]*(options.metallic_factor||1)+base.dielectric_w_m),0));
  if(next.some(t=>!Number.isFinite(t)||t>1e6))return {converged:false,temps:null,history};
  const delta=Math.max(...next.map((t,i)=>Math.abs(t-temps[i])));if(it<5||it%10===0||delta<1e-7)history.push({iteration:it+1,maximum_temperature_c:Math.max(...next),residual_c:delta});
  temps=next;if(delta<1e-7)return {converged:true,temps,history};
 }return {converged:false,temps:null,history};};
 const actualLoads=circuits.map(c=>c.load_a),actual=solveAt(actualLoads);
 const allowed=r=>r.converged&&Math.max(...r.temps)<=base.max_temp_c;
 const bisect=(loads,start)=>{let lo=0,hi=Math.max(1,start);if(!allowed(solveAt(loads(0))))return null;while(hi<1e6&&allowed(solveAt(loads(hi))))hi*=2;if(hi>=1e6&&allowed(solveAt(loads(hi))))return null;for(let it=0;it<50;it++){const m=(lo+hi)/2;if(allowed(solveAt(loads(m))))lo=m;else hi=m;}return lo;};
 const scale=fixed?null:bisect(v=>actualLoads.map(l=>l*v),1);
 const ratings=fixed?circuits.map((c,ci)=>bisect(v=>actualLoads.map((l,i)=>ci===i?v:l),Math.max(c.load_a,500))):circuits.map(c=>scale===null?null:c.load_a*scale);
 const rows=circuits.map((c,ci)=>({name:c.name,load_a:c.load_a,conductor_temp_c:actual.temps?Math.max(...actual.temps.filter((_,i)=>positions[i].circuit===ci)):null,rating_a:ratings[ci],rating_basis:fixed?'Other circuit currents fixed':'All currents proportional'}));
 const temp=actual.temps?Math.max(...actual.temps):null,ampacity=ratings[0];
 return {status:!actual.converged?'FAIL':temp>base.max_temp_c?'FAIL':ratings.some(v=>v===null)?'INPUT REQUIRED':'PASS',issues:!actual.converged?['Coupled temperature solver diverged at the entered loads.']:ratings.some(v=>v===null)?['No rating is available while fixed neighbors already exceed the conductor limit.']:[],ampacity_a:ampacity,conductor_temp_c:temp,temperature_margin_c:temp!==null?base.max_temp_c-temp:null,utilization:fixed?(ampacity>0?circuits[0].load_a/ampacity:null):(scale>0?1/scale:null),load_scale_rating:scale,converged:actual.converged,iterations:actual.history.at(-1)?.iteration,convergence_history:actual.history,circuits:rows,positions:positions.map((p,i)=>({...p,temperature_c:actual.temps?.[i]??null,heat_w_m:actual.temps?p.load_a**2*base.r20_ohm_m*(1+base.alpha_per_c*(actual.temps[i]-20))*base.ac_factor*(options.metallic_factor||1)+base.dielectric_w_m:null})),matrix,thermal_method:'Coupled homogeneous-soil image-source matrix; common construction for every circuit.',t4_km_w:Math.max(...matrix.map(r=>r.reduce((a,b)=>a+b,0))),total_heat_w_m:actual.temps?positions.reduce((q,p,i)=>q+p.load_a**2*base.r20_ohm_m*(1+base.alpha_per_c*(actual.temps[i]-20))*base.ac_factor*(options.metallic_factor||1)+base.dielectric_w_m,0):null};
}
