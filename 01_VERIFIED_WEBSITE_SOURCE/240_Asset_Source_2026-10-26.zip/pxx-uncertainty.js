/** Research screen for annual PV energy probability-of-exceedance.
 * Independent Gaussian annual-energy uncertainty budget (not bankable).
 * Based on PVsyst help P50/P90, Sandia PVPMC uncertainty quantification,
 * and IEA PVPS Task 16 solar resource handbook. Independence is the legacy
 * default; optional user-evidenced resource/model/availability correlations
 * are screened using a valid positive-semidefinite correlation matrix.
 */
const Z={P50:0,P75:.6744897501960817,P90:1.2815515655446004,P95:1.6448536269514722,P99:2.3263478740408408};
const finite=(x,name,lo,hi)=>{if(!Number.isFinite(x)||x<lo||x>hi)throw Error(`${name} must be finite ${lo}..${hi}`);return x};
export function parseAnnualYieldText(text){
 if(typeof text!=='string')throw Error('Yearly energy series required');
 const tokens=text.split(/[,;\s]+/).filter(Boolean);
 if(tokens.length<5)throw Error('At least five independent annual yield entries required');
 if(tokens.length>100)throw Error('Maximum 100 annual entries');
 return tokens.map((s,i)=>finite(Number(s),`annualYield_${i+1}`,0.01,1e12));
}
export function empiricalQuantile(sorted,p){if(!Array.isArray(sorted)||!sorted.length)throw Error('Samples required');const at=(sorted.length-1)*p,i=Math.floor(at),f=at-i;return sorted[i]*(1-f)+sorted[Math.min(i+1,sorted.length-1)]*f;}
export function energyUncertaintyBudget(input){
 if(!input||typeof input!=='object')throw Error('Energy uncertainty inputs required');
 const x=input.years; if(!Array.isArray(x)||x.length<5||x.length>100)throw Error('Five to one hundred annual energy samples required');
 const e=x.map((v,i)=>finite(v,`year_${i+1}`,0.01,1e12));
 const n=e.length,mean=e.reduce((s,v)=>s+v,0)/n;
 const sampleSd=Math.sqrt(e.reduce((s,v)=>s+(v-mean)**2,0)/(n-1));
 const meanShiftPct=finite(input.meanShiftPct??0,'meanShiftPct',-50,50);
 const uResourcePct=finite(input.uResourcePct??0,'uResourcePct',0,35);
 const uModelPct=finite(input.uModelPct??0,'uModelPct',0,35);
 const uAvailabilityPct=finite(input.uAvailabilityPct??0,'uAvailabilityPct',0,35);
 const p50=mean*(1+meanShiftPct/100);
 if(p50<=0)throw Error('Shifted P50 cannot be negative/zero');
 const others=[uResourcePct,uModelPct,uAvailabilityPct].map(u=>p50*u/100);
 const independentSigma=Math.hypot(sampleSd,...others);
 const positiveSigma=Math.hypot(sampleSd,others.reduce((s,u)=>s+u,0));
 // Optional correlations apply ONLY to the three user-specified non-weather
 // components. Sample interannual weather variability stays independent here.
 // 3x3 R must be symmetric, have unit diagonal and be positive semidefinite.
 // Reject impossible coefficient combinations rather than displaying a false P90.
 const named=['resourceModel','resourceAvailability','modelAvailability'];
 const userCorrelations=input.correlations;
 if(userCorrelations!==undefined&&(!userCorrelations||typeof userCorrelations!=='object'||Array.isArray(userCorrelations)))throw Error('correlations must be an object');
 const corr=Object.fromEntries(named.map(k=>[k,finite(userCorrelations?.[k]??0,`correlations.${k}`,-1,1)]));
 if(userCorrelations&&Object.keys(userCorrelations).some(k=>!named.includes(k)))throw Error('Unknown correlation coefficient; use resourceModel, resourceAvailability, modelAvailability');
 const {resourceModel:rm,resourceAvailability:ra,modelAvailability:ma}=corr;
 const determinant=1+2*rm*ra*ma-rm*rm-ra*ra-ma*ma;
 if(determinant< -1e-10)throw Error('Correlation matrix is not positive semidefinite: the specified coefficients are mutually inconsistent');
 const varianceCorrelated=independentSigma**2+2*(rm*others[0]*others[1]+ra*others[0]*others[2]+ma*others[1]*others[2]);
 if(varianceCorrelated< -1e-9*Math.max(1,independentSigma**2))throw Error('Invalid negative variance from correlation model');
 const sigmaCorrelationAdjusted=Math.sqrt(Math.max(0,varianceCorrelated));
 const nonphysical=[];
 const nonnegative=(raw,q,label)=>{if(raw<=0){nonphysical.push(`${label} ${q} mathematically nonpositive under the unbounded Gaussian assumption; no physical energy percentile is reported.`);return null}return raw};
 const quantiles={};for(const [q,z] of Object.entries(Z))quantiles[q]=nonnegative(p50-z*independentSigma,q,'Independent');
 const stress={};for(const [q,z] of Object.entries(Z))stress[q]=nonnegative(p50-z*positiveSigma,q,'Correlation stress');
 const correlated={};for(const [q,z] of Object.entries(Z))correlated[q]=nonnegative(p50-z*sigmaCorrelationAdjusted,q,'User-correlation');
 const sorted=e.toSorted((a,b)=>a-b);
 const empirical={P50:empiricalQuantile(sorted,.5),P75:empiricalQuantile(sorted,.25),P90:empiricalQuantile(sorted,.1),P95:empiricalQuantile(sorted,.05)};
 const warnings=[
 ...nonphysical,
 'NOT BANKABLE: Gaussian P-values assume annual yields are representative of a stationary long-term resource and uncertainties are normally distributed.',
 'Weather interannual variability is calculated as an uncorrected sample standard deviation; serial correlation, trends and measurement representativeness are not tested.',
 'Resource/model/availability uncertainty terms are user-entered 1-sigma percentages; independence can understate error where correlated or double-counted.',
 'User-entered correlation coefficients describe assumptions, not measured covariance or a financing-approved joint probability model.',
 'The optional covariance matrix covers only resource/model/availability terms; interannual weather variability is assumed independent and cannot be inferred from a short time series.',

 'These are ANNUAL energy exceedance levels only, not scaled hourly or monthly P90 weather series.',
 'Check whether year samples already include changes in equipment, curtailment, availability or degradation; mixtures can invalidate the calculation.',
 'Model bias (including systematic source mismatch), resource representativeness, market financing requirements and long-term climatology require project evidence.'
 ];
 if(n<15)warnings.push('SHORT HISTORICAL RECORD: fewer than 15 annual samples; Gaussian and empirical P90 have considerable sampling uncertainty.');
 if(input.uResourcePct===undefined||input.uModelPct===undefined||input.uAvailabilityPct===undefined)warnings.push('Unspecified uncertainty terms default to 0, not verified negligible.');
 if(Math.abs(meanShiftPct)>1e-9)warnings.push('User-specified mean shift is an assumption requiring independent source/bias evidence.');
 if([rm,ra,ma].some(x=>Math.abs(x)>1e-12))warnings.push('Nonzero user correlation assumptions changed annual Pxx. Preserve supporting covariance evidence and audit risk of double-counted resource/model errors.');
 return {samples:n,annualMeanKWh:mean,sampleSDkWh:sampleSd,sampleCVPct:100*sampleSd/mean,shiftedP50KWh:p50,otherSigmasKWh:others,sigmaIndependentKWh:independentSigma,sigmaStressKWh:positiveSigma,sigmaCorrelationAdjustedKWh:sigmaCorrelationAdjusted,correlations:corr,correlationDeterminant:determinant,gaussian:quantiles,correlationAdjusted:correlated,highCorrelationStress:stress,empirical,confidence:'SCREENING ONLY',warnings,method:'Annual Gaussian exceedance screening; independent RSS legacy baseline, optional PSD-checked covariance for three non-weather uncertainty terms; interannual weather variability assumed independent; sensitivity stress with fully positively correlated non-weather terms.'};
}
