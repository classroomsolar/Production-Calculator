/** Research-only OPT-IN AC yield handoff from 2D bifacial ray-screen to
 * existing v1.7 PV diode/PVWatts-loss simulation. NEVER automatically overwrite
 * the preliminary or v1.7 production results. Reuses matched weather and
 * equipment config, with deliberate front-only vs bifacial comparison.
 */
import {simulateDetailedHourly} from './pv-detailed-v17.js';
const finite=Number.isFinite;
function ensure(x,msg){if(!x)throw Error(msg)}
export function buildBifacialWeatherPair(bifacialState,productionState){
 const b=bifacialState,p=productionState;
 ensure(b?.result?.hourly?.length&&b.prepared?.length,'Run the bifacial optical year first');
 ensure(p?.config&&p?.result&&p?.upstream,'Run the v1.7 detailed engineering model with current equipment inputs first');
 ensure(b.upstream&&b.upstream===p.upstream,'Optical and production cases do not use the same current weather study; rerun both');
 ensure(!p.config.losses?.linearShadePct,'Set v1.7 linearShadePct=0, because the optical model already includes geometrical row shading (avoid double count)');
 const bh=b.result.hourly,prepared=b.prepared;
 ensure(bh.length===prepared.length&&[8760,8784].includes(bh.length),'Complete matching full-year optical/weather records required');
 const front=[],both=[];
 for(let i=0;i<bh.length;i++){
  const d=bh[i],w=prepared[i];
  ensure(d?.timestamp_utc===w?.timestamp_utc,`Weather/optical UTC alignment failed at hour ${i+1}`);
  ensure([d.front_wm2,d.effective_wm2,w.temp_air_c,w.wind_speed_mps].every(finite),`Nonfinite optical or meteorological value at hour ${i+1}`);
  ensure(d.front_wm2>=0&&d.effective_wm2>=0&&d.front_wm2<=1800&&d.effective_wm2<=1800,`Optical POA outside diode model range at hour ${i+1}`);
  ensure(d.effective_wm2+1e-8>=d.front_wm2,`Effective bifacial irradiance must not be below front-only at hour ${i+1}`);
  const rec={...w,poa_wm2:d.front_wm2};
  front.push(rec);both.push({...rec,poa_wm2:d.effective_wm2});
 }
 return {front,both,config:structuredClone(p.config),hours:bh.length,geometry:b.input,source:b.source};
}
export function simulateCoupledBifacialAC(bifacialState,productionState){
 const x=buildBifacialWeatherPair(bifacialState,productionState);
 const front=simulateDetailedHourly(x.front,x.config),combined=simulateDetailedHourly(x.both,x.config);
 ensure(front.hourCount===x.hours&&combined.hourCount===x.hours,'Production / optical hour count mismatch');
 const a=front.annual.poiExportKWh,z=combined.annual.poiExportKWh,g=z-a;
 ensure(finite(g)&&g>=-1e-6,'Unexpected bifacial conversion loss: inspect numeric inputs before interpreting');
 return {method:'Experimental Bifacial optical -> v1.7 detailed diode/PVWatts POI yield adapter, identical system topology, weather and electrical loss inputs',classification:'RESEARCH SCREEN ONLY - NOT BANKABLE OR OEM QUALIFIED',hours:x.hours,geometry:x.geometry,weatherSource:x.source,moduleProvenance:x.config.provenance||'UNVERIFIED USER/SYNTHETIC',frontOnly:{annual:front.annual,lossStages:front.lossStages},bifacial:{annual:combined.annual,lossStages:combined.lossStages},gainPoiKWh:g,gainPoiPct:a>0?100*g/a:null,geometryAssumptions:['Fixed tilt or horizontal single-axis infinite 2D level-ground rows only','Rear conversion is scalar bifaciality/structural loss; spatial electrical rear mismatch omitted','Faiman temperature driven by total effective POA is screening simplification, not calibrated rear-side thermal behavior','IAM and soiling scalar factors are applied to effective POA, not front/back differentiated','A residual user-set mismatchPct may still cover other electrical mismatch, but partial-shade substring loss is NOT automatically applied'],warnings:['NOT A VALIDATED PROJECT ENERGY FORECAST. Historical/test or user-provided PV coefficients must be qualified before design use.','AC outputs inherit v1.7 PVWatts rather than a voltage-dependent CEC/Sandia inverter curve.','Do not compare the result to unrelated v1.5 or original v1.7 POA geometry outputs as a like-for-like production benchmark.'],hourlyComparison:front.hourly.map((r,i)=>({timestamp_utc:r.timestamp_utc,front_poa_wm2:x.front[i].poa_wm2,bifacial_effective_poa_wm2:x.both[i].poa_wm2,front_poi_kw:r.poi_export_kw,bifacial_poi_kw:combined.hourly[i].poi_export_kw}))};
}
