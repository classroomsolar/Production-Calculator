/** Batch 4: limited DC PV circuit screening, NOT NEC approval. Numeric inputs explicitly supplied by user. */
const valid=(x,n)=>{if(!Number.isFinite(x))throw Error(n+' must be finite');return x};
export function dcCircuitScreen(c){
 for(const k of ['iscA','impA','vmpV','vocV','tempCoeffVocPctC','minDesignTempC','maxOperatingTempC','seriesModules','parallelStrings','loopLengthM','ohmPerKm20C','alphaPerC','conductorTempC','baseAmpacityA','tempFactor','adjustFactor','maxSystemVoltageV','maxModuleFuseA'])valid(c[k],k);
 if(!Number.isInteger(c.seriesModules)||c.seriesModules<1||!Number.isInteger(c.parallelStrings)||c.parallelStrings<1)throw Error('Series and parallel counts must be positive integers');
 for(const k of ['iscA','impA','vmpV','vocV','loopLengthM','ohmPerKm20C','baseAmpacityA','maxSystemVoltageV','maxModuleFuseA'])if(c[k]<=0)throw Error(k+' must be positive');
 if(c.impA>c.iscA||c.vmpV>=c.vocV)throw Error('PV nameplate voltage/current values inconsistent');
 if(c.tempCoeffVocPctC>=0||c.tempCoeffVocPctC< -1)throw Error('Voc coefficient outside typical c-Si screening range; manual engineering review');
 if(c.minDesignTempC>25||c.maxOperatingTempC<c.minDesignTempC)throw Error('Invalid input temperature range');
 if(c.tempFactor<=0||c.tempFactor>1||c.adjustFactor<=0||c.adjustFactor>1)throw Error('Correction factors must lie in (0,1]');
 if(c.alphaPerC<0||c.alphaPerC>.01||c.conductorTempC< -40||c.conductorTempC>150)throw Error('Conductor temperature coefficient/temperature invalid');
 // The same loop resistance cannot represent both a common combiner feeder
 // and multiple independently routed strings. Explicit topology is required
 // for project use. The historical default 'common_feeder' preserves the
 // former screening math only when its installation assumption is true.
 const topology=c.topology??'common_feeder';
 if(!['common_feeder','individual_string_loops'].includes(topology))throw Error('Conductor routing topology must be common_feeder or individual_string_loops');
 const vocCold=c.vocV*(1+c.tempCoeffVocPctC/100*(c.minDesignTempC-25))*c.seriesModules;
 const stringImp=c.impA,totalImp=c.impA*c.parallelStrings;
 const loops=topology==='individual_string_loops'?c.parallelStrings:1;
 const loopImp=topology==='individual_string_loops'?stringImp:totalImp;
 const imax=1.25*c.iscA*(topology==='individual_string_loops'?1:c.parallelStrings);
 const arrayMaximumCurrentA=1.25*c.iscA*c.parallelStrings;
 // 2023 NEC 690.8(B) conventional non-electronic current screen: larger of 125% Imax uncorrected or Imax / corrections.
 const minNameplateAmpacity=Math.max(1.25*imax,imax/(c.tempFactor*c.adjustFactor));
 const corrected=c.baseAmpacityA*c.tempFactor*c.adjustFactor;
 const ampacityPass=c.baseAmpacityA+1e-9>=1.25*imax&&corrected+1e-9>=imax;
 const loopR=c.ohmPerKm20C*c.loopLengthM/1000*(1+c.alphaPerC*(c.conductorTempC-20));
 const dropV=loopImp*loopR,dropPct=100*dropV/(c.vmpV*c.seriesModules),watts=loops*loopImp*loopImp*loopR;
 const reverseFeedPotentialA=Math.max(0,c.parallelStrings-1)*1.25*c.iscA;
 const warnings=[`Conductor routing model: ${topology==='common_feeder'?'one common PV combiner feeder':'independent identical DC string loops'}. Resistance, ampacity and loss apply to each modeled routed circuit, not an arbitrarily mixed topology.`, 'Preliminary screening only: no automatic PV module reverse-current protection/OCPD decision; fuse requirement depends on source interconnections and protective equipment.','Conductor corrected ampacity entered by user; cable insulation, ambient, grouping, rooftop adjustments, terminals, OCPD and installation type not independently checked.','Voltage drop and I²R evaluated at STC Imp, not time-varying maximum-power or short-circuit current.','Linear temperature coefficient method subject to NEC 690.7 and actual OEM listing, ASHRAE design ambient and applicable AHJ edition.'];
 return {status:'DC_PV_ENGINEERING_SCREEN_ONLY',results:{topology,modelledConductorLoops:loops,currentPerConductorAtSTCA:loopImp,arrayMaximumSourceCurrentA:arrayMaximumCurrentA,vocColdV:vocCold,vocLimitPass:vocCold<=c.maxSystemVoltageV,maximumCurrentA:imax,minimumBaseAmpacityA:minNameplateAmpacity,enteredBaseAmpacityA:c.baseAmpacityA,correctedAmpacityA:corrected,ampacityScreenPass:ampacityPass,parallelStringImpA:totalImp,reverseSourceCurrentScreenA:reverseFeedPotentialA,moduleMaximumSeriesFuseA:c.maxModuleFuseA,dcLoopResistanceOhm:loopR,dcDropV:dropV,dcDropPercent:dropPct,dcConductorLossW:watts},warnings,reference:'2023 NEC 690.7/690.8 screen; engineering limits apply'};
}
