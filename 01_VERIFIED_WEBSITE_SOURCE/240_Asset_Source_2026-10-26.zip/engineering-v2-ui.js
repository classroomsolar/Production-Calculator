/** Solar Resource Studio: engineering verification workbench v1.3.
 * Loads after the base and advanced modules; no cloud accounts or storage.
 */
import {analyze,parseCSV,normalizeArchive,normalizePVGIS} from './engine.js';
import {computeEngineering} from './advanced-engine.js';
import {parseEPW,parseHorizonCSV,normalizePVGISHorizon,shadeStudy,referenceBenchmark,interannualStatistics,reconcileResources,checkHourlySeries} from './engineering-v2.js';
const $=id=>document.getElementById(id);
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const f=(x,n=2)=>Number.isFinite(x)?x.toLocaleString(undefined,{minimumFractionDigits:0,maximumFractionDigits:n}):'—';
const csv=rows=>{if(!rows?.length)return '';const cols=Object.keys(rows[0]);const e=v=>{const s=String(v??'');return /[,"\r\n]/.test(s)?'"'+s.replace(/"/g,'""')+'"':s};return [cols.join(','),...rows.map(r=>cols.map(c=>e(r[c])).join(','))].join('\r\n')};
function download(name,data,mime='text/csv'){const a=document.createElement('a'),url=URL.createObjectURL(new Blob([data],{type:mime}));a.href=url;a.download=name;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),5000)}
const base=()=>window.SolarResourceStudio?.getState?.()||null;
const panel={active:'imports',horizon:[],horizonName:'',shade:null,multi:null,reconcile:null,benchmark:null,runBusy:false,referenceResult:null,loadedResult:null};
const model=()=>$('advModel')?.value||'reindl';
function analyzed(){const s=base();if(!s?.result?.summary)return null;if(panel.referenceResult!==s.result||panel.referenceResultModel!==model()){
 panel.referenceResult=s.result;panel.referenceResultModel=model();panel.loadedResult=computeEngineering(s.result,s.config,model());panel.shade=null;panel.reconcile=null;
 }return panel.loadedResult;}
function wrap(){return '<div class="v2-muted">Complete an hourly resource analysis in the original Project &amp; Site panel first.</div>'}
function reportTable(rows,columns,limit=60){return `<div class="v2-tablewrap"><table class="v2-table"><thead><tr>${columns.map(c=>`<th>${esc(c[1])}</th>`).join('')}</tr></thead><tbody>${rows.slice(0,limit).map(r=>`<tr>${columns.map(c=>`<td>${typeof r[c[0]]==='number'?f(r[c[0]]):esc(r[c[0]])}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`}
const markup=`<section id="engineeringCompletion" class="v2" aria-label="Engineering completion modules"><div class="v2-heading"><div><span class="eyebrow">ENGINEERING MODULES · V1.3</span><h2>Data verification, shading &amp; climate uncertainty</h2><p>Reproducible engineering screens with explicit data and modeling limitations. No cloud case storage.</p></div><span id="v2Status" class="status muted">READY FOR REVIEW</span></div><div class="v2-tabs" role="tablist"><button data-v2="imports" class="active" type="button">EPW &amp; imports</button><button data-v2="shading" type="button">Horizon &amp; row shading</button><button data-v2="multi" type="button">Multi-year study</button><button data-v2="reconcile" type="button">Source reconciliation</button><button data-v2="verification" type="button">Numerical verification</button></div><div id="v2Content" class="v2-content" aria-live="polite"></div></section>`;
const main=document.querySelector('main > footer');if(main)main.insertAdjacentHTML('beforebegin',markup);else throw Error('Engineering verification panel cannot locate original footer');
function render(){document.querySelectorAll('[data-v2]').forEach(b=>b.classList.toggle('active',b.dataset.v2===panel.active));const r={imports,shading,multi,reconcile,verification}[panel.active]||imports;try{r()}catch(err){$('v2Content').textContent='Engineering panel error: '+err.message;console.error(err)}}
function setInfo(msg){$('v2Status').textContent=msg}
function imports(){const s=base(),a=analyzed();$('v2Content').innerHTML=`<h3>EPW, TMY and hourly CSV inputs</h3><p>The source selector in <b>Hourly weather</b> now supports .epw files (EnergyPlus local-standard-time weather). EPW hours are ending hours 1–24; Global / Direct Normal / Diffuse Horizontal Radiation are Wh/m² integrated over one hour and can be numerically read as mean W/m². EPW latitude/longitude and fixed standard timezone are taken from its LOCATION record.</p><div class="v2-info-grid"><article><b>EPW</b><p>Select “EPW” above, upload the file, then run the resource analysis. Validates 8,760 or 8,784 intervals, timezone, missing-value sentinels, record continuity and source location. Does not invent missing weather.</p></article><article><b>PVGIS TMY</b><p>Select “PVGIS typical meteorological year” above. Representative source years are retained in weather provenance. The TMY synthetic 2001 chronology is not a measured calendar year.</p></article><article><b>UTC hourly CSV</b><p>Use the original timestamp_utc, ghi_wm2, dni_wm2, dhi_wm2, temp_air_c, wind_speed_mps format, with ISO UTC timestamps. Irradiance interval meaning must be documented by the source.</p></article></div>${a?`<h3>Current data validation</h3>${reportTable([{source:s.weatherInfo?.label||'Uploaded',type:s.config.kind,rows:a.stats.hours,start:a.hourly[0].timestamp_utc,end:a.hourly.at(-1).timestamp_utc,offset:s.config.offsetHours,flags:a.warnings.length}], [['source','Source'],['type','Kind'],['rows','Hours'],['start','First UTC hour'],['end','Last UTC hour'],['offset','Solar offset (h)'],['flags','Review flags']])}<p class="v2-muted">${esc(s.weatherInfo?.irradianceConvention||'Irradiance convention documented in current provider source and offsets.')}</p>`:wrap()}`}
function shading(){const s=base(),a=analyzed();$('v2Content').innerHTML=`<h3>Horizon and inter-row shading screen</h3><p>Import a site-survey skyline in true-north clockwise degrees (azimuth_deg,elevation_deg), or use a flat zero-degree horizon. The model screens direct-beam blocking; it does not modify the original unshaded weather dataset.</p><div class="v2-fields"><label>Horizon skyline (.csv)<input id="v2Horizon" type="file" accept=".csv,text/csv"></label><label>Array pitch, m (row start to row start)<input id="v2Pitch" type="number" min="0.1" step="0.1" value="4"></label><label>Module slant length, m<input id="v2Slant" type="number" min="0.1" step="0.1" value="2.2"></label><label>Include inter-row direct shading<select id="v2IncludeRows"><option value="no">No — horizon only</option><option value="yes">Yes — screening geometry</option></select></label><button id="v2ShadeRun" class="v2-strong" type="button" ${a?'':'disabled'}>Calculate screened POA</button><button id="v2DEMHorizon" type="button" ${a?'':'disabled'}>Fetch PVGIS terrain horizon (DEM)</button><button id="v2HorizonTemplate" type="button">Download horizon template</button></div><p id="v2HorizonStatus" class="v2-muted">${panel.horizon.length?`${panel.horizon.length} horizon points loaded: ${esc(panel.horizonName)}`:'Flat skyline (0°). No skyline file uploaded.'}</p><div id="v2ShadeResult">${panel.shade?shadeMarkup(panel.shade):a?'Choose shading options, then calculate.':wrap()}</div>`;
 $('v2Horizon').addEventListener('change',async e=>{const file=e.target.files?.[0];if(!file)return;try{const pts=parseHorizonCSV(await file.text());panel.horizon=pts;panel.horizonName=file.name;panel.shade=null;setInfo('HORIZON IMPORTED');render()}catch(err){$('v2HorizonStatus').textContent='Horizon file invalid: '+err.message}});
 $('v2DEMHorizon').addEventListener('click',async()=>{
  const status=$('v2HorizonStatus'),button=$('v2DEMHorizon');button.disabled=true;status.textContent='Requesting PVGIS digital elevation horizon skyline...';
  try{
   const params=new URLSearchParams({lat:String(s.config.lat),lon:String(s.config.lon),outputformat:'json'});
   const url='https://re.jrc.ec.europa.eu/api/v5_3/printhorizon?'+params;
   const response=await fetch(url);if(!response.ok)throw Error('PVGIS terrain API HTTP '+response.status);
   const payload=await response.json(),norm=normalizePVGISHorizon(payload);
   panel.horizon=norm.points;panel.horizonName='JRC PVGIS DEM terrain skyline, not a local shade survey';panel.shade=null;setInfo('TERRAIN SKYLINE LOADED');render();
  }catch(err){status.textContent='Automated DEM horizon unavailable: '+err.message+'. Import a survey horizon CSV instead.';setInfo('TERRAIN API UNAVAILABLE')}
  finally{button.disabled=false}
 });
 $('v2HorizonTemplate').addEventListener('click',()=>download('horizon_survey_template.csv','azimuth_deg,elevation_deg\r\n0,0\r\n90,0\r\n180,0\r\n270,0\r\n'));
 $('v2ShadeRun').addEventListener('click',()=>{try{const opts={horizon:panel.horizon,rowsEnabled:$('v2IncludeRows').value==='yes',pitchM:Number($('v2Pitch').value),moduleSlantM:Number($('v2Slant').value),model:model()};panel.shade=shadeStudy(a.hourly,s.config,opts);$('v2ShadeResult').innerHTML=shadeMarkup(panel.shade);setInfo('SCREENING COMPLETE')}catch(err){$('v2ShadeResult').textContent='Shading input error: '+err.message}});
}
function shadeMarkup(r){return `<div class="v2-statrow"><article><small>Unshaded POA</small><b>${f(r.unshadedPoa)}</b> kWh/m²</article><article><small>Horizon beam loss</small><b>${f(r.horizonLoss)}</b> kWh/m²</article><article><small>Row beam loss</small><b>${f(r.rowLoss)}</b> kWh/m²</article><article><small>Screened POA</small><b>${f(r.screenedPoa)}</b> kWh/m²</article><article><small>Screening loss</small><b>${f(r.lossPct)}%</b></article></div>${reportTable(r.byMonth,[['month','UTC month'],['unshaded','Base POA'],['horizonLoss','Horizon loss'],['rowLoss','Row loss'],['shaded','Remaining POA']])}<button id="v2ShadeDownload" type="button" onclick="window.SolarV2ExportShade()">↓ Screened hourly CSV</button>${r.warnings.map(w=>`<p class="v2-warning">${esc(w)}</p>`).join('')}`}
window.SolarV2ExportShade=()=>{if(panel.shade)download('shading_screen_hourly.csv',csv(panel.shade.series))};
function multi(){const s=base(),a=analyzed();const defaultEnd=Math.min(2025,new Date().getUTCFullYear()-1);$('v2Content').innerHTML=`<h3>Interannual resource: consistent ERA5 reanalysis</h3><p>Download complete, non-overlapping calendar years from the Open-Meteo Historical API, explicitly selecting ERA5 (not the changing best-match mosaic). Report sample means, variability and empirical annual quantiles. This is an uncertainty screen, <b>not a bankable exceedance P50/P90</b>.</p><div class="v2-fields"><label>First year<input id="v2StartYear" type="number" min="1990" max="2025" value="${defaultEnd-4}"></label><label>Last year (inclusive)<input id="v2EndYear" type="number" min="1990" max="2025" value="${defaultEnd}"></label><button type="button" class="v2-strong" id="v2RunMulti" ${a?'':'disabled'}>Calculate 2–10 annual years</button></div><p id="v2MultiProgress" class="v2-muted">${panel.multi?`Latest comparison: ${panel.multi.count} complete years`:a?'No multi-year analysis in this session.':'Run a primary resource study first.'}</p><div id="v2MultiResult">${panel.multi?multiMarkup(panel.multi):''}</div>`;
 $('v2RunMulti').addEventListener('click',async()=>{if(panel.runBusy)return;let start=Number($('v2StartYear').value),end=Number($('v2EndYear').value);const p=$('v2MultiProgress');if(!Number.isInteger(start)||!Number.isInteger(end)||end<start||end-start+1<2||end-start+1>10||start<1940||end>new Date().getUTCFullYear()-1){p.textContent='Choose 2–10 consecutive complete past calendar years.';return}
  panel.runBusy=true;$('v2RunMulti').disabled=true;const records=[];panel.multi=null;
  try{for(let year=start;year<=end;year++){
    p.textContent=`Acquiring and independently validating ${year} (${year-start+1}/${end-start+1})...`;
    const params=new URLSearchParams({latitude:String(s.config.lat),longitude:String(s.config.lon),start_date:`${year}-01-01`,end_date:`${year}-12-31`,models:'era5',hourly:'shortwave_radiation,direct_normal_irradiance,diffuse_radiation,temperature_2m,wind_speed_10m',timezone:'GMT',wind_speed_unit:'kmh',...(s.config.elevation===null?{}:{elevation:String(s.config.elevation)})});
    const url='https://archive-api.open-meteo.com/v1/archive?'+params;
    const response=await fetch(url);if(!response.ok)throw Error(`ERA5 ${year}: HTTP ${response.status}`);const data=await response.json();if(data.error)throw Error(`ERA5 ${year}: ${data.reason}`);
    const rows=normalizeArchive(data);const check=checkHourlySeries(rows);
    if(!check.ok)throw Error(`ERA5 ${year}: ${check.issues.join('; ')}`);
    const annual=analyze(rows,{...s.config,offsetHours:-.5,kind:'Historical',assumedAlbedo:true},`Open-Meteo ERA5 ${year}`);
    if(!annual.summary||annual.failures.length)throw Error(`ERA5 ${year}: rejected by engineering QC — ${annual.failures.join('; ')}`);
    const eng=computeEngineering(annual,{...s.config,offsetHours:-.5},model());
    const months=eng.monthly;
    records.push({year,hours:rows.length,ghi:eng.stats.ghi,dni:eng.stats.dni,dhi:eng.stats.dhi,poa:eng.stats.poa,tempMean:annual.summary.tempMean,windMean:annual.summary.windMean,closureFlags:eng.stats.closure,nightFlags:eng.stats.night,sourceUrl:url,months});
  }
  panel.multi=interannualStatistics(records);$('v2MultiResult').innerHTML=multiMarkup(panel.multi);p.textContent=`Validated ${records.length} complete ERA5 years. Warnings are reported per calendar year.`;setInfo('MULTI-YEAR VALIDATED');
  }catch(e){p.textContent=`Multi-year dataset not accepted: ${e.message}. ${records.length} complete years analyzed before the failure; partial results are not issued as an interannual statistic.`;setInfo('MULTI-YEAR INCOMPLETE')}
  finally{panel.runBusy=false;$('v2RunMulti').disabled=false}
 });
}
function multiMarkup(r){const obj=Object.entries(r.metrics).map(([metric,v])=>({metric,...v}));return `<div class="v2-info-grid"><article><b>${r.count} complete years</b><p>Validated annual histories, identical ERA5 model selection</p></article><article><b>${f(r.metrics.ghi.mean)} kWh/m²</b><p>Sample mean annual GHI</p></article><article><b>${f(r.metrics.poa.mean)} kWh/m²</b><p>Sample mean annual POA</p></article></div><h3>Interannual statistics</h3>${reportTable(obj,[['metric','Metric'],['mean','Mean'],['sd','Sample SD'],['cvPct','CV %'],['min','Min'],['p10','Q10'],['p50','Median'],['p90','Q90'],['max','Max']])}<h3>Individual complete years</h3>${reportTable(r.years,[['year','Year'],['hours','Hours'],['ghi','GHI'],['dni','DNI'],['dhi','DHI'],['poa','Advanced POA'],['tempMean','T mean °C'],['closureFlags','Closure flags']])}<button onclick="window.SolarV2ExportMulti()" type="button">↓ Interannual CSV</button>${r.limitations.map(x=>`<p class="v2-warning">${esc(x)}</p>`).join('')}`}
window.SolarV2ExportMulti=()=>{if(panel.multi)download('interannual_resource.csv',csv(panel.multi.years.map(({months,...x})=>x)))};
async function loadPVGIS(s){const params=new URLSearchParams({lat:String(s.config.lat),lon:String(s.config.lon),outputformat:'json',usehorizon:'0'});
 const url='https://solar-resource-pvgis-proxy.vercel.app/api/tmy?'+params;const response=await fetch(url);if(!response.ok)throw Error('PVGIS proxy HTTP '+response.status);const data=normalizePVGIS(await response.json());
 const cfg={...s.config,kind:'TMY',offsetHours:data.offset};const checked=analyze(data.rows,cfg,'JRC PVGIS TMY');if(!checked.summary)throw Error('PVGIS TMY did not pass data validation: '+checked.failures.join('; '));
 const eng=computeEngineering(checked,cfg,model());return {eng,meta:{source:'PVGIS TMY',sourceYears:data.sourceYears,offsetHours:data.offset,sourceUrl:url}}
}
function reconcile(){const a=analyzed(),s=base();$('v2Content').innerHTML=`<h3>Independently compare PVGIS TMY with active weather data</h3><p>Retains both source datasets and reports climate-period incompatibility. Hourly residual metrics are shown only if UTC timestamps match exactly; otherwise compare monthly irradiation. Select both datasets' model/time conventions before interpreting differences.</p><button id="v2ReconcileRun" type="button" class="v2-strong" ${a?'':'disabled'}>Fetch independent PVGIS TMY and reconcile</button><div id="v2ReconStatus" class="v2-muted">${panel.reconcile?'Latest reconciliation completed':a?'Ready to query PVGIS.':'Run the primary source first.'}</div><div id="v2ReconResult">${panel.reconcile?reconMarkup(panel.reconcile):''}</div>`;
 $('v2ReconcileRun').addEventListener('click',async()=>{const b=$('v2ReconcileRun'),t=$('v2ReconStatus');b.disabled=true;t.textContent='Acquiring and validating independent PVGIS TMY...';try{
   const alt=await loadPVGIS(s);panel.reconcile=reconcileResources(a,alt.eng,{source:s.weatherInfo?.label||s.result.source,type:s.config.kind},{...alt.meta});$('v2ReconResult').innerHTML=reconMarkup(panel.reconcile);t.textContent='Validated source reconciliation complete. Check source-period and model warnings.';setInfo('SOURCES COMPARED');
 }catch(err){t.textContent=`Alternate resource not available or not validated: ${err.message}`;setInfo('COMPARE NOT VERIFIED')}finally{b.disabled=false}});
}
function reconMarkup(x){const m=x.summary;return `<div class="v2-statrow"><article><small>Primary GHI</small><b>${f(m.ghiA)}</b> kWh/m²</article><article><small>PVGIS GHI</small><b>${f(m.ghiB)}</b> kWh/m²</article><article><small>GHI difference</small><b>${f(m.ghiBiasPct)}%</b></article><article><small>POA difference</small><b>${f(m.poaBiasPct)}%</b></article><article><small>Same hourly timestamps</small><b>${m.sameTimestampGrid?'YES':'NO'}</b></article></div>${reportTable(x.monthly,[['month','UTC month'],['ghiA','GHI primary'],['ghiB','GHI alternate'],['ghiPct','GHI Δ%'],['poaA','POA primary'],['poaB','POA alternate'],['poaPct','POA Δ%']])}<button onclick="window.SolarV2ExportRecon()" type="button">↓ Source difference CSV</button>${x.warnings.map(y=>`<p class="v2-warning">${esc(y)}</p>`).join('')}`}
window.SolarV2ExportRecon=()=>{if(panel.reconcile)download('weather_source_reconciliation.csv',csv(panel.reconcile.monthly))};
function verification(){const b=panel.benchmark||referenceBenchmark(),a=analyzed(),s=base();panel.benchmark=b;const checks=b.tests.map(t=>({...t,pass:t.pass?'PASS':'FAIL'}));$('v2Content').innerHTML=`<h3>Reference-equation and integration acceptance checks</h3><p>Hay–Davies and Reindl sky diffuse values are compared with independent expressions given by Sandia PVPMC. Solar coordinates are checked against the published NREL SPA example with explicitly loose tolerances because the installed algorithm uses an approximate NOAA method, <b>not SPA precision</b>.</p><div class="v2-statrow"><article><small>Benchmark checks</small><b>${b.passed}/${b.total}</b></article><article><small>Verified public hourly dataset</small><b>${a?f(a.stats.hours,0):'—'}</b></article><article><small>Base QA status</small><b>${s?.result?.status||'—'}</b></article></div>${reportTable(checks,[['id','Verification'],['computed','Computed'],['reference','Benchmark'],['difference','Error'],['tolerance','Tolerance'],['pass','Result']],100)}<button type="button" id="v2Rerun">Rerun reference checks</button><button onclick="window.SolarV2ExportBenchmark()" type="button">↓ Benchmark report CSV</button><button id="v2VerifyExports" type="button" ${a?'':'disabled'}>Verify generated XLSX / hourly CSV</button><button id="v2VerifyEPW" type="button">Run synthetic EPW end-to-end engine test</button><div id="v2EPWQAResult" class="v2-muted">EPW full-year calculations not yet tested in this browser.</div><div id="v2ExportQAResult" class="v2-muted">Formats not yet verified for this data case.</div><p class="v2-muted"><a href="qa/SYNTHETIC_EPW_TEST_DATA.txt" download>Synthetic EPW test fixture (text)</a> · <a href="qa/horizon_synthetic.csv" download>Synthetic survey skyline</a> — TEST DATA ONLY, not real site weather or a measured obstruction.</p><p class="v2-muted">Reference formulas: Sandia PV Performance Modeling Collaborative, pvlib methods; NREL Solar Position Algorithm published test case. These checks do not assert a manufacturer, bankable resource or IEC validation certification.</p><p class="v2-warning">Full browser acceptance additionally requires PVGIS availability, real EPW import, downloaded Excel/CSV/JSON, PDF print, and adverse-weather/missing-data cases.</p>`;
 $('v2Rerun').addEventListener('click',()=>{panel.benchmark=referenceBenchmark();render()});$('v2VerifyExports').addEventListener('click',verifyExports);$('v2VerifyEPW').addEventListener('click',verifyEPW);setInfo(b.allPassed?'REFERENCE CHECKS PASS':'REFERENCE CHECKS FAIL');
}
window.SolarV2ExportBenchmark=()=>{if(panel.benchmark)download('solar_benchmark_checks.csv',csv(panel.benchmark.tests))};
async function verifyEPW(){
 const label=$('v2EPWQAResult'),button=$('v2VerifyEPW');button.disabled=true;label.textContent='Fetching synthetic EPW test data, parsing local-standard-time timestamps, validating all hours and calculating resource...';
 try{
  const rsp=await fetch('qa/SYNTHETIC_EPW_TEST_DATA.txt');if(!rsp.ok)throw Error('EPW test fixture unavailable (HTTP '+rsp.status+')');
  const epw=parseEPW(await rsp.text());const integrity=checkHourlySeries(epw.rows,{allowOffsetStart:true});
  if(!integrity.ok)throw Error('EPW timebase invalid: '+integrity.issues.join('; '));
  const s=base(),c={...s?.config,lat:epw.info.latitude,lon:epw.info.longitude,tilt:s?.config?.tilt??25,azimuth:s?.config?.azimuth??180,albedo:s?.config?.albedo??.2,offsetHours:epw.info.offsetHours,localStandardTimezoneHours:epw.info.timezoneOffsetHours,kind:'EPW',assumedAlbedo:true,timestampConventionVerified:true};
  const analyzed=analyze(epw.rows,c,'QA SYNTHETIC EPW — NOT REAL WEATHER');
  if(!analyzed.summary||analyzed.failures.length)throw Error('EPW source failed original engineering QA: '+analyzed.failures.join('; '));
  const adv=computeEngineering(analyzed,c,model());
  if(!adv.annual||adv.stats.hours!==8760||adv.daily.length!==epw.rows.length/24||!Number.isFinite(adv.stats.poa))throw Error('EPW year totals incomplete');
  label.style.color='#83e6c3';label.textContent=`PASS — Synthetic EPW imported with 8,760 hours, valid UTC+05:30 local-standard-time conversion, full original resource analysis, ${adv.daily.length} source-local-standard-time daily totals, GHI ${f(adv.stats.ghi)} and ${model()} POA ${f(adv.stats.poa)} kWh/m²; ${adv.stats.closure} irradiance closure flags. QA FIXTURE ONLY — not real weather.`;
 }catch(err){label.style.color='#ffaca5';label.textContent='Synthetic EPW full-year test FAIL: '+err.message;console.error(err)}finally{button.disabled=false}
}
async function verifyExports(){
 const status=$('v2ExportQAResult');status.textContent='Constructing XLSX and checking ZIP structure, worksheet counts, XML and hourly CSV...';
 const b=$('v2VerifyExports');b.disabled=true;
 try{
  const excel=window.SolarResourceStudio?.makeXlsx?.();
  const hourly=window.SolarResourceStudio?.makeHourlyCsv?.();
  if(!(excel instanceof Blob)||!hourly)throw Error('Original export generator not available');
  const bytes=new Uint8Array(await excel.arrayBuffer()),view=new DataView(bytes.buffer);
  const names=new Map(),dec=new TextDecoder();let pos=0,entries=0;
  while(pos+30<=bytes.length&&view.getUint32(pos,true)===0x04034b50){
   const method=view.getUint16(pos+8,true),len=view.getUint32(pos+18,true),fileNameLen=view.getUint16(pos+26,true),extraLen=view.getUint16(pos+28,true);
   const name=dec.decode(bytes.subarray(pos+30,pos+30+fileNameLen)),begin=pos+30+fileNameLen+extraLen,end=begin+len;
   if(method!==0||end>bytes.length||!name)throw Error('Invalid compressed ZIP layout');
   names.set(name,dec.decode(bytes.subarray(begin,end)));entries++;pos=end;
   if(entries>120)throw Error('Workbook has unexpected archive entry count');
  }
  for(const need of ['[Content_Types].xml','xl/workbook.xml','xl/_rels/workbook.xml.rels','xl/worksheets/sheet1.xml','xl/worksheets/sheet2.xml','xl/worksheets/sheet3.xml'])if(!names.has(need))throw Error('Workbook missing '+need);
  for(const [name,text] of names){if(name.endsWith('.xml')||name.endsWith('.rels')){
    const parsed=new DOMParser().parseFromString(text,'application/xml');if(parsed.querySelector('parsererror'))throw Error('Invalid workbook XML: '+name);
  }}
  const workbook=names.get('xl/workbook.xml');for(const title of ['Summary','Monthly','Hourly','Engineering'])if(!workbook.includes('name="'+title+'"'))throw Error('Workbook missing '+title+' sheet');
  const hourlyRows=(names.get('xl/worksheets/sheet3.xml').match(/<row r=/g)||[]).length;
  const expected=base()?.result?.summary?.hours;
  if(hourlyRows!==expected+1)throw Error('Hourly workbook count '+hourlyRows+' differs from validated '+expected);
  const lines=hourly.trim().split(/\r?\n/);
  if(lines.length!==expected+1||!lines[0].includes('timestamp_utc'))throw Error('Hourly CSV count or heading mismatch');
  status.textContent=`PASS — ZIP contains ${entries} files; ${names.size} archive entries; worksheet XML parses, ${expected} hourly Excel records and ${expected} hourly CSV records. Workbook ${(excel.size/1048576).toFixed(2)} MiB. Export payloads were generated without downloading.`;
  status.style.color='#80e5c0';
 }catch(e){status.textContent='Export verification failed: '+e.message;status.style.color='#ffaba4';console.error(e)}finally{b.disabled=false}
}

// Extend existing three-sheet export without removing original and advanced sheets.
window.SolarV2Sheets=()=>{
 const sheets=[];
 if(panel.shade){const r=panel.shade;sheets.push(['Horizon_Row_Screen',[['Parameter','Value'],['Model',r.method],['Horizon points',r.options.horizonPointCount],['Pitch m',r.options.pitchM],['Module slant m',r.options.moduleSlantM],['Unshaded POA',r.unshadedPoa],['Horizon loss',r.horizonLoss],['Row loss',r.rowLoss],['Screened POA',r.screenedPoa],['Percent screened loss',r.lossPct],['Exclusion','Diffuse sky, electrical mismatch, tracked PV and survey uncertainty not modeled']]]);sheets.push(['Shade_Monthly',[Object.keys(r.byMonth[0]),...r.byMonth.map(x=>Object.values(x))]]);}
 if(panel.multi){const r=panel.multi;sheets.push(['Interannual',[['Year','GHI','DNI','DHI','POA','Air mean','Wind mean'],...r.years.map(x=>[x.year,x.ghi,x.dni,x.dhi,x.poa,x.tempMean,x.windMean])]]);sheets.push(['Interannual_Stats',[['Metric','Mean','SD','CV %','Q10','Median','Q90'],...Object.entries(r.metrics).map(([k,v])=>[k,v.mean,v.sd,v.cvPct,v.p10,v.p50,v.p90])]]);}
 if(panel.reconcile){const r=panel.reconcile;sheets.push(['Source_Reconciliation',[Object.keys(r.monthly[0]),...r.monthly.map(x=>Object.values(x))]]);}
 if(panel.benchmark){const r=panel.benchmark;sheets.push(['Reference_Benchmarks',[['Check','Computed','Expected','Difference','Tolerance','PASS'],...r.tests.map(x=>[x.id,x.computed,x.reference,x.difference,x.tolerance,x.pass?'PASS':'FAIL'])]]);}
 return sheets;
};
window.SolarV2ReportHTML=()=>{
 const pieces=['<h2>Additional acceptance screens — resource engineering</h2>'];
 if(panel.benchmark)pieces.push(`<p>Benchmark checks ${panel.benchmark.passed}/${panel.benchmark.total}. NOAA solar-position approximation tested against NREL SPA example at relaxed engineering screening tolerance.</p>`);
 if(panel.multi)pieces.push(`<p>ERA5 annual period ${panel.multi.years[0].year}–${panel.multi.years.at(-1).year}, sample average annual GHI ${f(panel.multi.metrics.ghi.mean)} kWh/m², sample SD ${f(panel.multi.metrics.ghi.sd)} kWh/m². These are not bankable P50/P90 values.</p>`);
 if(panel.shade)pieces.push(`<p>Direct-beam shading screen: unshaded POA ${f(panel.shade.unshadedPoa)} kWh/m²; horizon loss ${f(panel.shade.horizonLoss)}, row loss ${f(panel.shade.rowLoss)}, screened POA ${f(panel.shade.screenedPoa)} kWh/m². No 3D geometric or module mismatch evaluation.</p>`);
 if(panel.reconcile)pieces.push(`<p>Source comparison: annual GHI difference ${f(panel.reconcile.summary.ghiBiasPct)}%; annual POA difference ${f(panel.reconcile.summary.poaBiasPct)}%. Datasets may differ in their reference periods and timestamps.</p>`);
 return pieces.join('');
};
// Flag changed location, array settings or weather source; discard stale supplementary case results.
let priorResult=null;window.addEventListener('solarresource:updated',()=>{
 const r=base()?.result;if(priorResult!==r){priorResult=r;panel.referenceResult=null;panel.loadedResult=null;panel.multi=null;panel.reconcile=null;panel.shade=null;if(panel.active!=='imports'&&panel.active!=='verification')setInfo('SOURCE CHANGED — RECALCULATE');render();}
});
window.SolarV2State=()=>({multi:panel.multi,reconcile:panel.reconcile,shade:panel.shade,benchmark:panel.benchmark,prepared:analyzed()});
document.querySelectorAll('[data-v2]').forEach(b=>b.addEventListener('click',()=>{panel.active=b.dataset.v2;render()}));
render();
