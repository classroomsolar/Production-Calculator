/** Batch 3 — Solar Resource Studio, deterministic single-axis tracker and mutual row beam-shading geometry.
 * References: Anderson & Mikofski, NREL/TP-5K00-76626 (2020); Anderson & Jensen (2024)
 * DOI 10.2172/1660126, DOI 10.1063/5.0202220.
 * pvlib tracking.singleaxis and shaded_fraction1d numerical/test conventions used for cross-checks.
 * Research screening ONLY. Does not calculate electrical mismatch, bifacial, diffuse row masking,
 * torque tube obstruction, curtailment, wind stow or bankable AC production.
 */
const R=Math.PI/180;
const finite=Number.isFinite;
const cd=x=>Math.cos(x*R),sd=x=>Math.sin(x*R);
const clamp=(v,lo,hi)=>Math.min(hi,Math.max(lo,v));
function assert(ok,msg){if(!ok)throw new Error(msg);}
export function validateTrackerConfig(c){
 assert(c&&typeof c==='object','Tracker configuration required');
 for(const [n,lo,hi] of [['axisTilt',-45,45],['axisAzimuth',0,360],['crossAxisTilt',-30,30],['minAngle',-90,0],['maxAngle',0,90]])assert(finite(c[n])&&c[n]>=lo&&c[n]<=hi,n+' must be between '+lo+' and '+hi+' degrees');
 for(const n of ['widthM','pitchM'])assert(finite(c[n])&&c[n]>0,n+' must be positive');
 assert(c.pitchM>=c.widthM,'Tracker pitch must be >= collector width (GCR <= 1)');
 assert(c.minAngle<c.maxAngle,'Tracker rotation limits must be ordered');
 assert(Math.abs(c.crossAxisTilt)<89,'Cross-axis slope too steep');
 return {...c,gcr:c.widthM/c.pitchM};
}
/** Project sun onto plane perpendicular to the tracker axis; pvlib right-handed y-axis convention. */
export function projectedSolarAngle(zenith,azimuth,axisTilt=0,axisAzimuth=0){
 const sx=sd(zenith)*sd(azimuth),sy=sd(zenith)*cd(azimuth),sz=cd(zenith);
 const xp=sx*cd(axisAzimuth)-sy*sd(axisAzimuth);
 const zp=(sx*sd(axisAzimuth)+sy*cd(axisAzimuth))*sd(axisTilt)+sz*cd(axisTilt);
 return Math.atan2(xp,zp)/R;
}
export function trackerOrientation(theta,axisTilt=0,axisAzimuth=0){
 const cA=cd(-axisAzimuth),sA=sd(-axisAzimuth),cT=cd(-axisTilt),sT=sd(-axisTilt),ct=cd(theta),st=sd(theta);
 const east=sA*sT*ct+cA*st;
 const north=sA*st-cA*sT*ct;
 const up=cT*ct;
 const surfaceTilt=Math.acos(clamp(up,-1,1))/R;
 const surfaceAzimuth=((Math.atan2(east,north)/R + 360)%360);
 return {surfaceTilt,surfaceAzimuth:surfaceTilt<1e-10?(axisAzimuth+270)%360:surfaceAzimuth,normal:{east,north,up}};
}
/** More general pvlib-style shaded-row equation (2024 rolling-terrain extension).
 * Caller must select which physical row receives a shadow; the roles reverse as sun crosses axis.
 */
export function shadedFraction1d({solarZenith,solarAzimuth,axisAzimuth,axisTilt=0,shadedRotation,shadingRotation=shadedRotation,collectorWidth,pitch,offsetM=0,crossAxisSlope=0}){
 for(const [key,val] of Object.entries({solarZenith,solarAzimuth,axisAzimuth,axisTilt,shadedRotation,shadingRotation,collectorWidth,pitch,offsetM,crossAxisSlope}))assert(finite(val),'Invalid 1D shading parameter: '+key);
 assert(collectorWidth>0&&pitch>0,'Positive row width/pitch required');
 assert(Math.abs(crossAxisSlope)<80,'Cross-axis slope outside physical screening range');
 if(solarZenith>90)return 0;
 const projected=projectedSolarAngle(solarZenith,solarAzimuth,axisTilt,axisAzimuth);
 const t1=shadingRotation-projected,t2=shadedRotation-projected;
 const denominator=Math.abs(cd(t2));
 if(denominator<1e-10)return 1;
 const tstar=.5+Math.abs(cd(t1))/(2*denominator)
 + Math.sign(projected)*offsetM/(collectorWidth*denominator)*(sd(t2)-sd(t1))
 - (pitch/collectorWidth)*cd(projected-crossAxisSlope)/(denominator*cd(crossAxisSlope));
 const clipped=clamp(tstar,0,1);
 return clipped<1e-9?0:clipped;
}
/** Returns null at night, never substitutes a physical tracker rotation for nighttime. */
export function trackerAt(zenith,azimuth,config){
 const c=validateTrackerConfig(config);
 assert(finite(zenith)&&zenith>=0&&zenith<=180,'Solar zenith 0–180 degrees required');
 assert(finite(azimuth)&&azimuth>=0&&azimuth<=360,'Solar azimuth 0–360 degrees required');
 if(zenith>90)return {night:true,trackerTheta:null,idealTheta:null,surfaceTilt:null,surfaceAzimuth:null,aoi:null,beamShadedFraction:null};
 const ideal=projectedSolarAngle(zenith,azimuth,c.axisTilt,c.axisAzimuth);
 let theta=ideal;
 if(c.backtrack){
  const normalizedAxisDistance=1/(c.gcr*cd(c.crossAxisTilt));
  const factor=Math.abs(normalizedAxisDistance*cd(ideal-c.crossAxisTilt));
  if(factor<1)theta=ideal-Math.sign(ideal)*Math.acos(clamp(factor,-1,1))/R;
 }
 theta=clamp(theta,c.minAngle,c.maxAngle);
 const o=trackerOrientation(theta,c.axisTilt,c.axisAzimuth);
 const cosInc=cd(zenith)*o.normal.up+sd(zenith)*(sd(azimuth)*o.normal.east+cd(azimuth)*o.normal.north);
 const aoi=Math.acos(clamp(cosInc,-1,1))/R;
 // Equal adjacent row rotations, zero surface-to-axis offset. 2D horizontal/slope geometry only.
 const beamShadedFraction=shadedFraction1d({solarZenith:zenith,solarAzimuth:azimuth,axisAzimuth:c.axisAzimuth,axisTilt:c.axisTilt,shadedRotation:theta,shadingRotation:theta,collectorWidth:c.widthM,pitch:c.pitchM,crossAxisSlope:c.crossAxisTilt});
 return {night:false,trackerTheta:theta,idealTheta:ideal,surfaceTilt:o.surfaceTilt,surfaceAzimuth:o.surfaceAzimuth,aoi,beamShadedFraction,gcr:c.gcr,backtrackingCorrectionDeg:theta-ideal};
}
/** Compute annual hourly geometry and optical POA on validated primary resource, not energy production. */
export function summarizeTracker(prepared,c,irradianceFn){
 if(!Array.isArray(prepared)||![8760,8784].includes(prepared.length))throw Error('Requires complete 8760/8784-hour validated weather');
 if(typeof irradianceFn!=='function')throw Error('Irradiance calculation function required');
 const cfg=validateTrackerConfig(c);
 let prev=null;
 const hourly=[],monthly=Array.from({length:12},(_,i)=>({month:i+1,hours:0,directUnshaded:0,directScreened:0,diffuse:0,ground:0,totalUnshaded:0,totalScreened:0}));
 let unshaded=0,screened=0,lost=0,shadedHours=0;
 for(const h of prepared){
  const now=Date.parse(h.timestamp_utc);
  assert(finite(now),'Invalid timestamp in hourly record');
  if(prev!==null)assert(now-prev===3600000,'Duplicate or missing hourly record');
  prev=now;
  const solar=h._pos;assert(solar&&finite(solar.zenith)&&finite(solar.azimuth),'Solar-position preparation missing');
  const t=trackerAt(solar.zenith,solar.azimuth,cfg);
  let beam=0,sky=0,ground=0,poaBefore=0,poaAfter=0;
  if(!t.night){
   const p=irradianceFn(h,t);
   for(const key of ['beam','sky','ground'])assert(finite(p[key])&&p[key]>=-1e-6,'Invalid POA '+key);
   beam=Math.max(0,p.beam);sky=Math.max(0,p.sky);ground=Math.max(0,p.ground);
   poaBefore=beam+sky+ground;poaAfter=beam*(1-t.beamShadedFraction)+sky+ground;
   if(t.beamShadedFraction>1e-9&&beam>1)shadedHours++;
  }
  const m=monthly[new Date(now).getUTCMonth()];m.hours++;m.directUnshaded+=beam/1000;m.directScreened+=(beam*(1-(t.beamShadedFraction||0)))/1000;m.diffuse+=sky/1000;m.ground+=ground/1000;m.totalUnshaded+=poaBefore/1000;m.totalScreened+=poaAfter/1000;
  unshaded+=poaBefore/1000;screened+=poaAfter/1000;lost+=(poaBefore-poaAfter)/1000;
  hourly.push({timestamp_utc:h.timestamp_utc,zenith_deg:solar.zenith,solar_azimuth_deg:solar.azimuth,
   tracker_theta_deg:t.trackerTheta,collector_tilt_deg:t.surfaceTilt,collector_azimuth_deg:t.surfaceAzimuth,
   incidence_deg:t.aoi,beam_row_shaded_fraction:t.beamShadedFraction,
   poa_direct_unshaded_wm2:beam,poa_direct_screened_wm2:beam*(1-(t.beamShadedFraction||0)),
   poa_sky_wm2:sky,poa_ground_wm2:ground,poa_unshaded_wm2:poaBefore,poa_screened_wm2:poaAfter});
 }
 assert(Math.abs((screened+lost)-unshaded)<1e-6,'Annual solar irradiance conservation failure');
 return {geometry:{...cfg},hours:prepared.length,annual:{poaUnshadedKWhM2:unshaded,poaScreenedKWhM2:screened,directRowShadeLossKWhM2:lost,rowShadeLossPercent:unshaded?100*lost/unshaded:0,shadedHours},monthly,hourly,
 warnings:['SLOPE-AWARE TWO-DIMENSIONAL SCREEN: assumes long equal rows, uniform rotation, no surface-to-axis offset or obstacles.','Only direct beam row-shading applied; circumsolar, diffuse sky masking, structural shading and bifacial rear irradiance are not modeled.','Solar position uses upstream NOAA approximate model; weather and timestamp semantics inherited from existing resource study.','Not a tracker controller, wind-stow model, electrical shading mismatch, POI power or bankable production estimate.']};
}

/** Pitch / ground occupation sensitivity only; not financial nor constructability optimization. */
export function sweepTrackerPitch(prepared,baseConfig,pitches,irradianceFn){
 if(!Array.isArray(pitches)||pitches.length<2||pitches.length>20)throw Error('2–20 row pitches required');
 const unique=[...new Set(pitches.map(Number))];
 const rows=[];
 for(const pitch of unique){
  const cfg={...baseConfig,pitchM:pitch};
  const sim=summarizeTracker(prepared,cfg,irradianceFn);
  rows.push({pitchM:pitch,gcr:sim.geometry.gcr,screenedPoaKWhM2:sim.annual.poaScreenedKWhM2,
   beamShadeLossKWhM2:sim.annual.directRowShadeLossKWhM2,screenedIncidentPerGroundM2:sim.geometry.gcr*sim.annual.poaScreenedKWhM2,
   shadedHours:sim.annual.shadedHours});
 }
 return {rows,highestIncidentPerCollector:rows.reduce((a,b)=>b.screenedPoaKWhM2>a.screenedPoaKWhM2?b:a),
 highestIncidentPerGroundArea:rows.reduce((a,b)=>b.screenedIncidentPerGroundM2>a.screenedIncidentPerGroundM2?b:a),
 disclaimer:'Geometric irradiance tradeoff only. GCR*POA assumes collector slant area/land area; no setbacks, grading, tracker spacing requirements, mismatch, land cost, CAPEX or LCOE.'};
}
