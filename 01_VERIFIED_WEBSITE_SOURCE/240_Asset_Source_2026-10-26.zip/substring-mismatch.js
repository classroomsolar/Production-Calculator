/** Batch 3 electrical partial shading: bypass-protected substring series circuit.
 * Device physics is a 5-parameter single-diode module, partitioned into N equal
 * electrically series substrings with independent effective irradiance.
 * NO reverse avalanche, hotspot, half-cut/cross-tie, substring temperature
 * gradients or actual field topology model. Bypass diode is fixed-voltage clamp.
 * Sources: pvlib singlediode and partial shading gallery; Energy 218 (2021) 119480.
 * Units SI: W/m2, C, V, A, ohm, W. Research calculator, not construction design.
 */
import {singleDiodeAtReference} from './pv-reference-kernel.js';
import {deSotoAuxiliary} from './pv-detailed-v17.js';
const ok=(n)=>Number.isFinite(n);
const requireNumber=(value,name,lo,hi)=>{if(!ok(value)||value<lo||value>hi)throw Error(`${name} must be in ${lo}..${hi}`);return value};
export function validateMismatchConfig(c){
 if(!c||typeof c!=='object')throw Error('Configuration required');
 const ref=c.module;
 if(!ref||typeof ref!=='object')throw Error('Five-parameter reference coefficients required');
 for(const k of ['ILrefA','I0refA','RshRefOhm','aRefV'])requireNumber(ref[k],k,Number.MIN_VALUE,1e9);
 requireNumber(ref.RsRefOhm,'RsRefOhm',0,100);
 requireNumber(ref.alphaIscAperC,'alphaIscAperC',-0.1,0.1);
 requireNumber(ref.EgRefEv,'EgRefEv',0.05,3);
 requireNumber(ref.dEgdTPerK,'dEgdTPerK',-0.01,0.01);
 requireNumber(c.cellC,'cellC',-80,120);
 requireNumber(c.bypassForwardV,'bypassForwardV',0.05,1.5);
 requireNumber(c.modulesPerString,'modulesPerString',1,80);
 if(!Number.isInteger(c.modulesPerString))throw Error('modulesPerString must be an integer');
 requireNumber(c.parallelStrings,'parallelStrings',1,100);
 if(!Number.isInteger(c.parallelStrings))throw Error('parallelStrings must be an integer');
 requireNumber(c.stringCableResistanceOhm,'stringCableResistanceOhm',0,10);
 requireNumber(c.mpptMinV,'mpptMinV',0,4000);
 requireNumber(c.mpptMaxV,'mpptMaxV',0,4000);
 if(c.mpptMinV>=c.mpptMaxV)throw Error('MPPT limits must be ordered');
 if(!Array.isArray(c.substringIrradianceWm2)||!c.substringIrradianceWm2.length||c.substringIrradianceWm2.length>12)throw Error('1–12 series substring irradiances required');
 for(const g of c.substringIrradianceWm2)requireNumber(g,'substring irradiance',0,1800);
 return c;
}
export function moduleAtCurrentSetup(ref, G, cellC, nSubstrings){
 if(G===0)return {ocV:0,atI:(i)=>i===0?0:-Infinity,iscA:0,illumination:false};
 const base=deSotoAuxiliary(ref,G,cellC);
 // Equal series group: a, Rs, Rsh scale with number of cells (1 / nSubstrings).
 const p={...base,nNsVth:base.nNsVth/nSubstrings,seriesOhm:base.seriesOhm/nSubstrings,shuntOhm:base.shuntOhm/nSubstrings};
 const cell=singleDiodeAtReference(p);
 function branchAtI(i){
  if(i<=0)return cell.voc;
  if(i>=p.photocurrentA*1.2)return -Infinity;
  let a=-2,b=p.nNsVth*Math.log1p(p.photocurrentA/p.saturationCurrentA);
  const residual=(v)=>p.photocurrentA-p.saturationCurrentA*Math.expm1(Math.min(700,(v+i*p.seriesOhm)/p.nNsVth))-(v+i*p.seriesOhm)/p.shuntOhm-i;
  if(residual(a)<0)return -Infinity;
  for(let j=0;j<85;j++){const mid=(a+b)/2; if(residual(mid)>0)a=mid;else b=mid}
  return (a+b)/2;
 }
 return {ocV:cell.voc,iscA:cell.isc,atI:branchAtI,illumination:true};
}
const localOpt=(fun,l,r)=>{
 const q=(Math.sqrt(5)-1)/2;
 let c=r-q*(r-l),d=l+q*(r-l),fc=fun(c),fd=fun(d);
 for(let j=0;j<60;j++){if(fc<fd){l=c;c=d;fc=fd;d=l+q*(r-l);fd=fun(d)}else{r=d;d=c;fd=fc;c=r-q*(r-l);fc=fun(c)}}
 const x=(l+r)/2;return {i:x,power:fun(x)};
};
export function substringMismatchStudy(input){
 const c=validateMismatchConfig(input),n=c.substringIrradianceWm2.length;
 const parts=c.substringIrradianceWm2.map(G=>G===0?null:moduleAtCurrentSetup(c.module,G,c.cellC,n));
 const highestIL=Math.max(0,...c.substringIrradianceWm2.map(g=>{const p=g?deSotoAuxiliary(c.module,g,c.cellC):null;return p?.photocurrentA||0}));
 // Bypass clamp allows series current to exceed a shaded substring's Isc, but never the brightest's photocurrent.
 const iUpper=Math.max(0,highestIL*1.000001);
 function stateAtI(I){
  let sum=0,bypassed=0;
  for(const s of parts){
    const v=s?s.atI(I):-Infinity;
    if(v < -c.bypassForwardV){sum-=c.bypassForwardV;bypassed++}else sum+=v;
  }
  const stringV=Math.max(0,c.modulesPerString*sum-I*c.stringCableResistanceOhm);
  const parallelI=I*c.parallelStrings;
  return {stringV,parallelI,power:Math.max(0,stringV*parallelI),bypassedSubstringsPerModule:bypassed};
 }
 const samples=1401,raw=[];
 for(let j=0;j<samples;j++){const I=iUpper*j/(samples-1);const x=stateAtI(I);raw.push({stringCurrentA:I,stringVoltageV:x.stringV,arrayCurrentA:x.parallelI,powerW:x.power,bypassedPerModule:x.bypassedSubstringsPerModule})}
 const candidates=[];
 for(let j=1;j<samples-1;j++)if(raw[j].powerW>=raw[j-1].powerW&&raw[j].powerW>=raw[j+1].powerW){
  const q=localOpt(i=>stateAtI(i).power,iUpper*(j-1)/(samples-1),iUpper*(j+1)/(samples-1));candidates.push({currentPerStringA:q.i,...stateAtI(q.i)});
 }
 const peakCount=candidates.filter(x=>x.power>1e-8).length;
 candidates.push({currentPerStringA:0,...stateAtI(0)},{currentPerStringA:iUpper,...stateAtI(iUpper)});
 candidates.sort((a,b)=>b.power-a.power);
 const global=candidates[0];
 const inWindow=(s)=>s.stringV>=c.mpptMinV&&s.stringV<=c.mpptMaxV;
 const filtered=candidates.filter(inWindow);
 // MPPT optimal point can lie at the MPPT min/max boundary, not a full-string local peak.
 for(let j=1;j<samples;j++){
  const a=raw[j-1],b=raw[j];
  for(const boundary of [c.mpptMinV,c.mpptMaxV]){
   if((a.stringVoltageV-boundary)*(b.stringVoltageV-boundary)<=0&&a.stringVoltageV!==b.stringVoltageV){
    let lo=a.stringCurrentA,hi=b.stringCurrentA;
    for(let k=0;k<45;k++){const mid=(lo+hi)/2;const m=stateAtI(mid);
     if((m.stringV-boundary)*(a.stringVoltageV-boundary)>0)lo=mid;else hi=mid;
    }
    const I=(lo+hi)/2,m=stateAtI(I);
    if(inWindow(m))filtered.push({currentPerStringA:I,...m});
   }
  }
 }
 const mppt=filtered.sort((a,b)=>b.power-a.power)[0]||null;
 // Baseline with same string layout, wind/cell temperature and wiring; does not imply actual irradiance loss decomposition.
 const pristinePower=(()=>{
   const br=moduleAtCurrentSetup(refFrom(c),1000,c.cellC,1);
   const f=i=>{const p=br.atI(i);return Math.max(0,(p*c.modulesPerString-i*c.stringCableResistanceOhm)*i*c.parallelStrings)};
   const m=localOpt(f,0,br.iscA);
   return m.power;
 })();
 return {status:'RESEARCH_MODEL_NOT_OEM_QUALIFIED',config:{modulesPerString:c.modulesPerString,parallelStrings:c.parallelStrings,cellC:c.cellC,substringCount:n,irradiances:c.substringIrradianceWm2},
  globalMPP:global,mpptMPP:mppt,globalPowerW:global.power,mpptPowerW:mppt?.power??0,pristineSTCpowerW:pristinePower,lossVsFullSTCpercent:pristinePower>0?100*(1-global.power/pristinePower):null,
  localPeakCount:peakCount,curve:raw,reference:'pvlib single-diode and partial shading educational examples',
  warnings:['Equal-electrical-series-substring approximation with ideal fixed-voltage bypass diode clamp; real diode I–V and reverse-bias not modeled.',
   'No manufacturer-verified bypass topology, half-cut parallel branches, thermal hotspot, cell-level shadow distribution or mismatch layout.',
   'MPPT selection is a static voltage-window screen; inverter algorithm, power startup, current limit, wiring temperature and module absolute maximum voltage need separate checks.',
   'Pristine comparison is a common 1000 W/m² reference rather than weather-normalized shadow-only loss; not annual energy or bankable estimate.']};
}
const refFrom=c=>c.module;
