/** Batch 4 DC circuit screen, code-dependent preliminary engineering only */
import {dcCircuitScreen} from './electrical-screen.js';
const root=document.getElementById('pv15Section');
if(root){
const tabs=root.querySelector('.pv15-tabs'),ref=document.getElementById('pv15Result');
if(tabs&&ref){
const specs=[['iscA','Module Isc (A)',14],['impA','Module Imp (A)',13],['vmpV','Module Vmp (V)',42],['vocV','Module Voc (V)',50],['tempCoeffVocPctC','Voc temperature coefficient (%/°C)',-.27],['minDesignTempC','ASHRAE/site minimum temperature (°C)',-10],['maxOperatingTempC','Maximum module operating temperature (°C)',70],['seriesModules','Modules in series',15],['parallelStrings','Parallel strings',2],['loopLengthM','DC circuit conductor total loop length (m)',140],['ohmPerKm20C','Conductor resistance at 20°C (Ω/km)',.5],['alphaPerC','Conductor resistance temperature coefficient (1/°C)',.00393],['conductorTempC','Assumed operating conductor temperature (°C)',70],['baseAmpacityA','Conductor nameplate ampacity before correction (A)',60],['tempFactor','Installation temperature correction factor',.8],['adjustFactor','Conductor count adjustment factor',.9],['maxSystemVoltageV','Lowest system/equipment maximum DC voltage (V)',1000],['maxModuleFuseA','Module maximum series fuse rating (A)',25]];
tabs.insertAdjacentHTML('beforeend','<button type="button" data-electrical-b4="circuit">DC Circuit &amp; Ampacity R&amp;D · B4</button>');
const inputs=specs.map(([k,label,value])=>`<label style="display:block;font-size:.82rem"><span id="elB4_label_${k}">${label}</span><input id="elB4_${k}" type="number" step="any" value="${value}" style="width:100%;margin-top:4px"></label>`).join('');
ref.insertAdjacentHTML('afterend',`<section id="electricalB4" hidden style="padding:16px;margin-top:12px;border:1px solid #95a3b9;border-radius:12px"><h3>DC string, circuit-current &amp; conductor-loss engineering screening</h3><p><strong>Example inputs only. Not NEC, OEM, cable thermal or construction compliance approval.</strong> Input actual manufacturer ratings and derating factors. The minimum-current screen follows the conventional 2023 NEC 690.8 pathway only; 690.9 OCPD/exception rules require separate analysis.</p><label style="display:block;margin:12px 0">DC conductor topology (select actual wire routing)<select id="elB4_topology"><option value="common_feeder">Common combined DC feeder after combiner (one circuit carries all string current)</option><option value="individual_string_loops">Separate identical positive/negative loops for each PV string</option></select></label><div style="display:flex;gap:12px;align-items:end;flex-wrap:wrap;margin:12px 0"><label>DC total loop length units<select id="elB4_lengthUnit" style="display:block;width:100%"><option value="m">Metres (m)</option><option value="ft">Feet (decimal ft)</option><option value="ft_in">Feet and inches</option></select></label><label id="elB4_inchesLabel" hidden>Additional inches (0 to less than 12)<input id="elB4_loopInches" type="number" min="0" max="11.999999" step="any" value="0" style="display:block;width:100%"></label></div><div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:10px">${inputs}</div><p><button id="elB4_run" type="button">Calculate DC circuit screen</button> <button type="button" id="elB4_json" disabled>Download audit JSON</button></p><p id="elB4_status" role="status">Not evaluated.</p><div id="elB4_output"></div></section>`);
const panel=document.getElementById('electricalB4'),b=tabs.querySelector('[data-electrical-b4]');
const hide=()=>{panel.hidden=true;b.classList.remove('active')};
for(const x of tabs.querySelectorAll('button:not([data-electrical-b4])'))x.addEventListener('click',hide);
b.addEventListener('click',()=>{for(const other of ['pv15StringForm','pv15YieldForm','pv15AuditForm','pv17Lab','trackerB3','financeB5','bessB4']){const el=document.getElementById(other);if(el)el.hidden=true}ref.hidden=true;for(const x of tabs.querySelectorAll('button'))x.classList.remove('active');b.classList.add('active');panel.hidden=false});
let last=null;const status=document.getElementById('elB4_status'),output=document.getElementById('elB4_output'),exportButton=document.getElementById('elB4_json');
const invalidate=()=>{last=null;exportButton.disabled=true;output.replaceChildren();status.textContent='Inputs changed — rerun';};
// The calculation kernel always receives metres; unit switching preserves
// actual circuit length and never silently relabels the same number.
const lengthInput=document.getElementById('elB4_loopLengthM'),unitChoice=document.getElementById('elB4_lengthUnit'),inchInput=document.getElementById('elB4_loopInches'),inchWrap=document.getElementById('elB4_inchesLabel'),lengthLabel=document.getElementById('elB4_label_loopLengthM');
let lengthUnit='m';
const numberField=(el,label)=>{if(el.value.trim()==='')throw Error(label+' is required');const v=Number(el.value);if(!Number.isFinite(v)||v<0)throw Error(label+' must be finite and nonnegative');return v};
const readLengthM=(unit=lengthUnit)=>{
 const x=numberField(lengthInput,'Loop length');
 if(unit==='m')return x;
 if(unit==='ft')return x*0.3048;
 const inch=numberField(inchInput,'Additional inches');
 if(!Number.isInteger(x)||inch>=12)throw Error('Feet must be a whole number and additional inches must be in [0,12)');
 return x*0.3048+inch*0.0254;
};
const setDisplayLength=(metres,unit)=>{
 if(unit==='m'){lengthInput.value=String(Number(metres.toPrecision(12)));lengthLabel.textContent='DC positive + negative conductor total loop length (m)';}
 else if(unit==='ft'){lengthInput.value=String(Number((metres/0.3048).toPrecision(12)));lengthLabel.textContent='DC positive + negative conductor total loop length (ft)';}
 else {let feet=Math.floor(metres/0.3048+1e-10),inches=Math.max(0,metres/0.0254-12*feet);inches=Number(inches.toFixed(6));if(inches>=12){feet++;inches=0;}lengthInput.value=String(feet);inchInput.value=String(inches);lengthLabel.textContent='DC positive + negative conductor loop length — whole feet';}
 inchWrap.hidden=unit!=='ft_in';
};
lengthLabel.textContent='DC positive + negative conductor total loop length (m)';
unitChoice.addEventListener('change',()=>{
 let currentM;try{currentM=readLengthM(lengthUnit)}catch(e){unitChoice.value=lengthUnit;status.textContent='Correct the existing length first: '+e.message;return;}
 lengthUnit=unitChoice.value;setDisplayLength(currentM,lengthUnit);invalidate();
});
inchInput.addEventListener('input',invalidate);
for(const [key] of specs)document.getElementById('elB4_'+key).addEventListener('input',invalidate);
document.getElementById('elB4_topology').addEventListener('change',invalidate);
document.getElementById('elB4_run').addEventListener('click',()=>{try{const cfg=Object.fromEntries(specs.map(([key])=>{const raw=document.getElementById('elB4_'+key).value;if(!raw)throw Error(key+' required');return [key,Number(raw)]}));cfg.topology=document.getElementById('elB4_topology').value;const enteredLength={unit:lengthUnit,feet:lengthUnit==='ft_in'?Number(lengthInput.value):null,inches:lengthUnit==='ft_in'?Number(inchInput.value):null,displayValue:Number(lengthInput.value)};cfg.loopLengthM=readLengthM();if(!(cfg.loopLengthM>0))throw Error('Total loop length must be greater than zero');last={input:cfg,enteredLength,...dcCircuitScreen(cfg)};const r=last.results;output.replaceChildren();const lengthNote=document.createElement('p');lengthNote.textContent=`Validated conductor loop length: ${cfg.loopLengthM.toFixed(6)} m (${(cfg.loopLengthM/0.3048).toFixed(6)} ft); conversion factors: 1 ft = 0.3048 m; 1 in = 0.0254 m.`;output.append(lengthNote);const table=document.createElement('table');for(const [k,v] of Object.entries(r)){const tr=document.createElement('tr'),th=document.createElement('th'),td=document.createElement('td');th.textContent=k;td.textContent=typeof v==='number'?Number(v.toFixed(5)).toString():String(v);tr.append(th,td);table.append(tr)}output.append(table);const w=document.createElement('p');w.textContent=last.warnings.join(' ');output.append(w);status.textContent='PRELIMINARY DC SCREEN ONLY — voltage '+(r.vocLimitPass?'within supplied limit':'EXCEEDS LIMIT')+', conductor '+(r.ampacityScreenPass?'passes supplied ampacity screen':'FAILS supplied ampacity screen');exportButton.disabled=false;}catch(e){last=null;output.replaceChildren();status.textContent='REJECTED: '+e.message;exportButton.disabled=true}});
exportButton.addEventListener('click',()=>{if(!last)return;const blob=new Blob([JSON.stringify(last,null,2)],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='dc-circuit-preliminary-screen.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),5000)});
window.SolarElectricalB4Sheets=()=>last?[['B4 DC Circuit',Object.entries(last.results).map(([metric,value])=>({metric,value}))]]:[];
window.SolarElectricalB4ReportHTML=()=>last?`<h2>Preliminary DC circuit screening · Not NEC certification</h2><p>${last.warnings.join(' ')}</p>`:'';
}}
