/** Solar Resource Studio 1.3. Data import, QA, site horizon and interannual resource screens.
 * All calculations local. EPW format: EnergyPlus Auxiliary Programs, Weather File EPW.
 * Horizon screening affects direct beam only, no terrain DEM or obstructed diffuse sky.
 */
import {solar} from './engine.js';
import {irradianceParts,dniExtraterrestrial,percentile} from './advanced-engine.js';
const H=3600000, D=Math.PI/180;
const finite=Number.isFinite;
const clamp=(x,lo,hi)=>Math.max(lo,Math.min(hi,x));
const sum=(list,key)=>list.reduce((s,r)=>s+(Number.isFinite(r[key])?r[key]:0),0);
const n=v=>v===''?NaN:Number(v);
/** The 8-line EPW header includes LOCATION,...,latitude,longitude,time-zone,elevation.
 * EPW hourly records are hour-ending local standard time, Wh/m² for integrated irradiance.
 * One-hour EPW irradiance Wh/m² numerically equals mean W/m² over that hour.
 * We normalize the synthetic/local reference year to UTC timestamp for interval end,
 * and retain fixed station offset; no DST is applied to EPW local standard time.
 */
export function parseEPW(content){
  const lines=String(content).replace(/^\uFEFF/,'').split(/\r?\n/).filter(s=>s.trim());
  if(lines.length<9||!/^LOCATION,/i.test(lines[0]))throw Error('EPW LOCATION header and eight metadata lines required');
  const header=lines[0].split(',').map(s=>s.trim());
  if(header.length<10)throw Error('Incomplete EPW LOCATION header');
  const lat=n(header[6]),lon=n(header[7]),tz=n(header[8]),elev=n(header[9]);
  if(!finite(lat)||Math.abs(lat)>90||!finite(lon)||Math.abs(lon)>180||!finite(tz)||Math.abs(tz)>14||!finite(elev))throw Error('Invalid EPW latitude/longitude/timezone/elevation');
  const data=lines.slice(8);const len=data.length;
  if(len!==8760&&len!==8784)throw Error(`EPW file has ${len} hours; require exactly 8,760 or 8,784 hourly records`);
  const yr=len===8784?2000:2001;
  const rows=[];let prev=null;const sourceYears=new Set();
  for(let i=0;i<len;i++){
    const p=data[i].split(',');if(p.length<22)throw Error(`EPW row ${i+1} has missing weather columns`);
    const mo=n(p[1]),day=n(p[2]),hour=n(p[3]),min=n(p[4]);
    if(!Number.isInteger(mo)||mo<1||mo>12||!Number.isInteger(day)||day<1||day>31||!Number.isInteger(hour)||hour<1||hour>24||!Number.isInteger(min)||min!==60)throw Error(`EPW row ${i+1}: expected hourly, hour-ending local-standard-time (minute 60)`);
    // An EPW interval ending at local hour 1 ends 01:00; hour 24 ends next 00:00.
    const wall=Date.UTC(yr,mo-1,day,hour),check=new Date(Date.UTC(yr,mo-1,day));
    if(check.getUTCMonth()!==mo-1||check.getUTCDate()!==day)throw Error(`EPW row ${i+1}: invalid month/day`);
    const t=wall-tz*H;
    if(prev!==null&&t-prev!==H)throw Error(`EPW row ${i+1}: missing, duplicate or nonsequential hour; invalid TMY month assembly`);
    prev=t;
    const temp=n(p[6]),wind=n(p[21]),ghi=n(p[13]),dni=n(p[14]),dhi=n(p[15]);
    if(![temp,wind,ghi,dni,dhi].every(finite)||temp>=99||wind>=999||ghi>=9999||dni>=9999||dhi>=9999)throw Error(`EPW row ${i+1}: missing-value sentinel or nonnumeric required weather field`);
    rows.push({timestamp_utc:new Date(t).toISOString().replace('.000Z','Z'),ghi_wm2:ghi,dni_wm2:dni,dhi_wm2:dhi,temp_air_c:temp,wind_speed_mps:wind});
    if(Number.isInteger(Number(p[0])))sourceYears.add(Number(p[0]));
  }
  const irradianceOffset=(lines.find(x=>/^COMMENTS\s*2,/i.test(x))||'').match(/Irradiance\s+Time\s+Offset\s*\(h\)\s*:\s*([+-]?\d+(?:\.\d+)?)/i);
  const epwExtraOffset=irradianceOffset?Number(irradianceOffset[1]):0;
  if(!finite(epwExtraOffset)||Math.abs(epwExtraOffset)>1.5)throw Error('EPW irradiance time offset outside supported range');
  // Hour-ending UTC record + (nominal -0.5 h) points to interval midpoint.
  // PVGIS EPW optionally documents an irradiance instant shift from file hour marker.
  const isPVGIS=/PVGIS/i.test(header.join(',')+' '+lines.slice(1,8).join(' '));
  const offsetHours=isPVGIS&&irradianceOffset ? -1+epwExtraOffset : -.5;
  if(Math.abs(offsetHours)>2)throw Error('EPW midpoint offset is outside 2h engineering screening range');
  return {rows,info:{label:`EPW local-standard-time weather: ${header[1]} (${header[3]})`,type:'EPW',timezoneOffsetHours:tz,timezone:`UTC${tz>=0?'+':''}${tz}`,offsetHours,offsetVerified:!!irradianceOffset||epwExtraOffset===0,sourceYears:[...sourceYears],elevation:elev,latitude:lat,longitude:lon,referenceYear:yr,irradianceConvention:'EPW hour-ending local standard time; instantaneous solar model evaluated at interval midpoint plus optional documented offset',source:'User-supplied EPW',pvgisEPW:isPVGIS}};
}
export function checkHourlySeries(rows,{requireYear=true,allowOffsetStart=false}={}){
  const issues=[];if(!Array.isArray(rows)||!rows.length)return {ok:false,hours:0,issues:['Empty weather record collection']};
  let prev=null;for(let i=0;i<rows.length;i++){
    const t=Date.parse(rows[i].timestamp_utc);
    if(!finite(t)){issues.push(`Invalid timestamp at index ${i}`);break}
    if(prev!==null&&t-prev!==H){issues.push(`Missing, duplicate or out-of-sequence hour at row ${i+1}`);break}prev=t;
    for(const k of ['ghi_wm2','dni_wm2','dhi_wm2','temp_air_c','wind_speed_mps'])if(!finite(rows[i][k])){issues.push(`Invalid ${k} at row ${i+1}`);break}
    if(issues.length)break;
  }
  const start=Date.parse(rows[0].timestamp_utc),year=new Date(start).getUTCFullYear(),annual=[8760,8784].includes(rows.length);
  if(requireYear&&!annual)issues.push(`Incomplete year: ${rows.length} hourly records`);
  if(requireYear&&!allowOffsetStart&&start!==Date.UTC(year,0,1))issues.push('Source is not aligned with UTC Jan 1 midnight');
  if(requireYear&&allowOffsetStart){
    const end=Date.parse(rows.at(-1).timestamp_utc),elapsed=end-start;
    if(elapsed!==(rows.length-1)*H)issues.push('EPW year not sequential');
  }
  return {ok:issues.length===0,hours:rows.length,issues,startUTC:rows[0].timestamp_utc,endUTC:rows.at(-1).timestamp_utc,annual};
}
/** JRC PVGIS 5.3 printhorizon response has 48 azimuths relative to South.
 * PVGIS A: 0=S, +90=W, -90=E. Convert to north-clockwise convention.
 */
export function normalizePVGISHorizon(payload){
 const raw=payload?.outputs?.horizon_profile;
 if(!Array.isArray(raw)||raw.length<4)throw Error('PVGIS horizon API missing DEM horizon_profile');
 const points=raw.map((e,i)=>{const a=Number(e.A??e.azimuth),h=Number(e.H_hor??e.horizon_height);
   if(!Number.isFinite(a)||!Number.isFinite(h)||h< -5||h>90)throw Error(`PVGIS skyline record ${i+1} invalid`);
   return {az:((a+180)%360+360)%360,elev:Math.max(0,h)};
 }).sort((a,b)=>a.az-b.az);
 const distinct=[];
 for(const p of points){const old=distinct.at(-1);
  if(old&&Math.abs(old.az-p.az)<1e-7){old.elev=Math.max(old.elev,p.elev);continue}
  distinct.push({...p});
 }
 if(distinct.length<4)throw Error('PVGIS skyline has fewer than four unique directions');
 return {points:distinct,meta:{database:payload?.inputs?.horizon_db||'PVGIS DEM-derived horizon',elevationM:payload?.inputs?.location?.elevation,pointCount:distinct.length,duplicateWrapPoints:points.length-distinct.length}};
}
/** Azimuth measured clockwise from true north, samples should cover 0–360°, circular interpolation. */
export function parseHorizonCSV(content){
  const all=String(content).replace(/^\uFEFF/,'').trim().split(/\r?\n/).filter(Boolean);
  if(all.length<3)throw Error('Horizon CSV requires header and at least two azimuth/elevation points');
  const head=all.shift().toLowerCase().split(',').map(s=>s.trim());
  const ia=head.findIndex(s=>['azimuth_deg','azimuth','az_deg'].includes(s)),ie=head.findIndex(s=>['elevation_deg','elevation','altitude_deg','horizon_deg'].includes(s));
  if(ia<0||ie<0)throw Error('Horizon CSV header must contain azimuth_deg,elevation_deg');
  const points=all.map((x,i)=>{const v=x.split(','),az=n(v[ia]),elev=n(v[ie]);if(!finite(az)||!finite(elev)||az<0||az>360||elev< -5||elev>90)throw Error(`Horizon row ${i+2}: invalid azimuth/elevation`);return {az:az===360?0:az,elev:Math.max(0,elev)};}).sort((a,b)=>a.az-b.az);
  if(points.length<2||points.some((v,i)=>i>0&&v.az===points[i-1].az))throw Error('Horizon points require distinct azimuths');
  return points;
}
export function horizonAt(points,azimuth){
  if(!Array.isArray(points)||!points.length)return 0;
  const az=((azimuth%360)+360)%360;
  for(let i=0;i<points.length;i++){
    const a=points[i],b=points[(i+1)%points.length],right=i===points.length-1?b.az+360:b.az;
    const x=az<a.az?az+360:az;
    if(x>=a.az&&x<=right)return a.elev+(b.elev-a.elev)*((x-a.az)/(right-a.az));
  }
  return 0;
}
/** Direct-beam obstacle and row-to-row shading screenings: no diffuse or mismatch penalties. */
export function shadeStudy(prepared,cfg,options){
  if(!Array.isArray(prepared)||!prepared.length)throw Error('An analyzed hourly weather series is required');
  const model=options.model||'reindl',horizon=options.horizon||[],tilt=cfg.tilt,azimuth=cfg.azimuth;
  const pitch=Number(options.pitchM),slant=Number(options.moduleSlantM),clearance=Number(options.clearanceM||0);
  const rowsEnabled=!!options.rowsEnabled;
  if(rowsEnabled&&(!finite(pitch)||pitch<=0||!finite(slant)||slant<=0||!finite(clearance)||clearance<0||pitch<slant*Math.cos(tilt*D)))throw Error('Row pitch must exceed horizontal module projection; positive slant length and nonnegative clearance required');
  let unshaded=0,horizonLost=0,rowLost=0,remaining=0,maskedHours=0,rowAffectedHours=0;
  const byMonth=Array.from({length:12},(_,i)=>({month:i+1,unshaded:0,horizonLoss:0,rowLoss:0,shaded:0}));
  const series=[];
  for(const h of prepared){
    const p=irradianceParts(h.ghi_wm2,h.dni_wm2,h.dhi_wm2,h._pos,tilt,azimuth,cfg.albedo,model,h._extra);
    let beam=p.beam; const blocked=h._pos.elevation>0&&h._pos.elevation<=horizonAt(horizon,h._pos.azimuth);
    const hl=blocked?beam:0;if(blocked&&beam>0)maskedHours++;
    beam-=hl;
    let fractionalShade=0;
    if(rowsEnabled&&beam>0&&h._pos.elevation>.1){
      const beta=tilt*D,el=h._pos.elevation*D;
      const forward=Math.max(0,Math.cos((h._pos.azimuth-azimuth)*D));
      const horizontalModule=slant*Math.cos(beta);
      const height=slant*Math.sin(beta); // Equal-elevation adjacent rows: ground clearance cancels
      const edgeReach=horizontalModule+height/Math.tan(el)*forward;
      fractionalShade=clamp((edgeReach-pitch)/Math.max(horizontalModule,0.001),0,1);
      if(fractionalShade>0)rowAffectedHours++;
    }
    const rl=beam*fractionalShade,shaded=p.total-hl-rl;
    const m=byMonth[new Date(h.timestamp_utc).getUTCMonth()];m.unshaded+=p.total/1000;m.horizonLoss+=hl/1000;m.rowLoss+=rl/1000;m.shaded+=shaded/1000;
    unshaded+=p.total/1000;horizonLost+=hl/1000;rowLost+=rl/1000;remaining+=shaded/1000;
    series.push({timestamp_utc:h.timestamp_utc,unshaded_poa_wm2:p.total,horizon_blocked:blocked?1:0,horizon_loss_wm2:hl,row_shade_fraction:fractionalShade,row_loss_wm2:rl,screened_poa_wm2:shaded});
  }
  return {method:'Screening-only direct beam horizon mask + geometrical row overlap, no sky diffuse occlusion or module electrical effects',unshadedPoa:unshaded,horizonLoss:horizonLost,rowLoss:rowLost,screenedPoa:remaining,lossPct:unshaded?100*(horizonLost+rowLost)/unshaded:0,maskedHours,rowAffectedHours,byMonth,series,options:{...options,horizonPointCount:horizon.length},warnings:['NOT a 3D shading simulation or near-shading electrical yield estimate; skyline silhouettes, horizon uncertainty, array row geometry and ground slope require site design verification.','Diffuse-sky obstruction, horizon reflected irradiance, bypass diode/mismatch losses, tracker backtracking, setbacks, parapets and irregular objects are excluded.','Uniform effective module slant length and pitch assumed; horizon blocking applies to direct beam only.']};
}
/** Independent reference formulas from Sandia/PVPMC; asserts production model outputs. */
export function referenceBenchmark(){
  const tests=[];const check=(id,computed,reference,tolerance)=>tests.push({id,computed,reference,difference:computed-reference,tolerance,pass:finite(computed)&&Math.abs(computed-reference)<=tolerance});
  const sample={zenith:35,elevation:55,azimuth:195,cosz:Math.cos(35*D)};
  const tilt=30,az=180,ghi=800,dni=650,dhi=800-650*sample.cosz,albedo=.22,extra=1367;
  const cosAoi=sample.cosz*Math.cos(tilt*D)+Math.sin(35*D)*Math.sin(tilt*D)*Math.cos(15*D);
  const rb=Math.max(cosAoi,0)/sample.cosz,ai=dni/extra,skyIso=dhi*(1+Math.cos(tilt*D))/2;
  const skyHay=dhi*(ai*rb+(1-ai)*(1+Math.cos(tilt*D))/2);
  const skyReindl=dhi*(ai*rb+(1-ai)*(1+Math.cos(tilt*D))/2*(1+Math.sqrt(dni*sample.cosz/ghi)*Math.sin(tilt*D/2)**3));
  const direct=dni*Math.max(cosAoi,0),ground=ghi*albedo*(1-Math.cos(tilt*D))/2;
  for(const [name,sky] of [['isotropic',skyIso],['haydavies',skyHay],['reindl',skyReindl]]){
    const out=irradianceParts(ghi,dni,dhi,sample,tilt,az,albedo,name,extra);
    check(name+' sky',out.sky,sky,1e-7);check(name+' total',out.total,direct+sky+ground,1e-7);
    check(name+' direct',out.beam,direct,1e-7);
  }
  // Published NREL SPA reference (2003-10-17T19:30:30Z, Colorado).
  const pos=solar('2003-10-17T19:30:30Z',39.742476,-105.1786);
  check('NOAA vs NREL SPA reference zenith (approx tolerance)',pos.zenith,50.11162,0.8);
  check('NOAA vs NREL SPA reference azimuth (approx tolerance)',pos.azimuth,194.34024,1.2);
  return {passed:tests.filter(t=>t.pass).length,total:tests.length,tests,allPassed:tests.every(t=>t.pass),reference:'Sandia PVPMC Hay–Davies/Reindl; NREL SPA published reference, loose tolerances for NOAA approximation'};
}
export function interannualStatistics(years){
  if(!Array.isArray(years)||years.length<2)throw Error('At least two complete weather years are required');
  const sorted=[...years].sort((a,b)=>a.year-b.year);
  const keys=['ghi','dni','dhi','poa','tempMean','windMean'];
  const metrics={};for(const k of keys){const vals=sorted.map(y=>y[k]).filter(finite);if(vals.length!==years.length)throw Error('Multi-year metric missing: '+k);
    const mean=vals.reduce((a,b)=>a+b,0)/vals.length,sd=Math.sqrt(vals.reduce((a,b)=>a+(b-mean)**2,0)/(vals.length-1));
    metrics[k]={mean,sd,min:Math.min(...vals),max:Math.max(...vals),cvPct:mean?100*sd/Math.abs(mean):null,p10:percentile(vals,.1),p50:percentile(vals,.5),p90:percentile(vals,.9)};
  }
  return {years:sorted,metrics,count:years.length,limitations:['Historical interannual sample quantiles are descriptive empirical statistics, NOT bankable exceedance P50/P90 predictions.','Source reanalysis product and model continuity must be consistent across years; separate calibrated ground sensors are preferable.']};
}
/** Monthly source reconciliation; hourly alignment only meaningful for identical exact hourly timestamp grids. */
export function reconcileResources(a,b,metaA={},metaB={}){
  if(!a?.stats||!b?.stats)throw Error('Both sources must pass full engineering analysis before reconciliation');
  const monthly=a.monthly.map((m,i)=>({month:i+1,ghiA:m.ghi,ghiB:b.monthly[i].ghi,ghiDelta:b.monthly[i].ghi-m.ghi,ghiPct:m.ghi?100*(b.monthly[i].ghi/m.ghi-1):null,poaA:m.poa,poaB:b.monthly[i].poa,poaPct:m.poa?100*(b.monthly[i].poa/m.poa-1):null}));
  const annualA=a.stats.ghi,annualB=b.stats.ghi;
  const sameGrid=a.hourly.length===b.hourly.length&&a.hourly.every((r,i)=>r.timestamp_utc===b.hourly[i].timestamp_utc);
  let hourlyMAE=null,hourlyBias=null;if(sameGrid){let ae=0,bias=0;for(let i=0;i<a.hourly.length;i++){const dif=b.hourly[i].ghi_wm2-a.hourly[i].ghi_wm2;ae+=Math.abs(dif);bias+=dif;}hourlyMAE=ae/a.hourly.length;hourlyBias=bias/a.hourly.length;}
  return {monthly,summary:{ghiA:annualA,ghiB:annualB,ghiBiasPct:annualA?(annualB/annualA-1)*100:null,poaA:a.stats.poa,poaB:b.stats.poa,poaBiasPct:a.stats.poa?(b.stats.poa/a.stats.poa-1)*100:null,hourlyMAE,hourlyBias,sameTimestampGrid:sameGrid,sourceA:metaA,sourceB:metaB},warnings:[...(!sameGrid?['Sources do not have identical physical hourly timestamps. Monthly comparisons may reflect different climatological periods or TMY source-month sampling; no hourly RMSE/MAE is reported.']:[]),'Disagreement indicates different source periods, resolutions and irradiance estimates; neither source is established as ground truth.']};
}
