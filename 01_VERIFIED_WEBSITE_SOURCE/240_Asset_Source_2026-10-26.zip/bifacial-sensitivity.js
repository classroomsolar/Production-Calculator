/** Optical-only bifacial pitch/GCR sensitivity (not electricity yield or land optimization). */
import {simulateBifacialYear,validateBifacialConfig} from './bifacial-vf.js';
import {simulateBifacialTrackerYear} from './bifacial-tracker.js';
export function sweepBifacialPitch(prepared,raw,mode='fixed',tracking=null,pitches=null){
 const base=validateBifacialConfig(raw);
 const series=pitches||[1.25,1.5,1.75,2,2.5,3,4].map(f=>f*base.widthM);
 if(!['fixed','tracker'].includes(mode))throw Error('Mode must be fixed or tracker');
 if(!Array.isArray(series)||series.length<2||series.length>15||series.some(p=>!Number.isFinite(p)||p<base.widthM||p>100))throw Error('Pitch sweep requires 2–15 physical pitches inside width..100m');
 const rows=series.map(pitchM=>{
  const config={...base,pitchM};
  const r=mode==='tracker'?simulateBifacialTrackerYear(prepared,config,tracking):simulateBifacialYear(prepared,config);
  const a=r.annual,gcr=base.widthM/pitchM;
  return {pitchM,gcr,annualFrontKWhM2:a.frontKWhM2,annualRearEffectiveKWhM2:a.backEffectiveKWhM2,collectorEffectiveKWhM2:a.totalEffectiveKWhM2,perGroundAreaKWhM2:a.totalEffectiveKWhM2*gcr,backOpticalGainPct:a.bifacialOpticalGainPct};
 });
 const collector=[...rows].sort((a,b)=>b.collectorEffectiveKWhM2-a.collectorEffectiveKWhM2)[0],land=[...rows].sort((a,b)=>b.perGroundAreaKWhM2-a.perGroundAreaKWhM2)[0];
 return {rows,mode,collectorScreenMaximumPitchM:collector.pitchM,groundIncidentScreenMaximumPitchM:land.pitchM,warnings:['Sensitivity ONLY: per collector m² and per idealized projected land m² incident irradiance. Not a PV DC/AC energy optimization, land entitlement study or project LCOE.','Fixed tilt model assumes level ground; tracker mode additionally requires horizontal axis, bounded rotation and no site-specific terrain/obstacle/stow.','Sampled pitches only; no analytic global optimum, cable/road spacing, soil condition, structural/racking economics or electrical mismatch included.']};
}
