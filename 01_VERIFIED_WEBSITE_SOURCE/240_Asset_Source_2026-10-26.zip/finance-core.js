/** Batch 5 — simplified nominal pre-tax front-of-meter cashflow reference.
 * Source: NLR/NREL SAM financial-model documentation, Short et al. 1995.
 * NO debt, incentives, taxes, financing, depreciation, demand tariff, merchant TOD,
 * replacement reserves, battery dispatch or bankable P90. Currency must be consistent.
 */
const finite=Number.isFinite;
const requireRange=(v,lo,hi,k)=>{if(!finite(v)||v<lo||v>hi)throw Error(k+' must be between '+lo+' and '+hi);};
export function projectFinance(p){
 if(!p||typeof p!=='object')throw Error('Finance inputs required');
 requireRange(p.year1KWh,1,1e15,'Year-one POI exported energy kWh');
 requireRange(p.capex,0,1e15,'CAPEX');requireRange(p.omFixedPerYear,0,1e13,'Fixed O&M');
 requireRange(p.omVariablePerKWh,0,100,'Variable O&M per kWh');
 requireRange(p.ppaPerKWh,0,100,'Initial PPA per kWh');
 requireRange(p.degradationPct,0,25,'Annual degradation %');
 requireRange(p.ppaEscalationPct,-20,50,'PPA escalation %');
 requireRange(p.omEscalationPct,-20,50,'O&M escalation %');
 requireRange(p.discountNominalPct,-50,100,'Nominal discount %');
 if(!Number.isInteger(p.years)||p.years<1||p.years>60)throw Error('Analysis years must be 1..60 integer');
 const d=p.discountNominalPct/100;
 const rows=[];let cumulative=-p.capex,payback=null;
 let pvcost=p.capex,pvenergy=0,netNPV=-p.capex,undiscountedLifetimeEnergy=0;
 for(let y=1;y<=p.years;y++){
  const energy=p.year1KWh*(1-p.degradationPct/100)**(y-1);
  const tariff=p.ppaPerKWh*(1+p.ppaEscalationPct/100)**(y-1);
  const fixedOpex=p.omFixedPerYear*(1+p.omEscalationPct/100)**(y-1);
  const variableOpex=p.omVariablePerKWh*energy*(1+p.omEscalationPct/100)**(y-1);
  const rev=energy*tariff,opex=fixedOpex+variableOpex,cashflow=rev-opex;
  const discount=(1+d)**y;
  pvcost+=opex/discount;pvenergy+=energy/discount;netNPV+=cashflow/discount;
  undiscountedLifetimeEnergy+=energy;
  const prev=cumulative;cumulative+=cashflow;
  if(payback===null&&prev<0&&cumulative>=0&&cashflow>0)payback=(y-1)+(-prev/cashflow);
  rows.push({year:y,productionKWh:energy,ppaTariff:tariff,revenue:rev,operatingCost:opex,preTaxCashFlow:cashflow,presentValueNetCashFlow:cashflow/discount,cumulativeCashFlow:cumulative});
 }
 const npvAt=rate=>-p.capex+rows.reduce((s,r)=>s+r.preTaxCashFlow/(1+rate)**r.year,0);
 // IRR can have multiple roots if cashflow changes sign; do not return a misleading unique IRR.
 let irr=null,irrWarning=null;
 let signChanges=0,lastSign=-1;for(const r of rows){const sign=Math.sign(r.preTaxCashFlow);if(sign&&lastSign!==sign){signChanges++;lastSign=sign}}
 if(signChanges>1)irrWarning='Cash-flow sign changes: more than one IRR may exist; omitted.';
 else{let lo=-.9999,hi=10,flo=npvAt(lo),fhi=npvAt(hi);
  if(flo*fhi>0)irrWarning='No IRR root over -99.99% to 1000%; omitted.';
  else{for(let n=0;n<140;n++){const mid=(lo+hi)/2,ym=npvAt(mid);if(flo*ym<=0){hi=mid;fhi=ym}else{lo=mid;flo=ym}}irr=(lo+hi)/2;}
 }
 const lcoe=pvcost/pvenergy;
 if(!finite(lcoe)||!finite(netNPV))throw Error('Unstable financial calculation');
 return {status:'SIMPLE_PRETAX_CASHFLOW_SCREEN',annualRows:rows,
 summary:{nominalLCOEPerKWh:lcoe,nominalNPV:netNPV,preTaxIRRPercent:irr===null?null:100*irr,undiscountedPaybackYears:payback,
 year1ExportKWh:p.year1KWh,undiscountedLifetimeEnergyKWh:undiscountedLifetimeEnergy,presentValueTotalCost:pvcost,presentValueEnergyKWh:pvenergy},
 assumptions:['Simplified front-of-meter project. Nominal currency/cashflow and nominal discount rate; not a full SAM PPA or tax model.',
 'No debt, interest, incentives, income taxes, tax depreciation, inflation/real conversion, replacement capex, insurance, curtailment price exposure, time-of-delivery or ancillary revenue.',
 'Year-one energy must come from independently qualified exported POI production, or be explicitly marked synthetic.',
 irrWarning].filter(Boolean)};
}
