/** Batch 6 incremental UI consolidation: maintain one visible PV workbench panel per tab.
 * Does not alter original numeric inputs, engines, reports, or storage.
 */
const root=document.getElementById('pv15Section');
const groups={strings:'pv15StringForm',yield:'pv15YieldForm',audit:'pv15AuditForm',detail:'pv17Lab',tracker:'trackerB3',finance:'financeB5',bess:'bessB4',electrical:'electricalB4',mismatch:'mismatchB3',thermal:'thermalB4',bifacial:'bifacialB3'};
const classifier=b=>b.dataset.pv15||(b.dataset.pv17!==undefined?'detail':null)||(b.dataset.trackerB3!==undefined?'tracker':null)||(b.dataset.financeB5!==undefined?'finance':null)||(b.dataset.bessB4!==undefined?'bess':null)||(b.dataset.electricalB4!==undefined?'electrical':null)||(b.dataset.mismatchB3!==undefined?'mismatch':null)||(b.dataset.thermalB4!==undefined?'thermal':null)||(b.dataset.bifacialB3!==undefined?'bifacial':null);
export function normalizePanelVisibility(tabButtons,panels,active){
 if(!groups[active])return false;
 for(const [key,id] of Object.entries(groups)){const panel=panels[id];if(panel)panel.hidden=key!==active}
 for(const b of tabButtons){const isActive=classifier(b)===active;b.classList.toggle('active',isActive);b.setAttribute('aria-selected',isActive?'true':'false')}
 return true;
}
if(root){const tabs=root.querySelector('.pv15-tabs');if(tabs){
 tabs.setAttribute('role','tablist');tabs.setAttribute('aria-label','PV engineering tools');
 const toolbar=document.createElement('div');toolbar.className='pv-shell';toolbar.setAttribute('role','note');
 const title=document.createElement('strong');title.textContent='Integrated PV engineering workbench';
 const sub=document.createElement('span');sub.textContent='Choose a calculator below. Only its workspace is shown; saved results stay local in their original modules.';
 toolbar.append(title,sub);tabs.before(toolbar);
 for(const button of tabs.querySelectorAll('button')){button.setAttribute('role','tab');button.setAttribute('aria-selected',button.classList.contains('active')?'true':'false')}
 tabs.addEventListener('click',e=>{const btn=e.target.closest('button');if(!btn||!tabs.contains(btn))return;const selected=classifier(btn);if(!selected)return;
  const panels=Object.fromEntries(Object.values(groups).map(id=>[id,document.getElementById(id)]));
  normalizePanelVisibility(Array.from(tabs.querySelectorAll('button')),panels,selected);
 });
 }}
