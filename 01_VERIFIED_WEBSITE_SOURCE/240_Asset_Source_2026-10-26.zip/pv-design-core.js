/** Solar PV Platform prototype v1.5: string/MPPT and preliminary hourly production.
 * Methods: manufacturer temperature coefficients for nameplate points; Faiman-style
 * temperature screening, PVWatts-style DC power law, explicit sequential losses.
 * NOT a certified NEC/IEC string design, single-diode model, detailed PVsyst/HelioScope
 * electrical model, or bankable energy yield. No vendor rating is hard coded here.
 * All inputs must be user-supplied, source-tagged, and validated before use.
 */
const finite=Number.isFinite;
const clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
const requirePositive=(obj, keys, name)=>{for(const k of keys)if(!finite(obj[k])||obj[k]<=0)throw Error(`${name}.${k}: required finite positive number`)};
const requireNonnegative=(obj,keys,name)=>{for(const k of keys)if(!finite(obj[k])||obj[k]<0)throw Error(`${name}.${k}: required finite nonnegative number`)};
const toRatio=(x)=>x/100;
export function temperaturePoint(stc, pctPerC, tCellC){
 if(![stc,pctPerC,tCellC].every(finite))throw Error('Invalid STC temperature correction inputs');
 const corrected=stc*(1+toRatio(pctPerC)*(tCellC-25));
 if(corrected<=0)throw Error('Temperature extrapolation produced nonphysical value; review module limits');
 return corrected;
}
export function validateHardware(module,inverter,design){
 requirePositive(module,['pmpW','vocV','vmpV','iscA','impA','maxSystemVoltageV'],'module');
 requirePositive(inverter,['pacRatedKW','maxDcVoltageV','mpptMinV','mpptMaxV','mpptCount','maxOperatingCurrentPerMpptA','maxShortCircuitCurrentPerMpptA'],'inverter');
 requirePositive(design,['modulesPerString','stringsPerMppt','mpptUsed','systemMaxVoltageV'],'design');
 if(module.vocV<=module.vmpV||module.iscA<=module.impA)throw Error('Module STC values require Voc>Vmp and Isc>Imp');
 if(inverter.mpptMaxV>inverter.maxDcVoltageV||inverter.mpptMinV>=inverter.mpptMaxV)throw Error('Inverter MPPT voltage window contradicts absolute maximum input voltage');
 for(const [obj,keys,label] of [[module,['betaVocPctC','betaVmpPctC','alphaIscPctC','gammaPmpPctC'],'module'],[design,['minCellC','maxCellC'],'design']])for(const k of keys)if(!finite(obj[k]))throw Error(`${label}.${k}: required numeric`);
 for(const k of ['modulesPerString','stringsPerMppt','mpptUsed'])if(!Number.isInteger(design[k]))throw Error(`design.${k}: integer required`);
 if(!Number.isInteger(inverter.mpptCount)||inverter.mpptCount>500)throw Error('Inverter MPPT count not valid');
 if(design.mpptUsed>inverter.mpptCount)throw Error('Used MPPTs exceed inverter MPPT count');
 if(design.maxCellC<=design.minCellC||design.minCellC< -100||design.maxCellC>150)throw Error('Cell temperature design bounds invalid');
 if(module.betaVocPctC>=0||module.betaVmpPctC>=0||module.gammaPmpPctC>=0||module.alphaIscPctC<0)throw Error('Temperature coefficient signs require review; check datasheet units %/°C versus V/°C');
 if(module.vocV*module.iscA<module.pmpW||Math.abs(module.vmpV*module.impA/module.pmpW-1)>.06)throw Error('Module power and I-V nameplate points are inconsistent (>6%)');
}
export function checkStringMppt(module,inverter,design){
 validateHardware(module,inverter,design);
 const coldV=temperaturePoint(module.vocV,module.betaVocPctC,design.minCellC);
 const hotVmp=temperaturePoint(module.vmpV,module.betaVmpPctC,design.maxCellC);
 const coldVmp=temperaturePoint(module.vmpV,module.betaVmpPctC,design.minCellC);
 const hotIsc=temperaturePoint(module.iscA,module.alphaIscPctC,design.maxCellC);
 const hotImp=module.alphaImpPctC===undefined?null:temperaturePoint(module.impA,module.alphaImpPctC,design.maxCellC);
 const maxVoltage=Math.min(module.maxSystemVoltageV,inverter.maxDcVoltageV,design.systemMaxVoltageV);
 const minModules=Math.ceil(inverter.mpptMinV/hotVmp);
 const maxModulesVoc=Math.floor(maxVoltage/coldV);
 const maxModulesMPPT=Math.floor(inverter.mpptMaxV/coldVmp);
 const maxModules=Math.min(maxModulesVoc,maxModulesMPPT);
 const checks=[
  {id:'absolute_cold_voc',passed:design.modulesPerString*coldV<=maxVoltage,actual:design.modulesPerString*coldV,limit:maxVoltage,unit:'V'},
  {id:'mppt_hot_vmp',passed:design.modulesPerString*hotVmp>=inverter.mpptMinV,actual:design.modulesPerString*hotVmp,limit:inverter.mpptMinV,unit:'V'},
  {id:'mppt_cold_vmp',passed:design.modulesPerString*coldVmp<=inverter.mpptMaxV,actual:design.modulesPerString*coldVmp,limit:inverter.mpptMaxV,unit:'V'},
  {id:'inverter_short_circuit_input',passed:design.stringsPerMppt*hotIsc<=inverter.maxShortCircuitCurrentPerMpptA,actual:design.stringsPerMppt*hotIsc,limit:inverter.maxShortCircuitCurrentPerMpptA,unit:'A'},
  {id:'inverter_operating_current_STC',passed:design.stringsPerMppt*module.impA<=inverter.maxOperatingCurrentPerMpptA,actual:design.stringsPerMppt*module.impA,limit:inverter.maxOperatingCurrentPerMpptA,unit:'A'},
 ];
 if(hotImp!==null)checks.push({id:'inverter_operating_current_hot',passed:design.stringsPerMppt*hotImp<=inverter.maxOperatingCurrentPerMpptA,actual:design.stringsPerMppt*hotImp,limit:inverter.maxOperatingCurrentPerMpptA,unit:'A'});
 const mppts=design.mpptUsed,strings=mppts*design.stringsPerMppt,modules=strings*design.modulesPerString;
 const warnings=[
  'Temperature corrections use datasheet linear coefficients, not a full single-diode I–V curve or manufacturer voltage-temperature lookup.',
  'Minimum temperatures must be independently selected for the project; historical observed minima are not automatically adopted as code design temperatures.',
  'Inverter current ratings are compared directly with modeled string currents; source-dependent input-count, fuse, OCPD, conductor and module reverse-current compliance remain separate reviews.',
  'String configuration alone does not establish NEC Article 690, IEC 62548 or UL listing compliance.',
 ];
 if(hotImp===null)warnings.push('No Imp temperature coefficient supplied; operating-current evaluation at hot condition remains unverified. STC input current is checked.');
 if(minModules>maxModules)warnings.push('No string count satisfies both hot minimum MPPT voltage and cold upper voltage constraints.');
 return {passed:checks.every(x=>x.passed)&&minModules<=maxModules,checks,validStringRange:{minModules,maxModules,maxModulesVoc,maxModulesMPPT},design:{moduleCount:modules,stringCount:strings,nameplateDcKW:modules*module.pmpW/1000,nameplateAcKW:inverter.pacRatedKW,dcAcRatio:modules*module.pmpW/(1000*inverter.pacRatedKW)},conditions:{coldVocV:coldV,hotVmpV:hotVmp,coldVmpV:coldVmp,hotIscA:hotIsc,hotImpA:hotImp,seriesVoltageCeilingV:maxVoltage},warnings};
}
export function simulatePreliminaryYield(hours,module,inverter,design,losses,temperatureModel,weatherConfig={}){
 const electrical=checkStringMppt(module,inverter,design);
 if(!electrical.passed)throw Error('PV simulation withheld: string/MPPT electrical screening failed.');
 if(!Array.isArray(hours)||hours.length===0)throw Error('Validated hourly POA weather series required');
 if(![8760,8784].includes(hours.length))throw Error('Only complete 8760/8784-hour series accepted for annual production results');
 requirePositive(temperatureModel,['u0Wm2K'],'temperatureModel');
 requireNonnegative(temperatureModel,['u1Wm2KPerMps'],'temperatureModel');
 const derates=['soilingPct','iamPct','shadingPct','dcWiringPct','mismatchPct','acWiringPct','transformerPct'];
 for(const k of derates)if(!finite(losses[k])||losses[k]<0||losses[k]>=100)throw Error(`losses.${k}: percentage must be between 0 (inclusive) and 100 (exclusive)`);
 for(const k of ['inverterEfficiencyPct','availabilityPct'])if(!finite(losses[k])||losses[k]<=0||losses[k]>100)throw Error(`losses.${k}: percentage must be greater than 0 and no greater than 100`);
 if(losses.poiExportLimitKW!==null && losses.poiExportLimitKW!==undefined && (!finite(losses.poiExportLimitKW)||losses.poiExportLimitKW<=0))throw Error('Invalid POI export limit');
 let prev=null, monthly=Array.from({length:12},(_,i)=>({month:i+1,hours:0,irradiationKWhM2:0,dcEnergyKWh:0,inverterAcEnergyKWh:0,poiEnergyKWh:0,clippedKWh:0}));
 const energy={},stages=['idealDC','afterSoiling','afterIAM','afterShading','afterTemperature','afterMismatch','afterDcWiring','afterInverterEfficiency','afterClipping','afterAcWiring','afterTransformer','afterAvailability','afterCurtailment'];
 for(const stage of stages)energy[stage]=0;
 const results=[],kwp=electrical.design.nameplateDcKW,invAc=inverter.pacRatedKW;
 const invEff=toRatio(losses.inverterEfficiencyPct),availability=toRatio(losses.availabilityPct);
 for(let i=0;i<hours.length;i++){
  const h=hours[i],t=Date.parse(h.timestamp_utc);
  if(!finite(t)||prev!==null&&t-prev!==3600000)throw Error(`Timestamp missing/duplicate/out of sequence at row ${i+1}`);prev=t;
  const ghi=Number(h.poa_wm2),ta=Number(h.temp_air_c),ws=Number(h.wind_speed_mps);
  if(![ghi,ta,ws].every(finite)||ghi<0||ghi>2200||ta< -100||ta>80||ws<0||ws>85)throw Error(`Hourly input out of physical QC bounds at row ${i+1}`);
  const denom=temperatureModel.u0Wm2K+temperatureModel.u1Wm2KPerMps*ws;
  if(denom<=0)throw Error('Nonphysical cell-temperature model denominator');
  const cellC=ta+ghi/denom;
  let idealDC=kwp*(ghi/1000);
  let afterSoiling=idealDC*(1-toRatio(losses.soilingPct));
  let afterIAM=afterSoiling*(1-toRatio(losses.iamPct));
  let afterShading=afterIAM*(1-toRatio(losses.shadingPct));
  const factor=1+toRatio(module.gammaPmpPctC)*(cellC-25);
  if(factor<0||factor>2.5)throw Error(`Temperature response extrapolation invalid at row ${i+1}`);
  let afterTemperature=afterShading*factor;
  let afterMismatch=afterTemperature*(1-toRatio(losses.mismatchPct));
  let afterDcWiring=afterMismatch*(1-toRatio(losses.dcWiringPct));
  let afterInverterEfficiency=afterDcWiring*invEff;
  let afterClipping=Math.min(invAc,afterInverterEfficiency);
  let afterAcWiring=afterClipping*(1-toRatio(losses.acWiringPct));
  let afterTransformer=afterAcWiring*(1-toRatio(losses.transformerPct));
  let afterAvailability=afterTransformer*availability;
  let afterCurtailment=losses.poiExportLimitKW?Math.min(afterAvailability,losses.poiExportLimitKW):afterAvailability;
  const values={idealDC,afterSoiling,afterIAM,afterShading,afterTemperature,afterMismatch,afterDcWiring,afterInverterEfficiency,afterClipping,afterAcWiring,afterTransformer,afterAvailability,afterCurtailment};
  for(const stage of stages)energy[stage]+=values[stage];
  const clippedKW=afterInverterEfficiency-afterClipping;
  const monthTime=weatherConfig.kind==='EPW'?new Date(t+((weatherConfig.localStandardTimezoneHours||0)-1)*3600000):new Date(t);
  const m=monthly[monthTime.getUTCMonth()];m.hours++;m.irradiationKWhM2+=ghi/1000;m.dcEnergyKWh+=afterDcWiring;m.inverterAcEnergyKWh+=afterClipping;m.poiEnergyKWh+=afterCurtailment;m.clippedKWh+=clippedKW;
  results.push({timestamp_utc:h.timestamp_utc,poa_wm2:ghi,temp_air_c:ta,wind_speed_mps:ws,cell_temp_c:cellC,dc_kw:afterDcWiring,ac_inverter_kw:afterClipping,poi_kw:afterCurtailment,clipping_kw:clippedKW});
 }
 const annualPoA=monthly.reduce((s,m)=>s+m.irradiationKWhM2,0);
 const yieldKWh=energy.afterCurtailment;
 return {method:'Preliminary PVWatts-style irradiance-temperature output + Faiman-style thermal screen + constant efficiency and sequential losses (not exact PVWatts V8)',status:'PRELIMINARY ONLY',hours:hours.length,design:electrical.design,summary:{annualPoaKWhM2:annualPoA,dcEnergyKWh:energy.afterDcWiring,inverterAcKWh:energy.afterClipping,poiKWh:yieldKWh,specificYieldKWhPerKWp:yieldKWh/kwp,performanceRatio:annualPoA?yieldKWh/(kwp*annualPoA):null,capacityFactor:yieldKWh/(invAc*hours.length),clippingKWh:energy.afterInverterEfficiency-energy.afterClipping},monthly,hourly:results,stages:energy,electrical,warnings:['Not an equivalent or independently benchmarked reproduction of PVsyst, HelioScope, SAM/PVWatts V8 or a single-diode model.','Constant loss factors are explicit user assumptions; detailed shading/mismatch, tracker backtracking, spectral corrections, inverter efficiency maps and module-level electronics are not represented.','Faiman screening parameters must match the real mounting configuration. Temperature module model must be benchmarked against measured/validated performance before production acceptance.','Averaged wind-speed values and irradiance timestamps must be physically aligned. POI output is energy estimation, not a utility interconnection study.','Availability percentage represents energy derate, not an independently simulated outage schedule.']};
}
