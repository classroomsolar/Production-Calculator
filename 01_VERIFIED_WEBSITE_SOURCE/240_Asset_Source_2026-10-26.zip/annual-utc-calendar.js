/** Full-calendar UTC hour validation for any result labelled ANNUAL.
 * The 8760/8784 length alone does NOT establish a calendar year. A shifted
 * or non-leap 8784-hour interval produces misleading month/annual metrics.
 * Source input should already be timezone-normalized to UTC (Z) upstream.
 * This does not validate weather quality, source timestamp convention or
 * energy-method validity.
 */
export function validateAnnualUtcCalendar(rows,{label='Annual energy series'}={}){
 if(!Array.isArray(rows)||![8760,8784].includes(rows.length))
  throw Error(`${label}: exactly 8760 or 8784 hourly records required`);
 const first=rows[0]?.timestamp_utc;
 if(typeof first!=='string'||!/^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}(?:\.[0-9]{1,3})?Z$/.test(first))
  throw Error(`${label}: UTC timestamps must be canonical ISO-8601 values ending in Z`);
 const start=Date.parse(first);
 if(!Number.isFinite(start))throw Error(`${label}: invalid UTC start timestamp`);
 const year=new Date(start).getUTCFullYear();
 if(year<1000||year>9999||start!==Date.parse(`${String(year).padStart(4,'0')}-01-01T00:00:00Z`))
  throw Error(`${label}: annual series must start on January 1 at 00:00 UTC`);
 const leap=(year%4===0&&year%100!==0)||year%400===0;
 const expected=leap?8784:8760;
 if(rows.length!==expected)
  throw Error(`${label}: ${year} needs ${expected} UTC hours (${leap?'leap':'ordinary'} year); received ${rows.length}`);
 for(let i=0;i<rows.length;i++){
  const s=rows[i]?.timestamp_utc;
  if(typeof s!=='string'||!/^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}(?:\.[0-9]{1,3})?Z$/.test(s))
   throw Error(`${label}: invalid or non-UTC timestamp at hour ${i+1}`);
  const t=Date.parse(s);
  if(t!==start+i*3600000)
   throw Error(`${label}: missing, repeated or shifted UTC hour at row ${i+1}`);
 }
 return {calendarYear:year,expectedHours:expected,isLeapYear:leap,startUTC:first,endUTC:rows.at(-1).timestamp_utc};
}
