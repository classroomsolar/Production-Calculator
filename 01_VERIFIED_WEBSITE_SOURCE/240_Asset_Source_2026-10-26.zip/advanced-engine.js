/** Solar Resource Studio - engineering extensions v1.2 (2026-10).
 * Not an energy-yield, bankability, IEC 61724 or site-survey model.
 * Solar positioning is the existing NOAA approximation in engine.js.
 * Diffuse transposition formulae: Hay & Davies (1980), Reindl (1990).
 * Independent from any Wix or API client: calculation kernel is deterministic.
 */
import {solar} from './engine.js';
const RAD=Math.PI/180;
const clamp=(x,l,h)=>Math.max(l,Math.min(h,x));
const finite=Number.isFinite;
const r=(n,p=3)=>finite(n)?Number(n.toFixed(p)):null;
export function dniExtraterrestrial(date){
  const dt=new Date(date),yr=dt.getUTCFullYear();
  const doy=Math.floor((+dt-Date.UTC(yr,0,1))/86400000)+1;
  const days=(Date.UTC(yr+1,0,1)-Date.UTC(yr,0,1))/86400000;
  const B=2*Math.PI*(doy-1)/days;
  // Spencer/Fourier earth-sun eccentricity correction, solar constant 1367 W/m2.
  return 1367*(1.00011+.034221*Math.cos(B)+.00128*Math.sin(B)+.000719*Math.cos(2*B)+.000077*Math.sin(2*B));
}
export function irradianceParts(ghi,dni,dhi,position,tilt,azimuth,albedo,model='isotropic',extra=1367){
  if(!['isotropic','haydavies','reindl'].includes(model))throw Error('Unknown diffuse transposition model');
  if([ghi,dni,dhi,tilt,azimuth,albedo,extra].some(v=>!finite(v)))throw Error('Non-finite irradiance inputs');
  const t=tilt*RAD,cosT=Math.cos(t),sinT=Math.sin(t);
  const zen=position.zenith*RAD,cosz=position.cosz;
  const cosi=cosz*cosT+Math.sin(zen)*sinT*Math.cos((position.azimuth-azimuth)*RAD);
  const sunUp=position.elevation>0;
  const posi=sunUp?Math.max(0,cosi):0;
  const beam=dni*posi,ground=ghi*albedo*(1-cosT)/2;
  const iso=dhi*(1+cosT)/2;
  let circumsolar=0,horizon=0,isotropic=iso;
  if(model!=='isotropic'&&sunUp){
    const ai=clamp(dni/extra,0,1);
    // Consistent with pvlib's Rb limiter cosz>=cos(89°)=0.01745.
    const rb=posi/Math.max(cosz,0.01745);
    circumsolar=dhi*ai*rb;
    isotropic=dhi*(1-ai)*(1+cosT)/2;
    if(model==='reindl'){
      const bhi=Math.max(0,dni*cosz);
      horizon=isotropic*Math.sqrt(clamp(ghi>0?bhi/ghi:0,0,1))*Math.sin(t/2)**3;
    }
  }
  const sky=isotropic+circumsolar+horizon;
  return {beam,sky,ground,isotropic,circumsolar,horizon,total:beam+sky+ground,aoi:Math.acos(clamp(cosi,-1,1))/RAD,cosi};
}
export function percentile(values,p){
  if(!values.length||p<0||p>1)return null;
  const a=[...values].sort((x,y)=>x-y),q=(a.length-1)*p,i=Math.floor(q);
  return a[i]+(a[Math.min(i+1,a.length-1)]-a[i])*(q-i);
}
export function datesForUTCYear(year){
  const days=(Date.UTC(year+1,0,1)-Date.UTC(year,0,1))/86400000;
  return Array.from({length:days},(_,i)=>new Date(Date.UTC(year,0,i+1)).toISOString().slice(0,10));
}
export function sunEventsUTC(day,lat,lon){
  if(!/^\d{4}-\d{2}-\d{2}$/.test(day))throw Error('UTC day required');
  const start=Date.parse(`${day}T00:00:00Z`);
  if(!finite(start))throw Error('Invalid UTC day');
  // Standard geometric sunrise/sunset solar-center altitude -0.833 deg.
  const step=5*60000,lim=start+86400000,target=-.833;
  let rise=null,set=null,noon=null,noonAlt=-91,last=solar(start,lat,lon).elevation-target;
  for(let t=start+step;t<=lim;t+=step){
    const p=solar(t,lat,lon),v=p.elevation-target;
    if(p.elevation>noonAlt){noonAlt=p.elevation;noon=t}
    if(last<0&&v>=0&&rise===null)rise=t-step+step*(-last)/(v-last);
    if(last>=0&&v<0)set=t-step+step*(last)/(last-v);
    last=v;
  }
  const stamp=t=>t===null?null:new Date(t).toISOString().slice(11,16);
  return {sunriseUTC:stamp(rise),sunsetUTC:stamp(set),noonUTC:stamp(noon),noonElevation:r(noonAlt,2),daylightHours:rise!==null&&set!==null&&set>rise?r((set-rise)/3600000,2):null,note:'UTC calendar day; edge events may fall on adjacent UTC day. Approximate refraction only.'};
}
function makeMonthly(){return Array.from({length:12},(_,i)=>({month:i+1,hours:0,ghi:0,dni:0,dhi:0,poa:0,beam:0,sky:0,ground:0,kt:0,ktHours:0,tempSum:0,windSum:0}));}
/** Accept only a result already successfully validated by engine.analyze. */
export function computeEngineering(result,cfg,model='reindl'){
  if(!result?.summary||!Array.isArray(result.hourly)||result.hourly.length===0)throw Error('Run the primary validated resource study first');
  const rows=result.hourly,monthly=makeMonthly(),days=new Map(),prepared=[],temps=[],winds=[];
  let highKT=0,night=0,closure=0,exceedsExtra=0,totalBeam=0,totalSky=0,totalGround=0;
  for(let i=0;i<rows.length;i++){
    const x=rows[i],dt=new Date(x.timestamp_utc),posTime=new Date(+dt+(cfg.offsetHours||0)*3600000);
    const pos=solar(posTime,cfg.lat,cfg.lon),extra=dniExtraterrestrial(posTime);
    const p=irradianceParts(x.ghi_wm2,x.dni_wm2,x.dhi_wm2,pos,cfg.tilt,cfg.azimuth,cfg.albedo,model,extra);
    const kt=(pos.cosz>.065?x.ghi_wm2/(extra*pos.cosz):null);
    if(kt!==null&&kt>1.05)highKT++;
    if(x.dni_wm2>extra*1.05)exceedsExtra++;
    const c=x.dhi_wm2+x.dni_wm2*Math.max(0,pos.cosz),err=x.ghi_wm2-c;
    if(x.ghi_wm2>100&&Math.abs(err)>Math.max(75,.20*x.ghi_wm2))closure++;
    if(pos.elevation< -6&&x.ghi_wm2>40)night++;
    const groupDate=cfg.kind==='EPW'?new Date(+dt+((cfg.localStandardTimezoneHours||0)-1)*3600000):dt;
    const m=monthly[groupDate.getUTCMonth()];m.hours++;m.ghi+=x.ghi_wm2/1000;m.dni+=x.dni_wm2/1000;m.dhi+=x.dhi_wm2/1000;m.poa+=p.total/1000;m.beam+=p.beam/1000;m.sky+=p.sky/1000;m.ground+=p.ground/1000;m.tempSum+=x.temp_air_c;m.windSum+=x.wind_speed_mps;
    if(kt!==null&&finite(kt)){m.kt+=kt;m.ktHours++}
    totalBeam+=p.beam/1000;totalSky+=p.sky/1000;totalGround+=p.ground/1000;
    const day=groupDate.toISOString().slice(0,10);
    if(!days.has(day))days.set(day,{dateUTC:day,hours:0,ghi:0,dni:0,dhi:0,poa:0,tempSum:0,tempMin:Infinity,tempMax:-Infinity,windSum:0,windMax:0});
    const d=days.get(day);d.hours++;d.ghi+=x.ghi_wm2/1000;d.dni+=x.dni_wm2/1000;d.dhi+=x.dhi_wm2/1000;d.poa+=p.total/1000;d.tempSum+=x.temp_air_c;d.tempMin=Math.min(d.tempMin,x.temp_air_c);d.tempMax=Math.max(d.tempMax,x.temp_air_c);d.windSum+=x.wind_speed_mps;d.windMax=Math.max(d.windMax,x.wind_speed_mps);
    temps.push(x.temp_air_c);winds.push(x.wind_speed_mps);
    prepared.push({ ...x,solar_zenith_deg:r(pos.zenith),solar_elevation_deg:r(pos.elevation),solar_azimuth_deg:r(pos.azimuth),declination_deg:r(pos.declination),aoi_deg:r(p.aoi),etr_dni_wm2:r(extra),clearness_index:kt===null?'':r(kt),ghi_closure_wm2:r(err),poa_direct_wm2:r(p.beam),poa_sky_wm2:r(p.sky),poa_ground_wm2:r(p.ground),poa_wm2:r(p.total),_pos:pos,_extra:extra });
  }
  for(const m of monthly){m.tempMean=m.hours?m.tempSum/m.hours:null;m.windMean=m.hours?m.windSum/m.hours:null;m.ktMean=m.ktHours?m.kt/m.ktHours:null;delete m.tempSum;delete m.windSum;delete m.kt;delete m.ktHours;}
  const daily=[...days.values()].map(d=>({...d,tempMean:d.tempSum/d.hours,windMean:d.windSum/d.hours})).map(({tempSum,windSum,...d})=>d);
  const annual=result.summary.hours===8760||result.summary.hours===8784;
  const warnings=[...result.failures,...result.reviews];
  if(highKT)warnings.push(`${highKT} high-clearness-index hours (Kt > 1.05); inspect extraterrestrial normalization and weather/source timestamps.`);
  if(exceedsExtra)warnings.push(`${exceedsExtra} records have DNI greater than 105% of extraterrestrial DNI; review source values and units.`);
  if(!annual)warnings.push('Partial resource sample: orientation optimum and totals cannot be described as annual.');
  return {model,hourly:prepared,monthly,daily,annual,sourceStatus:result.status,warningCount:warnings.length,warnings,stats:{hours:rows.length,ghi:result.summary.ghi,dni:result.summary.dni,dhi:result.summary.dhi,poa:totalBeam+totalSky+totalGround,beam:totalBeam,sky:totalSky,ground:totalGround,temperature:{min:percentile(temps,0),p01:percentile(temps,.01),p05:percentile(temps,.05),p50:percentile(temps,.5),p95:percentile(temps,.95),p99:percentile(temps,.99),max:percentile(temps,1)},wind:{min:percentile(winds,0),p50:percentile(winds,.5),p90:percentile(winds,.9),p95:percentile(winds,.95),p99:percentile(winds,.99),max:percentile(winds,1)},closure,night,highKT,exceedsExtra}};
}
/** Deterministic whole-sample POA sweep; output not energy production. */
export function optimizeOrientation(prepared,cfg,model='reindl',stepTilt=5,stepAz=15){
  if(!prepared?.length)throw Error('No hourly data for orientation sweep');
  const tg=Array.from({length:Math.floor(90/stepTilt)+1},(_,i)=>i*stepTilt).filter(v=>v<=90);
  const az=Array.from({length:Math.floor(360/stepAz)},(_,i)=>i*stepAz);
  const scenarios=[];
  for(const tilt of tg)for(const azimuth of az){
    let sum=0;
    for(const h of prepared){sum+=irradianceParts(h.ghi_wm2,h.dni_wm2,h.dhi_wm2,h._pos,tilt,azimuth,cfg.albedo,model,h._extra).total;}
    scenarios.push({tilt,azimuth,poa:sum/1000});
  }
  scenarios.sort((a,b)=>b.poa-a.poa);
  return {best:scenarios[0],scenarios,tilts:tg,azimuths:az,evaluated:scenarios.length,model,disclaimer:'Coarse grid maximum of incident POA irradiation; does not include shading, structural constraints, tracking, losses or PV energy yield.'};
}
export function simpleHistogram(values,bins=12){
  const arr=values.filter(finite);if(!arr.length)return [];
  const mi=Math.min(...arr),ma=Math.max(...arr),width=(ma-mi||1)/bins;
  const counts=Array(bins).fill(0);
  for(const v of arr)counts[Math.min(bins-1,Math.floor((v-mi)/width))]++;
  return counts.map((count,i)=>({from:mi+i*width,to:mi+(i+1)*width,count}));
}
export function publicHourly(h){const {_pos,_extra,...o}=h;return o;}
