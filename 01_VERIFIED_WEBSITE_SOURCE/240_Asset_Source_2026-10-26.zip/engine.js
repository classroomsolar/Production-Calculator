/* Solar Resource Studio v1.1: UTC hourly auditable engineering engine. */
export const HOUR=3600000;
export const COLUMNS=['timestamp_utc','ghi_wm2','dni_wm2','dhi_wm2','temp_air_c','wind_speed_mps'];
export const finite=x=>typeof x==='number'&&Number.isFinite(x);
export function solar(when,lat,lon){
 const dt=new Date(when);if(!Number.isFinite(+dt)||!finite(lat)||!finite(lon))throw Error('Invalid solar timestamp or site coordinates');
 const year=dt.getUTCFullYear(),jan=Date.UTC(year,0,1),day=Math.floor((+dt-jan)/86400000)+1,days=(Date.UTC(year+1,0,1)-jan)/86400000;
 const h=dt.getUTCHours()+dt.getUTCMinutes()/60+dt.getUTCSeconds()/3600;
 const g=2*Math.PI/days*(day-1+(h-12)/24);
 const eq=229.18*(.000075+.001868*Math.cos(g)-.032077*Math.sin(g)-.014615*Math.cos(2*g)-.040849*Math.sin(2*g));
 const dec=.006918-.399912*Math.cos(g)+.070257*Math.sin(g)-.006758*Math.cos(2*g)+.000907*Math.sin(2*g)-.002697*Math.cos(3*g)+.00148*Math.sin(3*g);
 const ha=((h*60+eq+4*lon)/4-180)*Math.PI/180,la=lat*Math.PI/180;
 const cz=Math.max(-1,Math.min(1,Math.sin(la)*Math.sin(dec)+Math.cos(la)*Math.cos(dec)*Math.cos(ha)));
 const zen=Math.acos(cz),az=(Math.atan2(Math.sin(ha),Math.cos(ha)*Math.sin(la)-Math.tan(dec)*Math.cos(la))*180/Math.PI+180+360)%360;
 return {zenith:zen*180/Math.PI,elevation:90-zen*180/Math.PI,azimuth:az,cosz:cz,declination:dec*180/Math.PI};
}
export function poa(ghi,dni,dhi,s,tilt,azimuth,albedo){
 const t=tilt*Math.PI/180,delta=(s.azimuth-azimuth)*Math.PI/180;
 const ca=s.cosz*Math.cos(t)+Math.sin(s.zenith*Math.PI/180)*Math.sin(t)*Math.cos(delta);
 const beam=s.elevation>0?dni*Math.max(0,ca):0,sky=dhi*(1+Math.cos(t))/2,ground=ghi*albedo*(1-Math.cos(t))/2;
 return {beam,sky,ground,total:beam+sky+ground};
}
export function parseCSV(csv){
 const lines=csv.replace(/^\uFEFF/,'').trim().split(/\r?\n/),header=lines.shift();
 if(!header)throw Error('CSV has no header');
 const cols=header.split(',').map(x=>x.trim().toLowerCase());
 if(COLUMNS.some(x=>!cols.includes(x)))throw Error('CSV requires '+COLUMNS.join(', '));
 return lines.filter(x=>x.trim()).map((line,i)=>{
  const parts=line.split(','),r={};
  for(const k of COLUMNS){let v=(parts[cols.indexOf(k)]??'').trim();r[k]=k==='timestamp_utc'?v:(v===''?null:Number(v))}
  if(!r.timestamp_utc)throw Error('Missing UTC timestamp at CSV row '+(i+2));
  if(!/(?:Z|[+-]\d\d:\d\d)$/.test(r.timestamp_utc)||!Number.isFinite(+new Date(r.timestamp_utc)))throw Error('Invalid timezone-aware timestamp at CSV row '+(i+2));
  r.timestamp_utc=new Date(r.timestamp_utc).toISOString().replace('.000Z','Z');return r;
 });
}
export function normalizeArchive(payload){
 if(!Array.isArray(payload?.hourly?.time))throw Error('Historical API returned no hourly series');
 const h=payload.hourly,names=['shortwave_radiation','direct_normal_irradiance','diffuse_radiation','temperature_2m','wind_speed_10m'];
 for(const k of names)if(!Array.isArray(h[k])||h[k].length!==h.time.length)throw Error('Historical field missing or length mismatch: '+k);
 return h.time.map((t,i)=>({timestamp_utc:new Date(/Z$/.test(t)?t:t+'Z').toISOString().replace('.000Z','Z'),ghi_wm2:h.shortwave_radiation[i],dni_wm2:h.direct_normal_irradiance[i],dhi_wm2:h.diffuse_radiation[i],temp_air_c:h.temperature_2m[i],wind_speed_mps:h.wind_speed_10m[i]/3.6}));
}
export function normalizePVGIS(payload){
 const src=payload?.outputs?.tmy_hourly,selected=payload?.outputs?.months_selected;
 if(!Array.isArray(src)||src.length!==8760)throw Error('PVGIS did not supply a valid 8,760-hour TMY');
 const meta=payload?.inputs||{},offset=Number(meta.location?.irradiance_time_offset??0);
 if(!finite(offset)||Math.abs(offset)>1.5)throw Error('Invalid PVGIS irradiance time offset');
 const rows=src.map((v,i)=>{
  const match=/^(\d{4})(\d{2})(\d{2}):(\d{2})(\d{2})$/.exec(v['time(UTC)']||v.time||'');
  if(!match)throw Error('PVGIS TMY invalid source timestamp at row '+(i+1));
  const [,year,mm,dd,hh,mi]=match,month=+mm,day=+dd;
  const ts=new Date(Date.UTC(2001,month-1,day,+hh,0));
  if(ts.getUTCMonth()+1!==month||ts.getUTCDate()!==day||(+mi<0||+mi>59))throw Error('PVGIS TMY invalid date at row '+(i+1));
  return {timestamp_utc:ts.toISOString().replace('.000Z','Z'),source_timestamp_utc:`${year}-${mm}-${dd}T${hh}:${mi}:00Z`,source_year:+year,ghi_wm2:v['G(h)'],dni_wm2:v['Gb(n)'],dhi_wm2:v['Gd(h)'],temp_air_c:v.T2m,wind_speed_mps:v.WS10m};
 });
 if(rows[0].timestamp_utc!=='2001-01-01T00:00:00Z'||rows.at(-1).timestamp_utc!=='2001-12-31T23:00:00Z')throw Error('PVGIS TMY canonical year incomplete');
 return {rows,offset,sourceYears:Array.isArray(selected)?selected.map(x=>({month:x.month,year:x.year})):[],elevation:meta.location?.elevation,radiationDb:meta.meteo_data?.radiation_db};
}
export function percentile(sorted,p){if(!sorted.length)return null;const n=(sorted.length-1)*p,k=Math.floor(n),a=n-k;return sorted[k]*(1-a)+(sorted[Math.min(k+1,sorted.length-1)]*a)}
export function analyze(rows,cfg,source='Hourly weather'){
 const failures=[],reviews=[];const add=(a,msg)=>{if(a.length<18)a.push(msg)};
 const {lat,lon,tilt,azimuth,albedo}=cfg;
 for(const [label,v,lo,hi] of [['latitude',lat,-90,90],['longitude',lon,-180,180],['tilt',tilt,0,90],['azimuth',azimuth,0,360],['albedo',albedo,0,1]])if(!finite(v)||v<lo||v>hi)add(failures,`Invalid ${label}: expected ${lo} to ${hi}.`);
 if(cfg.elevation!==null&&cfg.elevation!==undefined&&(!finite(cfg.elevation)||cfg.elevation< -500||cfg.elevation>9000))add(failures,'Site elevation must be -500 to 9000 m, or left on automatic.');
 if(!finite(cfg.offsetHours??0)||Math.abs(cfg.offsetHours??0)>(cfg.kind==='EPW'?2:1.5))add(failures,'Irradiance timestamp offset must be within ±1.5 hours.');
 if(!Array.isArray(rows)||!rows.length)add(failures,'Hourly weather records are required.');
 if(failures.length)return {status:'FAIL',failures,reviews,source,monthly:[],hourly:[],summary:null};
 if(![8760,8784].includes(rows.length))add(reviews,`Partial series of ${rows.length} hours: not a complete-year resource study.`);
 if(cfg.kind==='TMY')add(reviews,'TMY is representative source months assembled from different years; it does not describe current conditions or a measured calendar year.');
 if(cfg.kind==='EPW')add(reviews,'EPW is fixed local-standard-time weather; grouping uses the EPW station local calendar. EPW weather year may not represent an observed calendar year.');
 if(cfg.kind==='Historical')add(reviews,'One historical calendar year is not a validated long-term bankable resource estimate.');
 if(cfg.assumedAlbedo!==false)add(reviews,'Array albedo is a project assumption; field measurement is not provided.');
 if(cfg.kind==='Uploaded'&&!cfg.timestampConventionVerified)add(reviews,'Uploaded dataset irradiance timestamp convention has not been independently verified.');
 const monthly=Array.from({length:12},(_,i)=>({month:i+1,hours:0,ghi:0,dni:0,dhi:0,poa:0,tempSum:0,windSum:0,tempMin:Infinity,tempMax:-Infinity,windMax:0}));
 const hourly=[],temps=[],winds=[];let prev=null,closure=0,night=0;
 for(let i=0;i<rows.length;i++){
  const r=rows[i],ts=String(r.timestamp_utc||'');
  if(!/(?:Z|[+-]\d\d:\d\d)$/.test(ts)){add(failures,`Weather row ${i+1}: missing UTC timezone identifier.`);break}
  const dt=new Date(ts),tt=+dt;if(!Number.isFinite(tt)){add(failures,`Row ${i+1}: invalid timestamp.`);break}
  if(prev!==null&&tt-prev!==HOUR){add(failures,`Weather row ${i+1}: missing/duplicate/out-of-order hour.`);break}prev=tt;
  const vals=[r.ghi_wm2,r.dni_wm2,r.dhi_wm2,r.temp_air_c,r.wind_speed_mps];
  if(vals.some(x=>!finite(x))){add(failures,`Weather row ${i+1}: missing or nonnumeric required field.`);break}
  const [ghi,dni,dhi,temp,wind]=vals;
  if(ghi<0||ghi>1450||dni<0||dni>1600||dhi<0||dhi>1450||temp< -90||temp>75||wind<0||wind>85){add(failures,`Weather row ${i+1}: physically implausible screening value.`);break}
  const positionTime=new Date(tt+(cfg.offsetHours||0)*HOUR),s=solar(positionTime,lat,lon),p=poa(ghi,dni,dhi,s,tilt,azimuth,albedo);
  if(ghi>100&&Math.abs(ghi-(dhi+dni*Math.max(0,s.cosz)))>Math.max(75,.2*ghi))closure++;
  if(s.elevation< -6&&ghi>40)night++;
  const groupDate=cfg.kind==='EPW'?new Date(tt+((cfg.localStandardTimezoneHours||0)-1)*HOUR):dt;const m=monthly[groupDate.getUTCMonth()];m.hours++;m.ghi+=ghi/1000;m.dni+=dni/1000;m.dhi+=dhi/1000;m.poa+=p.total/1000;m.tempSum+=temp;m.windSum+=wind;m.tempMin=Math.min(m.tempMin,temp);m.tempMax=Math.max(m.tempMax,temp);m.windMax=Math.max(m.windMax,wind);
  hourly.push({...r,poa_wm2:+p.total.toFixed(3),solar_elevation_deg:+s.elevation.toFixed(3),solar_azimuth_deg:+s.azimuth.toFixed(3)});temps.push(temp);winds.push(wind);
 }
 if(closure)add(reviews,`${closure} irradiance GHI/DNI/DHI closure discrepancies; review component models and irradiance timestamps.`);
 if(night)add(reviews,`${night} nontrivial nighttime irradiance records; verify timestamp offsets and source.`);
 if(!failures.length&&[8760,8784].includes(rows.length)&&cfg.kind!=='EPW'){
  const year=new Date(rows[0].timestamp_utc).getUTCFullYear();
  const expected=(Date.UTC(year+1,0,1)-Date.UTC(year,0,1))/HOUR;
  if(+new Date(rows[0].timestamp_utc)!==Date.UTC(year,0,1)||+new Date(rows.at(-1).timestamp_utc)!==Date.UTC(year+1,0,1)-HOUR||rows.length!==expected)add(failures,'An annual dataset must span every UTC hour of exactly one calendar year.');
 }
 for(const m of monthly){m.tempMean=m.hours?m.tempSum/m.hours:null;m.windMean=m.hours?m.windSum/m.hours:null;if(!m.hours){m.tempMin=null;m.tempMax=null}}
 const sum=k=>monthly.reduce((a,m)=>a+m[k],0);
 const valid=!failures.length;temps.sort((a,b)=>a-b);winds.sort((a,b)=>a-b);
 return {status:failures.length?'FAIL':reviews.length?'REVIEW REQUIRED':'PASS',failures,reviews,source,monthly,hourly:valid?hourly:[],summary:valid?{hours:rows.length,ghi:sum('ghi'),dni:sum('dni'),dhi:sum('dhi'),poa:sum('poa'),tempMin:temps[0],tempMax:temps.at(-1),tempMean:temps.reduce((a,b)=>a+b,0)/temps.length,tempP1:percentile(temps,.01),tempP99:percentile(temps,.99),windMean:winds.reduce((a,b)=>a+b,0)/winds.length,windMax:winds.at(-1),windP99:percentile(winds,.99),closure,night}:null,metadata:{type:cfg.kind,method:'NOAA approximate solar position; isotropic sky diffuse and ground reflected POA',timezone:'UTC',offsetHours:cfg.offsetHours||0,units:'Hourly W/m² integrated over one hour to kWh/m²'}};
}
export function compareResources(a,b){if(!a?.summary||!b?.summary)throw Error('Comparison requires two validated datasets');const keys=['ghi','dni','dhi','poa','tempMean','windMean'];return keys.map(key=>({key,primary:a.summary[key],secondary:b.summary[key],delta:b.summary[key]-a.summary[key],relativePct:a.summary[key]!==0?100*(b.summary[key]-a.summary[key])/a.summary[key]:null}));}
