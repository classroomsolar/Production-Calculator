/** PV engineering research: deterministic 2-D periodic-row view-factor/ray-screen model.
 * Geometry: level horizontal ground; fixed tilt, infinite straight uniform rows; diffuse sky isotropic,
 * ground Lambertian, no spectral/IAM, no transmission, no edge/structural scattering.
 * This is an independent *screening* model, NOT pvlib infinite_sheds, PVsyst or bankable parity.
 * References: Sandia PVPMC View Factor Models; pvlib bifacial infinite_sheds interface/limitations.
 */
const PI=Math.PI, R=PI/180;
const clamp=(x,a,b)=>Math.min(b,Math.max(a,x));
const valid=(v,n,min,max)=>{if(!Number.isFinite(v)||v<min||v>max)throw Error(`${n}: expected finite ${min}..${max}`);return v};
export function validateBifacialConfig(raw){
 if(!raw||typeof raw!=='object')throw Error('Bifacial geometry is required');
 const c={...raw};
 valid(c.tiltDeg,'tiltDeg',0,80);valid(c.frontAzimuthDeg,'frontAzimuthDeg',0,360);
 valid(c.widthM,'widthM',.2,20);valid(c.pitchM,'pitchM',.2,100);
 if(c.pitchM<c.widthM)throw Error('Pitch must be >= module slant width');
 valid(c.heightM,'heightM',.15,25);
 if(c.heightM<=.5*c.widthM*Math.sin(c.tiltDeg*R)+.02)throw Error('Bottom module edge must be at least 2 cm above ground');
 valid(c.albedo,'albedo',0,1);valid(c.bifaciality,'bifaciality',0,1);
 valid(c.rearStructuralLoss,'rearStructuralLoss',0,1);
 const n=c.angularSamples??72,ms=c.moduleSamples??16,gs=c.groundBins??48;
 for(const [name,value,lo,hi] of [['angularSamples',n,16,160],['moduleSamples',ms,4,40],['groundBins',gs,16,160]])if(!Number.isInteger(value)||value<lo||value>hi)throw Error(`${name} must be integer ${lo}..${hi}`);
 c.angularSamples=n;c.moduleSamples=ms;c.groundBins=gs;
 return c;
}
function row(c,k){const a=c.tiltDeg*R,w=c.widthM/2,x=k*c.pitchM;return {x0:x-w*Math.cos(a),y0:c.heightM-w*Math.sin(a),x1:x+w*Math.cos(a),y1:c.heightM+w*Math.sin(a)};}
function cross(ax,ay,bx,by){return ax*by-ay*bx;}
function rayHitSegment(x,y,dx,dy,seg){
 const vx=seg.x1-seg.x0,vy=seg.y1-seg.y0;
 const den=cross(dx,dy,vx,vy);
 if(Math.abs(den)<1e-12)return Infinity;
 const qx=seg.x0-x,qy=seg.y0-y;
 const t=cross(qx,qy,vx,vy)/den,u=cross(qx,qy,dx,dy)/den;
 return t>1e-8&&u>=-1e-9&&u<=1+1e-9?t:Infinity;
}
function normal(c,front){const a=c.tiltDeg*R;return front?[-Math.sin(a),Math.cos(a)]:[Math.sin(a),-Math.cos(a)];}
// Compute first interaction: sky, ground, or another row segment.
function trace(c,rows,x,y,dx,dy){
 let tG=dy< -1e-10?-y/dy:Infinity;
 if(tG<=1e-8)tG=Infinity;
 let t=tG,kind=Number.isFinite(tG)?'ground':'sky';
 for(const seg of rows){const q=rayHitSegment(x,y,dx,dy,seg);if(q<t){t=q;kind='row';}}
 return {kind,x:x+dx*t,t};
}
function segmentRows(c,count=10){return Array.from({length:2*count+1},(_,i)=>row(c,i-count));}
const wrap=(x,p)=>x-Math.floor((x+p/2)/p)*p;
function skyViewFromGround(c,x,angles){
 const rows=segmentRows(c,9),eps=1e-5;
 let view=0;
 for(let j=0;j<angles;j++){
  const phi=-PI/2+(j+.5)*PI/angles,dx=Math.sin(phi),dy=Math.cos(phi);
  if(trace(c,rows,x,eps,dx,dy).kind==='sky')view+=Math.cos(phi)*Math.sin(PI/(2*angles));
 }
 return clamp(view,0,1);
}
export function prepareBifacialGeometry(raw){
 const c=validateBifacialConfig(raw),rows=segmentRows(c,10),a=c.tiltDeg*R;
 const bins=c.groundBins, skyOnGround=[];
 for(let b=0;b<bins;b++)skyOnGround.push(skyViewFromGround(c,((b+.5)/bins-.5)*c.pitchM,Math.min(c.angularSamples,72)));
 const samples={front:[],back:[]},fraction={front:{sky:0,ground:0,row:0},back:{sky:0,ground:0,row:0}};
 for(const side of ['front','back']){
  const n=normal(c,side==='front');
  for(let i=0;i<c.moduleSamples;i++){
   const q=(i+.5)/c.moduleSamples-.5,x=q*c.widthM*Math.cos(a),y=c.heightM+q*c.widthM*Math.sin(a);
   const rays=[];
   for(let j=0;j<c.angularSamples;j++){
    const phi=-PI/2+(j+.5)*PI/c.angularSamples;
    // Rotate from normal by phi to launch a 2-D cosine-weighted hemispheric ray.
    const dx=n[0]*Math.cos(phi)-n[1]*Math.sin(phi);
    const dy=n[1]*Math.cos(phi)+n[0]*Math.sin(phi);
    const hit=trace(c,rows,x+1e-5*n[0],y+1e-5*n[1],dx,dy);
    const weight=Math.cos(phi)*Math.sin(PI/(2*c.angularSamples))/c.moduleSamples;
    const b=hit.kind==='ground'?clamp(Math.floor((wrap(hit.x,c.pitchM)/c.pitchM+.5)*bins),0,bins-1):-1;
    rays.push({kind:hit.kind,weight,groundBin:b});
    fraction[side][hit.kind]+=weight;
   }
   samples[side].push({x,y,n,rays});
  }
 }
 const geometry={gcr:c.widthM/c.pitchM,frontView:fraction.front,backView:fraction.back,groundSkyViewMean:skyOnGround.reduce((s,x)=>s+x,0)/bins};
 for(const side of ['front','back']){const v=fraction[side],t=v.sky+v.ground+v.row;if(Math.abs(t-1)>0.001)throw Error('View factors not closed: '+side+'='+t);}
 return {config:c,geometry,samples,skyOnGround,rows};
}
function sunVec(zen,azi,frontAzimuth){
 const ze=zen*R,az=azi*R,cr=((frontAzimuth+180)%360)*R;
 return [Math.sin(ze)*Math.cos(az-cr),Math.cos(ze)];
}
function isBlocked(g,x,y,dx,dy){return trace(g.config,g.rows,x,y,dx,dy).kind==='row';}
export function irradianceBifacialHour(g,h){
 if(!g?.geometry||!g?.samples)throw Error('Prepared bifacial geometry required');
 for(const [n,lo,hi] of [['zenithDeg',0,180],['solarAzimuthDeg',0,360],['dni',0,1600],['dhi',0,1600],['ghi',0,1600]])valid(h[n],n,lo,hi);
 const c=g.config;const closureWm2=Math.abs(h.ghi-(h.dni*Math.max(0,Math.cos(h.zenithDeg*R))+h.dhi));const closureFlag=h.zenithDeg<87&&closureWm2>Math.max(30,.1*Math.max(1,h.ghi));if(h.zenithDeg>=90||h.ghi+h.dhi+h.dni===0)return {front:0,back:0,backEffective:0,effective:0,frontBeam:0,backBeam:0,frontDiffuseSky:0,backDiffuseSky:0,frontGround:0,backGround:0,shadedFrontFraction:0,shadedGroundFraction:0,night:true,weatherClosureWm2:closureWm2,weatherClosureFlag:closureFlag};
 const [sx,sy]=sunVec(h.zenithDeg,h.solarAzimuthDeg,c.frontAzimuthDeg);
 const groundIncident=[],beamHorizontal=h.dni*Math.max(0,Math.cos(h.zenithDeg*R));let shadedGround=0;
 for(let i=0;i<c.groundBins;i++){
  const x=((i+.5)/c.groundBins-.5)*c.pitchM;
  const shade=isBlocked(g,x,1e-5,sx,sy);
  shadedGround+=shade?1:0;
  groundIncident.push(c.albedo*((shade?0:beamHorizontal)+h.dhi*g.skyOnGround[i]));
 }
 const out={};
 for(const side of ['front','back']){
  const key=side==='front'?'front':'back',nSamples=g.samples[side];
  let beam=0,sky=0,ground=0,blocked=0;
  for(const p of nSamples){
   const incidence=p.n[0]*sx+p.n[1]*sy;
   if(incidence>0&&h.dni>0){
    if(!isBlocked(g,p.x+1e-5*p.n[0],p.y+1e-5*p.n[1],sx,sy))beam+=h.dni*incidence/c.moduleSamples;
    else blocked++;
   }
   for(const ray of p.rays){if(ray.kind==='sky')sky+=ray.weight*h.dhi;else if(ray.kind==='ground')ground+=ray.weight*groundIncident[ray.groundBin];}
  }
  out[key+'Beam']=beam;out[key+'DiffuseSky']=sky;out[key+'Ground']=ground;out[key]=beam+sky+ground;
  out['shaded'+(side==='front'?'Front':'Back')+'Fraction']=blocked/c.moduleSamples;
 }
 out.backEffective=out.back*c.bifaciality*(1-c.rearStructuralLoss);
 out.effective=out.front+out.backEffective;
 out.shadedGroundFraction=shadedGround/c.groundBins;out.night=false;out.weatherClosureWm2=closureWm2;out.weatherClosureFlag=closureFlag;
 for(const [key,value] of Object.entries(out))if(typeof value==='number'&&(!Number.isFinite(value)||value< -1e-8))throw Error('Nonphysical '+key);
 return out;
}
/** Annual UTC chronology review. A translated EPW weather year may legitimately begin
 * at a different UTC hour; report that fact without silently labelling calendar-year
 * output as an exactly aligned January–December UTC study. */
export function inspectAnnualChronology(prepared){
 if(!Array.isArray(prepared)||![8760,8784].includes(prepared.length))throw Error('Exactly 8760/8784 consecutive hourly weather records required');
 const first=prepared[0]?.timestamp_utc,last=prepared.at(-1)?.timestamp_utc;
 if(typeof first!=='string'||typeof last!=='string'||!/[zZ]$/.test(first)||!/[zZ]$/.test(last))throw Error('Explicit UTC Z timestamps required');
 const start=Date.parse(first),end=Date.parse(last);
 if(!Number.isFinite(start)||!Number.isFinite(end))throw Error('Invalid UTC timestamp');
 const y=new Date(start).getUTCFullYear(),aligned=start===Date.UTC(y,0,1);
 if(end-start!==(prepared.length-1)*3600000)throw Error('Hourly data must span exactly the requested number of contiguous hours');
 const expectedHours=(Date.UTC(y+1,0,1)-Date.UTC(y,0,1))/3600000;
 const exactCalendar=aligned&&prepared.length===expectedHours;
 const diagnostic=exactCalendar?'UTC_CALENDAR_YEAR_ALIGNED':'COMPLETE_8760_8784_PERIOD_NOT_ALIGNED_TO_UTC_CALENDAR_YEAR';
 return {startUtc:first,endUtc:last,yearAtStartUTC:y,exactCalendarYearUTC:exactCalendar,offsetYearPeriod:!exactCalendar,diagnostic};
}
export function simulateBifacialYear(prepared,raw){
 const chronology=inspectAnnualChronology(prepared);
 const geometry=prepareBifacialGeometry(raw);let last=null;
 const totals={frontKWhM2:0,backKWhM2:0,backEffectiveKWhM2:0,totalEffectiveKWhM2:0,frontDirectKWhM2:0,frontSkyKWhM2:0,frontGroundKWhM2:0,backSkyKWhM2:0,backGroundKWhM2:0};
 const monthly=Array.from({length:12},(_,i)=>({month:i+1,frontKWhM2:0,backKWhM2:0,effectiveKWhM2:0}));const hourly=[];let weatherClosureFlaggedHours=0;
 for(const row of prepared){
  const time=Date.parse(row.timestamp_utc);if(!Number.isFinite(time)||(last!==null&&time-last!==3600000))throw Error('Noncontiguous or invalid hourly UTC timestamps');last=time;
  const h={zenithDeg:row._pos?.zenith,solarAzimuthDeg:row._pos?.azimuth,dni:row.dni_wm2,dhi:row.dhi_wm2,ghi:row.ghi_wm2};
  const v=irradianceBifacialHour(geometry,h),m=monthly[new Date(time).getUTCMonth()];
  weatherClosureFlaggedHours+=v.weatherClosureFlag?1:0;totals.frontKWhM2+=v.front/1000;totals.backKWhM2+=v.back/1000;totals.backEffectiveKWhM2+=v.backEffective/1000;totals.totalEffectiveKWhM2+=v.effective/1000;totals.frontDirectKWhM2+=v.frontBeam/1000;totals.frontSkyKWhM2+=v.frontDiffuseSky/1000;totals.frontGroundKWhM2+=v.frontGround/1000;totals.backSkyKWhM2+=v.backDiffuseSky/1000;totals.backGroundKWhM2+=v.backGround/1000;
  m.frontKWhM2+=v.front/1000;m.backKWhM2+=v.back/1000;m.effectiveKWhM2+=v.effective/1000;
  hourly.push({timestamp_utc:row.timestamp_utc,front_wm2:v.front,back_wm2:v.back,back_effective_wm2:v.backEffective,effective_wm2:v.effective,front_direct_wm2:v.frontBeam,front_sky_wm2:v.frontDiffuseSky,front_ground_wm2:v.frontGround,back_sky_wm2:v.backDiffuseSky,back_ground_wm2:v.backGround,front_shaded_fraction:v.shadedFrontFraction,ground_shaded_fraction:v.shadedGroundFraction,weather_closure_abs_wm2:v.weatherClosureWm2,weather_closure_flag:v.weatherClosureFlag});
 }
 totals.bifacialOpticalGainPct=totals.frontKWhM2?100*totals.backEffectiveKWhM2/totals.frontKWhM2:0;
 if(Math.abs(totals.frontKWhM2+totals.backEffectiveKWhM2-totals.totalEffectiveKWhM2)>1e-6)throw Error('Annual irradiance balance failed');
 return {hours:prepared.length,chronology,geometry:geometry.geometry,config:geometry.config,annual:totals,monthly,hourly,weatherDiagnostics:{closureFlaggedHours:weatherClosureFlaggedHours},warnings:[...(chronology.exactCalendarYearUTC?[]:['WARNING: Annual period covers 8760/8784 UTC hours but is not Jan 1 00:00 UTC through Dec 31 23:00 UTC; monthly/calendar-year claims must be reviewed against EPW/local-standard-time conversion.']), 'SCREENING ONLY: level ground, identical infinite straight fixed-tilt rows, 2D cross-section, periodic ground, Lambertian reflection and isotropic sky.','Direct ground shade and sky obstruction are ray screened; finite row ends, complex torque tubes, soiling, IAM, spectra, snow and cell mismatch are not included.','Backside conversion uses a scalar bifaciality and a user-assumed structural-loss factor; actual spatial rear nonuniformity, electrical mismatch and bankable calibration require external validation.',`Weather source irradiance closure screen: ${weatherClosureFlaggedHours} of ${prepared.length} hours exceed max(30 W/m2, 10% of GHI); source GHI is not used to replace DNI cos zenith + DHI.`,
 'No direct pvlib infinite_sheds parity or independent field measurement acceptance established. Hourly W/m2 interpreted as one-hour mean.']};
}
