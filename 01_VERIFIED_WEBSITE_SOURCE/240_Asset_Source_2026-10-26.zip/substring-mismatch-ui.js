/** Optional B3 electrical bypass and shading physics; no automatic weather or real-world shading inference. */
import {substringMismatchStudy} from './substring-mismatch.js';
const root=document.getElementById('pv15Section');
const $=id=>document.getElementById(id);
if(root){
 const tabs=root.querySelector('.pv15-tabs'),anchor=$('pv15Result');
 if(tabs&&anchor){
  tabs.insertAdjacentHTML('beforeend','<button type="button" data-mismatch-b3="mismatch">Substring &amp; bypass shading R&amp;D · B3</button>');
  const block=`<section id="mismatchB3" class="b3mis-screen" hidden>
  <h3>Partial electrical shading: substring/bypass I–V &amp; P–V curve</h3>
  <p class="b3mis-warning"><strong>RESEARCH SCREEN ONLY.</strong> Equal series-connected substring approximation with ideal fixed-voltage bypass diode. SYNTHETIC module parameters. NOT actual module topology, optimizer design, certification, thermal hotspot assessment or bankable energy loss.</p>
  <div class="b3mis-grid">
  <label>Effective irradiance on substring 1 (W/m²)<input type="number" id="b3misG1" value="1000" min="0" max="1800"></label>
  <label>Substring 2 (W/m²)<input type="number" id="b3misG2" value="1000" min="0" max="1800"></label>
  <label>Substring 3 (W/m²)<input type="number" id="b3misG3" value="250" min="0" max="1800"></label>
  <label>Cell temperature (°C)<input type="number" id="b3misCellC" value="25" min="-80" max="120"></label>
  <label>Modules in each string<input type="number" id="b3misSeries" value="10" min="1" max="80"></label>
  <label>Parallel strings<input type="number" id="b3misParallel" value="2" min="1" max="100"></label>
  <label>Total per-string loop resistance (Ω)<input type="number" id="b3misR" value="0.1" min="0" max="10" step="0.01"></label>
  <label>Bypass diode forward voltage (V)<input type="number" id="b3misBypass" value="0.5" min="0.05" max="1.5" step="0.05"></label>
  <label>MPPT minimum voltage (V)<input type="number" id="b3misMin" value="200" min="0" max="4000"></label>
  <label>MPPT maximum voltage (V)<input type="number" id="b3misMax" value="650" min="0" max="4000"></label>
  </div>
  <details><summary>Synthetic reference diode parameters (not OEM-qualified)</summary>
  <div class="b3mis-grid">
  <label>IL_ref (A)<input id="b3misIL" type="number" value="9.02" step="any"></label>
  <label>I0_ref (A)<input id="b3misI0" type="number" value="1.4e-10" step="any"></label>
  <label>Rs_ref (Ω)<input id="b3misRs" type="number" value="0.33" step="any"></label>
  <label>Rsh_ref (Ω)<input id="b3misRsh" type="number" value="760" step="any"></label>
  <label>a_ref (V)<input id="b3misA" type="number" value="2.1" step="any"></label>
  <label>alpha_Isc (A/°C)<input id="b3misAlpha" type="number" value="0.005" step="any"></label>
  <label>dEg/dT relative (1/K)<input id="b3misDEgdT" type="number" value="-0.0002677" step="any"></label>
  </div></details>
  <p><button type="button" id="b3misRun">Compute multi-peak substring I–V / P–V</button>
  <button type="button" id="b3misCsv" disabled>Export curve CSV</button>
  <button type="button" id="b3misJson" disabled>Export audit JSON</button></p>
  <p role="status" id="b3misStatus">Example coefficients only. Calculation not run.</p>
  <div id="b3misResult"></div>
  <p class="b3mis-warning">Reference framework: pvlib singlediode modeling and partial module shading example; 2015/2017/2021 partial-shading electrical research. Real half-cut layouts, bypass topology and reverse breakdown curves must come from verified equipment sources.</p>
  </section>`;
  anchor.insertAdjacentHTML('afterend',block);
  const panel=$('mismatchB3'),button=tabs.querySelector('[data-mismatch-b3]');
  for(const other of tabs.querySelectorAll('button:not([data-mismatch-b3])'))other.addEventListener('click',()=>{panel.hidden=true;button.classList.remove('active')});
  button.addEventListener('click',()=>{for(const id of ['pv15StringForm','pv15YieldForm','pv15AuditForm','pv17Lab','trackerB3','financeB5','bessB4','electricalB4']){const node=$(id);if(node)node.hidden=true}anchor.hidden=true;for(const b of tabs.querySelectorAll('button'))b.classList.remove('active');button.classList.add('active');panel.hidden=false});
  const get=(id)=>{const s=$(id).value;if(!s)throw Error(id+' is missing');return Number(s)};
  let current=null;
  const status=$('b3misStatus'),out=$('b3misResult');
  function renderGraph(curve){
   const w=700,h=230, pad=28,maxV=Math.max(1,...curve.map(x=>x.stringVoltageV)),maxP=Math.max(1,...curve.map(x=>x.powerW));
   const coords=curve.filter((_,i)=>i%4===0).map(x=>[pad+(w-2*pad)*x.stringVoltageV/maxV,h-pad-(h-2*pad)*x.powerW/maxP]);
   const poly=coords.map(p=>p.map(v=>v.toFixed(1)).join(',')).join(' ');
   const svg=document.createElementNS('http://www.w3.org/2000/svg','svg');svg.setAttribute('viewBox',`0 0 ${w} ${h}`);svg.setAttribute('role','img');svg.setAttribute('aria-label','Array power in watts against operating DC voltage; multiple peaks indicate bypass diode states');svg.classList.add('b3mis-svg');
   const line=document.createElementNS('http://www.w3.org/2000/svg','polyline');line.setAttribute('fill','none');line.setAttribute('stroke','currentColor');line.setAttribute('stroke-width','2');line.setAttribute('points',poly);svg.appendChild(line);return svg;
  }
  function save(name,mime,text){const url=URL.createObjectURL(new Blob([text],{type:mime}));const a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),5000)};
  const read=()=>({module:{ILrefA:get('b3misIL'),I0refA:get('b3misI0'),RsRefOhm:get('b3misRs'),RshRefOhm:get('b3misRsh'),aRefV:get('b3misA'),alphaIscAperC:get('b3misAlpha'),EgRefEv:1.121,dEgdTPerK:get('b3misDEgdT')},cellC:get('b3misCellC'),substringIrradianceWm2:[get('b3misG1'),get('b3misG2'),get('b3misG3')],bypassForwardV:get('b3misBypass'),modulesPerString:get('b3misSeries'),parallelStrings:get('b3misParallel'),stringCableResistanceOhm:get('b3misR'),mpptMinV:get('b3misMin'),mpptMaxV:get('b3misMax')});
  panel.querySelectorAll('input').forEach(x=>x.addEventListener('input',()=>{current=null;$('b3misCsv').disabled=true;$('b3misJson').disabled=true;out.replaceChildren();status.textContent='Inputs changed — rerun required.'}));
  $('b3misRun').addEventListener('click',()=>{try{const cfg=read(),result=substringMismatchStudy(cfg);current={input:cfg,result};out.replaceChildren();const summary=document.createElement('p');summary.textContent=`Global DC MPP ${result.globalPowerW.toFixed(2)} W. MPPT-window screen ${result.mpptMPP?result.mpptPowerW.toFixed(2)+' W':'NO OPERATING POINT'}. Baseline unshaded STC ${result.pristineSTCpowerW.toFixed(2)} W. Local peaks ${result.localPeakCount}. Bypassed substrings per module at GMPP ${result.globalMPP.bypassedSubstringsPerModule}.`;out.append(summary,renderGraph(result.curve));const warning=document.createElement('p');warning.textContent=result.warnings.join(' ');out.append(warning);status.textContent='RESEARCH MODEL CALCULATED · NOT OEM QUALIFIED';$('b3misCsv').disabled=false;$('b3misJson').disabled=false}catch(e){current=null;out.replaceChildren();status.textContent='REJECTED: '+e.message;$('b3misCsv').disabled=true;$('b3misJson').disabled=true}});
  $('b3misCsv').addEventListener('click',()=>{if(!current)return;const rows=['string_current_a,string_voltage_v,array_current_a,power_w,bypassed_per_module',...current.result.curve.map(r=>[r.stringCurrentA,r.stringVoltageV,r.arrayCurrentA,r.powerW,r.bypassedPerModule].join(','))];save('b3-substring-iv-curve.csv','text/csv',rows.join('\n'))});
  $('b3misJson').addEventListener('click',()=>{if(current)save('b3-substring-research-audit.json','application/json',JSON.stringify({...current,generatedAtUTC:new Date().toISOString(),source:'Independent educational substring+bypass numerical model'},null,2))});
  window.SolarMismatchB3Sheets=()=>current?[['B3 Substring Mismatch',[{metric:'Global MPP W',value:current.result.globalPowerW},{metric:'MPPT MPP W',value:current.result.mpptPowerW},{metric:'Unshaded STC W',value:current.result.pristineSTCpowerW},{metric:'Local peaks',value:current.result.localPeakCount}]],['B3 I-V P-V Curve',current.result.curve.map(x=>({stringCurrentA:x.stringCurrentA,stringVoltageV:x.stringVoltageV,arrayCurrentA:x.arrayCurrentA,powerW:x.powerW,bypassedPerModule:x.bypassedPerModule}))]]:[];
  window.SolarMismatchB3ReportHTML=()=>current?`<h2>Experimental substring electrical mismatch (not manufacturer-qualified)</h2><p>Global MPP ${current.result.globalPowerW.toFixed(3)} W; MPPT screened MPP ${current.result.mpptPowerW.toFixed(3)} W. These results are not annual production or actual cell topology.</p>`:'';
 }
}
