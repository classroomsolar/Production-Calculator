/** Optional POI + PV branch power/current screen within the existing electrical tab. */
import {screenThreePhasePoi} from './grid-poi-screen.js';
const host=document.getElementById('electricalB4');
if(host){
 const d=[
  ['pvGenerationKW','PV inverter AC output upstream of load (kW)',5000],
  ['siteLoadKW','Coincident site load on common bus (kW)',2000],
  ['bessNetKW','BESS AC power +discharge / −charge (kW)',0],
  ['netReactiveKvar','Net POI reactive power (kvar, signed)',0],
  ['pvBranchReactiveKvar','PV branch reactive power (kvar, signed)',0],
  ['poiVoltageLLV','POI equipment line-to-line voltage (V)',12470],
  ['pvBranchVoltageLLV','PV branch conductor voltage (V, separate from POI)',12470],
  ['poiSwitchContinuousA','POI switch continuous rating (A)',400],
  ['poiConductorContinuousA','POI conductor continuous rating (A)',400],
  ['poiTransformerKVA','POI transformer nameplate kVA',7500],
  ['exportAgreementCapKW','Agreed maximum POI export (kW)',5000],
  ['importAgreementCapKW','Optional maximum POI import (kW)',null],
  ['pvBranchConductorContinuousA','Optional upstream PV branch conductor rating (A)',null],
  ['pvBranchBreakerContinuousA','Optional upstream PV branch breaker continuous rating (A)',null]];
 const fields=d.map(([k,title,value])=>`<label style="display:block"><span>${title}</span><input type="number" step="any" id="gridPoi_${k}" ${value===null?'placeholder="Not specified"':`value="${value}"`} style="width:100%"></label>`).join('');
 host.insertAdjacentHTML('beforeend',`<section id="gridPoiScreen" style="margin-top:24px;padding:16px;border:1px solid #95a3b9;border-radius:12px"><h3>Grid interconnection · Bidirectional POI power/current screen</h3><p><strong>Conservative example data only. Nothing entered here establishes code compliance or protection relay/PPC approval.</strong> POI export restriction does not cap imported load, reactive current or PV branch current. Ratings must represent the exact equipment and location being checked.</p><div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:10px">${fields}</div><p><button id="gridPoi_run" type="button">Evaluate bidirectional current / kVA</button> <button id="gridPoi_download" type="button" disabled>Download POI audit JSON</button></p><p role="status" id="gridPoi_status">Not evaluated.</p><div id="gridPoi_output"></div></section>`);
 const by=id=>document.getElementById(id),sta=by('gridPoi_status'),out=by('gridPoi_output'),download=by('gridPoi_download');let last=null;
 const clear=()=>{last=null;download.disabled=true;out.replaceChildren();sta.textContent='INPUT CHANGED — re-evaluate current and power limits';};
 const read=()=>Object.fromEntries(d.flatMap(([key])=>{const raw=by('gridPoi_'+key).value.trim();if(raw===''){if(d.find(x=>x[0]===key)[2]===null)return [];throw Error('Input required: '+key);}const value=Number(raw);if(!Number.isFinite(value))throw Error('Invalid number: '+key);return [[key,value]];}));
 for(const [k] of d)by('gridPoi_'+k).addEventListener('input',clear);
 by('gridPoi_run').addEventListener('click',()=>{clear();try{last=screenThreePhasePoi(read());const table=document.createElement('table');for(const [key,value] of Object.entries({...last.results,...last.checks})){const tr=document.createElement('tr'),th=document.createElement('th'),td=document.createElement('td');th.textContent=key;td.textContent=typeof value==='number'?Number(value.toFixed(5)).toLocaleString('en-US'):String(value);tr.append(th,td);table.append(tr)}out.append(table);const note=document.createElement('p');note.textContent=last.warnings.join(' ');out.append(note);sta.textContent=last.passForSpecifiedSnapshot?'ALL SPECIFIED SNAPSHOT LIMITS PASS · preliminary engineering screen only':'SPECIFIED LIMIT VIOLATION — '+last.failedChecks.join(', ');download.disabled=false;}catch(error){sta.textContent='REJECTED: '+error.message;}});
 download.addEventListener('click',()=>{if(!last)return;const blob=new Blob([JSON.stringify(last,null,2)],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='bidirectional_poi_equipment_screen.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),4000);});
 window.SolarGridPoiSheets=()=>last?[['POI Bidirectional Power',Object.entries({...last.results,...last.checks}).map(([metric,value])=>({metric,value}))]]:[];
 window.SolarGridPoiReportHTML=()=>last?`<h2>Bidirectional POI equipment screening (not construction-approved)</h2><p>${last.passForSpecifiedSnapshot?'Supplied limits pass at modeled snapshot.':'Supplied limits failed: '+last.failedChecks.join(', ')}</p>`:'';
}
