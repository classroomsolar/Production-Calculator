/** Grid / POI three-phase bidirectional apparent-power screening.
 * Not a short-circuit, thermal ampacity, IEEE 1547, relay, PPC or utility-approved study.
 * Sources for 3-phase current equation: IEC 60076-1 definitions and Schneider
 * Electric FA338225; requires separately verified ratings and location topology.
 */
const requireNum=(x,key,min,max)=>{if(typeof x!=='number'||!Number.isFinite(x)||x<min||x>max)throw Error(`${key} must be a finite number in ${min}..${max}`);return x};
const sq=(x)=>x*x;
const a3=(kw,kvar,vLL)=>Math.hypot(kw,kvar)*1000/(Math.sqrt(3)*vLL);
export function screenThreePhasePoi(config){
 if(!config||typeof config!=='object')throw Error('POI screening inputs required');
 const c=config;
 for(const key of ['pvGenerationKW','siteLoadKW','poiVoltageLLV','pvBranchVoltageLLV','poiSwitchContinuousA','poiConductorContinuousA','poiTransformerKVA','exportAgreementCapKW'])
  requireNum(c[key],key,(key==='poiVoltageLLV'||key==='pvBranchVoltageLLV')||key.endsWith('ContinuousA')||key==='poiTransformerKVA'?0.001:0,1e10);
 requireNum(c.bessNetKW??0,'bessNetKW',-1e10,1e10);
 requireNum(c.netReactiveKvar??0,'netReactiveKvar',-1e10,1e10);
 requireNum(c.pvBranchReactiveKvar??0,'pvBranchReactiveKvar',-1e10,1e10);
 if(c.importAgreementCapKW!==undefined&&c.importAgreementCapKW!==null)requireNum(c.importAgreementCapKW,'importAgreementCapKW',0,1e10);
 if(c.pvBranchConductorContinuousA!==undefined&&c.pvBranchConductorContinuousA!==null)requireNum(c.pvBranchConductorContinuousA,'pvBranchConductorContinuousA',.001,1e10);
 if(c.pvBranchBreakerContinuousA!==undefined&&c.pvBranchBreakerContinuousA!==null)requireNum(c.pvBranchBreakerContinuousA,'pvBranchBreakerContinuousA',.001,1e10);
 const p=c.pvGenerationKW+(c.bessNetKW??0)-c.siteLoadKW;
 const q=c.netReactiveKvar??0;
 const s=Math.hypot(p,q);
 const i=a3(p,q,c.poiVoltageLLV);
 const ip=a3(c.pvGenerationKW,c.pvBranchReactiveKvar??0,c.pvBranchVoltageLLV);
 const tol=1e-9;
 const exportKW=Math.max(0,p),importKW=Math.max(0,-p);
 const capExportMet=exportKW<=c.exportAgreementCapKW+tol;
 const capImportMet=c.importAgreementCapKW===undefined||c.importAgreementCapKW===null||importKW<=c.importAgreementCapKW+tol;
 const checks={exportAgreementCapMet:capExportMet,importAgreementCapMet:capImportMet,
  poiSwitchWithinProvidedContinuousRating:i<=c.poiSwitchContinuousA+tol,
  poiConductorWithinProvidedContinuousRating:i<=c.poiConductorContinuousA+tol,
  poiTransformerWithinProvidedKVA:s<=c.poiTransformerKVA+tol,
  pvBranchConductorWithinProvidedContinuousRating:c.pvBranchConductorContinuousA==null?null:ip<=c.pvBranchConductorContinuousA+tol,
  pvBranchBreakerWithinProvidedContinuousRating:c.pvBranchBreakerContinuousA==null?null:ip<=c.pvBranchBreakerContinuousA+tol};
 const failed=Object.entries(checks).filter(([,v])=>v===false).map(([k])=>k);
 return {status:'BIDIRECTIONAL_AC_SCREEN_ONLY',input:{...c},
  results:{netRealPowerKW:p,netReactiveKvar:q,netApparentKVA:s,poiCurrentA:i,poiFlowDirection:p>0?'EXPORT':p<0?'IMPORT':'ZERO_REAL_POWER',
   netPowerFactor:s>0?Math.abs(p)/s:null,poiExportKW:exportKW,poiImportKW:importKW,
   agreementExportCapKW:c.exportAgreementCapKW,agreementImportCapKW:c.importAgreementCapKW??null,
   poiTransformerRatedKVA:c.poiTransformerKVA,poiTransformerLoadFraction:s/c.poiTransformerKVA,
   pvBranchVoltageLLV:c.pvBranchVoltageLLV,pvBranchRealKW:c.pvGenerationKW,pvBranchReactiveKvar:c.pvBranchReactiveKvar??0,pvBranchApparentKVA:Math.hypot(c.pvGenerationKW,c.pvBranchReactiveKvar??0),pvBranchCurrentA:ip,
   requiredRealPowerExportReductionKW:Math.max(0,exportKW-c.exportAgreementCapKW),
   requiredRealPowerImportReductionKW:c.importAgreementCapKW==null?null:Math.max(0,importKW-c.importAgreementCapKW)},
  checks,failedChecks:failed,passForSpecifiedSnapshot:failed.length===0,
  warnings:[
   'A POI export power limit does NOT bound reverse import current, net reactive current or upstream PV feeder current.',
   'Snapshot assumes a balanced steady-state three-phase circuit and a single defined POI with input voltages at the rated equipment terminals; it cannot establish sustained thermal ratings or NEC 705 compliance.',
   'Any export/import reduction indicated is a required change, NOT an implemented PPC control or automatic curtailment; reduction of real power alone may leave reactive-current or apparent-power ratings exceeded.',
   'True equipment rating review must cover manufacturer continuous/interrupting ratings, duty cycle, faults, relays, settings, applicable code/AHJ, meter/CT, terminals, transformer winding connection, harmonics and measured voltage envelopes.',
   'Battery net kW positive means discharge and negative means charge; source location must be compatible with the assumed common-bus topology.',
   'PV branch voltage is independent from POI voltage and must match the actual branch conductor location; AC inverter/PV output must be within its own validated nameplate limits.',
   'The PV branch current is upstream of site load and POI export limiting and is not reduced by coincident site consumption.']};
}
