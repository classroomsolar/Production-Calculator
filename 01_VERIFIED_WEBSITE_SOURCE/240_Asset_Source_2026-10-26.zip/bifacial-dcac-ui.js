/** Opt-in research coupling; original hourly engines/results are NOT modified. */
import {simulateCoupledBifacialAC} from './bifacial-dcac-adapter.js';
const el=id=>document.getElementById(id);
const fmt=(n,d=2)=>Number.isFinite(n)?n.toLocaleString(undefined,{maximumFractionDigits:d}):'—';
const esc=s=>String(s??'').replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
const panel=el('bifacialB3');
const state={result:null,refs:null,running:false};
function fresh(){if(!state.result||!state.refs)return false;const b=window.SolarBifacialB3State?.(),p=window.SolarPV17State?.(),current=window.SolarResourceStudio?.getState?.()?.result;return !!(b?.result===state.refs.bifacial&&p?.result===state.refs.production&&b?.upstream===current&&p?.upstream===current);}
function clear(){state.result=null;state.refs=null;el('bf3dcac-export').disabled=true;el('bf3dcac-json').disabled=true;el('bf3dcac-result').replaceChildren();el('bf3dcac-status').textContent='Optical/weather or equipment inputs changed. Previous AC comparison invalidated.';}
function save(name,content,mime){const blob=new Blob([content],{type:mime}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),5000)}
function csv(rows){const keys=Object.keys(rows[0]||{});const cell=x=>{let v=String(x??'');if(/^[=+@]/.test(v))v="'"+v;return /[",\r\n]/.test(v)?'"'+v.replaceAll('"','""')+'"':v};return [keys.join(','),...rows.map(r=>keys.map(k=>cell(r[k])).join(','))].join('\r\n')}
function display(r){const f=r.frontOnly.annual,c=r.bifacial.annual;return `<div class="bf3ac-stats"><div><small>Front-only reference POI</small><strong>${fmt(f.poiExportKWh/1000,3)} MWh</strong></div><div><small>Bifacial POI screen</small><strong>${fmt(c.poiExportKWh/1000,3)} MWh</strong></div><div><small>POI difference</small><strong>${fmt(r.gainPoiKWh,1)} kWh</strong></div><div><small>POI change</small><strong>${fmt(r.gainPoiPct,2)}%</strong></div></div><p class="bf3ac-warning">${r.geometryAssumptions.concat(r.warnings).map(esc).join(' ')}</p>`}
if(panel){
 const area=document.createElement('section');area.id='bf3DCAc';area.className='bf3ac-box';
 area.innerHTML=`<h4>Optional bifacial → detailed DC/AC yield coupling</h4><p><strong>RESEARCH SCREEN ONLY.</strong> Runs the existing v1.7 five-parameter module and preliminary inverter-loss physics twice on the <em>same</em> bifacial geometry, equipment and hourly weather. First pass uses front irradiance; second adds effective rear irradiance. It does not modify original yield results or certify a PVsyst-equivalent simulation.</p><div class="bf3-actions"><button id="bf3dcac-run" type="button">Compare annual front-only vs bifacial POI</button><button id="bf3dcac-export" type="button" disabled>Hourly comparison CSV</button><button id="bf3dcac-json" type="button" disabled>Evidence JSON</button></div><p id="bf3dcac-status" role="status" aria-live="polite">First complete resource → detailed v1.7 production → bifacial optical year. To avoid double-counting row shade, detailed v1.7 linearShadePct must be zero.</p><div id="bf3dcac-result"></div>`;
 panel.appendChild(area);
 area.querySelector('#bf3dcac-run').addEventListener('click',()=>{
  if(state.running)return;clear();state.running=true;el('bf3dcac-run').disabled=true;el('bf3dcac-status').textContent='Evaluating matched front-only and bifacial DC-to-POI cases (experimental)...';
  setTimeout(()=>{try{const b=window.SolarBifacialB3State?.(),p=window.SolarPV17State?.(),current=window.SolarResourceStudio?.getState?.()?.result;
   if(!current||b?.upstream!==current||p?.upstream!==current)throw Error('Live resource weather case changed or required runs absent. Recalculate v1.7 and optical studies.');
   const r=simulateCoupledBifacialAC(b,p);state.result=r;state.refs={bifacial:b.result,production:p.result};el('bf3dcac-result').innerHTML=display(r);
   el('bf3dcac-status').textContent=`EXPERIMENTAL COUPLING COMPLETE · ${r.hours} hourly records · not OEM/field accepted`;
   el('bf3dcac-export').disabled=false;el('bf3dcac-json').disabled=false;
  }catch(err){el('bf3dcac-status').textContent='SCREEN REJECTED: '+err.message;}finally{state.running=false;el('bf3dcac-run').disabled=false;}},0);
 });
 for(const kind of ['input','change'])document.addEventListener(kind,e=>{const id=e.target?.id||'';if((id.startsWith('bf3_')||id.startsWith('pv17_'))&&state.result)clear();});
 el('bf3dcac-export').addEventListener('click',()=>{if(!fresh())return clear();save('bifacial_poi_comparison_hourly.csv',csv(state.result.hourlyComparison),'text/csv;charset=utf-8')});
 el('bf3dcac-json').addEventListener('click',()=>{if(!fresh())return clear();const {hourlyComparison,...summary}=state.result;save('bifacial_poi_comparison_audit.json',JSON.stringify({computedUtc:new Date().toISOString(),...summary,hourlyCount:hourlyComparison.length,classification:'EXPERIMENTAL_NOT_FOR_DESIGN'},null,2),'application/json')});
 window.SolarBifacialACSheets=()=>fresh()?[['Bifacial AC delta',[{case:'front only',annualPoiKWh:state.result.frontOnly.annual.poiExportKWh},{case:'bifacial',annualPoiKWh:state.result.bifacial.annual.poiExportKWh},{case:'difference',annualPoiKWh:state.result.gainPoiKWh}]]]:[];
 window.SolarBifacialACReportHTML=()=>fresh()?`<h2>Experimental bifacial DC/AC comparison - unverified</h2><p>Front POI: ${fmt(state.result.frontOnly.annual.poiExportKWh,2)} kWh; bifacial POI: ${fmt(state.result.bifacial.annual.poiExportKWh,2)} kWh; change ${fmt(state.result.gainPoiPct)}%.</p><p>${state.result.warnings.map(esc).join(' ')}</p>`:'';
}
