/** Batch 5 preliminary financial screen; linked only by user-initiated action. */
import {projectFinance} from './finance-core.js';
import {compareAnnualEnergyFinance} from './finance-sensitivity.js';
const el=id=>document.getElementById(id);
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fmt=(n,d=2)=>Number.isFinite(n)?n.toLocaleString('en-US',{maximumFractionDigits:d}):'—';
const defaults={year1KWh:0,capex:20000,omFixedPerYear:300,omVariablePerKWh:.005,ppaPerKWh:.10,degradationPct:.5,ppaEscalationPct:0,omEscalationPct:2,discountNominalPct:7,years:25};
let sourceEvidence='USER ENTERED YEAR-1 ENERGY · NOT INDEPENDENTLY VERIFIED',last=null,lastInput=null,linkedProduction=null;
const parent=el('pv15Section');
if(parent){
 const tabs=parent.querySelector('.pv15-tabs'),oldResult=el('pv15Result');
 if(tabs&&oldResult){
  tabs.insertAdjacentHTML('beforeend','<button type="button" data-finance-b5="finance">Finance &amp; LCOE R&amp;D · B5</button>');
  const fields=[['year1KWh','Year-1 POI export (kWh)',1,1e12,1],['capex','Initial installed CAPEX (currency)',0,1e12,100],['omFixedPerYear','Fixed annual O&M (currency/year)',0,1e9,10],['omVariablePerKWh','Variable O&M (currency/kWh)',0,100,.001],['ppaPerKWh','Year-1 sales price (currency/kWh)',0,100,.001],['degradationPct','Annual energy degradation (%)',0,25,.1],['ppaEscalationPct','Tariff escalation (%/year)',-20,50,.1],['omEscalationPct','O&M escalation (%/year)',-20,50,.1],['discountNominalPct','Nominal discount rate (%)',-50,100,.1],['years','Analysis term (years)',1,60,1]];
  const fieldHtml=fields.map(([k,title,low,high,step])=>`<label class="fin-lab">${esc(title)}<input id="finB5-${k}" type="number" min="${low}" max="${high}" step="${step}" value="${defaults[k]===0&&k==='year1KWh'?'':defaults[k]}"></label>`).join('');
  oldResult.insertAdjacentHTML('afterend',`<section id="financeB5" hidden class="fin-screen"><span class="eyebrow">BATCH 5 · PRELIMINARY PRE-TAX FINANCE</span><h3>Discounted LCOE, NPV, cash flow, simple IRR</h3><p>Nominal-currency front-of-meter scenario. All costs/prices use the <strong>same arbitrary currency</strong>. Not a SAM tax, debt, incentive or merchant-revenue model.</p><button type="button" id="finB5-load">Load last v1.7 synthetic annual POI energy (not qualified)</button><p id="finB5-provenance">Year-one energy must be entered or explicitly loaded from a research case.</p><div class="fin-grid">${fieldHtml}</div><div class="fin-actions"><button type="button" id="finB5-run">Calculate finance scenario</button><button type="button" id="finB5-csv" disabled>Cash flow CSV</button><button type="button" id="finB5-json" disabled>Finance audit JSON</button></div><p id="finB5-status" role="status">INPUT REQUIRED · Year-one annual production unavailable.</p><div id="finB5-results"></div><p class="fin-caution">No incentives, tax/ITC/MACRS, depreciation, insurance, debt, real-rate conversion, replacement capital, grid price risk, battery or PPA time-of-delivery. Current v1.7 annual production is synthetic. Never treat this screen as financeable or as a full SAM financial model.</p></section>`);
  const panel=el('financeB5'),tab=parent.querySelector('[data-finance-b5=finance]');
  // Explicitly linked sensitivity: no silent inheritance of unrelated annual yields.
  const sensitivityEl=document.createElement('section');sensitivityEl.id='finPxxSensitivity';
  sensitivityEl.innerHTML='<h4>P50 / P90 → finance sensitivity (screening only)</h4><p>Run the annual Pxx screen first. Its annual yields must describe the same PV plant and POI export definition as this finance study; the software cannot independently verify that link. This does NOT calculate probabilistic NPV.</p><label><input type="checkbox" id="finPxxSameProject"> I confirm the annual Pxx samples represent the same project, configuration and POI export basis</label><p><button type="button" id="finPxx-run">Compare P50 / P90 finance scenarios</button> <button type="button" id="finPxx-json" disabled>Scenario audit JSON</button></p><p id="finPxx-status" role="status">Finance and annual uncertainty studies required.</p><div id="finPxx-result"></div>';
  panel.appendChild(sensitivityEl);
  let sensitivity=null,sensitivitySources=null;
  const currentPxx=()=>window.SolarPxxB5State?.()||null;
  const sensitivityFresh=()=>!!sensitivity&&!!last&&!!sensitivitySources&&
    sensitivitySources.finance===last&&sensitivitySources.pxx===currentPxx()?.result&&energyFresh()&&el('finPxxSameProject').checked;
  const clearSensitivity=()=>{sensitivity=null;sensitivitySources=null;el('finPxx-json').disabled=true;el('finPxx-result').replaceChildren()};
  document.addEventListener('input',event=>{
    if(event.target?.id?.startsWith('pxx')||event.target?.id==='finPxxSameProject'){
      clearSensitivity();el('finPxx-status').textContent='Source changed; re-run the P50/P90 finance comparison.';
    }
  });
  const scenarioFmt=n=>n===null||!Number.isFinite(n)?'—':fmt(n,3);
  el('finPxx-run').addEventListener('click',()=>{
    clearSensitivity();try{
      const source=currentPxx();if(!source)throw Error('Run the annual P50/P90 study first.');
      if(!last||!lastInput||!energyFresh())throw Error('Calculate a fresh finance scenario first.');
      const response=compareAnnualEnergyFinance(source.result,lastInput,{sameProjectConfirmed:el('finPxxSameProject').checked});
      sensitivity=response;sensitivitySources={finance:last,pxx:source.result};
      const rows=response.scenarios.map(r=>'<tr><td>'+esc(r.name)+'</td><td>'+scenarioFmt(r.year1KWh)+'</td><td>'+scenarioFmt(r.nominalNPV)+'</td><td>'+scenarioFmt(r.nominalLCOEPerKWh)+'</td></tr>').join('');
      el('finPxx-result').innerHTML='<table class="fin-table"><thead><tr><th>Energy case</th><th>Year-1 kWh</th><th>Pre-tax nominal NPV</th><th>Nominal LCOE / kWh</th></tr></thead><tbody>'+rows+'</tbody></table><p>'+esc(response.warnings.join(' '))+'</p>';
      el('finPxx-status').textContent='P50/P90 FINANCE SENSITIVITY CALCULATED · USER-CONFIRMED SAME PROJECT · NOT BANKABLE';
      el('finPxx-json').disabled=false;
    }catch(e){el('finPxx-status').textContent='SENSITIVITY NOT CALCULATED: '+e.message;}
  });
  el('finPxx-json').addEventListener('click',()=>{if(!sensitivityFresh())return;
    const downloadObj={generatedUtc:new Date().toISOString(),sourceAnnualPxxInputs:currentPxx().inputs,sourceFinanceInputs:lastInput,result:sensitivity};
    const u=URL.createObjectURL(new Blob([JSON.stringify(downloadObj,null,2)],{type:'application/json'}));const a=document.createElement('a');a.href=u;a.download='research_pxx_finance_sensitivity.json';document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(u),5000);
  });
  window.SolarFinancePxxSheets=()=>sensitivityFresh()?[['B5 Pxx Finance Sensitivity',sensitivity.scenarios.map(x=>({...x}))]]:[];
  window.SolarFinancePxxReportHTML=()=>sensitivityFresh()?'<h2>P50/P90-linked preliminary finance sensitivity</h2><p>Same-project basis is user-confirmed, not independently qualified. NOT a P90 NPV.</p><table>'+sensitivity.scenarios.map(r=>'<tr><th>'+esc(r.name)+'</th><td>'+scenarioFmt(r.year1KWh)+' kWh</td><td>NPV '+scenarioFmt(r.nominalNPV)+'</td></tr>').join('')+'</table>':'';

  const hide=()=>{panel.hidden=true;tab.classList.remove('active')};
  for(const b of tabs.querySelectorAll('button:not([data-finance-b5])'))b.addEventListener('click',hide);
  tab.addEventListener('click',()=>{for(const id of ['pv15StringForm','pv15YieldForm','pv15AuditForm','pv17Lab','trackerB3']){const n=el(id);if(n)n.hidden=true}oldResult.hidden=true;for(const b of tabs.querySelectorAll('button'))b.classList.remove('active');tab.classList.add('active');panel.hidden=false});
  const read=()=>{const x={};for(const [k] of fields){const n=el('finB5-'+k);if(!n||n.value==='')throw Error('Missing '+k);x[k]=Number(n.value)}return x};
  const csv=rows=>{const keys=Object.keys(rows[0]||{});const cell=v=>{let x=String(v??'');if(/^[=+@]/.test(x))x="'"+x;return /[",\n\r]/.test(x)?'"'+x.replaceAll('"','""')+'"':x};return [keys.join(','),...rows.map(x=>keys.map(k=>cell(x[k])).join(','))].join('\r\n')};
  const download=(name,data,type)=>{const u=URL.createObjectURL(new Blob([data],{type})),a=document.createElement('a');a.href=u;a.download=name;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(u),5000)};
  const render=r=>{const s=r.summary;const first5=r.annualRows.slice(0,5).map(x=>`<tr><td>${x.year}</td><td>${fmt(x.productionKWh,0)}</td><td>${fmt(x.revenue,0)}</td><td>${fmt(x.operatingCost,0)}</td><td>${fmt(x.preTaxCashFlow,0)}</td></tr>`).join('');return `<div class="fin-stats"><div><small>Nominal LCOE</small><strong>${fmt(s.nominalLCOEPerKWh,4)} / kWh</strong></div><div><small>Pre-tax NPV</small><strong>${fmt(s.nominalNPV,0)}</strong></div><div><small>Pre-tax IRR</small><strong>${s.preTaxIRRPercent===null?'Not uniquely available':fmt(s.preTaxIRRPercent,2)+'%'}</strong></div><div><small>Simple undiscounted payback</small><strong>${s.undiscountedPaybackYears===null?'Not reached':fmt(s.undiscountedPaybackYears,2)+' years'}</strong></div><div><small>Discounted energy (kWh)</small><strong>${fmt(s.presentValueEnergyKWh,0)}</strong></div></div><h4>Cash flow: years 1–5 (full data in CSV)</h4><table class="fin-table"><thead><tr><th>Year</th><th>kWh</th><th>Revenue</th><th>Costs</th><th>Net cash flow</th></tr></thead><tbody>${first5}</tbody></table><p><strong>Assumptions:</strong> ${esc(r.assumptions.join(' '))}</p>`};
  const invalidate=()=>{clearSensitivity();last=null;el('finB5-csv').disabled=true;el('finB5-json').disabled=true;el('finB5-results').replaceChildren()};
 const energyFresh=()=>linkedProduction===null||window.SolarPV17State?.()?.result===linkedProduction;
 const clearStaleEnergy=()=>{if(linkedProduction===null)return;linkedProduction=null;invalidate();el('finB5-year1KWh').value='';sourceEvidence='PREVIOUS v1.7 ENERGY IS STALE — RELOAD THE CURRENT PV CASE';el('finB5-provenance').textContent=sourceEvidence;el('finB5-status').textContent='ENERGY SOURCE INVALIDATED · rerun the current detailed PV study and reload the energy.'};
 window.addEventListener('solarresource:updated',()=>{if(linkedProduction!==null&&!energyFresh())clearStaleEnergy()});
 document.addEventListener('input',event=>{if(linkedProduction!==null&&event.target?.id?.startsWith('pv17_'))clearStaleEnergy()});
 document.addEventListener('change',event=>{if(linkedProduction!==null&&event.target?.id?.startsWith('pv17_'))clearStaleEnergy()});
  el('finB5-year1KWh').addEventListener('input',()=>{linkedProduction=null;sourceEvidence='USER ENTERED ANNUAL PRODUCTION · NOT VERIFIED';el('finB5-provenance').textContent=sourceEvidence;invalidate()});
  for(const [k] of fields){if(k==='year1KWh')continue;el('finB5-'+k).addEventListener('input',()=>{invalidate();el('finB5-status').textContent='INPUT CHANGED · rerun financial calculation before exporting';});}
  el('finB5-load').addEventListener('click',()=>{invalidate();const original=window.SolarPV17State?.();const kwh=original?.result?.annual?.poiExportKWh;if(!Number.isFinite(kwh)||kwh<=0){el('finB5-status').textContent='Run detailed v1.7 hourly production before loading its research energy';return;}el('finB5-year1KWh').value=String(kwh);linkedProduction=original.result;sourceEvidence='SYNTHETIC v1.7 DC-to-AC RESEARCH POI ENERGY · NOT BANKABLE';el('finB5-provenance').textContent=sourceEvidence;el('finB5-status').textContent='Loaded '+fmt(kwh,1)+' kWh annual POI export from v1.7. Recheck all financial assumptions.'});
  el('finB5-run').addEventListener('click',()=>{invalidate();try{if(!energyFresh()){clearStaleEnergy();throw Error('Upstream v1.7 changed; reload POI energy from current production result');}const x=read(),r=projectFinance(x);last=r;lastInput=x;el('finB5-results').innerHTML=render(r);el('finB5-status').textContent='PRELIMINARY FINANCE SCREEN CALCULATED · '+sourceEvidence;el('finB5-csv').disabled=false;el('finB5-json').disabled=false;}catch(e){el('finB5-status').textContent='INPUT REJECTED: '+e.message}});
  el('finB5-csv').addEventListener('click',()=>{if(last&&energyFresh())download('pv_finance_cashflow.csv',csv(last.annualRows),'text/csv;charset=utf-8')});
  el('finB5-json').addEventListener('click',()=>{if(last&&energyFresh())download('pv_finance_audit.json',JSON.stringify({inputs:lastInput,energyEvidence:sourceEvidence,summary:last.summary,rows:last.annualRows,assumptions:last.assumptions},null,2),'application/json')});
  window.SolarFinanceB5Sheets=()=>last&&energyFresh()?[['B5 Finance Summary',Object.entries(last.summary).map(([metric,value])=>({metric,value}))],['B5 Finance Annual',last.annualRows]]:[];
  window.SolarFinanceB5ReportHTML=()=>last&&energyFresh()?`<h2>Batch 5 nominal pre-tax financial screening</h2><p>${esc(sourceEvidence)}</p><table>${Object.entries(last.summary).map(([k,v])=>`<tr><th>${esc(k)}</th><td>${esc(v)}</td></tr>`).join('')}</table><p>${esc(last.assumptions.join(' '))}</p>`:'';
 }
}
