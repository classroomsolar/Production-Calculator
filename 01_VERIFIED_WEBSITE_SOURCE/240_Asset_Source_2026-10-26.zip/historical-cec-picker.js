/** Reproducible historical CEC module fit prefill for existing v1.7 study.
 * The source is a published, pinned local research fixture; NOT current OEM approval.
 * Inputs are explicitly overwritten only after a button press.
 */
import {deSotoDetailedPower} from './pv-detailed-v17.js';
const lab=document.getElementById('pv17Lab');
const provenance=document.getElementById('pv17_provenance');
if(lab&&provenance){
 const area=document.createElement('div');area.className='pv17-reference-picker';
 const button=document.createElement('button');button.type='button';button.id='pv17-load-historical-cec';button.textContent='Load historical CEC 220 W test module (research only)';
 const status=document.createElement('p');status.id='pv17-historical-cec-status';status.setAttribute('role','status');status.textContent='This loads coefficients from a source-linked historical pvlib/CEC test fixture. It is not an OEM-qualified design product.';
 const label=document.createElement('label');label.className='pv17-preset-opt';
 const box=document.createElement('input');box.type='checkbox';box.id='pv17-historical-example-topology';box.checked=true;
 const message=document.createElement('span');message.textContent='Also set 12 series modules as an illustrative topology (other array/inverter assumptions remain user-provided).';
 label.append(box,message);area.append(button,label,status);provenance.parentElement.after(area);
 let busy=false;
 button.addEventListener('click',async()=>{
  if(busy)return;
  busy=true;button.disabled=true;status.textContent='Checking source, diode fit and STC benchmark…';
  try{
   const response=await fetch('./batch2-cec-module-historical-reference.json',{cache:'no-store'});
   if(!response.ok)throw Error(`Reference fixture unavailable (HTTP ${response.status})`);
   const j=await response.json();
   if(j.classification!=='HISTORICAL_CEC_FIT_REFERENCE_NOT_CURRENT_OEM_QUALIFIED')throw Error('Unexpected or unqualified source classification');
   if(!j.source?.startsWith('https://pvlib-python.readthedocs.io/'))throw Error('Expected public pvlib source is not recorded');
   const ref=j.coefficients;
   const keys=['ILrefA','I0refA','RsRefOhm','RshRefOhm','aRefV','alphaIscAperC','EgRefEv','dEgdTPerK'];
   for(const k of keys)if(!Number.isFinite(ref?.[k]))throw Error('Reference coefficient missing: '+k);
   const physical=deSotoDetailedPower(ref,1000,25);
   const pTarget=j.stcListed?.PmpW;
   if(!Number.isFinite(pTarget)||Math.abs(physical.pmp-pTarget)>0.02)throw Error(`Published CEC STC consistency error: ${physical.pmp} W differs from ${pTarget} W`);
   for(const k of keys){const el=document.getElementById('pv17_module_'+k);if(!el)throw Error('De Soto input missing: '+k)}
   for(const k of keys){const el=document.getElementById('pv17_module_'+k);el.value=String(ref[k]);el.dispatchEvent(new Event('input',{bubbles:true}))}
   if(box.checked){const n=document.getElementById('pv17_array_modulesPerString');if(!n)throw Error('Array topology input missing');n.value='12';n.dispatchEvent(new Event('input',{bubbles:true}))}
   provenance.value=`HISTORICAL CEC FIT, NOT OEM-APPROVED: ${j.name} | ${j.source}`;
   provenance.dispatchEvent(new Event('input',{bubbles:true}));
   status.textContent=`Historical CEC fixture loaded, STC Pmp ${physical.pmp.toFixed(4)} W vs source ${pTarget.toFixed(3)} W. Configuration changed: old results invalidated. User must verify array/inverter/current/voltage constraints before rerunning; no current manufacturer approval.`;
  }catch(e){status.textContent='NOT LOADED: '+e.message}
  finally{busy=false;button.disabled=false}
 });
}
