/** Batch 2 CEC/Sandia curve verification panel; nested INSIDE v1.7 R&D workbench.
 * Does not mutate existing 2024 weather simulation nor change canonical PV module database.
 */
import {CEC_MODEL_VERSION, sandiaCecInverter, sandiaPowerCurve} from './cec-sandia-engine.js';
const parent=document.getElementById('pv17Lab');
if(!parent)throw Error('Expected v1.7 lab container not present');
const box=document.createElement('details');box.id='cecBatch2Bench';box.className='cec-bench';
box.innerHTML=`<summary>Batch 2 · CEC/Sandia inverter validation bench (6 real source-library fits)</summary>
<div class="cec-body"><p><strong>Reference coefficients:</strong> six exact rows from the public NLR/NREL SAM CEC Inverters library. Historical fitted efficiency coefficients, <strong>NOT current OEM listing, certification or a replacement for inverter-specific inputs.</strong> Source revision is recorded below. This benchmark does not alter v1.7 yield.</p>
<div class="cec-controls"><label>Reference inverter<select id="cec-model" disabled><option>Load reference file first</option></select></label>
<label>DC power, kW<input type="number" min="0" step="0.01" id="cec-dc" value="2.5"></label>
<label>DC operating voltage, V<input type="number" min="1" step="1" id="cec-vdc" value="340"></label></div>
<div class="cec-actions"><button type="button" id="cec-load">Load six checked CEC rows</button><button type="button" id="cec-full">Load all 2,343 CEC library rows</button><button type="button" id="cec-run" disabled>Compute CEC/Sandia inverter response</button><button type="button" id="cec-csv" disabled>Export curve CSV</button><button type="button" id="cec-json" disabled>Export audit JSON</button></div>
<label class="cec-find-label">Search full inverter catalogue by manufacturer or model<input type="search" id="cec-search" disabled placeholder="Try SMA, Fronius, Sungrow or specific model"></label><p class="cec-catalog-status" id="cec-catalog-summary"></p><p role="status" aria-live="polite" id="cec-status">Reference model file not loaded. Results are neither manufacturer-calibrated by this website nor project approved.</p><div id="cec-results"></div><div id="cec-plot"></div>
<p class="cec-disclaimer">This module screens library MPPT envelope and CEC Idcmax but does not establish hardware input-current limits, individual MPPT channel ratings, thermal derating, efficiency maps outside the fitted range, AC grid requirements, optimizer compatibility, anti-islanding or NEC/UL compliance. No manufacturer-specific module operating data or total-plant yield is inferred.</p></div>`;
parent.appendChild(box);
const $=id=>document.getElementById(id),esc=x=>String(x??'').replace(/[&<>'"]/g,k=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[k]));
const fmt=(v,d=3)=>typeof v==='number'&&Number.isFinite(v)?v.toFixed(d):'—';
let library=null,current=null,currentModel=null,curve=null,fullLibrary=null;
function status(s){$('cec-status').textContent=s}
async function load(){try{status('Reading six exact published CEC/Sandia fits');
 const response=await fetch('./cec-inverter-library.json',{cache:'no-cache'});
 if(!response.ok)throw Error('CEC library HTTP '+response.status);
 const data=await response.json();if(!Array.isArray(data.models)||data.models.length!==6)throw Error('Expected six documented models');
 library=data;fullLibrary=null;const select=$('cec-model');select.innerHTML=data.models.map((x,i)=>`<option value="${i}">${esc(x.name)}</option>`).join('');select.disabled=false;$('cec-run').disabled=false;
 select.value='0';select.dispatchEvent(new Event('change'));$('cec-search').disabled=true;$('cec-search').value='';$('cec-catalog-summary').textContent='Six-model controlled example selected. No manufacturer product approval is implied.';status('Loaded 6 source-linked CEC inverter coefficient sets from public SAM reference. NOT OEM-approved equipment.');
}catch(err){status('REFERENCE LOAD ERROR: '+err.message); $('cec-run').disabled=true}}
$('cec-model').addEventListener('change',()=>{if(!library)return;const m=library.models[Number($('cec-model').value)];if(!m){$('cec-run').disabled=true;return;}$('cec-run').disabled=false;$('cec-dc').value=(m.Pdco*.78/1000).toFixed(3);$('cec-vdc').value=m.Vdco;current=null;$('cec-csv').disabled=true;$('cec-json').disabled=true;$('cec-results').textContent='';$('cec-plot').textContent=''});
$('cec-load').addEventListener('click',load);
function parseFullCecCsv(raw){
 const lines=raw.trim().split(/\r?\n/);
 const header=['Name','Vac','Pso','Paco','Pdco','Vdco','C0','C1','C2','C3','Pnt','Vdcmax','Idcmax','Mppt_low','Mppt_high','CEC_Date','CEC_hybrid'];
 if(lines[0].split(',').join('|')!==header.join('|'))throw Error('Unexpected source library schema');
 const rows=lines.slice(3).filter(Boolean),incomplete=[];
 const models=rows.map((row,i)=>{
  const parts=row.split(',');if(parts.length!==17)throw Error('CSV column mismatch at line '+(i+4));
  const o={};for(let j=0;j<header.length;j++){
   const k=header[j],v=parts[j];o[k]=j===0||j===15||j===16?v:(v==='NaN'||v===''?null:Number(v));
  }
  o.name=o.Name;
  if(Object.entries(o).some(([k,v])=>k!=='CEC_Date'&&k!=='CEC_hybrid'&&k!=='Name'&&k!=='name'&&(!Number.isFinite(v))) )incomplete.push(o.Name);
  return o;
 });
 if(models.length!==2343)throw Error('CEC CSV record count changed from vetted snapshot: '+models.length);
 return {models,incomplete};
}
function optionsBySearch(){
 if(!fullLibrary||!library)return;
 const term=$('cec-search').value.trim().toLowerCase(),matches=term?fullLibrary.models.filter(m=>m.Name.toLowerCase().includes(term)):fullLibrary.models;
 const shown=matches.slice(0,90),select=$('cec-model');
 select.innerHTML=shown.map(x=>{const i=fullLibrary.models.indexOf(x);return `<option value="${i}">${esc(x.Name)}${Number.isFinite(x.Pnt)?'':' · INCOMPLETE CEC DATA'}</option>`}).join('');
 select.disabled=shown.length===0;
 $('cec-catalog-summary').textContent=`Full SAM CEC library: ${fullLibrary.models.length.toLocaleString()} records, 8 missing/non-numeric night-power values, 1,016 missing fit dates. ${matches.length} names match your search; first ${shown.length} displayed. Source revision pinned.`;
 current=null;curve=null;$('cec-csv').disabled=true;$('cec-json').disabled=true;
 $('cec-results').textContent='';$('cec-plot').textContent='';
 if(shown.length){select.selectedIndex=0;select.dispatchEvent(new Event('change'));}
}
$('cec-full').addEventListener('click',async()=>{
 const button=$('cec-full');button.disabled=true;status('Fetching all 2,343 CEC inverter records from the pinned site snapshot…');
 try{
  const [response,metaResponse]=await Promise.all([fetch('./sam-cec-inverters-snapshot.csv',{cache:'no-cache'}),fetch('./sam-cec-inverters-snapshot.manifest.json',{cache:'no-cache'})]);
  if(!response.ok||!metaResponse.ok)throw Error('Source snapshot fetch '+response.status+'/'+metaResponse.status);
  const manifest=await metaResponse.json(),data=parseFullCecCsv(await response.text());
  if(manifest.sourceBlobSha!=='3f54e6dad8a6996514c72aa0ed86e65f68f2dae7')throw Error('Unexpected source snapshot revision');
  fullLibrary=data;
  library={models:data.models,source:{url:manifest.url,gitBlobSha:manifest.sourceBlobSha,scope:manifest.approval}};
  $('cec-search').disabled=false;$('cec-search').value='';optionsBySearch();
  $('cec-run').disabled=false;status('Loaded 2,343 source-linked CEC inverter fit records; 8 incomplete rows are not silently fixed. NOT OEM-approved equipment.');
 }catch(e){status('FULL LIBRARY ERROR: '+e.message);fullLibrary=null;}finally{button.disabled=false}
});
$('cec-search').addEventListener('input',optionsBySearch);
function svgLine(pts,kind,maxP,minVal,maxVal){return pts.map((d,i)=>{const val=d[kind];if(val===null||!Number.isFinite(val))return '';return `${i?'L':'M'}${(d.pdcW/maxP*760+42).toFixed(1)},${(238-(val-minVal)/(maxVal-minVal)*205).toFixed(1)}`}).filter(Boolean).join(' ')}
function drawChart(rows,m){const positives=rows.filter(r=>r.pacW!==null),maxP=Math.max(1,...rows.map(r=>r.pdcW)),minAc=Math.min(0,...positives.map(r=>r.pacW))/1000,maxAc=Math.max(0,...positives.map(r=>r.pacW))/1000;const span=Math.max(1,maxAc-minAc);
 const adjusted=rows.map(r=>({...r,pacKW:r.pacW===null?null:r.pacW/1000}));
 const path=svgLine(adjusted,'pacKW',maxP,minAc,minAc+span);
 return `<svg class="cec-chart" viewBox="0 0 840 280" role="img" aria-label="Sandia/CEC AC output versus DC power for the selected inverter, in kW"><path d="M42 20V238H805" fill="none" stroke="currentColor" stroke-width="1" opacity=".55"/><path d="${path}" fill="none" stroke="#2879aa" stroke-width="3"/><text x="48" y="17" font-size="12" fill="currentColor">AC kW · ${esc(fmt(maxAc,2))} max on grid</text><text x="570" y="263" font-size="12" fill="currentColor">Input DC kW · up to ${esc(fmt(maxP/1000,2))}</text></svg>`;
}
function render(){if(!library)return;try{
 const m=library.models[Number($('cec-model').value)];if(!m)throw Error('Select an inverter first');const p=Number($('cec-dc').value)*1000,v=Number($('cec-vdc').value);
 const operating=sandiaCecInverter(m,p,v),points=sandiaPowerCurve(m,{samples:41,voltageV:m.Vdco});
 current=operating;currentModel=m;curve=points;
 const fields=[['Current operating point',operating.status],['DC input kW',fmt(p/1000)],['DC voltage V',fmt(v,2)],['DC current A',fmt(operating.dcCurrentA,3)],['AC output kW',operating.acPowerW===null?'INVALID OPERATING SCREEN':fmt(operating.acPowerW/1000,4)],['Fitted AC max kW',fmt(m.Paco/1000)],['Curve input rated kW',fmt(m.Pdco/1000)],['CEC input current A',fmt(m.Idcmax,3)],['CEC MPPT limits V',`${m.Mppt_low}–${m.Mppt_high}`],['CEC listing fit date',m.CEC_Date==='NaN'?'MISSING IN DATASET':m.CEC_Date||'MISSING IN DATASET'],['Operating flags',operating.flags.join('; ')||'None at this test operating point']];
 $('cec-results').innerHTML=`<table class="cec-table"><tbody>${fields.map(([k,val])=>`<tr><th>${esc(k)}</th><td>${esc(val)}</td></tr>`).join('')}</tbody></table><p><strong>Source:</strong> <a target="_blank" rel="noopener noreferrer" href="${esc(library.source.url)}">NLR SAM CEC Inverters.csv</a> · Git blob ${esc(library.source.gitBlobSha)}</p>`;
 $('cec-plot').innerHTML=drawChart(points,m);
 $('cec-csv').disabled=false;$('cec-json').disabled=false;
 status(operating.status==='SCREEN_FAILED'?'NOT VALID: operating envelope exceeded; no AC extrapolation.':'CEC reference curve evaluated at stated point. Results are research-only; original PVWatts study is unchanged.');
}catch(e){current=null;curve=null;status('CALCULATION FAILED: '+e.message);$('cec-csv').disabled=true;$('cec-json').disabled=true}}
$('cec-run').addEventListener('click',render);
function download(n,text,mime){const a=document.createElement('a'),u=URL.createObjectURL(new Blob([text],{type:mime}));a.href=u;a.download=n;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(u),10000)}
const cval=x=>x===null?'':typeof x==='number'?x.toFixed(6):String(x);
$('cec-csv').addEventListener('click',()=>{if(!curve)return;download('CEC_SANDIA_REFERENCE_CURVE.csv', [['Input DC W','Output AC W','Efficiency %'],...curve.map(x=>[x.pdcW,x.pacW,x.efficiencyPct])].map(x=>x.map(cval).join(',')).join('\r\n'),'text/csv')});
$('cec-json').addEventListener('click',()=>{if(!current)return;download('CEC_SANDIA_RESEARCH_AUDIT.json',JSON.stringify({modelVersion:CEC_MODEL_VERSION,source:library.source,record:currentModel,operatingResult:current,input:{dcPowerKW:$('cec-dc').value,dcVoltageV:$('cec-vdc').value},curve,qualification:'NOT MANUFACTURER OR NEC APPROVED; REFERENCE EFFICIENCY MODEL ONLY'},null,2),'application/json')});
window.SolarCECInverterSheets=()=>current&&curve?[['CEC_CURVE_RESEARCH',[['Pdc_W','Pac_W','Efficiency_%'],...curve.map(x=>[x.pdcW,x.pacW,x.efficiencyPct])]],['CEC_SOURCE_AUDIT',[['Item','Value'],['Model name',currentModel.name],['Published CEC date',currentModel.CEC_Date||'Missing'],['SAM source git blob',library.source.gitBlobSha],['Project approval','NOT APPROVED']]]]:[];
window.SolarCECInverterReportHTML=()=>current?`<h2>Batch 2 CEC inverter curve — research only</h2><p>${esc(currentModel.name)} · CEC date ${esc(currentModel.CEC_Date||'unavailable')} · output ${esc(fmt(current.acPowerW===null?null:current.acPowerW/1000,3))} kW · status ${esc(current.status)}. This is a historical model-fit reference, not manufacturer/project approval.</p>`:'';
