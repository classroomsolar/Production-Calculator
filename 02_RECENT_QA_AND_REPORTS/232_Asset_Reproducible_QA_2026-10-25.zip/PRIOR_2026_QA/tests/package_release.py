from pathlib import Path
import hashlib, json, csv, collections, re, zipfile, shutil, datetime, os
W=Path('/mnt/data/solar_platform_working');BASE=W/'baseline';ROOT=W/'candidate';OUT=W/'deliverables';R=W/'results';OUT.mkdir(parents=True,exist_ok=True)
B=Path('/mnt/data/Solar_PV_Engineering_Current_217_Assets_Full_Source_2026-10-25.zip')
DATE='2026-10-25';SITE='ec984f80-a998-4e29-a38c-ca6b85dac4f4';BEFORE='dcc810083b1dc82d2cb5554812e4750a070da2c4';AFTER='9a34aef723da47eaf08eed70fa4b38d21f891cb8'
fix='pv-reference-kernel.js';backupdir='release-backups/pre-pvwatts-efficiency-floor-20261025/'
cat=json.loads((ROOT/'master_pv_modules.json').read_text());
byname=collections.defaultdict(list)
for m in cat['models']:
 def norm(x):return ' '.join(str(x or '').strip().upper().split())
 byname[(norm(m['maker']),norm(m['model']))].append(m)
rows=[]
for key,ms in sorted(byname.items()):
 if len(ms)>1:
  for m in ms:
   rows.append({'normalized_maker':key[0],'normalized_model':key[1],'identity_count':len(ms),'record_id':m['id'],'row':m.get('row'),'source':m.get('source'),'w':m.get('w'),'voc':m.get('voc'),'isc':m.get('isc'),'vmp':m.get('vmp'),'imp':m.get('imp'),'action':'PRESERVED_PENDING_OEM_REVIEW'})
with (R/'manufacturer_model_duplicate_flags.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
paths=[p for p in ROOT.rglob('*') if p.is_file()]
paths.sort(key=lambda p:str(p.relative_to(ROOT)))
assert len(paths)==220,len(paths)
assert len(cat['models'])==26000
assert sha(BASE/'master_pv_modules.json')==sha(ROOT/'master_pv_modules.json')
assert sha(BASE/'index.html')==sha(ROOT/'index.html')
assert sha(BASE/'main.js')==sha(ROOT/'main.js')
assert sha(ROOT/(backupdir+fix))==sha(BASE/fix)
local_manifest={'releaseDate':DATE,'existingSiteId':SITE,'siteUrl':'https://headless-spqwsttbeuf-classroomsolar-140e.wix-site-host.com/', 'previousRevision':BEFORE,'publishedRevision':AFTER,'publicationUploadId':'0866746d-43be-4bee-868a-959dcb54bdda','liveAssetCountAfter':219,'fullLocalArchiveEntriesIncludingWixConfig':220,'originalSourceArchiveEntriesIncludingWixConfig':218,'activeSourceChanges':[fix], 'addedRecoveryFiles':[backupdir+fix,backupdir+'MANIFEST.json'],'unchangedMasterPVModules':{'records':len(cat['models']),'bytes':(ROOT/'master_pv_modules.json').stat().st_size,'sha256':sha(ROOT/'master_pv_modules.json')},'catalogExactNormalizedIdentityDuplicates':{'groups':sum(1 for v in byname.values() if len(v)>1),'excessRecords':sum(len(v)-1 for v in byname.values() if len(v)>1),'action':'preserved pending original OEM data validation'},'inverterPatch':{'beforeSha256':sha(BASE/fix),'afterSha256':sha(ROOT/fix)},'files':{str(p.relative_to(ROOT)): {'bytes':p.stat().st_size,'sha256':sha(p)} for p in paths},'limitations':['Browser JS integration has not been exercised against live public URL in this execution environment.','SSC/PySAM and pvlib Python libraries were not installed in this runtime; no independent execution claimed.','Calculations are research screens, not bankable or construction certified.']}
manifest_file=R/'release_integrity_manifest.json';manifest_file.write_text(json.dumps(local_manifest,indent=2)+'\n')
sourcezip=OUT/'Solar_PV_Engineering_Verified_Live_219_Assets_Source_2026-10-25.zip'
with zipfile.ZipFile(sourcezip,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in paths:z.write(p,p.relative_to(ROOT))
with zipfile.ZipFile(sourcezip) as z:
 for p in paths:assert z.read(str(p.relative_to(ROOT)))==p.read_bytes()
original=OUT/'Solar_PV_Engineering_Original_PrePatch_218_Entry_Rollback_2026-10-25.zip'
shutil.copyfile(B,original)
assert sha(original)==sha(B)
qa=OUT/'Solar_PV_Engineering_Executable_QA_Evidence_2026-10-25.zip'
with zipfile.ZipFile(qa,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(R.glob('*')):
  if p.is_file() and p.suffix not in ['.png']:
   z.write(p,'results/'+p.name)
 for p in sorted((W/'tests').glob('*')):
  if p.is_file():z.write(p,'tests/'+p.name)
 for p in sorted((W/'transfer/03_ENGINEERING_CATALOG_AUDIT').glob('*')):
  if p.is_file() and p.name not in ['REFERENCE_SAM_CEC_Modules_pinned_blob.csv','ALL_26000_ROWS.csv']:
   z.write(p,'catalog_reference_audit/'+p.name)
index=OUT/'Solar_PV_Engineering_Release_Hashes_2026-10-25.txt'
index.write_text('SHA-256 release artifact checksums (locally computed)\n'+''.join(f'{sha(p)}  {p.name}  ({p.stat().st_size} bytes)\n' for p in [sourcezip,original,qa]))
print(json.dumps({'sourcezip':str(sourcezip),'size':sourcezip.stat().st_size,'sourceentries':len(paths),'backupzip':str(original),'qaZip':str(qa),'qaSize':qa.stat().st_size,'catalogDuplicateGroups':local_manifest['catalogExactNormalizedIdentityDuplicates'],'manifest':str(manifest_file)},indent=2))
