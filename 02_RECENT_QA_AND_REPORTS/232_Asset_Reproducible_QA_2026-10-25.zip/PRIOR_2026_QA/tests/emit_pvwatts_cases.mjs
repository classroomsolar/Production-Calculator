import fs from 'node:fs';
import {pvwattsInverterKW} from '../candidate/pv-reference-kernel.js';
const cases=[];
for(const ac of [1,25,250,1500]){
 for(let i=0;i<=500;i++){
  const dc=ac*(i/500)*1.8;
  const v=pvwattsInverterKW(dc,ac,.96,.9637);
  cases.push({dcKW:dc,acRatedKW:ac,acKW:v.acKW,efficiency:v.efficiency});
 }
}
fs.writeFileSync('/mnt/data/solar_platform_working/results/pvwatts_cases.json',JSON.stringify(cases));
