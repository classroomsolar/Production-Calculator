from pathlib import Path
import json,hashlib
W=Path('/mnt/data/solar_platform_working');R=W/'results';O=W/'deliverables';O.mkdir(exist_ok=True)
r=json.loads((R/'regression_candidate.json').read_text());p=json.loads((R/'independent_python_qa.json').read_text());st=json.loads((R/'static_browser.json').read_text());mp=json.loads((R/'release_integrity_manifest.json').read_text());sp=json.loads((R/'js_parse.json').read_text());
rows='\n'.join(f'| {k.replace("_"," ")} | {v} |' for k,v in r['suites'].items())
report=f'''# Solar PV Engineering Platform — Guarded Wix Release and Independent Engineering QA

**Released:** 25 October 2026  
**Current original website:** https://headless-spqwsttbeuf-classroomsolar-140e.wix-site-host.com/  
**Wix site ID:** `{mp['existingSiteId']}`  
**Previous revision:** `{mp['previousRevision']}`  
**Verified new revision:** `{mp['publishedRevision']}`  
**Wix upload ID:** `{mp['publicationUploadId']}`

## 1. Release result — existing site, no new site

- Wix accepted a guarded file-level patch and returned `published: true`. The patch helper reported `atomic: false`; concurrent edits during its read/merge/drop window are **not** transactionally prevented.
- Exactly one active application source was replaced: `pv-reference-kernel.js`.
- Exactly two files were added: a pristine on-site copy of the original source and a rollback manifest in `release-backups/pre-pvwatts-efficiency-floor-20261025/`.
- Wix returned **0 deletions**, **219 deployed file assets** following the patch (from 217 before), and the new deployment revision above.
- Authenticated read-back of the changed JS matched expected UTF-16 FNV-1a **3213434110**; read-back of the rollback JS matched its original value **2365299264**. These values are quick consistency checks, **not cryptographic signatures**; SHA-256 identities of the locally tested source are in the release integrity manifest.
- The master catalogue remained a listed asset of **6,809,617 bytes**. The recovered local source catalogue is **26,000 models** with SHA-256 `{mp['unchangedMasterPVModules']['sha256']}`, exactly unchanged from the previous complete source ZIP.
- Current source ZIP consists of **220 entries**, meaning the current **219 Wix-deployed assets + the generated Wix configuration (`wix.config.json`)** retained in the developer backup. Do not upload this ZIP without comparing current live inventory; a raw Wix drop replaces omitted files.

## 2. Reproduced bug and actual engineering correction

**Failure before correction.** The low-input side of the empirical PVWatts inverter curve may evaluate to a *negative* algebraic AC conversion efficiency, although the calculation already clips AC output power to zero. With `dcKW=0.0001`, `acRatedKW=1`, `etaNom=0.96`, `etaRef=0.9637`, the baseline source returned a reported efficiency of approximately **−60.24** (ratio), while AC power was zero. This reporting value violates physically admissible 0–100% efficiency. The invalid negative number was not a physically meaningful solar inverter operation.

**Change.** `const eff=Math.min(1,raw)` is replaced by `const eff=Math.max(0,Math.min(1,raw))`. Non-physical calculated efficiency greater than one continues to raise an error under the existing `>1 + 1e−10` guard. At very low DC input the fitted negative efficiency becomes a zero-efficiency/zero-AC-output case. **AC energy production is mathematically unchanged** because the pre-patch code already used `Math.max(0,dcKW*eff)` to calculate generated AC.

**Scope.** This is a software calculation/reporting fix, not a certified low-load inverter performance model and not a basis for OEM yield guarantees. The model fit, coefficients and manufacturer assumptions are unchanged.

## 3. Executed numerical and source regressions

- Candidate source: **{r['checks']} executable JavaScript assertions**, **{len(r['suites'])} independent test-suite groupings**, **{sum(v=='PASS' for v in r['suites'].values())} passed, 0 failed**. Running the same tests on the pre-patch baseline correctly **fails the low-input PVWatts efficiency assertion** and passes the other nine test suites.
- Separate Python/numpy comparator: **{p['pythonChecks']} independent checks**, covering BESS hourly/annual conservation and SOC, covariance/P90 matrix quadratic form, financial NPV/LCOE, catalogue/archive byte integrity. The Python implementation does not import production JS source. Both normal **8,760** and leap-year **8,784**-hour cases were exercised by the JS suite.
- Active JavaScript syntax parse: **{sp['checkedActiveJs']} `.js` files**, all passed under Node.js (including current source and generated thermal code).
- Browser static DOM/CSS smoke: Chromium rendered **1,440 px** and **390 px** viewports; no horizontal overflow, no missing linked local JS/CSS references (`{st['scriptsFound']}` scripts, `{st['stylesheetsFound']}` stylesheets), title/header and input controls rendered.
- All original 218 recovered ZIP entries were verified byte-for-byte against extracted original files. The correction is the **only changed active source path** compared with the original complete recovered ZIP; newly added recovery files are versioned separately.

| JavaScript test suite | Result |
|---|---|
{rows}

## 4. Module/manufacturer catalogue: preservation, not false OEM approval

The catalogue has **26,000 models** unchanged. The exact normalized manufacturer+model identity scan found **{mp['catalogExactNormalizedIdentityDuplicates']['groups']} repeated identity groups with {mp['catalogExactNormalizedIdentityDuplicates']['excessRecords']} excess rows**. These are flagged in `manufacturer_model_duplicate_flags.csv`; **none were deleted or silently merged**, because identical name strings are not proof of identical electrical specifications or approved revisions.

The inherited **pinned SAM CEC Modules CSV** audit includes 21,677 reference rows (21,533 normalized identities). Its existing classifications over the 26,000 current-module entries are:

| Catalogue status against pinned reference | Records |
|---|---:|
| Five-field STC match, ≤0.01 absolute tolerance | 8,202 |
| Five-field match within 2% | 236 |
| Large STC discrepancies, >2% | 58 |
| Ambiguous reference identity | 12 |
| No exact reference identity | 17,492 |

Audit reference is the historical Git blob `5f931df381c77633463c68eb7647a5e9bae30588` under NatLabRockies/SAM `deploy/libraries/CEC Modules.csv`. SAM catalogues are **secondary reference data**, not original manufacturer's revision-specific signed specification sheets. The inherited reference files and cross-check results are preserved in the transfer source; this release does not claim new OEM verification, complete CEC listing validity, UL recognition or deduplication.

## 5. Electrical, tracker, finance, BESS and thermal validation boundaries

- **Electrical/DC:** verified separate-string and common-feeder routing I²R scaling using explicit resistance; temperature corrected ampacity remains an installation-dependent NEC 690.8 *pre-screen*, not an approved conductor or OCPD design. MV coordination, arc-flash, equipment interrupting duties and actual protective settings were not independently engineered in this release.
- **PV:** single-diode I–V numerical constraints and the empirical PVWatts inverter loss balance exercised with synthetic data; no OEM module fitting, irradiance/weather provenance, bankable annual AC/POI energy agreement, spatial shade or ground bifacial irradiance validation performed here.
- **Trackers:** checked day/night handling, bounded row-shade fractions, geometric rotation limits; did not run independent pvlib tracking/shaded_fraction1d against actual site terrain and met data.
- **BESS:** hourly AC-bus PV-surplus self-consumption dispatch conserved AC energy and SOC; the model is **not** a true POI/PPC closed-loop export-controller validation, reactive-power control, grid import/charge schedule or battery-certified PCS dispatch.
- **P50/P90 and finance:** independently recomputed normal quantile + PSD-checked covariance and nominal pre-tax NPV/LCOE; no debt, tax equity, warranty degradation stochasticity or finance bankability claim.
- **Thermal:** evaluated existing default installation, rejected absent current-sharing verification and nonnumeric soil inputs; did not demonstrate IEC 60287/60853 project-specific certification, layered soils, proximity, overload sequence or feeder short-circuit thermal withstand.

## 6. Independent model/tool and browser availability — precise limitations

The sandbox has the scientific Python stack and Node.js but **does not have the `pvlib`, `PySAM` or SSC engines installed**. The transfer includes cached pvlib 0.16.1 reference-source excerpts. Those do **not** constitute execution of the official `pvlib` package. Therefore **no executed pvlib-to-platform or SSC/PySAM-to-platform annual-yield comparison is claimed**. The separate Python numerical oracle is independent mathematics, not those external simulators.

Chromium's navigation to public/local URLs in this execution environment was rejected as `net::ERR_BLOCKED_BY_ADMINISTRATOR`; static DOM/CSS rendering via `page.set_content` succeeded. **Public live browser UI/JS interaction, external network weather APIs and actual full integrated module acceptance were NOT verified.** Source read-back and Wix deployment verification are valid independently of the browser limit.

The source is an improved, versioned research engineering platform, **not** a fully manufacturer-validated, construction-issued, bankable or certified design application. No unsupported safety-critical equipment ratings were invented.

## 7. Recovery and use of deliverables

- `Solar_PV_Engineering_Verified_Live_219_Assets_Source_2026-10-25.zip` is the current full recoverable **developer source snapshot**, including the updated source and its two on-site recovery files. Its included generated `wix.config.json` is not a Wix deployed asset; do **not** upload it blindly to the live site.
- `Solar_PV_Engineering_Original_PrePatch_218_Entry_Rollback_2026-10-25.zip` is the unchanged previous 218-entry source snapshot including generated configuration. **Do not deploy that whole archive over a newer site**; restore only the necessary backed-up source through an inventory-guarded patch.
- `Solar_PV_Engineering_Executable_QA_Evidence_2026-10-25.zip` holds the Node/independent Python test sources, numerical outputs, static browser report and the targeted catalogue audit exceptions.
- `Solar_PV_Engineering_Release_Hashes_2026-10-25.txt` gives full SHA-256 checksums for the three ZIP packages.
- Rerun commands on extracted test working folder when the expected `candidate/` folder is present: `node --experimental-default-type=module tests/regression.mjs <source-root> <result-output.json>` and `python tests/independent_python.py` (the latter assumes the documented `/mnt/data/solar_platform_working` working tree with fixture data; copy/mount accordingly).

**Acceptance summary:** Verified guarded publication and local source integrity; 107/107 JS assertions, 32/32 Python independent mathematical and source checks, 48/48 JS syntax parses; a narrow software fix was safely applied. Independent external pvlib/PySAM execution, site-specific manufacturer ratings and full live browser functional acceptance remain **unverified** and must not be represented as complete.
'''
report_path=O/'Solar_PV_Engineering_Guarded_Release_and_Engineering_QA_Report_2026-10-25.md'
report_path.write_text(report)
print(report_path,'bytes',report_path.stat().st_size)
