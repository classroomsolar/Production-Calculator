"""Independent Python numeric oracles, dataset identity, and deployment integrity QA.
Not a pvlib/PySAM run or a manufacturer verification.
"""
import json, hashlib, math, csv, re, statistics, collections, pathlib, zipfile, sys
from datetime import datetime, timedelta, timezone
import numpy as np
W=pathlib.Path('/mnt/data/solar_platform_working'); B=W/'baseline'; C=W/'candidate';R=W/'results'
js=json.loads((R/'fixtures_for_python.json').read_text())
asserts=0
checks=[]
def ck(ok,title,**kwargs):
 global asserts
 asserts+=1
 if not ok: raise AssertionError(f'{title}: {kwargs}')
 checks.append({'name':title,'pass':True,**kwargs})
def eq(actual,expected,title,tol=1e-6):
 ck(math.isfinite(actual) and math.isfinite(expected) and abs(actual-expected)<=tol,title,actual=actual,expected=expected,tolerance=tol)
# Independent BESS implementation with Python arithmetic and separate state transitions
v=js['bess']['config'];q=js['bess']['summary']; e=v['capacityKWh']*v['initialSocPct']/100
lo=v['capacityKWh']*v['minSocPct']/100;hi=v['capacityKWh']*v['maxSocPct']/100
s=collections.defaultdict(float)
for i in range(8760):
 pv=max(0, math.sin((i%24-6)*math.pi/12)*175)
 load=v['loadKW'];direct=min(pv,load);head=max(0,pv-direct);short=max(0,load-direct)
 chg=min(head,v['maxChargeKW'],max(0,(hi-e)/v['chargeEfficiency']))
 e+=chg*v['chargeEfficiency']
 discharge=min(short,v['maxDischargeKW'],max(0,(e-lo)*v['dischargeEfficiency']))
 e-=discharge/v['dischargeEfficiency']
 ex=min(v['exportCapKW'],head-chg)
 curtailed=head-chg-ex
 imp=short-discharge
 for key,value in [('pvBusEnergyKWh',pv),('onSiteLoadKWh',load),('pvDirectToLoadKWh',direct),('batteryChargeFromPVKWh',chg),('batteryDischargeToLoadKWh',discharge),('gridImportKWh',imp),('gridExportKWh',ex),('exportCurtailmentKWh',curtailed),('chargeConversionLossKWh',chg*(1-v['chargeEfficiency'])),('dischargeConversionLossKWh',discharge*(1/v['dischargeEfficiency']-1))]:s[key]+=value
 ck(lo-1e-7<=e<=hi+1e-7 and 0<=ex<=v['exportCapKW']+1e-7,'annual BESS hourly state constraints') if i in [0, 100, 1000, 4000, 8759] else None
for k in s: eq(s[k],q[k],'Independent Python dispatch '+k,1e-5)
eq(e,q['endStoredKWh'],'Independent BESS ending SOC',1e-6)
# Separate P50/P90 statistical calculation, using linear algebra and numpy covariance
p=js['pxx'];y=np.asarray(p['input']['years'],dtype=float);mean=float(np.mean(y));weather=float(np.std(y,ddof=1));u=mean*np.asarray([.04,.03,.02]);corr=np.array([[1,.25,-.1],[.25,1,.15],[-.1,.15,1]])
ck(np.linalg.eigvalsh(corr).min()>=-1e-12,'uncertainty correlation PSD eigenvalue')
sigma=float(np.sqrt(weather*weather+u@corr@u))
eq(sigma,p['sigma'],'Independent numpy covariance sigma')
eq(mean-1.2815515655446004*sigma,p['quantiles']['P90'],'Independent numpy P90')
# DCF independently calculated in numpy arrays
inp=js['finance']['input'];year=np.arange(1,inp['years']+1);discount=(1+.08)**year
energy=inp['year1KWh']*(1-.005)**(year-1);price=inp['ppaPerKWh']*1.02**(year-1)
om=(inp['omFixedPerYear']+inp['omVariablePerKWh']*energy)*1.02**(year-1)
npv=float(-inp['capex']+np.sum((energy*price-om)/discount))
lcoe=float((inp['capex']+np.sum(om/discount))/np.sum(energy/discount))
eq(npv,js['finance']['summary']['nominalNPV'],'Independent numpy finance NPV')
eq(lcoe,js['finance']['summary']['nominalLCOEPerKWh'],'Independent numpy finance LCOE',1e-12)
# Module catalogue unchanged, index data and exact duplicate identity counts
catalog=json.loads((B/'master_pv_modules.json').read_text());model=catalog['models'];ck(len(model)==26000 and catalog['total']==26000,'26000 catalogue records')
for fp in ['master_pv_modules.json','sam-cec-manufacturer-crosscheck-26000.csv','sam-cec-inverters-snapshot.csv','index.html','main.js']:
 h1=hashlib.sha256((B/fp).read_bytes()).hexdigest();h2=hashlib.sha256((C/fp).read_bytes()).hexdigest()
 ck(h1==h2,'Preserved baseline bytes '+fp,sha256=h1)
# 218-entry ZIP file-level equivalence, and provider archive has 218 entries
orig=pathlib.Path('/mnt/data/Solar_PV_Engineering_Current_217_Assets_Full_Source_2026-10-25.zip')
with zipfile.ZipFile(orig) as z:
 names=[n for n in z.namelist() if not n.endswith('/')]
 ck(len(names)==218,'Source archive ZIP entries = 218',count=len(names))
 mismatch=[]
 for n in names:
  actual=(B/n).read_bytes();expected=z.read(n)
  if actual!=expected:mismatch.append(n)
 ck(not mismatch,'Source archive extracted bytes match',mismatch=mismatch)
# no altered static files except intended source
changed=[]
for file in B.rglob('*'):
 if file.is_file():
  path=file.relative_to(B);other=C/path
  if not other.exists() or file.read_bytes()!=other.read_bytes():changed.append(str(path))
ck(changed==['pv-reference-kernel.js'],'Only intended active source changed',changed=changed)
# Dataset audit inherited report is traceable; verify classifications by CSV reading not claim OEM approval
summary=json.loads((W/'transfer/03_ENGINEERING_CATALOG_AUDIT/SUMMARY.json').read_text())
ck(sum(summary['categories'].values())==26000,'Catalog audit categories exhaust 26000 records',categories=summary['categories'])
with (W/'transfer/03_ENGINEERING_CATALOG_AUDIT/ALL_26000_ROWS.csv').open(newline='') as f:
 reader=csv.DictReader(f);total=sum(1 for _ in reader)
ck(total==26000,'Audited per-record cross-check CSV has 26000 lines')
# exact catalogue intrinsic duplicated names, without silently deduplicating or claiming manufacturer-verified duplicates
head=model[0];keys=list(head)
print('model keys:',keys[:16])
r={'status':'PASS','pythonChecks':asserts,'oracles':{'dispatch_annual':'PASS','pxx_covariance':'PASS','npv_and_lcoe':'PASS','catalog_integrity':'PASS','source_archive_byte_comparison':'PASS'},'catalog':{'models':len(model),'audit_categories':summary['categories'],'catalog_sha256':hashlib.sha256((B/'master_pv_modules.json').read_bytes()).hexdigest(),'model_fields':keys},'changed_paths':changed,'checks':checks}
(R/'independent_python_qa.json').write_text(json.dumps(r,indent=2))
print(json.dumps({k:r[k] for k in ['status','pythonChecks','oracles','changed_paths']},indent=2))
