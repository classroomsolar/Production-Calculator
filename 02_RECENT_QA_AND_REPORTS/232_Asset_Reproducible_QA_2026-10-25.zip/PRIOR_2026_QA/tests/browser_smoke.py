import subprocess,time,json,collections,os
from playwright.sync_api import sync_playwright
root='/mnt/data/solar_platform_working/baseline'
server=subprocess.Popen(['python','-m','http.server','8765','--bind','127.0.0.1','--directory',root],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
try:
 time.sleep(0.8)
 with sync_playwright() as p:
  browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
  page=browser.new_page(viewport={'width':1440,'height':850})
  errors=[];fails=[]
  page.on('pageerror',lambda e:errors.append(str(e)))
  page.on('requestfailed',lambda r:fails.append({'url':r.url,'failure':r.failure}))
  page.goto('http://127.0.0.1:8765',wait_until='domcontentloaded',timeout=20000)
  page.wait_for_timeout(2200)
  title=page.title();tabs=page.locator('button').all_text_contents();sections=page.locator('section').count()
  interactive=[]
  for b in page.locator('.pv15-tabs button').all():
   try:
    txt=b.inner_text(timeout=1000).strip()
    b.click(timeout=3000)
    visible=[s.get_attribute('id') for s in page.locator('section:visible').all() if (s.get_attribute('id') or '').startswith(('pv','finance','bess','tracker','thermal','bifacial','cec','pxx'))]
    interactive.append({'tab':txt,'visible':visible[-5:]})
   except Exception as e:interactive.append({'tab':'FAILED', 'error':str(e)[:140]})
  page.screenshot(path='/mnt/data/solar_platform_working/results/baseline_homepage.png',full_page=False)
  result={'title':title,'sectionCount':sections,'buttonCount':len(tabs),'tabsTested':interactive,'jsErrors':errors,'failedRequests':fails[:20],'inputCount':page.locator('input').count()}
  print(json.dumps(result,indent=2))
  open('/mnt/data/solar_platform_working/results/browser_baseline.json','w').write(json.dumps(result,indent=2))
  browser.close()
finally:server.terminate();server.wait()
