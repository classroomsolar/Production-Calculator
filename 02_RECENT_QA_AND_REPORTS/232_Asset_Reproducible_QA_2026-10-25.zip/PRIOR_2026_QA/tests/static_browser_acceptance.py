"""DOM and CSS render smoke with browser set_content; DOES NOT execute application modules or remote APIs."""
import pathlib, json, re, os
from bs4 import BeautifulSoup
from playwright.sync_api import sync_playwright
W=pathlib.Path('/mnt/data/solar_platform_working');root=W/'candidate';index=(root/'index.html').read_text()
soup=BeautifulSoup(index,'html.parser');scripts=[];css=[];missing=[]
for t in soup.select('script[src]'):
 src=t.get('src','')
 if src.startswith('https:'):continue
 scripts.append(src)
 if not (root/src).exists(): missing.append(src)
for t in soup.select('link[rel=stylesheet]'):
 href=t.get('href','')
 css.append(href)
 if not (root/href).exists():missing.append(href)
for t in soup.select('script'):
 if t.has_attr('src'):t.decompose()
for t in soup.select('link[rel=stylesheet]'):
 href=t.get('href');f=root/href
 if f.exists():
  st=soup.new_tag('style');st.string=f.read_text();t.replace_with(st)
html=str(soup)
result={'scope':'STATIC DOM/CSS only: main JavaScript modules, network fetch, live Wix browser NOT exercised','scriptsFound':len(scripts),'stylesheetsFound':len(css),'missingReferences':missing,'viewports':{},'formControls':len(soup.select('input,select,button'))}
with sync_playwright() as p:
 br=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 for width,height in [(1440,900),(390,844)]:
  pg=br.new_page(viewport={'width':width,'height':height})
  pg.set_content(html,wait_until='domcontentloaded')
  st=pg.evaluate('''() => ({scrollWidth:document.documentElement.scrollWidth,clientWidth:document.documentElement.clientWidth, h1:document.querySelector('h1')?.innerText,controls:document.querySelectorAll('button,input,select').length,sections:document.querySelectorAll('section').length,title:document.title})''')
  st['horizontalOverflow']=st['scrollWidth']>st['clientWidth']+1
  result['viewports'][str(width)]=st
  pg.screenshot(path=str(W/'results'/f'static_render_{width}.png'),full_page=True)
  pg.close()
 br.close()
(W/'results'/'static_browser.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2));assert not missing
