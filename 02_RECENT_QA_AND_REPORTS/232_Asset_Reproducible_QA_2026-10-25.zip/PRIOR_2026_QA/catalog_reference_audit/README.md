# Full 26,000-Record PV Catalogue Read-Only Audit

Reference SAM official pinned Git blob `5f931df381c77633463c68eb7647a5e9bae30588` at `NatLabRockies/SAM/deploy/libraries/CEC Modules.csv`. This is a historical SAM/CEC library and not an OEM source-approval list.

Wix snapshot hash: `d815185d764fe71597ede57801083a44ca77e79cb97c47a95c5568b77d6956d9`. Source data never modified.

Results:
- **AMBIGUOUS_REFERENCE_IDENTITY**: 12
- **EXACT_FIVE_FIELD_STC_MATCH_0.01**: 8,202
- **LARGE_STC_DISCREPANCY_GT_2_PERCENT**: 58
- **NO_EXACT_REFERENCE_IDENTITY**: 17,492
- **STC_DIFFERENCE_LE_2_PERCENT**: 236

**Limitations:** strict maker+model string matching excludes naming variants. Distinct revisions may have different STC. Mathematical STC agreement does not authenticate manufacturer coefficients, system voltage/current limits, UL/IEC certifications, or site-specific designs. No row approved automatically.
