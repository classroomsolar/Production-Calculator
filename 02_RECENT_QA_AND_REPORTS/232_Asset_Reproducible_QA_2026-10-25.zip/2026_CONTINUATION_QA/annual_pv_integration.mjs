import fs from 'node:fs';
import {simulateDetailedHourly} from './current/pv-detailed-v17.js';
const config={
 module:{ILrefA:9.02,I0refA:1.4e-10,RsRefOhm:.33,RshRefOhm:760,aRefV:1.65,alphaIscAperC:.0043,EgRefEv:1.121,dEgdTPerK:-.0002677},
 array:{modulesPerString:18,stringsPerMppt:2,mpptsPerInverter:2,inverterCount:1,minCellDesignC:-10,maxCellDesignC:75},
 inverter:{pacKW:15,etaNom:.96,mpptMinV:250,mpptMaxV:850,maxDCV:1000,maxOperatingCurrentPerMpptA:35,maxShortCircuitCurrentPerMpptA:45},
 losses:{soilingPct:2,iamPct:1,linearShadePct:0,mismatchPct:1,availabilityLossPct:1,exportCapKW:12},
 thermal:{u0:25,u1:6.84},
 dcCable:{oneWayM:30,crossSectionMm2:6,tempC:45,material:'copper'},
 acCable:{oneWayM:40,crossSectionMm2:16,tempC:55,material:'copper',voltageLL:400,powerFactor:1},
 transformer:{ratedKVA:25,noLoadKW:.04,loadLossRatedKW:.25,energization:'always'},
 sourceStatus:'SYNTHETIC_TEST_NOT_MANUFACTURER_DATA'};
const year=2025,yearStart=Date.UTC(year,0,1),hours=Array.from({length:8760},(_,i)=>{
 const h=i%24,day=i/24,daySeason=.7+.3*Math.sin(2*Math.PI*(day-81)/365);
 const poa=Math.max(0,Math.sin(Math.PI*(h-6)/12))*900*daySeason;
 return {timestamp_utc:new Date(yearStart+i*3600000).toISOString(),poa_wm2:poa,temp_air_c:19+9*Math.sin(2*Math.PI*(day-81)/365)+4*Math.sin(2*Math.PI*(h-8)/24),wind_speed_mps:2+Math.max(0,Math.cos(2*Math.PI*h/24))};
});
const result=simulateDetailedHourly(hours,config);
const sample=result.hourly.map((h,i)=>({timestamp_utc:h.timestamp_utc,poa_wm2:hours[i].poa_wm2,module_vmp_v:h.module_vmp_v,module_imp_a:h.module_imp_a,module_dc_kw:h.module_dc_kw,mismatch_loss_kw:h.mismatch_loss_kw,dc_cable_loss_kw:h.dc_cable_loss_kw,inverter_dc_kw:h.inverter_dc_kw,ac_inverter_kw:h.ac_inverter_kw,ac_cable_loss_kw:h.ac_cable_loss_kw,transformer_loss_kw:h.transformer_loss_kw,poi_export_kw:h.poi_export_kw,grid_import_kw:h.grid_import_kw}));
const report={input:config,annual:result.annual,lossStages:result.lossStages,monthly:result.monthly,hourly:sample};
fs.writeFileSync('/mnt/data/solar_platform_next/annual_pv_accounting_cases.json',JSON.stringify(report));
console.log(JSON.stringify({hours:result.hourCount,stcKW:result.stc.stcKW,annualExportKWh:result.annual.poiExportKWh,annualImportKWh:result.annual.gridImportKWh,clippingKWh:result.lossStages.inverterClippingKWh,source:'synthetic',status:'PASS'}));
