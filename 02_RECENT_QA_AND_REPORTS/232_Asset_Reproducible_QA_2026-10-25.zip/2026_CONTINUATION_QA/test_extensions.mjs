import assert from 'node:assert/strict';
import {screenThreePhasePoi as grid} from './current/grid-poi-screen.js';
import {simulateDispatch} from './current/bess-dispatch.js';
import fs from 'node:fs';
let checks=0;const check=(flag,msg)=>{assert.ok(flag,msg);checks++};
const near=(a,b,tol=1e-8)=>check(Math.abs(a-b)<tol,`Expected ${a}≈${b}`);
const cases=[];let seed=20261025;const rnd=()=>((seed=(Math.imul(seed,1664525)+1013904223)>>>0)/4294967296);
const cfg={pvGenerationKW:5000,siteLoadKW:0,bessNetKW:0,netReactiveKvar:0,pvBranchReactiveKvar:0,poiVoltageLLV:12470,pvBranchVoltageLLV:12470,poiSwitchContinuousA:400,poiConductorContinuousA:400,poiTransformerKVA:7500,exportAgreementCapKW:5000,importAgreementCapKW:5000,pvBranchConductorContinuousA:400,pvBranchBreakerContinuousA:400};
let r=grid(cfg);check(r.passForSpecifiedSnapshot,'5MW export and 7.5MVA transformer');near(r.results.netApparentKVA,5000);near(r.results.poiCurrentA,5000e3/(Math.sqrt(3)*12470));
r=grid({...cfg,pvGenerationKW:2000,siteLoadKW:10000});check(!r.checks.importAgreementCapMet,'import cap independent of export cap');check(!r.checks.poiTransformerWithinProvidedKVA,'transformer can overload on import');check(r.results.poiImportKW===8000,'import 8MW');check(r.checks.exportAgreementCapMet,'export cap holds while import exceeds');
r=grid({...cfg,pvGenerationKW:6500,siteLoadKW:1500,netReactiveKvar:4500});check(r.checks.exportAgreementCapMet,'P export exactly 5MW');check(!r.checks.poiTransformerWithinProvidedKVA===false||Number.isFinite(r.results.poiCurrentA),'reactive draws current');near(r.results.netApparentKVA,Math.hypot(5000,4500));
r=grid({...cfg,pvGenerationKW:5500,siteLoadKW:0});check(!r.checks.exportAgreementCapMet,'needs export reduction');near(r.results.requiredRealPowerExportReductionKW,500);
r=grid({...cfg,pvGenerationKW:6500,siteLoadKW:2000,pvBranchConductorContinuousA:150});check(!r.checks.pvBranchConductorWithinProvidedContinuousRating,'PV branch not limited by coincident site load');
const lv=grid({...cfg,pvBranchVoltageLLV:480});check(lv.results.pvBranchCurrentA>grid(cfg).results.pvBranchCurrentA*20,'separate LV branch voltage drives higher current');
for(const c of [{...cfg,poiVoltageLLV:0},{...cfg,pvGenerationKW:-1},{...cfg,poiSwitchContinuousA:NaN},{...cfg,poiConductorContinuousA:0}]){assert.throws(()=>grid(c));checks++}
for(let j=0;j<10000;j++){
 const pv=rnd()*30000,load=rnd()*30000,q=(rnd()-.5)*20000,b=(rnd()-.5)*15000,v=400+rnd()*34000;
 const c={...cfg,pvGenerationKW:pv,siteLoadKW:load,bessNetKW:b,netReactiveKvar:q,poiVoltageLLV:v};
 const o=grid(c).results,refP=pv+b-load,refS=Math.sqrt(refP**2+q**2);
 if(j<100)cases.push({input:c,poIResult:{netRealPowerKW:o.netRealPowerKW,netApparentKVA:o.netApparentKVA,poiCurrentA:o.poiCurrentA}});
 near(o.netRealPowerKW,refP,1e-8);near(o.netApparentKVA,refS,1e-8);near(o.poiCurrentA,refS*1000/Math.sqrt(3)/v,1e-8);
}
const annual=(year,fn)=>{const t=Date.parse(`${year}-01-01T00:00:00Z`),n=year===2024?8784:8760;return Array.from({length:n},(_,i)=>({timestamp_utc:new Date(t+i*3600000).toISOString(),ac_inverter_kw:fn(i)}))};
const bc={capacityKWh:100,loadKW:15,maxChargeKW:25,maxDischargeKW:25,chargeEfficiency:.94,dischargeEfficiency:.94,minSocPct:10,maxSocPct:90,initialSocPct:50,exportCapKW:30};
for(const y of [2025,2024]){
 const rows=annual(y,i=>i%24>=7&&i%24<18?40:0);
 const profile=Array.from({length:24},(_,h)=>h>=6&&h<20?20:4);
 const d=simulateDispatch(rows,{...bc,loadProfile24KW:profile,gridImportCapKW:50});
 near(d.summary.onSiteLoadKWh,rows.length/24*profile.reduce((a,b)=>a+b,0),1e-7);
 check(d.hourly.every(h=>h.load_kw===profile[new Date(h.timestamp_utc).getUTCHours()]),'UTC hourly load exactly matches profile');
 check(d.hourly.every(h=>h.grid_import_ac_bus_kw<=50),'grid import cap observed');
 check(d.summary.peakGridImportKW>0&&d.summary.peakLoadKW===20,'peak load summary');
 const original=simulateDispatch(rows,bc),same=simulateDispatch(rows,{...bc,gridImportCapKW:1e6});near(original.summary.gridImportKWh,same.summary.gridImportKWh,1e-7);near(original.summary.gridExportKWh,same.summary.gridExportKWh,1e-7);
 assert.throws(()=>simulateDispatch(rows,{...bc,gridImportCapKW:0}),/Grid import exceeds/);checks++;
 for(const invalid of [[2,3],Array.from({length:24},()=>-1)]){assert.throws(()=>simulateDispatch(rows,{...bc,loadProfile24KW:invalid}),/loadProfile24KW/);checks++}
}
fs.writeFileSync('/mnt/data/solar_platform_next/poi_independent_cases.json',JSON.stringify(cases));
console.log(JSON.stringify({checks,poiVectors:10000,caseExamples:5,annualBessYears:2,status:'PASS'}));
