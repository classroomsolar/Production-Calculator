"""Independent 8760 h stage conservation oracle for existing experimental PV engine.
This verifies arithmetic and accounting, NOT independent pvlib/PySAM yield equivalence.
"""
import json,math,pathlib
path=pathlib.Path('/mnt/data/solar_platform_next')
a=json.loads((path/'annual_pv_accounting_cases.json').read_text());c=a['input'];hours=a['hourly']; assert len(hours)==8760
n=c['array']['modulesPerString']*c['array']['stringsPerMppt']*c['array']['mpptsPerInverter']*c['array']['inverterCount']
nstrings=c['array']['stringsPerMppt']*c['array']['mpptsPerInverter']*c['array']['inverterCount']
cu=.017241
Rdc=cu*2*c['dcCable']['oneWayM']/c['dcCable']['crossSectionMm2']*(1+.00393*(c['dcCable']['tempC']-20))
Rac=cu*c['acCable']['oneWayM']/c['acCable']['crossSectionMm2']*(1+.00393*(c['acCable']['tempC']-20))
failures=[];maximum={'module':0,'mismatch':0,'dcOhm':0,'dcInverter':0,'inverterAc':0,'acOhm':0,'transformer':0,'poi':0,'gridImport':0}
annual_export=annual_import=0
for h in hours:
 v,i=h['module_vmp_v'],h['module_imp_a'];md=n*v*i/1000
 mismatch=md*c['losses']['mismatchPct']/100
 dcOhm=min(md,nstrings*i*i*Rdc/1000)
 inverterIn=md-mismatch-dcOhm
 z=inverterIn/(c['inverter']['pacKW']/c['inverter']['etaNom'])
 if z<=0:ac=0
 else:
  eta=c['inverter']['etaNom']/.9637*(-.0162*z-.0059/z+.9858)
  ac=min(c['inverter']['pacKW'],inverterIn*max(0,min(1,eta)))
 I=1000*ac/(math.sqrt(3)*c['acCable']['voltageLL']*c['acCable']['powerFactor'])
 acOhm=min(ac,3*I*I*Rac/1000)
 afterAc=ac-acOhm
 xf=c['transformer']['loadLossRatedKW']*(afterAc/(c['transformer']['ratedKVA']*c['acCable']['powerFactor']))**2+c['transformer']['noLoadKW']
 preAvail=afterAc-xf;afterAvail=preAvail*(1-c['losses']['availabilityLossPct']/100) if preAvail>0 else preAvail
 exp=max(0,min(afterAvail,c['losses']['exportCapKW']))
 imp=max(0,-afterAvail)
 measured=[md,mismatch,dcOhm,inverterIn,ac,acOhm,xf,exp,imp]
 expected=[h['module_dc_kw'],h['mismatch_loss_kw'],h['dc_cable_loss_kw'],h['inverter_dc_kw'],h['ac_inverter_kw'],h['ac_cable_loss_kw'],h['transformer_loss_kw'],h['poi_export_kw'],h['grid_import_kw']]
 for key,m,e in zip(maximum,measured,expected):
  d=abs(m-e); maximum[key]=max(maximum[key],d)
  if d>1e-7*max(1,abs(m)):failures.append((h['timestamp_utc'],key,d))
 annual_export+=exp;annual_import+=imp
assert not failures,failures[:3]
assert abs(a['annual']['poiExportKWh']-annual_export)<1e-6
assert abs(a['annual']['gridImportKWh']-annual_import)<1e-6
out={'scope':'Independent Python accounting of 8760 modeled synthetic PV hours: module power, mismatch, two-conductor DC ohmic, PVWatts, AC three-phase ohmic, transformer fixed and load loss, availability, POI export/import','hourlyChecks':8760*9,'hourCount':8760,'annualExportKWh':annual_export,'annualImportKWh':annual_import,'maximumStageAbsoluteErrorKW':maximum,'passed':True,'data':'Synthetic coefficient and weather scenario, NOT production source, pvlib ModelChain, SAM or PySAM output'}
(path/'annual_pv_python_validation.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
