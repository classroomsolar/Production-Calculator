from pathlib import Path
from bs4 import BeautifulSoup
from playwright.sync_api import sync_playwright
import re,base64,json,datetime
root=Path('/mnt/data/solar_platform_next/current');seen={};checks=[];errors=[]
catalog=json.loads((root/'master_pv_modules.json').read_text());catalogSample=[m for m in catalog['models'] if m.get('model','').strip().upper() in {'GCL-M3/72DH370','Q.PEAK DUO ML-G-10.A'}];assert len(catalogSample)==6
def bundle(path):
 p=(root/path).resolve()
 if not p.is_relative_to(root.resolve()):raise ValueError(path)
 if p in seen:return seen[p]
 code=p.read_text()
 def change(m):
  f=m.group(2)
  if not f.startswith('.'):return m.group(0)
  fp=(p.parent/f).resolve();child=bundle(str(fp.relative_to(root.resolve())))
  return m.group(1)+'data:text/javascript;base64,'+base64.b64encode(child.encode()).decode()+m.group(3)
 code=re.sub(r'''(\bfrom\s*['"])([^'"]+)(['"])''',change,code)
 seen[p]=code;return code
soup=BeautifulSoup((root/'index.html').read_text(),'html.parser')
for t in soup.select('script[src]'):
 src=t.get('src');
 if src.startswith('http'):t.decompose();continue
 t.attrs.pop('src');t.string='\n'+bundle(src)
for t in soup.select('link[rel=stylesheet]'):
 p=root/t.get('href')
 if p.exists():
  st=soup.new_tag('style');st.string=p.read_text();t.replace_with(st)
html=str(soup)
def ck(flag,label):
 checks.append({'label':label,'pass':bool(flag)})
 if not flag:errors.append(label)
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 for vw in (1440,390):
  page=b.new_page(viewport={'width':vw,'height':900})
  pageErrors=[];page.on('pageerror',lambda ex:pageErrors.append(str(ex)))
  page.set_content(html,wait_until='load',timeout=45000);page.wait_for_timeout(300)
  ck(page.locator('button').count()>=70, f'{vw}: full JavaScript module integration rendered buttons')
  ck(page.evaluate('()=> typeof window.SolarPV17State === "function" && typeof window.SolarPxxB5Sheets === "function"'),f'{vw}: integrated PV and uncertainty modules bootstrapped')
  ck(page.evaluate('()=> document.documentElement.scrollWidth<=document.documentElement.clientWidth+1'),f'{vw}: no horizontal document overflow')
  # Actual 26,000-record source sample: group electrically identical listings,
  # while preserving four different-power entries sharing a model-family label.
  page.evaluate('''(models)=>{window.fetch=async()=>({ok:true,json:async()=>({models})})}''',catalogSample)
  page.locator('#moduleSearch').evaluate('''x=>{x.value='GCL-M3/72DH370';x.dispatchEvent(new Event('input',{bubbles:true}))}''')
  page.wait_for_timeout(200)
  ck(page.locator('#moduleMatches button').count()==1,f'{vw}: identical equipment records grouped in searchable catalogue')
  ck('2 identical source records' in page.locator('#moduleMatches button').first.inner_text(),f'{vw}: duplicate count shown, not silently deleted')
  page.locator('#moduleSearch').evaluate('''x=>{x.value='Q.PEAK DUO ML-G-10.A';x.dispatchEvent(new Event('input',{bubbles:true}))}''')
  page.wait_for_timeout(200)
  ck(page.locator('#moduleMatches button').count()==4,f'{vw}: different manufacturer ratings remain separate')
  ck('rating variants' in page.locator('#moduleMatches button').first.inner_text(),f'{vw}: ambiguous model rating warned before selection')
  # calculate 12-year synthetic P90 UI
  page.locator('#pxxRun').evaluate('(el)=>el.click()')
  ck(page.locator('#pxxStatus').inner_text().startswith('STATISTICAL SCREEN'),f'{vw}: P50/P90 interactive calculation completed')
  ck(not page.locator('#pxxDownload').is_disabled(),f'{vw}: P50/P90 result export becomes available')
  # engineering DC circuit screen with example inputs
  page.locator('#elB4_run').evaluate('(el)=>el.click()')
  ck(page.locator('#elB4_status').inner_text().startswith('PRELIMINARY DC'),f'{vw}: DC ampacity computation completed')
  ck(not page.locator('#elB4_json').is_disabled(),f'{vw}: DC audit export enabled')
  # Bidirectional POI at independent PV branch/POI voltage rating.
  page.locator('#gridPoi_run').evaluate('(el)=>el.click()')
  ck(page.locator('#gridPoi_status').inner_text().startswith('ALL SPECIFIED'),f'{vw}: three-phase POI current screen runs')
  ck(not page.locator('#gridPoi_download').is_disabled(),f'{vw}: POI audit JSON enabled only after valid calculation')
  ck(page.evaluate('()=>window.SolarGridPoiSheets().length===1'),f'{vw}: POI audit included in integrated Excel workbook')
  page.locator('#gridPoi_siteLoadKW').evaluate('(e,v)=>{e.value=v;e.dispatchEvent(new Event(\"input\",{bubbles:true}))}', '10000')
  page.locator('#gridPoi_importAgreementCapKW').evaluate('(e,v)=>{e.value=v;e.dispatchEvent(new Event(\"input\",{bubbles:true}))}', '1000')
  page.locator('#gridPoi_run').evaluate('(el)=>el.click()')
  ck('importAgreementCapMet' in page.locator('#gridPoi_status').inner_text(),f'{vw}: import 5MW fails independent 1MW input agreement')
  page.locator('#gridPoi_siteLoadKW').evaluate('(e,v)=>{e.value=v;e.dispatchEvent(new Event(\"input\",{bubbles:true}))}', '2000')
  page.locator('#gridPoi_importAgreementCapKW').evaluate('(e,v)=>{e.value=v;e.dispatchEvent(new Event(\"input\",{bubbles:true}))}', '')
  page.locator('#gridPoi_netReactiveKvar').evaluate('(e,v)=>{e.value=v;e.dispatchEvent(new Event(\"input\",{bubbles:true}))}', '8000')
  page.locator('#gridPoi_run').evaluate('(el)=>el.click()')
  ck('poiTransformerWithinProvidedKVA' in page.locator('#gridPoi_status').inner_text(),f'{vw}: 3MW export plus kvar exceeds 7.5 MVA transformer')
  page.locator('#gridPoi_netReactiveKvar').evaluate('(e,v)=>{e.value=v;e.dispatchEvent(new Event(\"input\",{bubbles:true}))}', '0')
  ck(page.locator('#gridPoi_download').is_disabled(),f'{vw}: POI audit export invalidated on input edit')
  # Set source stand-in: valid annual hourly AC bus stream, test only
  page.evaluate('''()=>{
    const base=Date.parse('2025-01-01T00:00:00Z');
    const hourly=Array.from({length:8760},(_,i)=>({timestamp_utc:new Date(base+i*3600000).toISOString(),ac_inverter_kw:(i%24)>=7&&(i%24)<17?15:0}));
    window.__mockPV={result:{hourly,annual:{poiExportKWh:30000}},upstream:{id:1}};
    window.SolarPV17State=()=>window.__mockPV;
  }''')
  page.locator('#bessB4_run').evaluate('(el)=>el.click()')
  ck(page.locator('#bessB4_status').inner_text().startswith('SIMULATED'),f'{vw}: complete 8760h BESS browser calculation')
  ck(not page.locator('#bessB4_csv').is_disabled(),f'{vw}: BESS CSV downloadable only after success')
  ck(page.evaluate('()=>window.SolarBessB4Sheets().length===2'),f'{vw}: BESS included in integrated report when fresh')
  # Zero-import demand profile which exactly follows synthetic daylight PV.
  profile=[10 if 7<=h<17 else 0 for h in range(24)]
  page.locator('#bessB4_profile24').evaluate('(e,v)=>{e.value=v;e.dispatchEvent(new Event("input",{bubbles:true}))}', ','.join(map(str,profile)))
  page.locator('#bessB4_importCap').evaluate('(e,v)=>{e.value=v;e.dispatchEvent(new Event(\"input\",{bubbles:true}))}', '0')
  page.locator('#bessB4_run').evaluate('(el)=>el.click()')
  ck(page.locator('#bessB4_status').inner_text().startswith('SIMULATED'),f'{vw}: 24h UTC demand profile meets zero import restriction')
  page.locator('#bessB4_profile24').evaluate('(e,v)=>{e.value=v;e.dispatchEvent(new Event("input",{bubbles:true}))}', ','.join(['10']*24))
  page.locator('#bessB4_run').evaluate('(el)=>el.click()')
  ck('import cap' in page.locator('#bessB4_status').inner_text().lower(),f'{vw}: infeasible no-import battery dispatch rejected')
  ck(page.locator('#bessB4_csv').is_disabled(),f'{vw}: no stale BESS export after infeasible cap')
  page.locator('#bessB4_profile24').evaluate('(e,v)=>{e.value=v;e.dispatchEvent(new Event(\"input\",{bubbles:true}))}', '')
  page.locator('#bessB4_importCap').evaluate('(e,v)=>{e.value=v;e.dispatchEvent(new Event(\"input\",{bubbles:true}))}', '')
  page.locator('#bessB4_run').evaluate('(el)=>el.click()')

  # upstream source changes: one UI event should invalidate old results
  page.locator('#pv17_module_ILrefA').evaluate('(x)=>x.dispatchEvent(new Event("input", {bubbles:true}))')
  ck(page.locator('#bessB4_csv').is_disabled(),f'{vw}: BESS export invalidated on PV configuration edits')
  ck(page.evaluate('()=>window.SolarBessB4Sheets().length===0'),f'{vw}: BESS stale results excluded from Excel exports')
  # Finance imports the current v1.7 result and must invalidate that evidence
  page.locator('#finB5-load').evaluate('(el)=>el.click()')
  ck(page.locator('#finB5-year1KWh').input_value()=='30000',f'{vw}: finance imports 30000 kWh synthetic case')
  page.locator('#finB5-run').evaluate('(el)=>el.click()')
  ck(not page.locator('#finB5-json').is_disabled(),f'{vw}: finance audit eligible on unchanged source')
  ck(page.evaluate('()=>window.SolarFinanceB5Sheets().length===2'),f'{vw}: finance included in report when fresh')
  page.locator('#pv17_module_ILrefA').evaluate('(x)=>x.dispatchEvent(new Event("input",{bubbles:true}))')
  ck(page.locator('#finB5-year1KWh').input_value()=='',f'{vw}: stale imported energy removed from finance')
  ck(page.locator('#finB5-json').is_disabled(),f'{vw}: finance JSON disabled on upstream PV edit')
  ck(page.evaluate('()=>window.SolarFinanceB5Sheets().length===0'),f'{vw}: stale finance excluded from combined Excel')
  # A source identity change without input event must still block export/report
  page.locator('#bessB4_run').evaluate('(el)=>el.click()')
  page.locator('#finB5-load').evaluate('(el)=>el.click()')
  page.locator('#finB5-run').evaluate('(el)=>el.click()')
  page.evaluate('()=>{window.__mockPV={...window.__mockPV,result:{...window.__mockPV.result}}}')
  ck(page.evaluate('()=>window.SolarBessB4Sheets().length===0'),f'{vw}: BESS source fingerprint checked on report extraction')
  ck(page.evaluate('()=>window.SolarFinanceB5Sheets().length===0'),f'{vw}: finance source fingerprint checked on report extraction')
  ck(len(pageErrors)==0,f'{vw}: zero browser JavaScript exceptions')
  if pageErrors:errors.extend([f'{vw}: {x}' for x in pageErrors])
  # one screenshot for evidence only
  if vw==390:page.screenshot(path='/mnt/data/solar_platform_next/mobile_integrated.png',full_page=True)
  page.close()
 b.close()
out={'date_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Chromium executed full application ES module set from exact packaged source, through embedded data-URL imports; no public network call or live-site test','checks':len(checks),'passed':sum(x['pass'] for x in checks),'failed':len(errors),'details':checks,'errors':errors}
Path('/mnt/data/solar_platform_next/ui_extended_results.json').write_text(json.dumps(out,indent=2))
print(json.dumps({'checks':len(checks),'passed':out['passed'],'failed':out['failed'],'errors':errors},indent=2))
if errors:raise SystemExit(1)
