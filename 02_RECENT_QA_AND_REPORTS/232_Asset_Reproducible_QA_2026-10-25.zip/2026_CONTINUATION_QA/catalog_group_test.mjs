import fs from 'node:fs';import assert from 'node:assert/strict';import {groupCatalogModels} from './current/catalog-display.js';
const all=JSON.parse(fs.readFileSync('./current/master_pv_modules.json','utf8'));
const grouped=groupCatalogModels(all.models,500);let checks=0;
function ck(condition,label){checks++;assert.ok(condition,label)}
ck(all.models.length===26000,'original full count');
ck(grouped.totalRaw===26000,'grouping preserves input count');
ck(grouped.totalDistinctElectricalListings===25989,'11 exact electrical repeats only');
const gcl=groupCatalogModels(all.models.filter(r=>String(r.model).trim().toUpperCase()==='GCL-M3/72DH370'),18);
ck(gcl.totalRaw===2,'two original GCL 370 source rows');
ck(gcl.totalDistinctElectricalListings===1,'GCL 370 identical electrical listings grouped');
ck(gcl.shown[0].identicalRecords===2,'duplicate source count shown');
ck(gcl.shown[0].ids.length===2,'both record IDs retained for investigation');
const q=groupCatalogModels(all.models.filter(r=>String(r.model).trim().toUpperCase()==='Q.PEAK DUO ML-G-10.A'),18);
ck(q.totalRaw===4,'four QCells record variants');
ck(q.totalDistinctElectricalListings===4,'different electrical ratings must NEVER be merged');
ck(q.shown.every(x=>x.modelNameHasDistinctRatings),'rating ambiguity flagged');
ck(q.shown.map(x=>x.record.w).sort((a,b)=>a-b).join(',')==='400,405,410,415','all four watt variants preserved');
ck(groupCatalogModels(all.models,18).shown.length===18,'display limit enforced AFTER grouping');
assert.throws(()=>groupCatalogModels(all.models,0),/Invalid/);checks++;
fs.writeFileSync('catalog_group_results.json',JSON.stringify({checks,passed:checks,fullRows:all.models.length,uniqueElectricalListings:grouped.totalDistinctElectricalListings,exactDuplicatedSourceRows:grouped.totalRaw-grouped.totalDistinctElectricalListings,collisionsPreserved:'Model-label collisions with different STC specifications remain separate.'},null,2));
console.log(`catalogue display check ${checks}/${checks}`)
