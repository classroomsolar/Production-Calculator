from pathlib import Path
from bs4 import BeautifulSoup
from playwright.sync_api import sync_playwright
import re,base64,json,io,csv
root=Path('/mnt/data/solar_validation_20261026/site')
seen={}
def bundle(path):
 p=(root/path).resolve()
 if p in seen:return seen[p]
 code=p.read_text()
 def change(m):
  f=m.group(2)
  if not f.startswith('.'):return m.group(0)
  fp=(p.parent/f).resolve();child=bundle(str(fp.relative_to(root.resolve())))
  return m.group(1)+'data:text/javascript;base64,'+base64.b64encode(child.encode()).decode()+m.group(3)
 code=re.sub(r'''(\bfrom\s*['"])([^'"]+)(['"])''',change,code)
 seen[p]=code;return code
soup=BeautifulSoup((root/'index.html').read_text(),'html.parser')
for t in soup.select('script[src]'):
 src=t.get('src');
 if src.startswith('http'):t.decompose();continue
 t.attrs.pop('src');t.string='\n'+bundle(src)
for t in soup.select('link[rel=stylesheet]'):
 p=root/t.get('href')
 if p.exists():
  st=soup.new_tag('style');st.string=p.read_text();t.replace_with(st)
html=str(soup)
catalog=json.loads((root/'master_pv_modules.json').read_text());catalog['models']=catalog['models'][:7];catalog['total']=7
checks=[];errs=[]
with sync_playwright() as pw:
 browser=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 for width in (1440,390):
  page=browser.new_page(viewport={'width':width,'height':900},accept_downloads=True)
  page.on('pageerror',lambda e:errs.append(str(e)))
  page.set_content(html,wait_until='load',timeout=45000);page.wait_for_timeout(600)
  page.evaluate('''(cat)=>{window.fetch=async(url)=>String(url).includes('master_pv_modules.json')?{ok:true,text:async()=>JSON.stringify(cat),json:async()=>cat}:{ok:false,status:404};}''',catalog)
  page.locator('button[data-catalog="quality"]').evaluate('(el)=>el.click()')
  page.locator('#catalogLoad').evaluate('(el)=>el.click()')
  page.wait_for_function("document.getElementById('catalogStatus').textContent.includes('7 records')",timeout=30000)
  checks.append(page.locator('#catalogExport').is_enabled())
  with page.expect_download(timeout=30000) as info:
   page.locator('#catalogExport').evaluate('(el)=>el.click()')
  download=info.value
  dest=f'/mnt/data/solar_validation_20261026/catalog_full_browser_{width}.csv';download.save_as(dest)
  rows=list(csv.reader(open(dest,encoding='utf-8')))
  checks.append(len(rows)==8)
  checks.append(len(rows[0])==20)
  checks.append(len({r[1] for r in rows[1:]})==7)
  checks.append(all(r[14]=='false' for r in rows[1:]))
  checks.append('7-row' in page.locator('#catalogStatus').inner_text())
  checks.append('26000' in download.suggested_filename)
  page.close()
 browser.close()
result={'checks':len(checks),'passed':sum(checks),'failures':len(checks)-sum(checks),'exceptions':errs,'saved_csvs':[f'/mnt/data/solar_validation_20261026/catalog_full_browser_{i}.csv' for i in (1440,390)]}
Path('/mnt/data/solar_validation_20261026/catalog_full_ui_results.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result))
if not all(checks) or errs:raise SystemExit(1)
