"""Independent scipy root and bounded MPP search over De Soto site JS results.
Synthetic fitted coefficients only, not a pvlib/PySAM annual cross-check.
"""
import json,math,random,subprocess,pathlib
from scipy.optimize import brentq,minimize_scalar
R=pathlib.Path('/mnt/data/solar_validation_20261026');site=R/'site'
random.seed(20261026)
ref={'ILrefA':9.02,'I0refA':1.4e-10,'RsRefOhm':.33,'RshRefOhm':760,'aRefV':1.65,'alphaIscAperC':.0043,'EgRefEv':1.121,'dEgdTPerK':-.0002677}
cases=[]
for n in range(280):
 irr=random.uniform(50,1500); t=random.uniform(-10,75)
 cases.append({'g':irr,'t':t})
(R/'diode_cases.json').write_text(json.dumps({'ref':ref,'cases':cases}))
js=R/'qa/diode_js_oracle.mjs'
js.write_text('''import fs from 'node:fs';import {deSotoDetailedPower} from '../site/pv-detailed-v17.js';const x=JSON.parse(fs.readFileSync('/mnt/data/solar_validation_20261026/diode_cases.json'));const output=x.cases.map(c=>deSotoDetailedPower(x.ref,c.g,c.t));fs.writeFileSync('/mnt/data/solar_validation_20261026/diode_js_results.json',JSON.stringify(output));''')
r=subprocess.run(['node',str(js)],capture_output=True,text=True)
assert r.returncode==0,r.stderr
out=json.loads((R/'diode_js_results.json').read_text())
Tref=298.15;kboltz=8.617333262145e-5
maxabs={name:0 for name in ['voc','isc','vmp','imp','pmp']};relmax={name:0 for name in maxabs}
for case,jsv in zip(cases,out):
 t=case['t']+273.15;g=case['g'];eg=ref['EgRefEv']*(1+ref['dEgdTPerK']*(t-Tref))
 il=g/1000*(ref['ILrefA']+ref['alphaIscAperC']*(case['t']-25))
 i0=ref['I0refA']*(t/Tref)**3*math.exp(ref['EgRefEv']/(kboltz*Tref)-eg/(kboltz*t))
 rs=ref['RsRefOhm'];rsh=ref['RshRefOhm']*1000/g;nns=ref['aRefV']*t/Tref
 def residual(i,v):return il-i0*math.expm1((v+i*rs)/nns)-(v+i*rs)/rsh-i
 voc=brentq(lambda v:residual(0,v),0,nns*math.log1p(il/i0),xtol=1e-12)
 isc=brentq(lambda i:residual(i,0),0,il,xtol=1e-12)
 def ii(v):return brentq(lambda i:residual(i,v),0,il,xtol=1e-12) if v<voc else 0.0
 opt=minimize_scalar(lambda v:-v*ii(v),method='bounded',bounds=(0,voc),options={'xatol':1e-10})
 vmp=opt.x;imp=ii(vmp);pmp=vmp*imp
 py={'voc':voc,'isc':isc,'vmp':vmp,'imp':imp,'pmp':pmp}
 for key,actual in py.items():
  err=abs(actual-jsv[key]);maxabs[key]=max(maxabs[key],err);relmax[key]=max(relmax[key],err/max(1,actual))
assert all(relmax[k]<2e-6 for k in maxabs),relmax
report={'testCases':len(cases),'compared':['Voc','Isc','Vmp','Imp','Pmp'],'maxAbsDifference':maxabs,'maxRelativeDifference':relmax,'result':'PASS','reference':'independent SciPy brentq IV root and bounded minimize_scalar maximum power','scope':'Synthetic fitted-coefficient De Soto vectors; not installed pvlib, PVsyst, SSC, PySAM or OEM calibration'}
(R/'single_diode_scipy_comparison.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
