import assert from 'node:assert/strict';
import {compareAnnualEnergyFinance} from '../site/finance-sensitivity.js';
import {energyUncertaintyBudget} from '../site/pxx-uncertainty.js';
import {projectFinance} from '../site/finance-core.js';
import fs from 'node:fs';
let checks=0;const check=(flag,label)=>{checks++;assert.ok(flag,label)};
const base={year1KWh:19000,capex:25000,omFixedPerYear:400,omVariablePerKWh:0.006,ppaPerKWh:.14,degradationPct:.5,ppaEscalationPct:1,omEscalationPct:2,discountNominalPct:7,years:25};
const pxx=energyUncertaintyBudget({years:[17000,18500,19200,19900,20000,18300,18700,19400,21100,19700,20200,18900],uResourcePct:3,uModelPct:2,uAvailabilityPct:1,correlations:{resourceModel:.2,modelAvailability:-.1}});
check(pxx.gaussian.P90>0,'physically positive P90');
check(!!(function(){try{compareAnnualEnergyFinance(pxx,base);return false}catch(e){return /Confirm/.test(e.message)}})(),'non-attested linkage rejects');
const r=compareAnnualEnergyFinance(pxx,base,{sameProjectConfirmed:true});
check(r.scenarios.length===4,'four scenario outputs');
for(const row of r.scenarios){check(row.status==='RESEARCH_SCENARIO','scenario valid');const expected=projectFinance({...base,year1KWh:row.year1KWh});check(Math.abs(row.nominalNPV-expected.summary.nominalNPV)<1e-8,'same finance DCF engine');check(Math.abs(row.nominalLCOEPerKWh-expected.summary.nominalLCOEPerKWh)<1e-12,'discounted LCOE follows same basis');}
const broken=structuredClone(pxx);broken.gaussian.P90=null;
const b=compareAnnualEnergyFinance(broken,base,{sameProjectConfirmed:true});check(b.scenarios[1].status==='UNAVAILABLE_NONPHYSICAL_OR_MISSING','nonphysical P90 withheld rather than replaced with zero');
for(let i=0;i<250;i++){
 const energy=10000+i*271;const capex=15000+i*62;const i2={...base,capex};
 const casePxx={...pxx,gaussian:{P50:energy,P90:energy*.82},correlationAdjusted:{P90:energy*.80},highCorrelationStress:{P90:energy*.7}};
 const s=compareAnnualEnergyFinance(casePxx,i2,{sameProjectConfirmed:true});
 check(s.scenarios[0].year1KWh===energy,'scenario unscaled kWh');
 check(Math.abs(s.scenarios[1].nominalNPV-projectFinance({...i2,year1KWh:energy*.82}).summary.nominalNPV)<1e-8,'P90 DCF independently reproduced');
 check(s.scenarios[0].year1KWh>s.scenarios[1].year1KWh,'exceedance interpretation');
}
const out={checks,passed:checks,failed:0,scenarioSources:'synthetic',qualification:'NOT BANKABLE; no probabilistic NPV claim'};
fs.writeFileSync('/mnt/data/solar_validation_20261026/finance_sensitivity_unit.json',JSON.stringify(out,null,2));console.log(out);
