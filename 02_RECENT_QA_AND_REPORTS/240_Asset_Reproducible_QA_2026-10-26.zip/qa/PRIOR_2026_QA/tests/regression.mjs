import fs from 'node:fs';
import assert from 'node:assert/strict';
import { pathToFileURL } from 'node:url';
const root=process.argv[2] || '/mnt/data/solar_platform_working/candidate';
const resultPath=process.argv[3] || '/mnt/data/solar_platform_working/results/regression.json';
const ld=async p=>import(pathToFileURL(`${root}/${p}`).href);
const PV=await ld('pv-reference-kernel.js');
const CEC=await ld('cec-sandia-engine.js');
const BESS=await ld('bess-dispatch.js');
const PXX=await ld('pxx-uncertainty.js');
const ELE=await ld('electrical-screen.js');
const FIN=await ld('finance-core.js');
const TRACK=await ld('tracker-physics.js');
const THERM=await ld('thermal-v362/thermal-engine.mjs');
const CAL=await ld('annual-utc-calendar.js');
const out={date:new Date().toISOString(),sourceRoot:root,suites:{},checks:0,errors:[]};
function check(cond,msg){out.checks++;assert.ok(cond,msg);}
function near(a,b,tol,msg){check(Number.isFinite(a)&&Number.isFinite(b)&&Math.abs(a-b)<=tol,`${msg}: ${a} != ${b} ± ${tol}`)}
function rejects(fn,rx,msg){out.checks++;assert.throws(fn,rx,msg)}
function section(n,fn){try{fn();out.suites[n]='PASS'}catch(e){out.suites[n]='FAIL';out.errors.push({suite:n,message:e.stack||String(e)})}}
section('pvwatts_inverter_reference',()=>{
 check(PV.pvwattsInverterKW(0,100).acKW===0,'DC 0 -> AC 0');
 for(const [dc,ac] of [[0.0001,1],[0.001,1],[.004,1],[.01,1],[.5,1],[1,1],[1.2,1],[10,1],[100,100],[105,100]]){
  const val=PV.pvwattsInverterKW(dc,ac,.96,.9637);
  const z=dc/(ac/.96),raw=.96/.9637*(-.0162*z-.0059/z+.9858),eta=Math.max(0,Math.min(1,raw));
  const produced=dc*eta,ref=Math.min(ac,produced);
  near(val.acKW,ref,1e-10,'PVWatts algebra AC power');
  near(val.efficiency,eta,1e-12,'PVWatts fitted bounded efficiency');
  check(val.efficiency>=0&&val.efficiency<=1,'0 <= efficiency <= 1');
  near(dc, val.acKW+val.conversionLossKW+val.clippingKW,1e-8,'energy conservation');
  check(val.conversionLossKW>=-1e-9&&val.clippingKW>=-1e-9,'loss nonnegative');
 }
 rejects(()=>PV.pvwattsInverterKW(-1,10),/Invalid/,'negative input rejected');
 rejects(()=>PV.pvwattsInverterKW(1,1,1,.5),/exceeds 100%/,'nonphysical inverter efficiency rejected');
});
section('pv_single_diode_and_desoto',()=>{
 const ref={ILrefA:9.5,I0refA:1e-10,RshRefOhm:500,RsRefOhm:.38,aRefV:1.45,alphaIscAperC:.0045};
 const stc=PV.deSotoPower(ref,1000,25);
 const half=PV.deSotoPower(ref,500,25);
 near(stc.pmp,stc.vmp*stc.imp,1e-9,'Pmp == Vmp*Imp');
 check(stc.voc>stc.vmp&&stc.vmp>0&&stc.isc>stc.imp&&stc.imp>0,'realistic IV ordering');
 check(stc.fillFactor>0&&stc.fillFactor<1,'physical fill factor');
 check(half.pmp<stc.pmp&&half.pmp>0,'reduced irradiance power');
 check(PV.deSotoPower(ref,0,25).pmp===0,'night zero');
 rejects(()=>PV.deSotoPower(ref,2000,25),/outside 0..1800/,'irradiance gate');
});
section('dc_circuit_topology',()=>{
 const inp={iscA:14,impA:13,vmpV:41,vocV:49,tempCoeffVocPctC:-.28,minDesignTempC:-10,maxOperatingTempC:75,seriesModules:20,parallelStrings:5,loopLengthM:210,ohmPerKm20C:.2,alphaPerC:.00393,conductorTempC:65,baseAmpacityA:150,tempFactor:.91,adjustFactor:.8,maxSystemVoltageV:1500,maxModuleFuseA:25};
 const a=ELE.dcCircuitScreen({...inp,topology:'common_feeder'}).results;
 const b=ELE.dcCircuitScreen({...inp,topology:'individual_string_loops'}).results;
 const R=inp.ohmPerKm20C*.001*inp.loopLengthM*(1+inp.alphaPerC*(inp.conductorTempC-20));
 near(a.dcLoopResistanceOhm,R,1e-12,'loop resistance');
 near(a.dcConductorLossW,(5*13)**2*R,1e-9,'common loop loss');
 near(b.dcConductorLossW,5*13**2*R,1e-9,'individual five loop losses');
 near(a.dcConductorLossW/b.dcConductorLossW,5,1e-10,'routing loss ratio');
 check(a.maximumCurrentA===1.25*5*14,'common feeder source');
 check(b.maximumCurrentA===1.25*14,'separate string source');
 check(a.vocColdV===b.vocColdV,'voltage independent routing');
 rejects(()=>ELE.dcCircuitScreen({...inp,topology:'anything'}),/topology/,'reject unknown routing topology');
});
const makeHours=(year,fun)=>{
 const first=Date.parse(`${year}-01-01T00:00:00.000Z`);
 const len=((year%4===0&&year%100!==0)||year%400===0)?8784:8760;
 return Array.from({length:len},(_,i)=>({timestamp_utc:new Date(first+i*3600000).toISOString(),ac_inverter_kw:fun(i)}));
};
section('annual_calendar_bess_dispatch',()=>{
 const config={capacityKWh:500,loadKW:60,maxChargeKW:90,maxDischargeKW:70,chargeEfficiency:.96,dischargeEfficiency:.94,minSocPct:10,maxSocPct:90,initialSocPct:50,exportCapKW:30};
 for(const year of [2025,2024]){
  const rows=makeHours(year,i=>Math.max(0,Math.sin((i%24-6)/12*Math.PI)*175));
  check(CAL.validateAnnualUtcCalendar(rows).expectedHours===rows.length,'full calendar check');
  const d=BESS.simulateDispatch(rows,config);
  check(d.hourly.length===rows.length&&d.monthly.length===12,'dispatch full year');
  const s=d.summary;
  near(s.pvBusEnergyKWh+s.batteryDischargeToLoadKWh+s.gridImportKWh,s.onSiteLoadKWh+s.batteryChargeFromPVKWh+s.gridExportKWh+s.exportCurtailmentKWh,1e-5,'AC bus yearly conservation');
  near(s.initialStoredKWh+s.batteryChargeFromPVKWh-s.chargeConversionLossKWh-s.batteryDischargeToLoadKWh-s.dischargeConversionLossKWh,s.endStoredKWh,1e-5,'battery yearly conservation');
  check(d.hourly.every(r=>r.stored_kwh>=50-1e-7&&r.stored_kwh<=450+1e-7&&r.grid_export_ac_bus_kw<=30+1e-7),'SOC and export caps');
  check(d.hourly.every(r=>!(r.grid_import_ac_bus_kw>0&&r.grid_export_ac_bus_kw>0)),'no simultaneous grid import/export');
 }
 const wrong=makeHours(2025,()=>0);wrong.shift();wrong.push({timestamp_utc:'2026-01-01T00:00:00.000Z',ac_inverter_kw:0});
 rejects(()=>BESS.simulateDispatch(wrong,config),/January 1/,'reject shifted annual year');
});
section('p50_p90_and_covariance',()=>{
 const years=[940000,980000,1010000,995000,1030000,975000,1020000,1005000,985000,1040000];
 const input={years,uResourcePct:4,uModelPct:3,uAvailabilityPct:2,correlations:{resourceModel:.25,resourceAvailability:-.1,modelAvailability:.15}};
 const o=PXX.energyUncertaintyBudget(input);
 const mean=years.reduce((a,b)=>a+b,0)/years.length;
 const sd=Math.sqrt(years.reduce((a,b)=>a+(b-mean)**2,0)/(years.length-1));
 const u=[mean*.04,mean*.03,mean*.02],s=Math.sqrt(sd**2+u.reduce((a,b)=>a+b*b,0));
 const corr=Math.sqrt(s*s+2*(.25*u[0]*u[1]-.1*u[0]*u[2]+.15*u[1]*u[2]));
 near(o.shiftedP50KWh,mean,1e-5,'mean P50');
 near(o.sigmaIndependentKWh,s,1e-7,'RSS variance');
 near(o.sigmaCorrelationAdjustedKWh,corr,1e-7,'covariance matrix quadratic form');
 near(o.correlationAdjusted.P90,mean-1.2815515655446004*corr,1e-6,'P90 exceedance');
 check(o.correlationAdjusted.P90<o.correlationAdjusted.P50,'P90 below P50');
 rejects(()=>PXX.energyUncertaintyBudget({...input,correlations:{resourceModel:.9,resourceAvailability:.9,modelAvailability:-.9}}),/not positive semidefinite/,'reject non PSD matrix');
});
section('finance_independent_dcf',()=>{
 const p={year1KWh:5000000,capex:3000000,omFixedPerYear:20000,omVariablePerKWh:.003,ppaPerKWh:.1,degradationPct:.5,ppaEscalationPct:2,omEscalationPct:2,discountNominalPct:8,years:20};
 const got=FIN.projectFinance(p);
 let npv=-p.capex,lcoeCosts=p.capex,lcoeEnergy=0;
 for(let i=1;i<=p.years;i++){
  const E=p.year1KWh*(1-.005)**(i-1),price=.1*1.02**(i-1),opex=(20000+.003*E)*1.02**(i-1);
  npv+=(E*price-opex)/1.08**i;lcoeCosts+=opex/1.08**i;lcoeEnergy+=E/1.08**i;
 }
 near(got.summary.nominalNPV,npv,1e-6,'independent discounted cashflow');
 near(got.summary.nominalLCOEPerKWh,lcoeCosts/lcoeEnergy,1e-12,'independent LCOE');
 check(got.summary.preTaxIRRPercent>0&&got.summary.preTaxIRRPercent<30,'IRR sensible');
 rejects(()=>FIN.projectFinance({...p,year1KWh:-1}),/Year-one POI/,'invalid input rejected');
});
section('tracker_geometry',()=>{
 const cfg={axisTilt:0,axisAzimuth:0,crossAxisTilt:0,minAngle:-60,maxAngle:60,widthM:2,pitchM:5,backtrack:true};
 const t=TRACK.trackerAt(30,110,cfg);
 check(!t.night&&Number.isFinite(t.trackerTheta),'day tracker valid');
 check(t.beamShadedFraction>=0&&t.beamShadedFraction<=1,'clipped row shade fraction');
 const v=t.trackerTheta;
 near(TRACK.projectedSolarAngle(0,130),0,1e-12,'zenith no tracker rotation');
 const night=TRACK.trackerAt(105,160,cfg);
 check(night.night&&night.trackerTheta===null,'night null orientation');
 check(Math.abs(v)<=60+1e-9,'mechanical rotation limits');
 check(TRACK.shadedFraction1d({solarZenith:20,solarAzimuth:100,axisAzimuth:0,shadedRotation:0,collectorWidth:2,pitch:7})>=0,'shade screen');
});
section('cec_curve_and_input_gates',()=>{
 const m={name:'Synthetic fixture - no OEM verification',Vac:240,Pso:10,Paco:4800,Pdco:5000,Vdco:400,C0:-.000003,C1:0,C2:0,C3:0,Pnt:1,Vdcmax:600,Idcmax:16,Mppt_low:150,Mppt_high:500};
 check(CEC.validateCecRecord(m),'CEC fixture basic');
 const r=CEC.sandiaCecInverter(m,2000,400);
 check(r.status==='MODEL_EVALUATED'&&r.acPowerW>0&&r.acPowerW<2000,'CEC physical power');
 near(r.acPowerW+r.clippedW+r.conversionW,2000,1e-7,'CEC conservation');
 check(CEC.sandiaCecInverter(m,5000,700).status==='SCREEN_FAILED','max DC voltage rejected');
 check(CEC.sandiaCecInverter(m,5000,200).status==='SCREEN_FAILED','excess DC current rejected');
});
section('thermal_engine_screens',()=>{
 const basic=THERM.steady({...THERM.BASE});
 check(['PASS','FAIL','REVIEW REQUIRED'].includes(basic.status),'thermal engine calculated with default input');
 check(Number.isFinite(basic.ampacity_a)&&basic.ampacity_a>0,'thermal engine ampacity numeric');
 check(THERM.steady({...THERM.BASE,soil_rho_km_w:NaN}).status==='INPUT REQUIRED','invalid thermal inputs blocked');
 check(THERM.sharing({total_current_a:500,parallel_sets:2}).status === 'INPUT REQUIRED','unverified parallel-current balance conservatively blocked');
});
const catalog=JSON.parse(fs.readFileSync(root+'/master_pv_modules.json','utf8'));
section('catalog_nonmutation',()=>{
 check(catalog.total===26000,'canonical module count from metadata');
 check(Array.isArray(catalog.models)&&catalog.models.length===26000,'actual array length');
});
fs.mkdirSync('/mnt/data/solar_platform_working/results',{recursive:true});
fs.writeFileSync(resultPath,JSON.stringify(out,null,2));
console.log(JSON.stringify({checks:out.checks,suites:out.suites,errors:out.errors.map(e=>e.message.slice(0,300))},null,2));
if(out.errors.length)process.exitCode=1;
