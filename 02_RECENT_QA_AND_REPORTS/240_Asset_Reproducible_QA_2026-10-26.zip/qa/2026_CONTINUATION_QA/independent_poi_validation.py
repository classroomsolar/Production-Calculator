"""Independent Python phasor/power law comparison against 100 JS exported fixtures.
Runs off user-supplied ratings only; does not establish IEC/NEC construction approval.
"""
import json,math,pathlib
base=pathlib.Path('/mnt/data/solar_platform_next')
rows=json.loads((base/'poi_independent_cases.json').read_text())
assert len(rows)==100
err={'pKw':0,'kVA':0,'iA':0}
for r in rows:
 c=r['input'];observed=r['poIResult']
 p=c['pvGenerationKW']+c['bessNetKW']-c['siteLoadKW']
 s=math.sqrt(p*p+c['netReactiveKvar']**2)
 amp=s*1000/(math.sqrt(3)*c['poiVoltageLLV'])
 for k,actual,v in [('pKw',p,observed['netRealPowerKW']),('kVA',s,observed['netApparentKVA']),('iA',amp,observed['poiCurrentA'])]:
  err[k]=max(err[k],abs(actual-v))
  assert math.isclose(actual,v,rel_tol=1e-12,abs_tol=1e-9),(k,actual,v)
out={'scope':'independent Python three-phase phasor and power/current equation on 100 seeded randomized JS cases','cases':len(rows),'maxAbsoluteDifference':err,'passed':True,'limitations':'Not site measured and not protection, thermal, IEEE 1547, NEC or OEM certification'}
(base/'poi_python_oracle.json').write_text(json.dumps(out,indent=2))
print(json.dumps(out))
