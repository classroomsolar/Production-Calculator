from pathlib import Path
p=Path('/mnt/data/solar_validation_20261026/site')
engine=p/'pv-catalog-qualification.js'; ui=p/'pv-catalog-qualification-ui.js'
t=engine.read_text()
if 'export function fullQualificationRegister' in t: raise SystemExit('already exists')
t+='''
/** Complete read-only per-record engineering exception register (never first-250 only).
 * Includes all source IDs; a valid STC shape is NOT an OEM qualification.
 * The optional external reference-status callback only annotates; never mutates.
 */
export function fullQualificationRegister(catalog, referenceStatus=()=> 'REFERENCE_NOT_LOADED') {
 if(!catalog||!Array.isArray(catalog.models)||catalog.models.length!==catalog.total)throw Error('Invalid canonical catalogue length');
 if(typeof referenceStatus!=='function')throw Error('Reference status lookup must be a function');
 const counts=new Map(), ids=new Set();
 for(const r of catalog.models){
  const id=String(r.id??'');if(!id||ids.has(id))throw Error('Duplicate or missing catalogue ID: '+id);ids.add(id);
  const k=norm(r.maker)+'\\u0000'+norm(r.model);counts.set(k,(counts.get(k)||0)+1);
 }
 const header=['Source row','Catalogue ID','Manufacturer','Model','Pmp (W)','Voc (V)','Vmp (V)','Isc (A)','Imp (A)','Efficiency (%)','STC structural validity','Pmp vs Vmp × Imp deviation (%)','Full diode model parameters present','Manufacturer six-field STC transcription','Independent production qualification','OEM source kind','OEM source URL','Reference-library status','Issue flags','Recommended verification'];
 const rows=catalog.models.map((r,i)=>{
  const a=assessRecord(r,counts.get(norm(r.maker)+'\\u0000'+norm(r.model)));
  let priority='OEM model datasheet/revision and calibrated coefficients required';
  if(!a.validSTC)priority='HIGH: missing or nonphysical STC ratings; seek original manufacturer data';
  else if(a.flags.includes('PMP_VMP_IMP_DISCREPANCY_ABOVE_7_PERCENT'))priority='HIGH: STC nameplate power inconsistent with Vmp × Imp; verify exact OEM revision';
  else if(!a.source.link)priority='Source traceability: obtain exact OEM datasheet and certification reference';
  else if(a.oemSTCTranscriptionChecked)priority='OEM STC spot-check recorded; still requires full electrical/thermal SDM and listing verification';
  return [r.row??i+1,a.id,a.maker,a.model,r.w??'',r.voc??'',r.vmp??'',r.isc??'',r.imp??'',r.efficiency??'',a.validSTC,
    a.powerProductDeltaPct??'',a.hasModelCoefficients,a.oemSTCTranscriptionChecked,a.qualifiedForProduction,
    a.source.sourceKind,a.source.link??'',String(referenceStatus(a.id)),a.flags.join('; '),priority];
 });
 return {headers:header,rows,sourceCount:catalog.models.length,uniqueIds:ids.size,recordsQualifiedForProduction:0};
}
'''
engine.write_text(t)
t=ui.read_text().replace('import {auditCatalog,assessRecord,searchCatalog,sourceAssessment}', 'import {auditCatalog,assessRecord,searchCatalog,sourceAssessment,fullQualificationRegister}')
t=t.replace('>Export audit CSV</button>', '>Export FULL 26,000-row audit CSV</button>')
start=t.index("byId('catalogExport').addEventListener(")
end=t.index("byId('catalogEvidence').addEventListener(",start)
t=t[:start]+'''byId('catalogExport').addEventListener('click',()=>{
 if(!state.catalog||!state.audit)return;
 try{
  const register=fullQualificationRegister(state.catalog,id=>state.sam?.statusForId(id)||'REFERENCE_NOT_LOADED');
  if(register.sourceCount!==state.audit.summary.total||register.uniqueIds!==register.sourceCount)throw Error('Full export record integrity mismatch');
  download('PV_MASTER_CATALOG_FULL_26000_RECORD_QUALIFICATION.csv',csv([register.headers,...register.rows]),'text/csv;charset=utf-8');
  byId('catalogStatus').textContent='Complete '+fmt(register.rows.length)+'-row read-only qualification register prepared. No products automatically qualified.';
 }catch(error){byId('catalogStatus').textContent='FULL AUDIT EXPORT REJECTED: '+error.message;}
});
''' + t[end:]
t=t.replace("reportScope:'Full catalogue counts; first 250 selected anomaly records. No original equipment data exported as a new master.'", "reportScope:'Full catalogue counts, 250 representative anomaly examples; full 26,000-row exception and source register is provided through CSV. Original master is unchanged.'")
ui.write_text(t)
print('patched',len(engine.read_bytes()),len(ui.read_bytes()))
