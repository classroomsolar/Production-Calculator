# Reproducible validation of the 240-asset solar research platform

Source is in the separate source ZIP. Extract that source to `site/` alongside `qa/`, and adjust absolute paths in historical Python scripts. Run:

```sh
node qa/full_catalog_register_test.mjs
node qa/generate_complete_equipment_register.mjs
python qa/full_catalog_ui_test.py
python qa/ui_test_20261026.py
node qa/PRIOR_2026_QA/tests/regression.mjs /absolute/path/to/site /absolute/path/to/regression_results.json
python qa/single_diode_scipy_oracle.py
node qa/finance_sensitivity_unit.mjs
```

Full installed pvlib/PySAM annual comparison and public Wix browser login/network acceptance were NOT executed. The report explicitly marks these limitations.
