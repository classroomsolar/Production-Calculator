import csv,json,collections,hashlib,pathlib
R=pathlib.Path('/mnt/data/solar_validation_20261026');p=R/'site/master_pv_modules.json';text=p.read_bytes();d=json.loads(text);models=d['models'];ids=[m['id'] for m in models];assert len(models)==26000 and len(ids)==len(set(ids))
from collections import Counter
counts=Counter();flags=[]
for m in models:
 bad=[]
 for k in ('w','voc','vmp','isc','imp'):
  v=m.get(k)
  if not isinstance(v,(int,float)) or v<=0:bad.append('MISSING_OR_NONPOSITIVE_'+k)
 if all(isinstance(m.get(k),(int,float)) for k in ('w','voc','vmp','isc','imp')):
  if m['voc']<=m['vmp']:bad.append('VOC_NOT_GT_VMP')
  if m['isc']<=m['imp']:bad.append('ISC_NOT_GT_IMP')
  if m['w']>0 and abs(m['vmp']*m['imp']/m['w']-1)>.07:bad.append('PMP_PRODUCT_GT_7_PERCENT')
 if bad:
  flags.append({'id':m['id'],'maker':m.get('maker',''),'model':m.get('model',''),'w':m.get('w'),'flags':';'.join(bad)})
 for k in bad:counts[k]+=1
pr=[]
for f in ['DISCREPANCIES.csv','AMBIGUOUS.csv']:
 with open(R/'qa/PRIOR_2026_QA/catalog_reference_audit'/f,encoding='utf-8-sig') as h:
  for row in csv.DictReader(h):
   if row['status'] in ('LARGE_STC_DISCREPANCY_GT_2_PERCENT','AMBIGUOUS_REFERENCE_IDENTITY'):
    pr.append({k:row.get(k,'') for k in ['row','id','maker','model','status','sam_reference','difference_fields','notes']})
pr.sort(key=lambda x:(x['status']!='LARGE_STC_DISCREPANCY_GT_2_PERCENT',int(x['row'])))
with open(R/'equipment_reference_exception_queue.csv','w',newline='',encoding='utf-8') as h:
 writer=csv.DictWriter(h,fieldnames=['row','id','maker','model','status','sam_reference','difference_fields','notes','required_action']);writer.writeheader();
 for row in pr:writer.writerow({**row,'required_action':'Find exact revision OEM datasheet and verify six STC/nameplate fields + 5-param IV coefficients + current listing. Do not auto-correct master.'})
with open(R/'equipment_local_physics_anomalies.csv','w',newline='',encoding='utf-8') as h:
 writer=csv.DictWriter(h,fieldnames=['id','maker','model','w','flags']);writer.writeheader();writer.writerows(flags)
ref=json.loads((R/'qa/PRIOR_2026_QA/catalog_reference_audit/SUMMARY.json').read_text())
summary={'sourceModelCount':len(models),'uniqueRecordIds':len(set(ids)),'sha256':hashlib.sha256(text).hexdigest(),'sourceDeclaredSHA256':d.get('sha256'), 'historicalSAMCategories':ref['categories'],'currentLocalPhysicalAnomalyRows':len(flags),'physicsFlagTypes':dict(counts),'priorityOEMReviewQueueCount':len(pr),'noSourceRowsMutated':True,'sourceQualification':'REFERENCE DATA ONLY, NOT OEM APPROVED'}
(R/'equipment_audit_summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))
