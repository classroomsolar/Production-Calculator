"""Execute the exact pvwatts() function body extracted from cached pvlib 0.16.1 Python source.
This is a focused source-function comparison, NOT an installed pvlib package import or full annual-model benchmark.
"""
import ast, json, pathlib, hashlib
import numpy as np
W=pathlib.Path('/mnt/data/solar_validation_20261026')
source_file=W/'transfer/05_EXTERNAL_PVLIB_REFERENCE/pvlib_0.16.1_inverter.py.txt'
source=source_file.read_text(encoding='utf-8-sig')
mod=ast.parse(source)
fn=next(node for node in mod.body if isinstance(node,ast.FunctionDef) and node.name=='pvwatts')
raw=ast.get_source_segment(source,fn)
namespace={'np':np}
exec(compile(raw, str(source_file),'exec'),namespace)
ref=namespace['pvwatts']
items=json.loads((W/'results/pvwatts_cases.json').read_text())
pdc=np.array([p['dcKW'] for p in items]);pac=np.array([p['acRatedKW'] for p in items]);expected=np.asarray(ref(pdc,pac/.96,.96,.9637))
actual=np.array([p['acKW'] for p in items]);difference=np.abs(actual-expected)
assert np.isfinite(expected).all()
assert np.max(difference)<1e-10, np.max(difference)
negative_efficiency_count=sum(p['efficiency']<0 for p in items)
assert negative_efficiency_count==0
result={'reference':'pvlib 0.16.1 cached official inverter.py function pvwatts (extracted and executed unchanged)','testCases':len(items),'maxAbsPowerDifferenceKW':float(np.max(difference)),'meanAbsPowerDifferenceKW':float(np.mean(difference)),'negativeReportedEfficienciesAfterPatch':negative_efficiency_count,'exactSourceSnippetSha256':hashlib.sha256(raw.encode()).hexdigest(),'qualification':'Focused function-level power comparison, NOT pip-installed pvlib runtime, annual PV yield, tracker/bifacial or SSC/PySAM benchmark.','status':'PASS'}
(W/'results/pinned_pvlib_inverter_comparison.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
