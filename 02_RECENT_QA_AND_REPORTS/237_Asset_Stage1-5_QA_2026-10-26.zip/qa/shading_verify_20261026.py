import ast,random,json,subprocess,hashlib,math
import numpy as np
from pathlib import Path
P=Path('/mnt/data/solar_validation_20261026');src=(P/'pvlib_0.16.1_shading.py.txt').read_text(encoding='utf-8-sig')
parsed=ast.parse(src)
need=['projected_solar_zenith_angle','shaded_fraction1d']
funcs=[n for n in parsed.body if isinstance(n,ast.FunctionDef) and n.name in need]
assert len(funcs)==2
ns={'np':np, 'sind':lambda d:np.sin(np.deg2rad(d)),'cosd':lambda d:np.cos(np.deg2rad(d))}
exec(compile(ast.Module(body=funcs,type_ignores=[]),'<pvlib-0.16.1-unmodified-two-functions>','exec'),ns)
random.seed(10252026)
cases=[]
for _ in range(2500):
 zen=random.uniform(1,89.9);azi=random.uniform(0,360);axisAz=random.uniform(0,360);axisTilt=random.uniform(-35,35)
 t1=random.uniform(-72,72);t2=random.uniform(-72,72);cross=random.uniform(-18,18)
 width=random.uniform(1.3,3.5);pitch=width/random.uniform(.22,.76);offset=random.uniform(-.08,.08)
 calc=ns['shaded_fraction1d'](zen,azi,axisAz,t2,collector_width=width,pitch=pitch,axis_tilt=axisTilt,surface_to_axis_offset=offset,cross_axis_slope=cross,shading_row_rotation=t1)
 projected=ns['projected_solar_zenith_angle'](zen,azi,axisTilt,axisAz)
 if not (np.isfinite(calc) and np.isfinite(projected)):continue
 cases.append({'solarZenith':zen,'solarAzimuth':azi,'axisAzimuth':axisAz,'axisTilt':axisTilt,'shadedRotation':t2,'shadingRotation':t1,'collectorWidth':width,'pitch':pitch,'offsetM':offset,'crossAxisSlope':cross,'referenceShadedFraction':float(calc),'referenceProjection':float(projected)})
(P/'tracker_comparison_input.json').write_text(json.dumps(cases))
js=P/'compare_tracker.mjs';js.write_text('''import fs from 'node:fs'; import {projectedSolarAngle,shadedFraction1d} from './site/tracker-physics.js';const inputs=JSON.parse(fs.readFileSync('./tracker_comparison_input.json','utf-8'));const out=inputs.map(({referenceShadedFraction,referenceProjection,...args})=>({shade:shadedFraction1d(args),proj:projectedSolarAngle(args.solarZenith,args.solarAzimuth,args.axisTilt,args.axisAzimuth)}));fs.writeFileSync('tracker_comparison_js.json',JSON.stringify(out));''')
p=subprocess.run(['node','--experimental-default-type=module',str(js)],cwd=str(P),capture_output=True,text=True)
if p.returncode:raise RuntimeError(p.stderr)
results=json.loads((P/'tracker_comparison_js.json').read_text());shadeErrors=[abs(a['referenceShadedFraction']-b['shade']) for a,b in zip(cases,results)];projErrors=[abs(a['referenceProjection']-b['proj']) for a,b in zip(cases,results)]
out={'reference':'pvlib-python 0.16.1 pinned shading.py, original projected_solar_zenith_angle and shaded_fraction1d function AST executed unmodified with numpy/sind/cosd reference imports substituted','sourceSHA256':hashlib.sha256(src.encode('utf-8-sig')).hexdigest(),'n':len(cases),'maxAbsShadedFractionDifference':max(shadeErrors),'maxAbsProjectionDifferenceDeg':max(projErrors),'shadeMismatchesAbove1e-9':sum(e>1e-9 for e in shadeErrors),'projectionMismatchesAbove1e-9':sum(e>1e-9 for e in projErrors),'exclusions':'Nighttime outside 0-90 and near-divergent denominator not sampled','notCompared':'Full pvlib tracker backtracking, bifacial, annual POI energy, SSC/PySAM'}
(P/'pvlib_shading_comparison.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
if out['shadeMismatchesAbove1e-9'] or out['projectionMismatchesAbove1e-9']:raise SystemExit(1)
