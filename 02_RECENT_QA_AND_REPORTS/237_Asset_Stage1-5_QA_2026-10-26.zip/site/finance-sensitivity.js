/** Linked annual-energy exceedance vs simplified project-finance screening.
 * Does not create an hourly P90 series or claim bankable/probabilistic NPV.
 * Uses same nominal pre-tax model as finance-core. Source years must represent
 * same plant and operating assumptions; that relationship cannot be inferred.
 */
import {projectFinance} from './finance-core.js';
const finite=(n)=>typeof n==='number'&&Number.isFinite(n);
export function compareAnnualEnergyFinance(annualPxx, financeInputs, {sameProjectConfirmed=false}={}) {
 if(!sameProjectConfirmed)throw Error('Confirm that annual energy samples represent the same PV project and design as the financial inputs');
 if(!annualPxx||!annualPxx.gaussian||!annualPxx.correlationAdjusted)throw Error('Run the annual Pxx study before finance sensitivity');
 if(!financeInputs||!finite(financeInputs.year1KWh)||financeInputs.year1KWh<=0)throw Error('Calculate the finance scenario with a valid baseline annual POI export first');
 const scenarioValues=[
  ['P50',annualPxx.gaussian.P50,'Annual mean/shifted P50'],
  ['P90-independent',annualPxx.gaussian.P90,'Independent Gaussian P90'],
  ['P90-correlated',annualPxx.correlationAdjusted.P90,'User-specified correlation P90'],
  ['P90-correlation-stress',annualPxx.highCorrelationStress?.P90,'Correlation stress, NOT a probability guarantee'],
 ];
 const scenarios=[];
 for(const [name,kWh,meaning] of scenarioValues){
  if(kWh===null||kWh===undefined||!finite(kWh)||kWh<1){scenarios.push({name,meaning,status:'UNAVAILABLE_NONPHYSICAL_OR_MISSING',year1KWh:null,nominalNPV:null,nominalLCOEPerKWh:null,preTaxIRRPercent:null,paybackYears:null});continue;}
  const f=projectFinance({...financeInputs,year1KWh:kWh});
  scenarios.push({name,meaning,status:'RESEARCH_SCENARIO',year1KWh:kWh,nominalNPV:f.summary.nominalNPV,nominalLCOEPerKWh:f.summary.nominalLCOEPerKWh,preTaxIRRPercent:f.summary.preTaxIRRPercent,paybackYears:f.summary.undiscountedPaybackYears});
 }
 if(scenarios[0].status!=='RESEARCH_SCENARIO')throw Error('P50 must be physically positive');
 return {status:'PRETAX_PXX_FINANCE_SENSITIVITY_NOT_BANKABLE',baselineUserAnnualKWh:financeInputs.year1KWh,
  uncertaintySamples:annualPxx.samples,scenarioCount:scenarios.length,scenarios,
  warnings:[
    'Annual energy P90 is NOT a P90 NPV, P90 revenue or P90 project financial outcome: fixed financing/tariff/model assumptions ignore joint uncertainty.',
    'All linked Pxx samples must describe the SAME site, scope, equipment configuration, curtailment/export definition and project years as finance. User confirmation cannot independently verify provenance.',
    'Pxx annual input is not scaled weather or an 8760-hour P90 production time series.',
    'No bankability, insurance, incentives, debt, taxes, tariff variability, hourly time-of-delivery or BESS degradation is modelled.',
    'This is a user-confirmed scenario sensitivity only; an independent finance and long-term irradiance study is needed for investment decisions.'
  ]};
}
