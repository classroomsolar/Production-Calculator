Run from root /mnt/data/solar_validation_20261026 with original site archive extracted to site/ (current source already in separate source ZIP). Commands:
node qa/PRIOR_2026_QA/tests/regression.mjs site results.json
node qa/finance_sensitivity_unit.mjs
python qa/single_diode_scipy_oracle.py
python qa/ui_test_20261026.py
Historical pinned pvlib validation is only function-level; scripts include explicit local paths for this run and should be adapted when executing elsewhere. Production does not include OEM-specific qualified parameters.
