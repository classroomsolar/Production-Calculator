# Solar PV Engineering Platform — Three-way cross-checked inputs, documents, open questions and studies
**Date:** 25 October 2026 | **Scope:** existing Solar Resource, PV Production & Electrical Engineering Platform only.

**Verification rule.** (1) Current-chat directives and historical controlling charters; (2) original nested 2026-10-24 handoff, 2026-10-25 transfer, database and archives; (3) currently deployed 232-asset Wix source, active UI fields, catalogue and published QA. They have been reconciled without treating demo-form defaults as project engineering facts.

**Material limitations:** These three checks establish inventory and consistency, not three independent OEM, electrical-code or numerical certifications. Not all older chat attachments are still reachable; Library metadata and nested archives cannot prove that every screenshot ever shared has been recovered. The project does not include a single completed, real-site parameter dataset with signed settings.

## A. Controlled input and requirements register

### Project identity and non-destructive continuation
| ID | Input / requirement | Recorded scope | Acceptance safeguard |
|---|---|---|---|
| P01 | Original Wix website | https://headless-spqwsttbeuf-classroomsolar-140e.wix-site-host.com/ | Existing site; do not create or migrate |
| P02 | Original Wix meta site ID | ec984f80-a998-4e29-a38c-ca6b85dac4f4 | Only same site |
| P03 | One integrated Solar Resource / PV Production / Electrical Engineering Platform | Required | Original existing code preserved |
| P04 | Browser-based application without installing software | Required | No new native app |
| P05 | Retain previous versions and guarded rollback | Required | Snapshot and readback before/after writes |
| P06 | Private recovery of source and confidential engineering resources | Required | On-site public backups alone insufficient |
| P07 | No deletion/reset of master equipment records | Required | Verified identity/units/revisions |
| P08 | Avoid inventing equipment specifications or engineering approvals | Required | Separate model/screen from certified design |
| P09 | Temporary client-side working-case retention | Session/refresh continuity, expire by 24 h | No new permanent account/project database without authorisation |
| P10 | All modules share project inputs and have clear input/output contracts | Required | No repeated inconsistent entry |
| P11 | Dual independent engineering and software QA | Required | Source, precision, traceability and release checks |
| P12 | Conservative technical assumptions when defensible | Required | All such assumptions identified, not mislabelled manufacturer specs |
| P13 | Same site at latest authenticated current revision | 84a9e4ffdbafb03cc0474e9e9d82ee8df5e98809 | 232 published assets, 38 rollback manifests read-only snapshot |
| P14 | Output formats | Excel, PDF, print, CSV and JSON | Include assumptions, origins, study results |
| P15 | Units | SI plus imperial ft/decimal ft/ft+in where appropriate | Internal unit conversions explicit |
| P16 | Platform functional scope | 22 calculator/study areas and 106-function original target blueprint | Feature-by-feature acceptance is separate from target count |
| P17 | Assisted engineering workflows | ChatGPT and Google AI Studio can assist with input completion and explanation | AI is not a substitute for verified numerical kernels, datasheets, or approval |

### Solar resource, site, weather and PV physics
| ID | Input / requirement | Recorded scope | Acceptance safeguard |
|---|---|---|---|
| S01 | Site/project identification | Project name; latitude; longitude; elevation; timezone | Site entries are not provided as one real project dataset |
| S02 | Time series | TMY, historical, uploaded EPW/CSV, 8760/8784-hour, timestamps | Correct leap-year, UTC/local convention, data quality |
| S03 | Weather variables | GHI, DNI, DHI, air temperature, wind speed, albedo and environmental metadata | Refresh live weather; keep TMY separate |
| S04 | Solar position and irradiance | Zenith, azimuth, POA, IAM, spectral and sky diffuse models | Independent pvlib/PySAM checks |
| S05 | Array orientation | Tilt, azimuth, pitch, slope, axis tilt/azimuth/cross-axis slope | Geometry must reflect actual row layout |
| S06 | Tracker geometry | Backtracking, mechanical limits, stow, row shade, pitch/GCR | Compare flat/sloping sites |
| S07 | Shading | Horizon survey, obstacles, ray geometry, 3-D scene, rear view factors | Substring/electrical mismatch separate from optical shade |
| S08 | Bifacial array | Bifaciality, row width/height, albedo, torque tube, rear shading/mismatch | Independent irradiance model |
| S09 | PV module nameplate and coefficients | Pmax, Voc, Vmp, Isc, Imp, alpha/beta/gamma, IL/I0/Rs/Rsh/a and curve source | OEM exact product and coefficient qualification |
| S10 | Stringing/MPPT | Modules/string, strings/MPPT, MPPT count and ranges, DC bus, cold/hot design temperatures | Current and voltage design envelope |
| S11 | Inverter | DC maximum/MPPT electrical limits, AC nameplate, CEC/Sandia curves, efficiency, PQ capability | Do not equate historical CEC fit to approved device |
| S12 | PV thermal/irradiance losses | Cell/module thermal model and mounting, ambient/wind, IAM, soiling, snow, spectral, degradation | Specified sources and valid weather height |
| S13 | Electrical yield losses | DC ohmic, mismatch, inverter, AC cable, transformer, auxiliaries, availability, curtailment | Annual reconciliation from DC to POI |
| S14 | Production reporting | Hourly, monthly, annual MWh/kWh/kWp, PR, CF and stage-loss diagrams | Independent engine parity |

### Electrical, cable thermal, protection and POI
| ID | Input / requirement | Recorded scope | Acceptance safeguard |
|---|---|---|---|
| E01 | DC circuits and conductors | Topology, voltage, max current, loop length, conductor material/area, temperature and installation | Combined feeder vs individual string loops distinct |
| E02 | AC cable feeders | Conductor material, size, run length, line voltage, PF, phases, conductor temperature | Voltage drop, I2R, protection |
| E03 | Cable thermal original 3.6.2 | Cable OD, resistance, dielectric losses, thermal resistances, soil resistivity, burial depth, grouping | Actual installation manufacturer sources; no simplified replacement |
| E04 | Cable thermal scenarios | Continuous, cyclic, emergency loading and duration | IEC 60287/60853/Neher–McGrath relevance |
| E05 | Conduit/tray and bonding | Cable tray width/fill, barriers, spacing, cleats, EGC, raceway geometry | Installation-specific NEC/IEC gating |
| E06 | NEC checks | NEC edition and adopted AHJ rules, PV source/MPPT, ampacity, OCPD, PV stations, interconnections | Do not label screening as construction compliance |
| E07 | Short circuit and protection | Utility fault duty, transformers, protection CT/PT, breaker curves, settings, relay logic | Coordination and arc flash system model |
| E08 | MV system | Transformer impedance/taps, MV topology, feeders, switchgear, insulation, grounding, relays | Equipment-specific test/certification |
| E09 | POI power flow | Net PV generation, site load, BESS, reactive power, voltage at POI AND PV feeder | Signed import/export, three-phase kVA/current |
| E10 | POI limits | Independent export and import limits, switch/transformer/conductor/breaker ratings | 5 MW example is NOT a fixed generic project value |

### BESS, controls, uncertainty, finance and governance
| ID | Input / requirement | Recorded scope | Acceptance safeguard |
|---|---|---|---|
| B01 | BESS energy and controls | Rated kWh and kW, SOC bounds, efficiencies, initial SOC, charge/discharge limits | Load and PV hourly chronology; manufacturer PCS limits |
| B02 | BESS site load | Constant load or 24-hour UTC repeating profile, independent grid import cap | Avoid conflating AC bus with POI |
| B03 | PPC/EMS | Export/import, ramp, reactive, PF, Q(V), P(f), curtailed output, telemetry and control priority | Utility/IEEE settings and dynamic response |
| B04 | P50/P75/P90/P95/P99 | Long-term annual yields, bias shift, resource/model/availability uncertainties and correlations | Correlated uncertainty and confidence limits explicit |
| B05 | Financial | Year-1 delivered energy, CAPEX, fixed/variable O&M, PPA/tariff, escalation, degradation, discount, years | Extend to cash flows, tax, debt, tariffs as inputs permit |
| B06 | Master database | Engineering_Master_Database_Audited.xlsx with 93 worksheets | Respect source, licensing, change log and primary provenance |
| B07 | PV module catalogue | master_pv_modules.json 26,000 records and unique IDs | Do not auto-delete duplicate names, distinguish electrically different models |
| B08 | Reference models | Pinned SAM CEC Modules and 2,343 CEC inverter fitted references | Historical references are not OEM certification |
| B09 | Cross-platform validation | pvlib, NLR SAM/SSC/PySAM, PVWatts, PVsyst and HelioScope where licensed | Versioned independent numerical and live browser acceptance |
| B10 | Application quality | Responsive desktop/mobile, browser accessibility, real external data, imports/exports | Session expiration, no stale cross-module results, privacy/security |

## B. Exact deliverable/source data checks
1. Original site ID and URL unchanged; last authenticated published revision `84a9e4ffdbafb03cc0474e9e9d82ee8df5e98809`, 232 serving assets plus provider-generated `wix.config.json` in source ZIP, total 233 entries.
2. Master PV catalogue: 26,000 rows, 26,000 unique primary IDs, 6,809,617 bytes, SHA-256 `89eebca9d597ddd2361d5f81beba564fa1772857e366011e264fcba785c47f5c`. Source snapshot and current asset copy match byte hash.
3. `Engineering_Master_Database_Audited.xlsx` has 93 named worksheets. Its individual cells were not exhaustively checked against all OEM documents. Its sheet-name list is in `MASTER_DATABASE_93_SHEETS.csv`.
4. Embedded handoff media: 25 readable nested ZIP containers; 6 PDF entries and 14 image entries (including four SVG graphic/icon files); zero nested archive-read errors. One old QA PDF occurs twice in nested release packages.
5. The current website source yields 244 distinct extracted DOM/dynamic input references across 47 scanned root JavaScript/HTML files. See `LIVE_WEBSITE_INPUT_FIELD_INVENTORY.csv`. This is a static source inventory, NOT proof that every control is displayed or functional on the hosted page.
6. A historical SAM CEC module comparison covers 26,000 index entries: 8,202 exact, 236 within 2%, 58 discrepancies >2%, 12 ambiguous and 17,492 with no exact maker/model reference match. The separate 2,343 CEC/Sandia inverter fits are historical engineering curves, not current manufacturer certification.
7. Historical catalogue QA found 24,705 missing source-field strings, 69 invalid electrical STC rows, 39 anomalous STC power products, and 19 manufacturer/model name-level duplicate excess rows. The live search display groups 11 electrically identical extra rows without deleting source records; other variant name collisions remain distinct.

## C. PDFs and images physically present inside the transfer archive
**Notes:** Each archive path below is a nested chain. Items are file evidence included in the archives, not necessarily files directly uploaded by the user to this conversation.
| Type | Filename | Parent area | Occurrences |
|---|---|---|---:|
| IMAGE | `desktop_report_archived.png` | Original Cable Thermal Studio | 1 |
| IMAGE | `desktop_steady_archived.png` | Original Cable Thermal Studio | 1 |
| IMAGE | `desktop_transient_archived.png` | Original Cable Thermal Studio | 1 |
| IMAGE | `favicon.svg` | Original Cable Thermal Studio | 1 |
| IMAGE | `file.svg` | Original Cable Thermal Studio | 1 |
| IMAGE | `generated_engineering_report_archived.png` | Original Cable Thermal Studio | 1 |
| IMAGE | `globe.svg` | Original Cable Thermal Studio | 1 |
| IMAGE | `master-database-explorer.png` | Original Cable Thermal Studio | 1 |
| IMAGE | `master-database-explorer.svg` | Original Cable Thermal Studio | 1 |
| IMAGE | `mobile_report_archived.png` | Original Cable Thermal Studio | 1 |
| IMAGE | `mobile_steady_archived.png` | Original Cable Thermal Studio | 1 |
| IMAGE | `mobile_transient_archived.png` | Original Cable Thermal Studio | 1 |
| IMAGE | `thermal-review-layout.png` | Original Cable Thermal Studio | 1 |
| IMAGE | `window.svg` | Original Cable Thermal Studio | 1 |
| PDF | `Solar_Resource_Engineering_Release_v1_4_QA_Report.pdf` | Prior release v1.4/v1.5 | 2 |
| PDF | `desktop_report_archived.pdf` | Original Cable Thermal Studio | 1 |
| PDF | `generated_engineering_report_archived.pdf` | Original Cable Thermal Studio | 1 |
| PDF | `mobile_report_archived.pdf` | Original Cable Thermal Studio | 1 |
| PDF | `thermal-review-layout.pdf` | Original Cable Thermal Studio | 1 |

The exact per-archive paths, sizes, and ZIP CRC entries appear in `NESTED_TRANSFER_MEDIA_FULL_INVENTORY.csv`. The 4 SVG images in the count include favicon/file/globe/window graphic assets. The v3.6.2 `master-database-explorer.svg` is a separately listed engineering design graphic.

## D. Other relevant PDFs/images discoverable in ChatGPT Library
These are filenames located in the Library, not an assurance of original uploader, full page review, or direct linkage to this Wix application. Broader Library browsing includes many **separate Heber 2, Blue Mountain, SunDrum and other-site drawings**; those records must not be used as this application’s real-site design values.
- `Solar_Resource_Engineering_Release_v1_4_QA_Report.pdf` — Release QA; also archive duplicate.
- `Solar_Resource_Engineering_Release_v1_4_QA_Report(1).pdf` — Library copy of older release QA.
- `Solar_Resource_Site_Report_Input_Required.pdf` — Site report demonstration.
- `Solar_Resource_Site_Report_v0_2_INPUT_REQUIRED.pdf` — Site report demonstration.
- `SolarPro 3 Production Modeling.pdf` — Production modeling research.
- `Array Trackers SolarPro (June-July 2011).pdf` — Tracker layout research.
- `SolarPro  January 2009  Calculating Interrow Spacing.pdf` — Inter-row geometry research.
- `January 2009 Solar Pro Solar Site Evaluation.pdf` — Site/resource research.
- `SOLARPRO 3 Voltage Drop in PV Systems.pdf` — DC circuit wiring reference.
- `SOLARPRO 4 PV Performance Guarantees-Part 1.pdf` — Warranty and production guarantee research.
- `SOLARPRO 4 PV Performance Guarantees-Part 2.pdf` — Performance guarantee research.
- `SOLARPRO 4 Field Application for I-V Curve Tracers.pdf` — Field measurement reference.
- `PV Array Wire Management _ SolarPro Magazine.pdf` — Wiring reference.
- `Raceway Selection and Installation for PV Systems_ Part One _ SolarPro Magazine.pdf` — Raceway reference.
- `Raceway Selection and Installation for PV Systems_ Part 2 _ SolarPro Magazine.pdf` — Raceway reference.
- `SolarPro Flat Roof Mounting Systems.pdf` — Rack layout reference.
- `PV_Install_Guide-Latest_CEC.pdf` — CEC installation reference.
- `PV_Install_Guide-Latest_CEC(1).pdf` — CEC installation reference duplicate.
- `PV_Electrical_Engineering_Course_Book_V1.pdf` — Course draft.
- `PV_Electrical_Engineering_Course_Book_V2.pdf` — Course draft.
- `PV_Electrical_Engineering_Course_Book_V3.pdf` — Course draft.
- `NFPA 70 NEC 2023 National Fire Protection Association National Electrical Code(1).pdf` — NEC edition reference.
- `NFPA 70, National Electrical Code.pdf` — NEC edition reference; confirm specific edition.
- `Mike-holts-illustrated-guide-to-understanding-the-national-electrical-code-2020-Vol 1.pdf` — Secondary explanatory reference.
- `Mike Holt's Illustrated Guide to Understanding Requirements for Bonding and Grounding, 2020 NEC.pdf` — Secondary grounding reference.
- `Siemens Basics of Electrical Engineering.pdf` — Theory reference.
- `Mersen-PVPN1-Ground-Fault-Analysis.pdf` — Fault and ground-fault research.
- `Practical-guide-to-electrical-grounding.pdf` — Grounding reference.
- `Practical-guide-to-electrical-grounding(1).pdf` — Grounding reference duplicate.
- `fdocuments.in_ul1741-inverter.pdf` — Inverter standard secondary source; verify provenance and license.
- `cable-thermal-v3-2-1791570830247.jpg` — Cable thermal screenshot in separate Library folder.
- `cable-thermal-audit-1791380438913.jpg` — Cable thermal screenshot.
- `cable-thermal-studio-v3-1791366797928.jpg` — Cable thermal screenshot.
- `cable-thermal-studio-1791310869052.jpg` — Cable thermal screenshot.

## E. Unanswered technical questions / information needed
1. **Site, weather:** Which precise sites, coordinates, terrain and elevation represent real studies? **Evidence needed:** Site survey/coordinates; DEM.
2. **Site, weather:** What is each project’s required UTC/local clock convention and year range? **Evidence needed:** Weather file timezone metadata.
3. **Site, weather:** Which weather dataset is authoritative for each installation and how is it quality-controlled? **Evidence needed:** EPW/TMY measured data; station record.
4. **Site, weather:** What measured resource years or on-site reference instruments can calibrate long-term yield? **Evidence needed:** Multi-year met/GHI/DNI/DHI history.
5. **Shading/tracker:** What is the surveyed terrain, horizon, obstruction and 3D geometry? **Evidence needed:** Survey CAD/GIS/LIDAR/obstruction coordinates.
6. **Shading/tracker:** Which actual trackers and fixed-rack OEM geometry, operating limits and stow strategy apply? **Evidence needed:** Tracker OEM drawings/manuals.
7. **Shading/tracker:** How are pitch, row widths, height, axis orientation, uneven terrain and cross-axis slopes specified? **Evidence needed:** Racking layout.
8. **Shading/tracker:** How are tracker backtracking, diffuse ground mask, torque tubes, row-end and electrical mismatch measured? **Evidence needed:** Field model/control details.
9. **Modules:** What exact module manufacturer, part number, date/revision and listing is installed? **Evidence needed:** Current OEM spec and safety certification.
10. **Modules:** What is the module I–V/De Soto/CEC parameter provenance and serial/temperature coefficients? **Evidence needed:** OEM I–V curves/test reports.
11. **Modules:** Are module-level optimizers installed; if yes, which models, placement and limits? **Evidence needed:** OEM optimiser/inverter compatibility docs.
12. **Database:** How should the 58 STC discrepancies and 12 ambiguous SAM identity matches be adjudicated? **Evidence needed:** Exact current primary OEM document/revision.
13. **Database:** What primary records substantiate 17,492 entries without exact SAM identity matches? **Evidence needed:** OEM sources and original row history.
14. **Database:** Are 69 invalid electrical rows corrections, obsolete SKUs or intentionally unqualified entries? **Evidence needed:** Vendor documentation and revision.
15. **Inverter:** Which exact inverter variants, count, MPPT allocations, limits and actual PQ envelopes apply? **Evidence needed:** Current OEM manual, certifications and commissioning settings.
16. **Inverter:** Is historical CEC/Sandia fitted efficiency appropriate for the selected inverter or must it be recalibrated? **Evidence needed:** OEM curves or measured data.
17. **Energy yield:** Which year and weather scenarios should be treated as benchmark for pvlib/SSC/PySAM? **Evidence needed:** Identical model inputs/reference runs.
18. **Energy yield:** What detailed IAM, spectral, snow, soiling, degradation, availability, clipping and curtailment evidence applies? **Evidence needed:** O&M history/project guarantee.
19. **Energy yield:** What plant auxiliary load and transformer load/no-load losses are actual? **Evidence needed:** Transformer report, aux profile.
20. **Cables:** What are all run lengths, conductor types, sizes, number of circuits, phases and routing topologies? **Evidence needed:** SLD/conduit/cable schedule.
21. **Cables:** What are conductor termination temperatures, installed correction factors and actual insulation ratings? **Evidence needed:** Cable/OEM termination schedules.
22. **Cables:** What are soil resistivity, depth, spacing, duct/raceway backfill and seasonal soil temperatures? **Evidence needed:** Geotechnical thermal study.
23. **Cables:** What emergency duration, initial temp and thermal RC parameters apply? **Evidence needed:** Cable OEM and grid demand profile.
24. **Cables:** How should the older Cable Thermal Studio private source be handled in publicly served assets? **Evidence needed:** Disclosure/licensing review.
25. **Electrical:** Which AHJ NEC edition and jurisdictions govern each design? **Evidence needed:** AHJ adopted code and utility manual.
26. **Electrical:** What are utility short-circuit contributions, X/R, grounding and operating configurations? **Evidence needed:** Utility short-circuit letter and relay drawings.
27. **Electrical:** What are transformer ratings/impedances/taps, switchgear, CT/PT, relays, OCPD and SCCR/AIC? **Evidence needed:** Approved nameplates/submittals.
28. **Electrical:** What is the final POI voltage, transformer placement and exact PV feeder voltage? **Evidence needed:** Approved SLD and meter location.
29. **Grid:** What independent real export AND import power/current limits apply at POI and other bus sections? **Evidence needed:** Executed interconnection agreement.
30. **Grid:** Which actual PPC/EMS controls enforce setpoints and how is failure handled? **Evidence needed:** Functional design/IO map.
31. **Grid:** What reactive-power, ramp-rate, Volt-VAR, frequency and communication requirements apply? **Evidence needed:** Grid code and utility requirements.
32. **BESS:** What exact battery/PCS units, SOC/rate/thermal bounds, warranty and round-trip test data apply? **Evidence needed:** OEM BESS PCS datasheets/manuals.
33. **BESS:** Are there hourly site loads, tariffs, demand charges, seasonal usage and grid-charging permissions? **Evidence needed:** Meter interval data and tariff.
34. **BESS:** Are BMS interlocks, standby losses, cycle aging and availability data available? **Evidence needed:** OEM warranty and control documentation.
35. **Pxx:** What long-term correlated weather/yield uncertainty distributions are supported by measurements? **Evidence needed:** Long-run simulations, met calibration and covariance evidence.
36. **Finance:** What are project CAPEX and detailed OPEX, energy price, incentives, taxes, financing, escalation and life? **Evidence needed:** Cost model, contracts and rates.
37. **Finance:** Which scenario represents energy exported vs energy self-consumed and how is revenue settled? **Evidence needed:** PPA/retail net-metering arrangement.
38. **Software:** Can the publicly hosted site be acceptance-tested in a browser with live PVGIS and weather endpoints? **Evidence needed:** Browser access/network and external APIs.
39. **Software:** What private Git/source-control repository and backup policy will ensure recovery beyond public Wix assets? **Evidence needed:** Private Git permissions and backup policy.
40. **Software:** Does the 24-hour browser-storage expiry hold under refresh, closure, offline use and crash recovery? **Evidence needed:** Automated browser privacy acceptance tests.
41. **Software:** Which full PVsyst/HelioScope/SAM parity targets and tolerances will constitute acceptance? **Evidence needed:** Reference project files and versioned benchmark cases.

## F. The 22 documented studies/calculator areas
- **PV-001 — Weather:** 8760/8784 hourly TMY and historical normalization. **Information needed:** Timestamp convention, GHI/DNI/DHI, T/W, site survey. **Acceptance check:** Independent pvlib/SPA comparison + real EPW regression.
- **PV-002 — Irradiance:** Perez family, IAM, albedo variation. **Information needed:** Airmass, sky diffuse, orientation, ground albedo. **Acceptance check:** Daily/hourly model parity, closure and spectral corrections.
- **PV-003 — Tracking:** SAT, axis tilt/azimuth, mechanical bounds, slope aware backtracking. **Information needed:** Tracker geometry/GCR/cross-axis slope/rotation limits. **Acceptance check:** pvlib tracking angle benchmark on flat and sloped terrain.
- **PV-004 — Bifacial:** Rear irradiance and torque tube occlusion. **Information needed:** bifaciality, albedo, row spacing, elevation, geometry. **Acceptance check:** view-factor vs field/raytracing benchmark.
- **PV-005 — Obstruction shade:** 3D projected boxes with row/horizon beam mask. **Information needed:** Survey obstacle model, module polygon, horizon. **Acceptance check:** Shadow shape and energy field / raytracing cross-check.
- **PV-006 — Electrical shade:** Substring bypass diode and string/MPPT mismatch. **Information needed:** Cell/submodule topology, bypass diode behavior, string wiring. **Acceptance check:** I-V/shade distribution module/substring benchmark.
- **PV-007 — Single diode:** De Soto parameter scaling and stable I-V solve. **Information needed:** ILref I0ref Rs Rsh a, gamma/alpha/I-V measurements. **Acceptance check:** Direct pvlib match + OEM fitted I-V curves.
- **PV-008 — Module qualification:** OEM module STC, coeffs, topology, version control. **Information needed:** OEM exact part/revision/date, test curves, certification. **Acceptance check:** Full manufacturer's current revision, listing, curve fit.
- **PV-009 — String/MPPT:** Cold/hot voltage, current, module strings. **Information needed:** OEM voltage/current constraints & design temperatures. **Acceptance check:** Actual module+inverter curves and ambient worst-case.
- **PV-010 — Inverter:** Part-load / DC-voltage efficiency, AC clipping, reactive power. **Information needed:** DC input range, MPPT, efficiency coefficients, Pac/PQ curve. **Acceptance check:** Compare Sandia/CEC efficiency map with measured OEM.
- **PV-011 — Thermal:** Cell temp Faiman/SAPM/Fuentes and transient behavior. **Information needed:** Module mounting, cell sensor, wind reference height. **Acceptance check:** Measured/integrated model validation vs OEM mounting.
- **PV-012 — DC losses:** Current-dependent cable I2R, temperature and mismatch. **Information needed:** Conductor material, size, length, temp, installation. **Acceptance check:** Compare wire resistance and loss across currents.
- **PV-013 — AC/transformer:** AC losses, reactive power and auxiliary load. **Information needed:** Transformer no-load/core/load curve, PF, voltage. **Acceptance check:** Measured transformer no-load/load and POI power.
- **PV-014 — NEC PV source:** 690.7/690.8/690.9 ampacity & OCPD. **Information needed:** Ambient Tmin, current, conductors, terminals, OCPD. **Acceptance check:** AHJ adopted edition, complete 690.7/690.8/690.9 gate.
- **PV-015 — NEC Large PV:** 691 station applicability and engineered approval. **Information needed:** Inverter nameplate, MV connection, access, monitor. **Acceptance check:** Station criteria and PE/AHJ review.
- **PV-016 — NEC Interconnection:** 705.28 and EMS-based circuit current. **Information needed:** EMS implementation, ratings, system types. **Acceptance check:** Qualified EMS and 705 ampacity model.
- **PV-017 — Yield:** 8760/8784 DC AC POI with detailed loss chain. **Information needed:** Hourly weather + qualified modules/inverters/network. **Acceptance check:** Manufacturer verified equipment, PVWatts & SAM parity.
- **PV-018 — Resource risk:** Long-run P50/P75/P90 and bankability uncertainty. **Information needed:** Multi-decade weather, ground measurement, error sources. **Acceptance check:** Long-term calibrated resource, uncertainties and correlation.
- **PV-019 — BESS:** Charge/discharge SOC, dispatch, cycle aging. **Information needed:** OEM SOC bounds, curve efficiency, EMS control. **Acceptance check:** Energy balance/dispatch constraints/battery limits.
- **PV-020 — Grid controls:** Curtailment, reactive power, AC POI, zero-export. **Information needed:** Utility POI limits, PPC, EMS, inverter capability. **Acceptance check:** Time-domain PPC response and control constraints.
- **PV-021 — Financial:** LCOE/NPV/IRR, capacity and TOU optimization. **Information needed:** CAPEX, OPEX, tariffs, fiscal assumptions. **Acceptance check:** Scenario finance and cash-flow regression.
- **PV-022 — Audit/UX:** Single integrated multi-engine project UI. **Information needed:** Unified data schema and separate versioned models. **Acceptance check:** Responsive and privacy/performance regression.

## G. Extra integrated studies available with these same input categories
1. Site meteorological data reconstruction and weather normalization.
2. Solar position, sunrise, beam and diffuse POA closure.
3. Fixed-vs-tracker energy and optimum GCR/row pitch.
4. Near-object 3D shading and horizon loss map.
5. Bifacial rear-ground view factors and albedo sensitivity.
6. Submodule diode/bypass shade and string IV/PV curves.
7. String/MPPT current/voltage/OEM envelope comparison.
8. Per-string DC wiring losses and cable thermal ampacity.
9. AC and MV conductor losses and transformer/PQ constraints.
10. Short-circuit, relay coordination, protection and arc-flash studies.
11. Grounding and touch/step potential studies.
12. Cable tray fill, support spacing, cleat and EGC studies.
13. POI simultaneous import/export/reactive current thermal loading.
14. Grid-forming/following and PPC EMS controls/dynamic dispatch.
15. BESS peak shaving/self-consumption, cycle aging and tariffs.
16. Hourly 8,760/8,784 energy-balance and loss waterfall.
17. P50/P75/P90/P95/P99 and uncertainty correlation sensitivity.
18. LCOE, IRR, NPV, payback, debt/tax and tariff scenarios.
19. IEC/NEC jurisdiction-specific compliance screening and exceptions.
20. Manufacturer specification/data provenance reconciliation.
21. UI/browser/privacy/24h expiry and download-report consistency testing.
22. Benchmark comparison against pvlib, SSC/PySAM and licensed PVsyst/HelioScope scenarios.

## H. Three verification passes — actual evidence
### CHECK_1_ARCHIVE_AND_NESTED_FILE_INVENTORY
- archive_crc_no_error: `True`
- archive_entries: `233`
- live_asset_entries_excluding_generated_config: `232`
- nested_archive_count: `25`
- embedded_pdf_entries: `6`
- embedded_image_entries_including_svg: `14`
- nested_archive_read_errors: `0`
### CHECK_2_DATABASE_PROVENANCE_AND_USER_TEXT
- catalogue_records: `26000`
- unique_catalogue_ids: `26000`
- catalogue_sha256: `89eebca9d597ddd2361d5f81beba564fa1772857e366011e264fcba785c47f5c`
- catalogue_shas_match_oct25_transfer: `True`
- workbook_worksheets: `93`
- feature_matrix_studies: `22`
### CHECK_3_FORM_AND_DELIVERED_SOURCE
- active_js_and_html_scanned: `47`
- source_ui_control_mentions_and_dynamic_fields: `244`
- source_only_demo_defaults_never_labeled_user_site_values: `True`
- generated_config_not_a_serving_asset: `True`
- reserved_live_deployment_revision: `84a9e4ffdbafb03cc0474e9e9d82ee8df5e98809`
### SCOPE_WARNING
Complete only for readable handoff + current developer source + explicitly listed Library references; historical unmounted screenshots and absent manufacturer originals cannot be inventorially certified.

## I. Source-control and memory consistency rule
This document is the consolidated, corrected project working register. UI demonstration defaults (e.g., 5,000 kW PV, 12,470 V bus, 25° tilt, 28.6139° location, battery 50 kWh, and synthetic weather/Pxx history) are model examples, **not values supplied for a real installation**. Always distinguish real uploaded evidence, project-wide required behaviour, actual verified source data, reference study examples, and still-unknown site parameters. Do not import unrelated project measurements.

The report is preserved for future sessions in the project Library folder. The assistant cannot directly rewrite the account-wide Memory summary from this conversation; any Memory summary change should be requested from Settings → Personalization → Memory summary → Manage.
