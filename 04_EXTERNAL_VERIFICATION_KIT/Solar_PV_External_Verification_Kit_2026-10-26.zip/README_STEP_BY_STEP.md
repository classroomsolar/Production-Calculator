# Solar PV Engineering Platform — complete external verification procedure
Date: 2026-10-26. Baseline: existing original Wix website, 240 serving assets, revision `1daff091e0192dd988a986888d6c191c1934b420`. Use a fresh authenticated Wix revision before any future publication. No file in this kit deploys anything.

Existing website: https://headless-spqwsttbeuf-classroomsolar-140e.wix-site-host.com/

## FIRST: preserve a repeatable test case
1. Keep the previous `Solar_PV_Engineering_240_Asset_Current_Source_2026-10-26.zip` and `Solar_PV_Engineering_240_Asset_Reproducible_QA_2026-10-26.zip` in a safe read-only location. Do not overwrite Wix with them.
2. Choose a **real named study case** with one site, one year, one weather dataset, one exact module revision, inverter, strings, tracker, cable, transformer and POI configuration. Mark anything synthetic.
3. On the published site, in *Hourly weather* choose `Upload standardized hourly CSV` or EPW, upload the same weather case you will use in SAM, then click `Run resource analysis`.
4. In the Detailed PV v1.7 panel set every relevant five-parameter module, topology, inverter, loss, cable and transformer field. Click `Compute independently screened hourly physics`. Download **Detailed hourly CSV** (`pv_detailed_v17_EXPERIMENTAL_hourly.csv`) and **Audit JSON**; the latter has assumptions and annual totals but currently does *not* export every detailed input parameter. Make and retain a separate `case_config.json` containing those displayed values; the bundled `case_config_EXAMPLE_ONLY.json` shows all keys. **Do not silently use its example values as actual site specifications.**
5. Also retain: downloaded input weather CSV/EPW, SAM weather CSV, the site study location/UTC offsets, all OEM datasheets, and a manifest with software versions and SHA256s. Normalize differing weather timestamp conventions BEFORE comparing.

## PART A — installed pvlib + PySAM and annual benchmark

### Step A1. Install an unrestricted Python environment

Windows PowerShell:
```
py -3.11 -m venv solar-validation
.\solar-validation\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
```
macOS/Linux:
```
python3.11 -m venv solar-validation
source solar-validation/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
```
Official pvlib: https://pvlib-python.readthedocs.io/en/stable/user_guide/getting_started/installation.html
Official PySAM: https://nlr-pysam.readthedocs.io/en/latest/installation.html . PySAM 8+ is `nlr-pysam` (older installations used `nrel-pysam`), never the unrelated genomics package `pysam`.

If package downloads are blocked here but your **other** computer can access PyPI: run on that computer:
```
python -m pip download -r requirements.txt -d wheels
```
Copy the `wheels/` folder to the machine with matching Python/platform, then:
```
python -m pip install --no-index --find-links=wheels -r requirements.txt
```
Otherwise run in an approved, networked development environment or CI runner. This does NOT require exposing your Wix credentials.

### Step A2. Compare like-for-like pvlib 5-parameter electrical physics
```
python scripts/run_pvlib_reference.py \
  --platform-hourly pv_detailed_v17_EXPERIMENTAL_hourly.csv \
  --config case_config.json \
  --output pvlib_electrical_reference.csv
```
This uses *actual installed* pvlib De Soto + Lam­bert-W single-diode and PVWatts inverter; it checks 8,760/8,784 original hours and excludes MPPT-constrained hours from unbounded module-MPP comparisons. Any nonphysical model envelope breach must be corrected instead of averaged away. It is not an independent POA/weather engine benchmark: the irradiance and temperature are the platform's identical inputs. Before signoff, separately compare irradiance-transposition/solar geometry using `pvlib.solarposition` and `pvlib.irradiance.get_total_irradiance` on identical timestamps, angles and diffuse model (isotropic/haydavies differences must not be conflated).

### Step A3. Run real SAM / PySAM
Use the official SAM desktop program to make the **same** site/weather/system case. For a rapid secondary check, create PVWatts V8 (`Pvwattsv8`), and in the SAM case use **Case → Generate Code → PySAM JSON**. SAM documentation specifically recommends code generation for detailed SSC cases because of their many variables. In SAM ensure the same hour/calendar, weather, geometry, albedo, module size, DC/AC ratio, inverter efficiency and loss assumptions. Check that SAM CSV's local standard times are correctly aligned to the platform's UTC timestamps; **never assume a row number implies the same hour**.

Optional quick PVWatts V8 secondary reference, *only after checking time alignment*:
```
python scripts/run_pysam_pvwatts.py \
  --sam-weather SAME_CASE_SAM_WEATHER.csv \
  --timestamps pv_detailed_v17_EXPERIMENTAL_hourly.csv \
  --system-capacity-kw YOUR_DC_KW --dc-ac-ratio YOUR_RATIO \
  --tilt YOUR_TILT --azimuth YOUR_AZIMUTH \
  --losses-pct YOUR_MATCHED_LOSS --array-type 0 \
  --inverter-efficiency-pct YOUR_PERCENT \
  --time-alignment-confirmed \
  --output pysam_pvwatts_reference.csv
```
Set `--array-type 2` for single-axis tracking, `3` for backtracking, using the official PVWatts definitions; other geometry/thermal/bifacial options must also match. `--timestamps` is used to label output rows and does NOT independently prove weather chronology. PVWatts is a **different model** from your five-parameter v1.7 and cannot by itself establish exact matching. For true Detailed PV equivalence, create an SSC **Pvsamv1** case in SAM with calibrated module, inverter, tracker, bifacial, losses, grid/transformer settings and run its generated PySAM code.

### Step A4. Quantitative hourly and annual reconciliation
For **like-for-like stage outputs only**, standardize reference headers to `timestamp_utc,ac_inverter_kw` (kW each hourly interval); do not re-label a different physical quantity merely to obtain a passing test. Then:
```
python scripts/compare_hourly.py --platform pv_detailed_v17_EXPERIMENTAL_hourly.csv \
  --reference MATCHED_REFERENCE.csv \
  --platform-column ac_inverter_kw --reference-column ac_inverter_kw \
  --output hourly_comparison.json
```
The script refuses mismatched timestamps, missing hours, NaNs and leap-year errors; reports annual energy, monthly energy, bias, RMSE and worst ten hourly errors. A provisional development target (NOT a universal certification standard) is <=2% annual stage energy deviation **only for matched models**, with every systematic monthly or extreme-hour difference explained; actual acceptable tolerances depend on physical model and inputs. Run deliberately broken test cases (night, cold Voc, clipping, high GCR/bifacial, full curtailment, night transformer import, leap year), not only one easy year.

**Acceptance:** real installed software version recorded; identical site/weather/geometry; all hourly timestamps reconciled; quantified stage-wise differences; final report lists reasons for every failed/blocked model case. A PVWatts-only comparison is a secondary check, not Detailed PV equivalence.

## PART B — full 26,000 record OEM document qualification

### Step B1. Start from the full, intact register
The separate release delivered `Equipment_Full_26000_Row_Qualification_Register_2026-10-26.csv`: 26,000 records, 26,000 unique catalogue IDs. This kit does not change the canonical `master_pv_modules.json`. The inherited register has 24,705 blank source fields, 1,159 internal/nonexternal references, and only 136 source fields containing candidate URLs. A candidate URL does **not** prove a matched manufacturer datasheet.

### Step B2. Acquire exact OEM documentation, not just model name
For every OEM/model/revision you intend to qualify:
- OEM-hosted original PDF technical datasheet (not a marketplace transcription).
- Exact model string, wattage bin, product suffix, market variant and revision date.
- Electrical STC values (Pmp, Voc, Vmp, Isc, Imp), temperature coefficients, operating limits, module dimensions and bifacial data if applicable.
- Type-safety/testing certificates and current regulatory/utility listings **where applicable**.
- The document's SHA-256, source URL, retrieval date and reviewer initials. If the official OEM document is unavailable, mark unresolved. Never invent URLs or model variants.

Priority order: (1) actually selected project models; (2) 69 invalid STC rows; (3) 39 other substantial product-power inconsistencies, with overlaps resolved by ID; (4) 58 historical SAM disagreements/12 ambiguous identities; (5) remaining source-missing rows. Do not approve a model merely because it appears on the CEC list: the CEC says manufacturer self-reported data are not independently confirmed.

### Step B3. Use the supplied evidence template
Fill `oem_evidence_template.csv` with one row per `Catalogue ID`. Reviewer explicitly records manufacturer match, exact suffix/revision and all six STC values as YES/NO; include OEM PDF source, its SHA-256, reviewer and review date. Do not manually edit source rows in the canonical JSON. Run:
```
python scripts/catalogue_evidence_gate.py \
  --catalogue Equipment_Full_26000_Row_Qualification_Register_2026-10-26.csv \
  --evidence oem_evidence_template.csv \
  --output qualification_decisions.csv
```
The script keeps unreviewed records NOT QUALIFIED, including those with source URLs. `OEM_EVIDENCE_REVIEWED_STC_ONLY` means a human documented an exact STC match — **not** IEC, UL, complete SDM calibration, warranty or site approval.

### Step B4. Stage your catalog without deleting history
Use separate layers:
1. `RAW_SOURCE` (immutable original 26k records)
2. `OEM_STC_REVIEWED` (original document, exact variant and reviewer)
3. `SIMULATION_READY` (valid diode fit, temperature, bifacial coefficients and solver checks)
4. `PROJECT_ENGINEERING_ACCEPTED` (project-specific OEM limits, PE/AHJ review where required)
Keep both active and archived/obsolete variants with source version tags; enforce a review queue instead of applying unsourced guesses. A genuine sign-off of the entire historic 26k record set is impossible if source documentation cannot be recovered; explicitly label such entries **unverified** rather than deleting them or falsely passing them.

**Acceptance:** 26k IDs preserved; every record has a clear evidence status, source URL/reference/receipt, reviewer and date, and 0 falsely qualified entries. For project-ready calculations, all **selected project equipment** must be at the required qualification tier. The historic catalogue as a whole may continue containing unverified entries.

## PART C — live public-browser acceptance

### Step C1. Install Playwright on a computer allowed to reach Wix
```
python -m pip install playwright
python -m playwright install chromium
```
Official reference: https://playwright.dev/python/docs/intro

### Step C2. Run actual public-site smoke tests
```
python scripts/browser_acceptance.py --output browser_acceptance.json
```
The script opens the **actual public URL**, separately at 1440×900 and 390×844, checks that core controls render, manufacturer search responds, Detailed PV module loads, missing JS/CSS assets, and uncaught JavaScript exceptions. It captures screenshot evidence. A blocked URL is **FAILED/BLOCKED**: a Wix publish/readback response or local source-render test cannot be substituted.

### Step C3. Test resource analysis and actual files using real site weather
With a suitable complete hourly CSV (columns `timestamp_utc,ghi_wm2,dni_wm2,dhi_wm2,temp_air_c,wind_speed_mps`, one row per UTC hour):
```
python scripts/browser_acceptance.py --weather-csv VALIDATED_INPUT_WEATHER.csv \
  --output browser_acceptance_with_weather.json
```
The script uploads the supplied weather, runs the real site calculator and checks it actually downloads hourly CSV. Then do authenticated manual/automated business acceptance for each dynamic calculator: PV Detail, tracker, bifacial, electrical, thermal, POI, BESS, Pxx, finance, full catalog export; compare exported totals with on-screen totals, probe invalid inputs and upstream invalidation, and test printing to PDF, mobile layout, browser refresh/24-hour session-clear, weather API failure handling and use of backup/restore paths. Test browser Chrome, Edge and Firefox where supported.

### Step C4. Diagnose blocked API calls separately
Check Browser Developer Tools → Network. For failed requests distinguish DNS, CORS, 401/403, 429 rate limits, HTTP 5xx, and bad response formats. Repair the actual cause: permitted HTTPS endpoint, authorized key only in server-side code, API quota/timeout, resilient source selection or a documented fallback. Never conceal a failing weather request behind synthetic values labelled as actual data.

**Acceptance:** browser automation actually visited the public URL; all required critical workflows passed on desktop/mobile; 0 uncaught app errors or missing required scripts; API status and downloads captured; all findings tracked and resolved. Only then sign the public-site browser acceptance report.

## PART D — final release guard
1. Compare the latest authenticated live Wix revision with the development baseline. Never publish a complete old archive over the newer site.
2. Patch changed files only. Before patch, save authenticated exact original files in `release-backups/<release>/` and a manifest with original SHA-256, inputs, tests and test software versions.
3. Publish only after the full regression pack plus newly corrected tests pass. Read every changed file back from Wix and verify its digest.
4. Retest the PUBLIC URL after publishing; do not count local rendering as public acceptance.
5. Archive source, test logs, weather input and response provenance, comparison report, OEM evidence index, browser traces/screenshots and rollback manifest.

### Evidence you cannot manufacture
The installation needs an internet-accessible approved environment; manufacturer verification needs genuine exact-model OEM documents; a real project yield needs the site, weather and plant inputs; public browser acceptance requires a networked browser. Source-level or synthetic tests cannot ethically replace those.
