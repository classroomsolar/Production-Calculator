import argparse,json,sys,datetime
from pathlib import Path
from playwright.sync_api import sync_playwright
URL='https://headless-spqwsttbeuf-classroomsolar-140e.wix-site-host.com/'
def main():
 p=argparse.ArgumentParser();p.add_argument('--output',default='browser_acceptance.json');p.add_argument('--weather-csv');a=p.parse_args()
 evidence=Path(a.output).resolve().parent/'browser_evidence';evidence.mkdir(exist_ok=True,parents=True)
 out={'site':URL,'runUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'screens':{},'overall':'FAILED_OR_BLOCKED'}
 with sync_playwright() as pw:
  browser=pw.chromium.launch(headless=True)
  for label,width,height in [('desktop',1440,900),('mobile',390,844)]:
   context=browser.new_context(viewport={'width':width,'height':height},accept_downloads=True,ignore_https_errors=False)
   page=context.new_page();errs=[];failrequests=[]
   page.on('pageerror',lambda e:errs.append(str(e)))
   page.on('requestfailed',lambda req:failrequests.append(req.url+' '+str(req.failure)))
   entry={'status':'PENDING','pageErrors':errs,'failedRequests':failrequests}
   try:
    response=page.goto(URL,wait_until='domcontentloaded',timeout=45000)
    page.locator('#project').wait_for(timeout=30000)
    page.locator('#pv17-run').wait_for(timeout=30000)
    page.locator('#source').wait_for(timeout=30000)
    entry['httpStatus']=response.status if response else None
    entry['projectEditable']=page.locator('#project').is_editable()
    entry['pvDetailedPresent']=page.locator('#pv17-run').count()==1
    entry['catalogExportPresent']=page.locator('button').filter(has_text='CSV').count()>0
    if a.weather_csv:
     page.locator('#source').select_option('csv')
     page.locator('#csv').set_input_files(a.weather_csv)
     run=page.locator('#run')
     if run.count():
      run.click();page.wait_for_timeout(8000)
     else:entry['weatherFlow']='WEATHER_UPLOADED_BUT_RUN_BUTTON_NOT_DETECTED'
    page.screenshot(path=str(evidence/f'{label}.png'),full_page=True)
    entry['status']='PASS' if entry['httpStatus']==200 and entry['projectEditable'] and entry['pvDetailedPresent'] and not errs else 'FAIL'
   except Exception as e:
    entry['status']='BLOCKED_OR_FAIL';entry['reason']=str(e)[:800]
   out['screens'][label]=entry
   context.close()
  browser.close()
 out['overall']='PASS_BASIC_SMOKE_ONLY' if all(x['status']=='PASS' for x in out['screens'].values()) else 'FAILED_OR_BLOCKED'
 Path(a.output).write_text(json.dumps(out,indent=2));print(json.dumps({'overall':out['overall'],'screens':{k:v['status'] for k,v in out['screens'].items()},'output':a.output}))
 if out['overall'].startswith('FAILED'):sys.exit(2)
if __name__=='__main__':main()
