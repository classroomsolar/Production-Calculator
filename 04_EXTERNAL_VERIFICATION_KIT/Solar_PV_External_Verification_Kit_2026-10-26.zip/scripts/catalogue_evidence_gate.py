import argparse, csv, hashlib, json, re, sys
from pathlib import Path

def norm(s):return (s or '').strip().lower() in ('yes','y','true','1')
def main():
 p=argparse.ArgumentParser();p.add_argument('--catalogue',required=True);p.add_argument('--evidence',required=True);p.add_argument('--output',default='qualification_decisions.csv');a=p.parse_args()
 with open(a.catalogue,encoding='utf-8-sig',newline='') as f: cat=list(csv.DictReader(f))
 with open(a.evidence,encoding='utf-8-sig',newline='') as f: ev=list(csv.DictReader(f))
 key='Catalogue ID'; known={r[key] for r in cat}
 if len(cat)!=26000 or len(known)!=26000:raise ValueError('Expected 26000 unique canonical IDs, do not approve partial catalogue')
 docs={}
 for e in ev:
  i=e.get(key,'').strip()
  if not i:continue
  if i not in known or i in docs:raise ValueError('Unknown or duplicate evidence Catalogue ID: '+i)
  docs[i]=e
 checks=['Verified manufacturer','Verified exact model','Verified six STC values']
 rows=[];approved=0
 for x in cat:
  i=x[key];e=docs.get(i,{})
  sh=e.get('OEM document SHA256','').strip().lower();hashgood=bool(re.fullmatch(r'[0-9a-f]{64}',sh))
  evidenceComplete=all(norm(e.get(z)) for z in checks) and hashgood and all(e.get(z,'').strip() for z in ['OEM PDF URL','OEM document version','Independent reviewer','Review date'])
  stcValid=x.get('STC structural validity','').lower()=='true'
  status='OEM_EVIDENCE_REVIEWED_STC_ONLY' if evidenceComplete and stcValid else 'NOT_QUALIFIED'
  if status!='NOT_QUALIFIED':approved+=1
  rows.append({key:i,'Manufacturer':x.get('Manufacturer',''),'Model':x.get('Model',''),'status':status,
   'OEM_PDF_URL':e.get('OEM PDF URL',''),'OEM_document_SHA256':sh,'Reviewer':e.get('Independent reviewer',''),
   'Reason':'' if status!='NOT_QUALIFIED' else ('NO_EXACT_DOCUMENTED_OEM_REVIEW' if not evidenceComplete else 'INVALID_SOURCE_STC')})
 with open(a.output,'w',newline='',encoding='utf-8')as f:
  w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
 print(json.dumps({'catalogue':len(rows),'evidenceRows':len(docs),'stcOnlyReviewed':approved,'notQualified':len(rows)-approved,'output':a.output}))
if __name__=='__main__':
 try:main()
 except Exception as e:print('FAILED:',str(e),file=sys.stderr);sys.exit(2)
