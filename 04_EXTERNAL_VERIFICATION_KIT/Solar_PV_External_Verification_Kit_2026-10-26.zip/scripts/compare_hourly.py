import argparse, json, sys
import numpy as np, pandas as pd

def load(p, col):
    df=pd.read_csv(p)
    if 'timestamp_utc' not in df or col not in df: raise ValueError(f'{p} needs timestamp_utc and {col}')
    raw=df['timestamp_utc']
    ts=pd.to_datetime(raw,utc=True,errors='raise')
    if ts.isna().any() or ts.duplicated().any():raise ValueError('Null/duplicate timestamp')
    if len(ts) not in (8760,8784): raise ValueError(f'Expected 8760/8784 hours, found {len(ts)}')
    if not ts.is_monotonic_increasing or not (ts.diff().iloc[1:]==pd.Timedelta(hours=1)).all():raise ValueError('Hourly data missing or not ordered')
    if ts.dt.year.nunique()!=1 or ts.dt.year.iloc[0]!=ts.dt.year.iloc[-1]:raise ValueError('UTC series spans more than one calendar year')
    vals=pd.to_numeric(df[col],errors='raise').to_numpy(float)
    if not np.isfinite(vals).all():raise ValueError(f'Missing/non-finite values: {col}')
    return pd.Series(vals,index=pd.DatetimeIndex(ts))

def main():
    p=argparse.ArgumentParser();p.add_argument('--platform',required=True);p.add_argument('--reference',required=True)
    p.add_argument('--platform-column',required=True);p.add_argument('--reference-column',required=True);p.add_argument('--output',default='hourly_comparison.json');a=p.parse_args()
    x=load(a.platform,a.platform_column);y=load(a.reference,a.reference_column)
    if not x.index.equals(y.index):raise ValueError('Timestamp mismatch between platform/reference — not reordering silently')
    d=x-y; err=(d/(y.abs().clip(lower=1e-9))).abs()
    annualPlatform=float(x.sum()); annualRef=float(y.sum()); bias=(annualPlatform-annualRef)/max(abs(annualRef),1e-9)*100
    months=[]
    for month in range(1,13):
        k=x.index.month==month; xp=float(x[k].sum());yp=float(y[k].sum());months.append({'month':month,'platform_kwh':xp,'reference_kwh':yp,'bias_pct':100*(xp-yp)/max(abs(yp),1e-9)})
    inds=np.argsort(-np.abs(d.to_numpy()))[:10]
    out={'status':'COMPARED_NOT_AUTOMATICALLY_APPROVED','hourCount':len(x),'annualPlatformKWh':annualPlatform,'annualReferenceKWh':annualRef,
        'annualBiasPct':bias,'hourlyRmseKw':float(np.sqrt(np.mean(d.to_numpy()**2))),'hourlyMaeKw':float(np.mean(np.abs(d))),
        'maxHourlyAbsKw':float(np.max(np.abs(d))),'monthly':months,
        'topHourlyDifferences':[{'timestamp_utc':x.index[i].isoformat(),'platform_kw':float(x.iloc[i]),'reference_kw':float(y.iloc[i]),'difference_kw':float(d.iloc[i])}for i in inds]}
    open(a.output,'w').write(json.dumps(out,indent=2));print(json.dumps({k:v for k,v in out.items() if k not in ('monthly','topHourlyDifferences')}))
if __name__=='__main__':
 try:main()
 except Exception as e:print('FAILED:',str(e),file=sys.stderr);sys.exit(2)
