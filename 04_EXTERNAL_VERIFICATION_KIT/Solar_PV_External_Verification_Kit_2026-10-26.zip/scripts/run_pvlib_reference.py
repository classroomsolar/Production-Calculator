import argparse,json,sys
import numpy as np,pandas as pd

def main():
 p=argparse.ArgumentParser();p.add_argument('--platform-hourly',required=True);p.add_argument('--config',required=True);p.add_argument('--output',default='pvlib_electrical_reference.csv');a=p.parse_args()
 import pvlib
 df=pd.read_csv(a.platform_hourly)
 cols=['timestamp_utc','effective_irradiance_wm2','cell_temp_c','module_dc_kw','inverter_dc_kw','ac_inverter_kw','mppt_voltage_constrained']
 if any(x not in df for x in cols): raise ValueError('Detailed PV hourly export missing required columns')
 ts=pd.to_datetime(df.timestamp_utc,utc=True,errors='raise')
 if len(df) not in (8760,8784) or ts.duplicated().any() or not (ts.diff().iloc[1:]==pd.Timedelta(hours=1)).all(): raise ValueError('Invalid hourly chronology')
 c=json.load(open(a.config));m=c['module'];q=c['array'];inv=c['inverter']
 pairs={'a_ref':'aRefV','I_L_ref':'ILrefA','I_o_ref':'I0refA','R_sh_ref':'RshRefOhm','R_s':'RsRefOhm','alpha_sc':'alphaIscAperC'}
 args={a:float(m[b]) for a,b in pairs.items()}
 params=pvlib.pvsystem.calcparams_desoto(effective_irradiance=df.effective_irradiance_wm2.to_numpy(float),
    temp_cell=df.cell_temp_c.to_numpy(float),**args,EgRef=float(m.get('EgRefEv',1.121)),dEgdT=float(m.get('dEgdTPerK',-0.0002677)))
 s=pvlib.pvsystem.singlediode(*params,method='lambertw')
 # These module-MPP values intentionally exclude voltage-constrained hours.
 total=float(q['modulesPerString'])*float(q['stringsPerMppt'])*float(q['mpptsPerInverter'])*float(q['inverterCount'])
 module_kw=np.asarray(s['p_mp'],dtype=float)*total/1000
 constrained=pd.to_numeric(df.mppt_voltage_constrained).to_numpy()!=0
 observed=df.module_dc_kw.to_numpy(float)
 diff=np.abs(module_kw[~constrained]-observed[~constrained])
 if not np.isfinite(module_kw).all():raise ValueError('pvlib produced nonfinite module outputs')
 # Inverter is matched with platform inverter-DC after cable and mismatch; no claim this independently validates those losses.
 input_w=df.inverter_dc_kw.to_numpy(float)*1000
 ac_w=pvlib.inverter.pvwatts(input_w,pdc0=float(inv['pacKW'])*float(q['inverterCount'])*1000/float(inv['etaNom']),eta_inv_nom=float(inv['etaNom']))
 out=pd.DataFrame({'timestamp_utc':df.timestamp_utc,'pvlib_module_dc_kw':module_kw,'pvlib_ac_inverter_reference_kw':ac_w/1000,
    'platform_ac_inverter_kw':df.ac_inverter_kw,'mppt_voltage_constrained':constrained.astype(int)})
 out.to_csv(a.output,index=False)
 stats={'pvlibVersion':pvlib.__version__,'nHours':len(df),'unconstrainedHours':int((~constrained).sum()),
    'maxModuleDcDifferenceKWUnconstrained':float(diff.max()) if len(diff) else None,
    'meanModuleDcDifferenceKWUnconstrained':float(diff.mean()) if len(diff) else None,
    'annualInverterAcBiasPct':float((out.pvlib_ac_inverter_reference_kw.sum()-df.ac_inverter_kw.sum())/max(abs(df.ac_inverter_kw.sum()),1e-9)*100),
    'moduleMethod':'pvlib.pvsystem.calcparams_desoto + singlediode Lambert-W',
    'inverterMethod':'pvlib.inverter.pvwatts matched platform inverter-DC input',
    'scope':'Electrical submodel only; no independent weather, horizon, IAM, full array yield or SSC annual validation'}
 open(a.output+'.summary.json','w').write(json.dumps(stats,indent=2));print(json.dumps(stats,indent=2))
if __name__=='__main__':
 try:main()
 except Exception as e:print('FAILED:',str(e),file=sys.stderr);sys.exit(2)
