import argparse,sys,json,numpy as np,pandas as pd

def main():
 p=argparse.ArgumentParser();p.add_argument('--sam-weather',required=True);p.add_argument('--timestamps',required=True)
 p.add_argument('--system-capacity-kw',required=True,type=float);p.add_argument('--dc-ac-ratio',required=True,type=float)
 p.add_argument('--tilt',required=True,type=float);p.add_argument('--azimuth',required=True,type=float)
 p.add_argument('--losses-pct',required=True,type=float);p.add_argument('--array-type',required=True,type=int)
 p.add_argument('--inverter-efficiency-pct',required=True,type=float);p.add_argument('--time-alignment-confirmed',action='store_true')
 p.add_argument('--output',default='pysam_pvwatts_reference.csv');a=p.parse_args()
 if not a.time_alignment_confirmed:raise ValueError('Explicit SAM weather time-alignment confirmation required')
 if a.system_capacity_kw<=0 or a.dc_ac_ratio<=0 or not (0<a.inverter_efficiency_pct<=100):raise ValueError('Invalid PVWatts system values')
 import PySAM.Pvwattsv8 as PV
 # Prefer official PVWatts V8 default, but always require a real SAM weather file.
 obj=PV.default('PVWattsNone');obj.SolarResource.solar_resource_file=a.sam_weather
 for key,value in {'system_capacity':a.system_capacity_kw,'dc_ac_ratio':a.dc_ac_ratio,'tilt':a.tilt,'azimuth':a.azimuth,
                   'losses':a.losses_pct,'array_type':a.array_type,'inv_eff':a.inverter_efficiency_pct}.items():
  obj.value(key,value)
 obj.execute(0)
 ac=np.asarray(obj.Outputs.ac,dtype=float)/1000
 ts=pd.read_csv(a.timestamps)['timestamp_utc']
 if len(ts)!=len(ac) or len(ac) not in(8760,8784):raise ValueError('PySAM and platform year/hour counts mismatch')
 dt=pd.to_datetime(ts,utc=True,errors='raise')
 if dt.duplicated().any() or not(dt.diff().iloc[1:]==pd.Timedelta(hours=1)).all():raise ValueError('Invalid platform timestamp chronology')
 pd.DataFrame({'timestamp_utc':ts,'ac_inverter_kw':ac}).to_csv(a.output,index=False)
 print(json.dumps({'nHours':len(ac),'pvwattsAnnualKWh':float(ac.sum()),'scope':'Independent PVWatts V8, model not the same as detailed 5-parameter; timestamp alignment externally confirmed; compare only equivalent AC boundary'}))
if __name__=='__main__':
 try:main()
 except Exception as e:print('FAILED:',str(e),file=sys.stderr);sys.exit(2)
